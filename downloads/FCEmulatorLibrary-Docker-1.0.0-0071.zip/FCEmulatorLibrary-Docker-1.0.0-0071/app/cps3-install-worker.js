"use strict";
/* Runs the WebAssembly CPS-3 installer (see cps3.js runCPS3Install) under
 * WASI in a worker thread, so the minutes-long install never blocks the
 * server's event loop. */
const fs = require("node:fs");
const { WASI } = require("node:wasi");
const { parentPort, workerData } = require("node:worker_threads");

(async () => {
  const { wasmFile, args, preopens, stdoutFile, stderrFile } = workerData;
  const stdout = fs.openSync(stdoutFile, "w");
  const stderr = fs.openSync(stderrFile, "w");
  try {
    const wasi = new WASI({ version: "preview1", args, env: {}, preopens, stdout, stderr, returnOnExit: true });
    const module = await WebAssembly.compile(fs.readFileSync(wasmFile));
    const instance = await WebAssembly.instantiate(module, { wasi_snapshot_preview1: wasi.wasiImport });
    const exitCode = wasi.start(instance);
    parentPort.postMessage({ exitCode });
  } finally {
    fs.closeSync(stdout);
    fs.closeSync(stderr);
  }
})().catch(error => parentPort.postMessage({ error: error.message || String(error) }));
