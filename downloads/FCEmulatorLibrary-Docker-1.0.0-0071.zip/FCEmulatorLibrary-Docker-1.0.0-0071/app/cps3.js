"use strict";
/*
 * Capcom CPS-3 on the library server.
 *
 * A CPS-3 game is three things the operator owns: the cartridge BIOS (the
 * MAME set zip, e.g. sfiii.zip), the game's CD (CloneCD .img) and the
 * cartridge's key pair. The server runs the CD install headlessly — the same
 * FCArcadeCoreC code the clients run, built as WebAssembly
 * (resources/cps3-install.wasm) — and publishes one FCC3PKG1 package per
 * game (BIOS, installed flash, EEPROM, CD boot stub). The key pair goes into
 * that game's manifest as emulation.cps3Key; like CPS2, only this server ever
 * reads the key table (resources/cps3-keys.json, 0600, never in a public
 * package).
 */
const crypto = require("node:crypto");
const fs = require("node:fs");
const fsp = require("node:fs/promises");
const path = require("node:path");
const { Worker } = require("node:worker_threads");
const { crc32 } = require("./lib/crc32");
const { writeJSONAtomic } = require("./lib/atomic-file");

const CPS3_BIOS_BYTES = 524288;
const CPS3_FLASH_BYTES = 2 * 1024 * 1024;
const CPS3_EEPROM_BYTES = 0x80;
const CPS3_PACKAGE_HEADER_BYTES = 44;
const CPS3_PACKAGE_EXTENSION = "fcc3";
const CD_RAW_SECTOR = 2352;
const CD_USER_DATA = 2048;
// Mode 1 CDs hold at most ~870 MB of raw sectors; anything larger is not a disc.
const MAX_CPS3_CD_BYTES = 900 * 1024 * 1024;
const INSTALL_WASM = path.join(__dirname, "resources", "cps3-install.wasm");

const CPS3_TABLE = JSON.parse(fs.readFileSync(path.join(__dirname, "resources", "cps3-drivers.json"), "utf8"));

function cps3Driver(driver) {
  const identifier = String(driver || "").toLowerCase();
  const record = CPS3_TABLE.drivers[identifier];
  if (!record) return null;
  return { driver: identifier, ...record, familyRecord: CPS3_TABLE.families[record.family] };
}

function cps3Drivers() { return Object.keys(CPS3_TABLE.drivers).map(cps3Driver); }

function cps3DriverForBIOSSHA256(sha256) {
  return cps3Drivers().find(record => record.bios.sha256 === sha256) || null;
}

/* ---- key pair ---- */

function normalizeCPS3KeyHex(value) {
  const text = String(value || "").trim();
  if (!text) return null;
  const compact = text.replace(/\s+|0x|[:,_-]/gi, "").toLowerCase();
  if (!/^[0-9a-f]{16}$/.test(compact)) throw new Error("CPS3 key 必须是 8 字节（16 个十六进制字符：key1 在前、key2 在后）。");
  return compact;
}

function rotateLeft16(value, n) { return ((value << n) | (value >>> (16 - n))) & 0xffff; }

function rotxor(value, xorValue) {
  const sum = (value + rotateLeft16(value, 2)) & 0xffff;
  return (rotateLeft16(sum, 4) ^ (sum & (value ^ xorValue))) & 0xffff;
}

/* MAME cps3.cpp cps3_mask (FCArcadeCPS3Board.c fc_arcade_cps3_crypt_mask). */
function cps3CryptMask(key1, key2, address) {
  const mixed = (address ^ key1) >>> 0;
  let value = (mixed & 0xffff) ^ 0xffff;
  value = rotxor(value, key2 & 0xffff);
  value ^= (mixed >>> 16) ^ 0xffff;
  value = rotxor(value, key2 >>> 16);
  value ^= (mixed & 0xffff) ^ (key2 & 0xffff);
  value &= 0xffff;
  return ((value << 16) | value) >>> 0;
}

/* The key decrypts the BIOS's SH-2 vector table into a plausible one: the
 * power-on and manual-reset PCs even and inside the BIOS, their stack
 * pointers inside main RAM, every other vector unused or BIOS code
 * (FCArcadeCPS3Install.c fc_arcade_cps3_key_matches_bios). */
function cps3KeyMatchesBIOS(bios, hex) {
  const key = normalizeCPS3KeyHex(hex);
  if (!key || !Buffer.isBuffer(bios) || bios.length !== CPS3_BIOS_BYTES) return false;
  const key1 = parseInt(key.slice(0, 8), 16) >>> 0;
  const key2 = parseInt(key.slice(8), 16) >>> 0;
  const vector = index => (bios.readUInt32BE(index * 4) ^ cps3CryptMask(key1, key2, index * 4)) >>> 0;
  const code = value => value >= 0x100 && value < CPS3_BIOS_BYTES && (value & 1) === 0;
  for (let index = 0; index < 4; index += 2) {
    const pc = vector(index), sp = vector(index + 1);
    if (!code(pc) || sp <= 0x02000000 || sp > 0x02080000 || (sp & 3) !== 0) return false;
  }
  for (let index = 4; index < 16; index++) {
    const value = vector(index);
    if (value !== 0 && !code(value)) return false;
  }
  return true;
}

function validateCPS3KeyForBIOS(value, bios, driver) {
  const hex = normalizeCPS3KeyHex(value);
  if (!hex) return null;
  if (!cps3KeyMatchesBIOS(bios, hex)) {
    throw new Error(`CPS3 key 解不开 ${driver} 的 BIOS 向量表：key 填错，或属于另一块卡带。`);
  }
  return hex;
}

/* ---- the server's private key table ---- */

function cps3KeyTableFile() {
  return process.env.FC_LIBRARY_CPS3_KEYS
    ? path.resolve(process.env.FC_LIBRARY_CPS3_KEYS)
    : path.join(__dirname, "resources", "cps3-keys.json");
}

async function readCPS3KeyTable() {
  try {
    const document = JSON.parse(await fsp.readFile(cps3KeyTableFile(), "utf8"));
    if (document?.schemaVersion === 1 && document?.format === "cps3-key-pair" &&
        document.keys && typeof document.keys === "object") return document;
    throw new Error("服务端 CPS3 key 表格式无效。");
  } catch (error) {
    // A public build ships without the table; the operator's own keys create it.
    if (error.code === "ENOENT") return { schemaVersion: 1, format: "cps3-key-pair", keys: {} };
    throw error;
  }
}

/* The table's key for this driver, if it opens this BIOS. A table entry that
 * does not is reported, not used: it is a wrong key, not a missing one. */
async function cps3TableKey(driver, bios) {
  const identifier = String(driver || "").toLowerCase();
  const document = await readCPS3KeyTable();
  const stored = document.keys[identifier];
  if (typeof stored !== "string") return { hex: null, status: "missing" };
  let hex;
  try { hex = normalizeCPS3KeyHex(stored); } catch { return { hex: null, status: "invalid" }; }
  if (bios && !cps3KeyMatchesBIOS(bios, hex)) return { hex: null, status: "invalid" };
  return { hex, status: "table" };
}

/* Records a key that opens `bios`; the one place the table is written. As
 * with CPS2: verified again here whatever the caller did, re-read from disk
 * rather than trusted from memory, unchanged values not rewritten, replaced
 * through a 0600 temporary file. */
async function rememberCPS3Key(driver, hex, bios) {
  const identifier = String(driver || "").toLowerCase();
  if (!cps3Driver(identifier)) throw new Error(`${driver} 不是 CPS3 驱动。`);
  const verified = validateCPS3KeyForBIOS(hex, bios, identifier);
  if (!verified) return false;
  const file = cps3KeyTableFile();
  const document = await readCPS3KeyTable();
  if (document.keys[identifier] === verified) return false;
  document.keys[identifier] = verified;
  await writeJSONAtomic(file, document, { mode: 0o600 });
  return true;
}

/* ---- uploads ---- */

/* A MAME CPS-3 set zip: one member is a cartridge BIOS we know. */
async function identifyCPS3BIOSArchive(file, { readZIPCentralDirectory, extractZIPEntry }) {
  let entries;
  try { entries = await readZIPCentralDirectory(file); } catch { return null; }
  for (const entry of entries) {
    if (entry.bytes !== CPS3_BIOS_BYTES) continue;
    const bios = await extractZIPEntry(file, entry, { maximumBytes: CPS3_BIOS_BYTES, purpose: "CPS3 BIOS" });
    const sha256 = crypto.createHash("sha256").update(bios).digest("hex");
    const record = cps3DriverForBIOSSHA256(sha256);
    if (record) return { ...record, bios, sha256 };
  }
  return null;
}

async function readRange(file, length, position) {
  const handle = await fsp.open(file, "r");
  try {
    const buffer = Buffer.alloc(length);
    const { bytesRead } = await handle.read(buffer, 0, length, position);
    return buffer.subarray(0, bytesRead);
  } finally { await handle.close(); }
}

/* A raw (2352-byte sector) MODE1 CD whose ISO 9660 volume names a CPS-3
 * game family. */
async function inspectCPS3CD(file) {
  const bytes = (await fsp.stat(file)).size;
  if (bytes % CD_RAW_SECTOR !== 0 || bytes < 32 * CD_RAW_SECTOR || bytes > MAX_CPS3_CD_BYTES) {
    throw new Error("CD 镜像必须是 CloneCD .img（每扇区 2352 字节的原始 MODE1 数据）。");
  }
  const sector = await readRange(file, CD_RAW_SECTOR, 16 * CD_RAW_SECTOR);
  const sync = Buffer.from([0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 0]);
  if (!sector.subarray(0, 12).equals(sync) || sector[15] !== 1) {
    throw new Error("CD 镜像第 16 扇区不是 MODE1 原始扇区；请使用 CloneCD .img，而不是 .iso。");
  }
  const user = sector.subarray(16, 16 + CD_USER_DATA);
  if (user[0] !== 1 || user.toString("ascii", 1, 6) !== "CD001") throw new Error("CD 镜像没有 ISO 9660 卷描述符。");
  const volumeID = user.toString("ascii", 40, 72).trim();
  const family = Object.entries(CPS3_TABLE.families).find(([, record]) => record.cd.volumeIDs.includes(volumeID));
  if (!family) throw new Error(`不认识卷标为 ${volumeID || "（空）"} 的 CD；目前支持：${Object.values(CPS3_TABLE.families).flatMap(record => record.cd.volumeIDs).join("、")}。`);
  return { family: family[0], volumeID, sectors: bytes / CD_RAW_SECTOR, bytes };
}

/* ---- the package ---- */


/* CRC-32 of a file from `offset` on, a megabyte at a time. */
async function fileCRC32(file, offset) {
  const handle = await fsp.open(file, "r");
  try {
    const chunk = Buffer.alloc(1024 * 1024);
    let crc = 0, position = offset;
    for (;;) {
      const { bytesRead } = await handle.read(chunk, 0, chunk.length, position);
      if (!bytesRead) return crc;
      crc = crc32(chunk.subarray(0, bytesRead), crc);
      position += bytesRead;
    }
  } finally { await handle.close(); }
}

/* FCArcadeCPS3Package.c: header, sizes and (when `verifyCRC`) CRC-32. */
function parseCPS3PackageHeader(header, fileBytes) {
  if (header.length < CPS3_PACKAGE_HEADER_BYTES || header.toString("latin1", 0, 8) !== "FCC3PKG1") {
    throw new Error("CPS3 游戏包缺少 FCC3PKG1 文件头。");
  }
  if (header.readUInt32LE(8) !== 1) throw new Error("不支持的 CPS3 游戏包版本。");
  const altEncryption = header.readUInt32LE(12);
  const simmChips = [...header.subarray(16, 23)];
  const [biosBytes, flashBytes, eepromBytes, stubBytes] = [24, 28, 32, 36].map(offset => header.readUInt32LE(offset));
  const chips = simmChips.reduce((sum, count) => sum + count, 0);
  if (altEncryption > 1 || header[23] !== 0 || simmChips.some(count => ![0, 2, 4, 8].includes(count)) ||
      biosBytes !== CPS3_BIOS_BYTES || eepromBytes !== CPS3_EEPROM_BYTES || !chips ||
      flashBytes !== chips * CPS3_FLASH_BYTES || !stubBytes ||
      fileBytes !== CPS3_PACKAGE_HEADER_BYTES + biosBytes + flashBytes + eepromBytes + stubBytes) {
    throw new Error("CPS3 游戏包的尺寸与文件头不一致。");
  }
  return { altEncryption, simmChips, biosBytes, flashBytes, eepromBytes, stubBytes, crc32: header.readUInt32LE(40) };
}

async function readCPS3Package(file, { verifyCRC = false } = {}) {
  const bytes = (await fsp.stat(file)).size;
  const header = parseCPS3PackageHeader(await readRange(file, CPS3_PACKAGE_HEADER_BYTES, 0), bytes);
  const bios = await readRange(file, CPS3_BIOS_BYTES, CPS3_PACKAGE_HEADER_BYTES);
  if (verifyCRC) {
    // A megabyte at a time: the package is up to ~100 MB and the NAS small.
    if (await fileCRC32(file, CPS3_PACKAGE_HEADER_BYTES) !== header.crc32) {
      throw new Error("CPS3 游戏包 CRC-32 校验失败，文件已损坏。");
    }
  }
  const sha256 = crypto.createHash("sha256").update(bios).digest("hex");
  return { ...header, bios, biosSHA256: sha256, driver: cps3DriverForBIOSSHA256(sha256)?.driver || null, bytes };
}

/* ---- the install (WebAssembly, off the event loop) ---- */

function cps3InstallerAvailable() { return fs.existsSync(INSTALL_WASM); }

/* Runs resources/cps3-install.wasm (Scripts/cps3-install.c) in a worker:
 * `bios` + `cd` in, `outDir/package.fcc3` out. Progress comes from the
 * tool's "frame N flash writes M" lines. */
async function runCPS3Install({ biosFile, cdFile, keyHex, simmChips, altEncryption = false, outDir, onProgress = null, signal = null, wasmFile = INSTALL_WASM }) {
  const key = normalizeCPS3KeyHex(keyHex);
  if (!key) throw new Error("缺少 CPS3 key。");
  if (!fs.existsSync(wasmFile)) throw new Error("服务端缺少 CPS3 安装器 resources/cps3-install.wasm。");
  await fsp.mkdir(outDir, { recursive: true });
  const stdoutFile = path.join(outDir, "install.out");
  const stderrFile = path.join(outDir, "install.log");
  const worker = new Worker(path.join(__dirname, "cps3-install-worker.js"), {
    workerData: {
      wasmFile, stdoutFile, stderrFile,
      args: ["cps3-install", `/bios/${path.basename(biosFile)}`, `/cd/${path.basename(cdFile)}`,
        `0x${key.slice(0, 8)}`, `0x${key.slice(8)}`, simmChips.join(","), "/out", ...(altEncryption ? ["alt"] : [])],
      preopens: { "/bios": path.dirname(path.resolve(biosFile)), "/cd": path.dirname(path.resolve(cdFile)), "/out": path.resolve(outDir) }
    }
  });
  let lastReported = "";
  const poll = setInterval(async () => {
    if (!onProgress) return;
    try {
      const text = await fsp.readFile(stderrFile, "utf8");
      const lines = text.trim().split("\n");
      const last = lines[lines.length - 1] || "";
      const match = /^frame (\d+) flash writes (\d+)$/.exec(last);
      if (match && last !== lastReported) {
        lastReported = last;
        onProgress({ frame: Number(match[1]), flashWrites: Number(match[2]) });
      }
    } catch { /* not written yet */ }
  }, 1000);
  try {
    const exitCode = await new Promise((resolve, reject) => {
      const abort = () => { void worker.terminate(); reject(new Error("CPS3 安装已取消。")); };
      if (signal?.aborted) return abort();
      signal?.addEventListener("abort", abort, { once: true });
      worker.once("message", message => message.error ? reject(new Error(message.error)) : resolve(message.exitCode));
      worker.once("error", reject);
      worker.once("exit", code => resolve(code === 0 ? 0 : code));
    });
    const output = await fsp.readFile(stdoutFile, "utf8").catch(() => "");
    const failure = await fsp.readFile(stderrFile, "utf8").catch(() => "");
    if (exitCode !== 0 || !/cps3_install=PASS/.test(output)) {
      const reason = /cps3_install=FAIL ?(.*)/.exec(failure)?.[1] || failure.trim().split("\n").pop() || `退出码 ${exitCode}`;
      throw new Error(`CPS3 CD 安装失败：${reason}`);
    }
  } finally {
    clearInterval(poll);
    await worker.terminate();
  }
  const packageFile = path.join(outDir, "package.fcc3");
  const parsed = await readCPS3Package(packageFile, { verifyCRC: true });
  if (!cps3KeyMatchesBIOS(parsed.bios, key)) throw new Error("安装生成的游戏包与 key 不匹配。");
  return packageFile;
}

module.exports = {
  CPS3_BIOS_BYTES, CPS3_PACKAGE_EXTENSION, MAX_CPS3_CD_BYTES,
  cps3Driver, cps3Drivers, cps3DriverForBIOSSHA256,
  normalizeCPS3KeyHex, cps3CryptMask, cps3KeyMatchesBIOS, validateCPS3KeyForBIOS,
  cps3KeyTableFile, cps3TableKey, rememberCPS3Key,
  identifyCPS3BIOSArchive, inspectCPS3CD,
  parseCPS3PackageHeader, readCPS3Package, crc32,
  cps3InstallerAvailable, runCPS3Install
};
