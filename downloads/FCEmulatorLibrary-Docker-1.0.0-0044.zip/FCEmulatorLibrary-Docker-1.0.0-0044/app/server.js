#!/usr/bin/env node
/*
 * FC Emulator Library Server
 *
 * A deliberately dependency-free, local-first ROM manager. The manager keeps
 * its own catalogue, hashes every artefact, and exports the exact portable
 * layout consumed by FCEmulatorTV's TVRemoteLibraryClient.
 */
const http = require("node:http");
const crypto = require("node:crypto");
const fsp = require("node:fs/promises");
const fs = require("node:fs");
const path = require("node:path");
const os = require("node:os");
const dns = require("node:dns/promises");
const net = require("node:net");
const { execFileSync } = require("node:child_process");
const { pipeline } = require("node:stream/promises");
const { URL } = require("node:url");
const zlib = require("node:zlib");
// Public archive identities from FCArcadeCoreC.c PGM_DRIVER entries.
// Classification is not a claim that a protection device is executable.
const identities = [
  ["orlegend", "00df222abdc32b792e89fa77feabc1aad258bec484d29fe2f39d004df77ab8c2", 18114087],
  ["drgw2", "770dc66e7929d287cfa577edd9c5e6ddd89784dd026de7d40153549978ad040f", 3992536],
  ["killbld", "226850fcd4e6dd4f48edf887b7a833a827bb6f69287eb774e4f7f6a98a20411f", 16331490],
  ["olds", "93f398660c1a44a3b9905b0f937595c7ae7746b3e3699c81e9a8bbe337f9d4de", 23177711],
  ["kovsh", "ae9436146ddc44f58479046d3f516f5a929e8a8a7227d7fd6c6aa08a147404bb", 22366936],
  ["martmast", "aff4260f6a53f514832ea2e968422000259dd2b6d72394bb5467698c5ed7018d", 30619610],
  ["ddp2", "ccd2dbf21efa267515661485d8bf2d114d970d510d3cdeeb3ce2048d34d74eee", 14985208],
  ["killbldp", "e5c92d751f590aa34bb80d76dca710e2d4fb8a23990f7cb0717a41f4d34ec21a", 20043075],
  ["dmnfrnt", "e343160c045ac91e173d442c363e680200a42529f033366bfcb613dd8a29d6d2", 24995334]
];
function identifyPGMArchive({ sha256, bytes } = {}) {
  return identities.find(entry => entry[1] === sha256 && entry[2] === bytes)?.[0] || null;
}

const SAVE_SYSTEMS = ["nes", "snes", "megaDrive", "neoGeo", "arcade"];
const SYSTEMS = [...SAVE_SYSTEMS, "pgm"];
// Retired systems are rejected rather than decoded as future product support.
const MANIFEST_SYSTEMS = [...SYSTEMS];
const CATEGORIES = ["经典", "动作", "闯关", "射击", "格斗", "体育", "竞速", "益智", "冒险", "角色扮演", "策略", "模拟", "街机", "破解", "其他"];
const EXTENSIONS = {
  nes: new Set(["nes", "fds", "qd"]),
  snes: new Set(["smc", "sfc"]),
  megaDrive: new Set(["bin", "md", "gen"]),
  pgm: new Set(["zip", "7z"]),
  neoGeo: new Set(["zip", "7z"]),
  arcade: new Set(["zip", "7z"])
};
const IMAGE_EXTENSIONS = new Set(["png", "jpg", "jpeg", "webp"]);
// `cover` and `backdrop` are the portable manifest v1 artwork keys consumed
// by Apple TV. `logo` is a manager-only extension and is intentionally
// ignored by clients that do not understand it.
const ARTWORK_TYPES = new Set(["cover", "backdrop", "logo"]);
const PREFERRED_SEARCH_SITES_VERSION = 2;
const ADDED_PREFERRED_SEARCH_SITES_V2 = [
  "https://thumbnails.libretro.com/",
  "https://adb.arcadeitalia.net/",
  "https://www.progettosnaps.net/flyers/",
  "https://www.gamesdatabase.org/"
];
const DEFAULT_PREFERRED_SEARCH_SITES = [
  "https://gamesdb.launchbox-app.com/",
  "https://www.arcadeartwork.org/",
  "https://flyers.arcade-museum.com/",
  "https://www.thecoverproject.net/",
  "https://www.coverbrowser.com/covers/nes-games",
  "https://archive.org/download/nes_classic_box_art/NES%20Box%20Art%20%28USA%29%20742%20Covers/",
  "https://www.arcadeartwork.org/index.php?%2Fcategory%2F698=",
  "https://archive.org/details/arcade-posters-b2-size",
  ...ADDED_PREFERRED_SEARCH_SITES_V2
];
const MIME_TYPES = {
  ".json": "application/json; charset=utf-8", ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
  ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp",
  ".nes": "application/octet-stream", ".fds": "application/octet-stream", ".qd": "application/octet-stream", ".rom": "application/octet-stream", ".smc": "application/octet-stream", ".sfc": "application/octet-stream", ".bin": "application/octet-stream", ".md": "application/octet-stream", ".gen": "application/octet-stream",
  ".zip": "application/zip", ".7z": "application/x-7z-compressed"
};
const CRC32_TABLE = Uint32Array.from({ length: 256 }, (_, index) => {
  let value = index;
  for (let bit = 0; bit < 8; bit++) value = value & 1 ? (value >>> 1) ^ 0xedb88320 : value >>> 1;
  return value >>> 0;
});

// Driver identity metadata is kept beside the private server-side key table.
// The CRCs and filenames mirror the locked CPS2 chip catalogue consumed by
// FCArcadeCoreC/MAME; raw keys are never exposed by a Web endpoint.
const CPS2_KEY_METADATA = Object.freeze({
  "choko": { name: "choko.key", crc32: "08505e8b" },
  "ddsom": { name: "ddsom.key", crc32: "541e425d" },
  "mshvsf": { name: "mshvsf.key", crc32: "64660867" },
  "qndream": { name: "qndream.key", crc32: "97eee4ff" },
  "uecology": { name: "uecology.key", crc32: "0bab792d" },
  "1944u": { name: "1944u.key", crc32: "61734f5b" },
  "19xxar1": { name: "19xxa.key", crc32: "2cd32eb9" },
  "19xxu": { name: "19xx.key", crc32: "77e67ba1" },
  "armwar": { name: "armwar.key", crc32: "fe979382" },
  "avspu": {
    name: "avspu.key", crc32: "4e68e346",
    archiveSHA256: "47fdc2edbdd57cbfc366a7f162a182c8ae1f9fe0f52c4271048339214ec9c44e"
  },
  "csclub1": { name: "csclub.key", crc32: "903907d7" },
  "ddtodur1": { name: "ddtodu.key", crc32: "7c03ec9e" },
  "gigawing": { name: "gigawing.key", crc32: "5076c26b" },
  "mmatrix": { name: "mmatrix.key", crc32: "8ed66bc4" },
  "mpang": { name: "mpang.key", crc32: "95354b0f" },
  "mvsc": { name: "mvsc.key", crc32: "7e101e09" },
  "pzloop2": { name: "pzloop2.key", crc32: "ae13be78" },
  "sfz2al": { name: "sfz2al.key", crc32: "2904963e" },
  "sgemf": { name: "sgemf.key", crc32: "3d604021" }
});
const ARCADE_HARDWARE_CATALOG = require("./resources/arcade-hardware.json");
const MAME_CAPCOM_CATALOG = require("./resources/mame-capcom-drivers.json");
if (MAME_CAPCOM_CATALOG?.schemaVersion !== 1 || !MAME_CAPCOM_CATALOG.drivers) {
  throw new Error("MAME Capcom driver 资料格式无效。");
}
function exactCPS2ArchiveMatch(matches, archiveSHA256) {
  return matches.find(candidate =>
    CPS2_KEY_METADATA[candidate.driver]?.archiveSHA256 === archiveSHA256
  ) || null;
}
const MAME_CAPCOM_DRIVERS = MAME_CAPCOM_CATALOG.drivers;
const MAME_CAPCOM_IDENTITY_INDEX = new Map();
for (const [driver, record] of Object.entries(MAME_CAPCOM_DRIVERS)) {
  for (const chip of record.identity || []) {
    const identity = `${chip.bytes}:${String(chip.crc32).toLowerCase()}`;
    const drivers = MAME_CAPCOM_IDENTITY_INDEX.get(identity) || [];
    drivers.push(driver);
    MAME_CAPCOM_IDENTITY_INDEX.set(identity, drivers);
  }
}
const ARCADE_HARDWARE_BY_DRIVER = new Map(
  Object.entries(ARCADE_HARDWARE_CATALOG.families).flatMap(([id, family]) =>
    family.drivers.map(driver => [driver, { id, label: family.label }])
  )
);
// Platform detection is deliberately broader than the device core's current
// executable catalog. Known Capcom driver basenames must remain Arcade even
// while an individual driver is still being implemented by FCArcadeCoreC.
const CPS1_DRIVERS = new Set([
  "1941", "3wonders", "cawing", "dino", "ffight", "ghouls", "knights",
  "megaman", "mercs", "nemo", "pang3", "punisher", "sf2", "sf2ce",
  "slammast", "strider", "unsquad", "varth", "willow", "wof", "wofh"
]);
const KONAMI_TMNT2_DRIVERS = new Set(["ssriderseaa"]);
const MAX_NEOGEO_BIOS_BYTES = 16 * 1024 * 1024;
const FDS_BIOS_BYTES = 8 * 1024;
const SNES_IPL_BYTES = 64;
// Cartridge coprocessor ROMs are owned by the user and never shipped. Sizes
// and concatenation order follow pinned ares v145 mia/medium/super-famicom.cpp:
// program ROM first, then data ROM. Cx4 contains only a data ROM.
const SNES_COPROCESSOR_FIRMWARE = new Map([
  ...["dsp1.rom", "dsp1b.rom", "dsp2.rom", "dsp3.rom", "dsp4.rom"].map(name =>
    [name, { architecture: "NEC uPD7725", bytes: 0x2000, halves: { program: 0x1800, data: 0x0800 } }]),
  ["cx4.rom", { architecture: "Hitachi HG51BS169", bytes: 0x0c00, halves: null }],
  ["st010.rom", { architecture: "NEC uPD96050", bytes: 0x0d000, halves: { program: 0x0c000, data: 0x1000 } }],
  ["st011.rom", { architecture: "NEC uPD96050", bytes: 0x0d000, halves: { program: 0x0c000, data: 0x1000 } }],
  ["st018.rom", { architecture: "SETA ARM6", bytes: 0x28000, halves: { program: 0x20000, data: 0x8000 } }]
]);
const SNES_COPROCESSOR_FIRMWARE_NAMES = new Set(SNES_COPROCESSOR_FIRMWARE.keys());
const SNES_COPROCESSOR_MAX_FIRMWARE_BYTES = Math.max(
  ...[...SNES_COPROCESSOR_FIRMWARE.values()].map(specification => specification.bytes)
);
const SNES_COPROCESSOR_HALF_PATTERN = /^((?:dsp[1-4]b?|st01[018]))\.(program|data)\.rom$/;
function snesNECDSPFirmwareUploadName(originalName) {
  const name = safeName(originalName).toLowerCase();
  if (SNES_COPROCESSOR_FIRMWARE_NAMES.has(name)) return { name, base: name, half: null };
  const half = SNES_COPROCESSOR_HALF_PATTERN.exec(name);
  if (half && SNES_COPROCESSOR_FIRMWARE_NAMES.has(`${half[1]}.rom`)) return { name, base: `${half[1]}.rom`, half: half[2] };
  return null;
}
function snesNECDSPFirmwareName(titleBytes) {
  let label;
  try { label = new TextDecoder("shift_jis").decode(titleBytes); } catch { label = titleBytes.toString("latin1"); }
  // Cartridge headers may encode Japanese katakana in half-width Shift-JIS
  // even though ares exposes the normalized full-width label.  Normalize the
  // decoded label before applying the same firmware identity table.
  label = label.replace(/\0/g, "").trim().normalize("NFKC");
  if (label === "PILOTWINGS") return "dsp1.rom";
  if (label === "DUNGEON MASTER") return "dsp2.rom";
  if (label === "SDガンダムGX") return "dsp3.rom";
  if (label === "PLANETS CHAMP TG3000" || label === "TOP GEAR 3000") return "dsp4.rom";
  return "dsp1b.rom";
}
// Which uPD96050 an EXNEC board carries is a matter of its title, exactly as
// its firmware is. The authority is ares mia and bsnes' firmwareEXNEC: F1 ROC
// II and Exhaust Heat II are the ST010, and everything else is the ST011.
//
// This used to name ST011 only for "2DAN MORITA SHOUGI" and default everything
// else to ST010, which is the opposite default. The two rules agree on the two
// titles they both know, but on any other header they disagree, and the client
// compares the manifest's board against what it detects from the ROM itself:
// the server would have said ST010 while the emulator said ST011, and the
// cartridge would have been refused as a board mismatch. Keep this identical to
// fc_snes_exnec_oscillator_for_cartridge, including trimming only the trailing
// pad so a header with leading spaces cannot be read two ways.
function snesSTFirmwareName(titleBytes) {
  let label;
  try { label = new TextDecoder("shift_jis").decode(titleBytes); } catch { label = titleBytes.toString("latin1"); }
  label = label.replace(/\0/g, "").replace(/[ \0]+$/, "");
  return label === "F1 ROC II" || label === "EXHAUST HEAT2" ? "st010.rom" : "st011.rom";
}
const FDS_BIOS_SHA1 = new Set([
  // MAME nes_disksys_device: 2c33a-01a and older 2c33-01.
  "57fe1bdee955bb48d357e463ccbf129496930b62",
  "af5af53f66982e749643fdf8b2acbb7d4d3ed229"
]);
// FCArcadeCoreC intentionally accepts one locked, reproducible MVS board
// profile. These size/CRC identities are the same defaults documented by
// MAME; the server stores only metadata and a user-supplied archive.
const MAX_PGM_BIOS_BYTES = 16 * 1024 * 1024;
// The three chips a PGM motherboard cannot start without, from the same pinned
// MAME inventory the emulator's PGM catalogue is generated from. pgm_p01s.u20
// is the older program revision and is not required, so an archive holding
// either program ROM is accepted.
const PGM_BIOS_COMPONENTS = Object.freeze([
  { role: "主程序", name: "pgm_p02s.u20", bytes: 0x20_000, crc32: "78c15fa2" },
  { role: "文字层", name: "pgm_t01s.rom", bytes: 0x200_000, crc32: "1a7123a0" },
  { role: "音色样本", name: "pgm_m01s.rom", bytes: 0x200_000, crc32: "45ae7159" }
]);

const NEOGEO_BIOS_COMPONENTS = Object.freeze([
  { role: "主 CPU", name: "sp-s2.sp1", bytes: 0x20_000, crc32: "9036d879" },
  { role: "固定层", name: "sfix.sfix", bytes: 0x20_000, crc32: "c2ea0cfd" },
  { role: "音频 CPU", name: "sm1.sm1", bytes: 0x20_000, crc32: "94416d67" },
  { role: "缩放表", name: "000-lo.lo", bytes: 0x20_000, crc32: "5a86cff2" }
]);

function now() { return new Date().toISOString(); }
function randomID() { return crypto.randomUUID(); }
function sha256(value) { return crypto.createHash("sha256").update(value).digest("hex"); }
function extension(name) { return path.extname(name).slice(1).toLowerCase(); }
function baseName(name) { return path.basename(name, path.extname(name)); }

function categoryForSystem(category, system) {
  const canonical = category === "教育" ? "益智" : category === "多人" ? "其他" : category;
  return canonical === "街机" && (system === "nes" || system === "snes") ? "其他" : canonical;
}

function arcadeHardware(system, driver) {
  if (system === "neoGeo") return { id: "neoGeoMVS", label: "Neo Geo MVS" };
  if (system !== "arcade") return null;
  const identifier = String(driver || "").trim().toLowerCase();
  if (!identifier) return null;
  const mame = MAME_CAPCOM_DRIVERS[identifier];
  if (mame?.family === "cps1") return { id: "cps1", label: "CPS-1" };
  if (mame?.family === "cps2") return { id: "cps2", label: "CPS-2" };
  if (CPS1_DRIVERS.has(identifier)) return { id: "cps1", label: "CPS-1" };
  if (CPS2_KEY_METADATA[identifier]) return { id: "cps2", label: "CPS-2" };
  if (KONAMI_TMNT2_DRIVERS.has(identifier)) return { id: "konamiTMNT2", label: "Konami" };
  if (identifier === "outrun") return { id: "segaOutRun", label: "Sega Out Run" };
  return ARCADE_HARDWARE_BY_DRIVER.get(identifier) || null;
}

function arcadeManufacturer(system, driver) {
  const hardware = arcadeHardware(system, driver);
  if (!hardware) return null;
  if (hardware.id === "cps1" || hardware.id === "cps2") return "capcom";
  if (hardware.id.startsWith("sega")) return "sega";
  return null;
}

function automaticArcadeCollection(system, driver) {
  switch (arcadeManufacturer(system, driver)) {
    case "capcom": return { id: "capcom", title: "Capcom", symbol: "arcade.stick.console" };
    case "sega": return { id: "sega-system16", title: "SEGA", symbol: "arcade.stick.console" };
    default: return null;
  }
}

function titleFromFile(name) {
  return baseName(name)
    .replace(/\s*[\[(][^\])]*[\])]/g, "")
    .replace(/\s+(?:Rev|PRG|v)\s*\d+(?:\.\d+)?\s*$/i, "")
    .replace(/\s+/g, " ").trim() || "未命名游戏";
}

function normalized(value) {
  return String(value).normalize("NFKD").toLowerCase().replace(/&/g, " and ")
    .replace(/[^\p{L}\p{N}]+/gu, " ").trim();
}

function scoreMatch(a, b) {
  a = normalized(a); b = normalized(b);
  if (!a || !b) return 0;
  if (a === b) return 1;
  if (a.includes(b) || b.includes(a)) return 0.94;
  const left = new Set(a.split(" ")), right = new Set(b.split(" "));
  let common = 0;
  for (const word of left) if (right.has(word)) common++;
  return common ? (2 * common) / (left.size + right.size) : 0;
}

function decodeHTMLText(value) {
  return String(value || "").replace(/&amp;/gi, "&").replace(/&quot;/gi, '"')
    .replace(/&#(?:x([0-9a-f]+)|(\d+));/gi, (_, hexadecimal, decimal) =>
      String.fromCodePoint(Number.parseInt(hexadecimal || decimal, hexadecimal ? 16 : 10)))
    .replace(/&#39;|&apos;/gi, "'").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">");
}

function libretroThumbnailEntries(html, directoryURL) {
  const entries = [];
  const seen = new Set();
  for (const match of String(html || "").matchAll(/<a\b[^>]*\bhref\s*=\s*(["'])(.*?)\1[^>]*>([\s\S]*?)<\/a>/gi)) {
    const href = decodeHTMLText(match[2]).trim();
    if (!/\.png(?:[?#].*)?$/i.test(href)) continue;
    let imageURL;
    try { imageURL = new URL(href, directoryURL).href; } catch { continue; }
    if (seen.has(imageURL)) continue;
    seen.add(imageURL);
    let fileName = href.split(/[?#]/, 1)[0].split("/").pop() || "";
    try { fileName = decodeURIComponent(fileName); } catch { /* retain the encoded filename */ }
    fileName = decodeHTMLText(fileName);
    const title = titleFromFile(fileName);
    if (title) entries.push({ title, fileName, imageURL });
  }
  return entries;
}

function libretroBoxArtMatches(entries, game, limit = 4) {
  const evidence = [game?.title, game?.chineseTitle, titleFromFile(game?.originalName || "")].filter(Boolean);
  if (!evidence.length) return [];
  const originalBaseName = normalized(baseName(game?.originalName || ""));
  const gameEvidence = [game?.title, game?.originalName, game?.region].join(" ");
  const variantPattern = /\[(?:h|b|p|t|tr|o|f|a)(?:\s|\d|\]|_)|\b(?:bootleg|hack|prototype|proto|beta|pirate|bad dump)\b/i;
  const gameIsVariant = variantPattern.test(gameEvidence);
  const regionAliases = ({
    usa: ["usa", "us", "world"], us: ["usa", "us", "world"],
    japan: ["japan", "jp"], jp: ["japan", "jp"],
    europe: ["europe", "euro", "eu", "pal"], eu: ["europe", "euro", "eu", "pal"],
    asia: ["asia", "asian"], china: ["china", "chinese", "cn"],
    taiwan: ["taiwan", "tw"], korea: ["korea", "korean", "kr"],
    brazil: ["brazil", "br"], world: ["world"]
  })[normalized(game?.region || "")] || [];
  return entries.map(entry => {
    const titleScore = Math.max(...evidence.map(value => scoreMatch(value, entry.title)));
    const annotationWords = new Set([...entry.fileName.matchAll(/[\[(]([^\])]+)[\])]/g)]
      .flatMap(match => normalized(match[1]).split(" ")));
    const regionScore = regionAliases.some(alias => annotationWords.has(alias)) ? 0.03 : 0;
    const exactFileScore = originalBaseName && originalBaseName === normalized(baseName(entry.fileName)) ? 0.08 : 0;
    const variantPenalty = !gameIsVariant && variantPattern.test(entry.fileName) ? 0.12 : 0;
    return { ...entry, titleScore, rankingScore: titleScore + regionScore + exactFileScore - variantPenalty };
  }).filter(entry => entry.titleScore >= 0.88)
    .sort((left, right) => right.rankingScore - left.rankingScore || left.title.length - right.title.length)
    .slice(0, limit);
}

function libretroPlaylists(system) {
  return ({
    nes: ["Nintendo - Nintendo Entertainment System"],
    snes: ["Nintendo - Super Nintendo Entertainment System"],
    neoGeo: ["SNK - Neo Geo"],
    arcade: ["FBNeo - Arcade Games", "MAME"]
  })[system] || [];
}

async function mapWithConcurrency(items, concurrency, mapper) {
  const results = new Array(items.length); let next = 0;
  async function worker() {
    while (true) {
      const index = next++;
      if (index >= items.length) return;
      results[index] = await mapper(items[index], index);
    }
  }
  await Promise.all(Array.from({ length: Math.min(items.length, Math.max(1, concurrency)) }, worker));
  return results;
}

function imageDimensions(data, contentType = "") {
  if (!Buffer.isBuffer(data) || data.length < 24) return null;
  if (contentType === "image/png" && data.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) {
    return { width: data.readUInt32BE(16), height: data.readUInt32BE(20) };
  }
  if (contentType === "image/jpeg" && data[0] === 0xff && data[1] === 0xd8) {
    let offset = 2;
    while (offset + 9 < data.length) {
      if (data[offset] !== 0xff) { offset++; continue; }
      const marker = data[offset + 1];
      if (marker === 0xd8 || marker === 0xd9) { offset += 2; continue; }
      const length = data.readUInt16BE(offset + 2);
      if (length < 2 || offset + 2 + length > data.length) break;
      if ((marker >= 0xc0 && marker <= 0xc3) || (marker >= 0xc5 && marker <= 0xc7) || (marker >= 0xc9 && marker <= 0xcb) || (marker >= 0xcd && marker <= 0xcf)) {
        return { width: data.readUInt16BE(offset + 7), height: data.readUInt16BE(offset + 5) };
      }
      offset += 2 + length;
    }
  }
  if (contentType === "image/webp" && data.toString("ascii", 0, 4) === "RIFF" && data.toString("ascii", 8, 12) === "WEBP") {
    const kind = data.toString("ascii", 12, 16);
    if (kind === "VP8X" && data.length >= 30) return { width: 1 + data.readUIntLE(24, 3), height: 1 + data.readUIntLE(27, 3) };
    if (kind === "VP8 " && data.length >= 30) return { width: data.readUInt16LE(26) & 0x3fff, height: data.readUInt16LE(28) & 0x3fff };
  }
  return null;
}

function detectedSystem(fileName) {
  const ext = extension(fileName);
  if (["nes", "fds", "qd"].includes(ext)) return "nes";
  if (["sfc", "smc"].includes(ext)) return "snes";
  if (["bin", "md", "gen"].includes(ext)) return "megaDrive";
  const lowerName = String(fileName).toLowerCase();
  if (lowerName === "neogeo.zip" || lowerName === "pgm.zip") return null;
  if ((ext === "zip" || ext === "7z") && arcadeHardware("arcade", baseName(fileName))) return "arcade";
  if (ext === "zip" || ext === "7z") return "neoGeo";
  return null;
}

function snesChecksum(rom) {
  let power = 1;
  while (power <= rom.length / 2) power *= 2;
  if (power === rom.length) {
    let linear = 0;
    for (const byte of rom) linear = (linear + byte) & 0xffff;
    return linear;
  }
  const extent = power * 2;
  const mirrored = (address, size) => {
    let branch = 1;
    while (branch <= size / 2) branch *= 2;
    if (branch === size) return address & (branch - 1);
    address &= branch * 2 - 1;
    return address < branch ? address : branch + mirrored(address - branch, size - branch);
  };
  let sum = 0;
  for (let offset = 0; offset < extent; offset++) sum = (sum + rom[mirrored(offset, rom.length)]) & 0xffff;
  return sum;
}

async function analyzeSNESROM(file) {
  const bytes = await fsp.readFile(file);
  const copierBytes = bytes.length % 0x8000 === 512 ? 512 : 0;
  const rom = bytes.subarray(copierBytes);
  if (rom.length < 0x8000 || rom.length > 8 * 1024 * 1024 || rom.length % 0x8000) {
    throw new Error("Super NES ROM 大小或 512 字节 copier header 无效。");
  }
  const actualChecksum = snesChecksum(rom);
  let best = null;
  let tied = false;
  for (const headerOffset of [0x7fc0, 0xffc0, 0x407fc0, 0x40ffc0]) {
    if (rom.length < headerOffset + 64) continue;
    const mapMode = rom[headerOffset + 21];
    const mode = mapMode & ~0x10;
    const low = mode === 0x20 || mode === 0x22 || mode === 0x23;
    const high = mode === 0x21 || mode === 0x25 || mode === 0x2a;
    if ((!low && !high) || low !== ((headerOffset & 0x8000) === 0)) continue;
    const romSizeCode = rom[headerOffset + 23];
    const ramSizeCode = rom[headerOffset + 24];
    // The header ROM-size code is advisory (bsnes sizes the ROM from the
    // image); it only contributes to the score below. The core parser
    // fc_snes_cartridge_inspect applies the same rule.
    if (ramSizeCode > 8) continue;
    const reset = rom.readUInt16LE(headerOffset + 60);
    if (reset < 0x8000) continue;
    const entry = (headerOffset & ~0x7fff) | (reset & 0x7fff);
    if (entry >= rom.length) continue;
    const checksum = rom.readUInt16LE(headerOffset + 30);
    const complement = rom.readUInt16LE(headerOffset + 28);
    const declaredBytes = romSizeCode <= 13 ? 1024 * (2 ** romSizeCode) : 0;
    const headerSRAMBytes = ramSizeCode ? 1024 * (2 ** ramSizeCode) : 0;
    let extent = 1;
    while (extent <= rom.length / 2) extent *= 2;
    if (extent !== rom.length) extent *= 2;
    let score = ((checksum ^ complement) === 0xffff ? 4 : 0)
      + (checksum === actualChecksum ? 8 : 0) + (extent === declaredBytes ? 2 : 0)
      + (headerOffset >= 0x400000 ? 4 : 0)
      + ([0x18, 0x78, 0x4c, 0x5c].includes(rom[entry]) ? 2 : 0);
    const cartridgeType = rom[headerOffset + 22];
    const cartridgeTypeHi = cartridgeType >> 4;
    const cartridgeTypeLo = cartridgeType & 0x0f;
    // Nintendo extended cartridge subtype lives immediately before the
    // 21-byte title. ares v145 uses it to distinguish Hitachi Cx4, SETA's
    // uPD96050 boards and ST018 rather than guessing from the game filename.
    const cartridgeSubType = rom[headerOffset - 1];
    const titleBytes = rom.subarray(headerOffset, headerOffset + 21);
    // SA-1 boards declare map mode $23 with cartridge type $32-$35; this is
    // the same title-independent identity the core parser derives.
    const isSA1 = mode === 0x23 && cartridgeType >= 0x32 && cartridgeType <= 0x35;
    // ares v145 mia/medium/super-famicom.cpp::board identifies GSU from the
    // chipset nibbles. GSU-RAM always supplies 32 KiB expansion RAM even
    // though early Star Fox headers declare no ordinary SRAM.
    const isSuperFX = mode === 0x20 && (cartridgeType & 0x0f) >= 0x03
      && (cartridgeType >> 4) === 0x01;
    const superFXType = cartridgeType & 0x0f;
    const superFXBattery = isSuperFX && (superFXType === 0x05 || superFXType === 0x06);
    // Same table, high nibble 0, low nibble 3-5: NEC's uPD7725 on a LoROM or
    // HiROM board (Pilotwings $03 without RAM, Super Mario Kart $05 with 2 KiB
    // battery RAM). The core parser derives the same identity.
    const isNECDSP = (mode === 0x20 || mode === 0x21) && (cartridgeType >> 4) === 0x0
      && (cartridgeType & 0x0f) >= 0x03 && (cartridgeType & 0x0f) <= 0x05;
    // ares mia chipset table: high nibble 2 selects OBC1. The production
    // SHVC-2E3M-01 board is LoROM type $25 with exactly 8 KiB battery RAM.
    const isOBC1 = mode === 0x20 && cartridgeType === 0x25;
    // ares mia board(): S-DD1 uses mapping $22 and cartridge family $4x;
    // SPC7110 uses mapping $2a, subtype 0, and $f5/$f9 (the latter adds RTC).
    const isSDD1 = mode === 0x22 && cartridgeTypeHi === 0x4 && cartridgeTypeLo >= 0x3;
    // The image has to be larger than the decompressor's own 1 MiB program
    // ROM, because the data ROM it reads sits behind that. The core requires
    // the same bound, and without it here a small image would be published as
    // SPC7110 and then refused by the client, which detects the board from the
    // very same header and compares.
    const isSPC7110 = mode === 0x2a && cartridgeTypeHi === 0x0f && cartridgeSubType === 0
      && (cartridgeTypeLo === 0x5 || cartridgeTypeLo === 0x9)
      && rom.length > 0x100000;
    const hasSPC7110RTC = isSPC7110 && cartridgeTypeLo === 0x9;
    // Extended subtype identities from the same function. These chips carry
    // internal ROMs which are supplied separately by the owner.
    const isCx4 = mode === 0x20 && cartridgeTypeHi === 0x0f && cartridgeTypeLo >= 0x3
      && cartridgeSubType === 0x10;
    const isST01x = mode === 0x20 && cartridgeTypeHi === 0x0f && cartridgeTypeLo >= 0x3
      && cartridgeSubType === 0x01;
    const isST018 = mode === 0x20 && cartridgeTypeHi === 0x0f && cartridgeTypeLo >= 0x3
      && cartridgeSubType === 0x02;
    const stFirmware = isST01x ? snesSTFirmwareName(titleBytes) : null;
    const sramBytes = isSuperFX ? (superFXBattery ? 32 * 1024 : 0) : headerSRAMBytes;
    const workRAMBytes = isSuperFX ? 32 * 1024 : headerSRAMBytes;
    const mapping = isSA1 ? "snes-sa1" : isSuperFX ? "snes-superfx" : isNECDSP ? "snes-necdsp"
      : isOBC1 ? "snes-obc1"
      : isSDD1 ? "snes-sdd1"
      : isSPC7110 ? (hasSPC7110RTC ? "snes-spc7110-rtc" : "snes-spc7110")
      : isCx4 ? "snes-cx4"
      : isST01x ? (stFirmware === "st010.rom" ? "snes-st010" : "snes-st011")
      : isST018 ? "snes-st018"
      : low ? "snes-lorom" : mode === 0x25 ? "snes-exhirom" : "snes-hirom";
    const standard = [0x20, 0x21, 0x25].includes(mode) && cartridgeType <= 2
      && (cartridgeType !== 0 || !sramBytes)
      && (mapping === "snes-exhirom"
        ? headerOffset === 0x40ffc0 && rom.length > 0x400000
        : headerOffset < 0x400000 && rom.length <= 0x400000)
      && sramBytes <= 128 * 1024;
    const supported = isSA1
      ? headerOffset < 0x400000 && rom.length <= 0x800000 && sramBytes <= 256 * 1024
      : isSuperFX ? headerOffset < 0x400000 && rom.length <= 0x800000
      : isNECDSP ? headerOffset < 0x400000 && rom.length <= 0x400000 && sramBytes <= 128 * 1024
      : isOBC1 ? headerOffset < 0x400000 && rom.length <= 0x400000 && sramBytes === 8 * 1024
      : isSDD1 ? headerOffset < 0x400000 && rom.length <= 0x800000 && sramBytes <= 256 * 1024
      : isSPC7110 ? headerOffset < 0x400000 && rom.length <= 0x800000 && sramBytes <= 128 * 1024
      : isCx4 || isST01x || isST018
        ? headerOffset < 0x400000 && rom.length <= 0x400000 && sramBytes <= 128 * 1024
      : standard;
    const coprocessorFirmware = isNECDSP ? snesNECDSPFirmwareName(titleBytes)
      : isCx4 ? "cx4.rom" : isST01x ? stFirmware : isST018 ? "st018.rom" : null;
    const candidate = { score, supported, board: mapping, sramBytes, workRAMBytes,
      regionCode: rom[headerOffset + 25],
      rtcBytes: hasSPC7110RTC ? 16 : 0,
      coprocessorFirmware,
      coprocessorFirmwareBytes: coprocessorFirmware
        ? SNES_COPROCESSOR_FIRMWARE.get(coprocessorFirmware).bytes : 0,
      // Kept for service API compatibility with 0038-0040 callers.
      necDSPFirmware: isNECDSP ? coprocessorFirmware : null };
    if (!best || score > best.score) { best = candidate; tied = false; }
    else if (score === best.score) tied = true;
  }
  if (!best) throw new Error("Super NES ROM 缺少有效的内部卡带头。");
  if (tied) throw new Error("Super NES ROM 存在歧义卡带头，拒绝猜测映射方式。");
  if (!best.supported) throw new Error("当前只支持标准 LoROM、HiROM、ExHiROM、SA-1、Super FX、DSP-1/2/3/4、OBC1、S-DD1、Cx4、SPC7110/RTC 与 ST010/011/018 卡带。");
  const pal = (best.regionCode >= 0x02 && best.regionCode <= 0x0c) || best.regionCode === 0x11;
  const region = best.regionCode === 0 ? "japan" : best.regionCode === 1 ? "usa"
    : best.regionCode === 0x0d ? "korea" : pal ? "europe" : "world";
  return { ...best, region, model: best.regionCode === 0 ? "super-famicom" : "super-nintendo" };
}

function safeName(value, fallback = "upload.bin") {
  const result = path.basename(String(value || "")).replace(/[\x00-\x1f<>:"/\\|?*]/g, "_").trim();
  return result || fallback;
}

function englishROMFileName(title, currentName) {
  const ext = extension(currentName);
  // The editable title is normally the English canonical name returned by
  // research. Keep the on-disk name portable, but never turn an untranslated
  // title into an unhelpful generic filename.
  const stem = String(title || "").normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^\x20-\x7e]/g, "")
    .replace(/[^A-Za-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  if (!/[A-Za-z0-9]/.test(stem)) return safeName(currentName);
 return safeName(stem + "." + ext, safeName(currentName));
}

function englishGamePackageID(title, sha256Value, fallback) {
  const stem = baseName(englishROMFileName(title, "rom.nes"));
  if (!/[A-Za-z0-9]/.test(stem)) return fallback;
  return stem + "-" + String(sha256Value || "").slice(0, 10);
}

function runtimeSecret(environmentName, keychainService) {
  if (process.env[environmentName]) return process.env[environmentName];
  if (process.platform !== "darwin") return "";
  try {
    return execFileSync("/usr/bin/security", ["find-generic-password", "-a", "FCEmulatorLibraryServer", "-s", keychainService, "-w"], {
      encoding: "utf8", stdio: ["ignore", "pipe", "ignore"]
    }).trim();
  } catch { return ""; }
}

function storeKeychainSecret(keychainService, value) {
  if (process.platform !== "darwin") return false;
  try {
    execFileSync("/usr/bin/security", ["add-generic-password", "-U", "-a", "FCEmulatorLibraryServer", "-s", keychainService, "-w", value], {
      stdio: ["ignore", "ignore", "ignore"]
    });
    return true;
  } catch { return false; }
}

function safeRelative(value) {
  const normalizedPath = path.posix.normalize(String(value || "").replaceAll("\\", "/"));
  if (!normalizedPath || normalizedPath === "." || normalizedPath.startsWith("../") || path.posix.isAbsolute(normalizedPath)) {
    throw new Error("路径必须是资料库内的相对路径。");
  }
  return normalizedPath;
}

function resolvedWithin(root, relativePath) {
  const target = path.resolve(root, safeRelative(relativePath));
  if (!target.startsWith(`${root}${path.sep}`)) throw new Error("资料库清单包含越界路径。");
  return target;
}

function isPrivateAddress(address) {
  if (net.isIP(address) === 4) {
    const [a, b] = address.split(".").map(Number);
    return a === 0 || a === 10 || a === 127 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168);
  }
  const lower = address.toLowerCase();
  if (lower.startsWith("::ffff:")) return isPrivateAddress(lower.slice("::ffff:".length));
  return lower === "::1" || lower.startsWith("fc") || lower.startsWith("fd") || lower.startsWith("fe80:");
}

async function safeRemoteURL(value) {
  const url = new URL(value);
  if (!/^https?:$/.test(url.protocol) || url.username || url.password) throw new Error("封面地址必须是公开的 HTTP(S) 地址。");
  if (net.isIP(url.hostname)) {
    if (isPrivateAddress(url.hostname)) throw new Error("不允许访问内网封面地址。");
    return url;
  }
  const addresses = await dns.lookup(url.hostname, { all: true });
  if (!addresses.length || addresses.some(item => isPrivateAddress(item.address))) throw new Error("不允许访问解析到内网的封面地址。");
  return url;
}

function mapperFromHeader(header) {
  if (header.length < 16 || header.toString("ascii", 0, 4) !== "NES\x1a") return 0;
  let mapper = (header[6] >> 4) | (header[7] & 0xf0);
  if ((header[7] & 0x0c) === 0x08) mapper |= (header[8] & 0x0f) << 8;
  return mapper;
}

function mapperForNESFile(fileName, header) {
  return ["fds", "qd"].includes(extension(fileName)) ? 20 : mapperFromHeader(header);
}

function romInfoForNESFile(fileName, header) {
  const ext = extension(fileName);
  if (ext === "fds") return { format: "FDS" };
  if (ext === "qd") return { format: "QD" };
  return nesROMInfo(header);
}

function crc32Update(value, chunk) {
  for (const byte of chunk) value = (value >>> 8) ^ CRC32_TABLE[(value ^ byte) & 0xff];
  return value >>> 0;
}

function crc32String(value) { return ((value ^ 0xffffffff) >>> 0).toString(16).padStart(8, "0"); }

function crc32Buffer(data) { return crc32String(crc32Update(0xffffffff, data)); }

function normalizeCPS2KeyHex(value) {
  const text = String(value || "").trim();
  if (!text) return null;
  const compact = text.replace(/\s+/g, "").toLowerCase();
  if (!/^[0-9a-f]{40}$/.test(compact)) throw new Error("CPS2 key 必须是 20 字节（40 个十六进制字符）。");
  return compact;
}

function cps2DriverMetadata(system, driver) {
  if (system !== "arcade") return null;
  const identifier = String(driver || "").toLowerCase();
  if (CPS2_KEY_METADATA[identifier]) return CPS2_KEY_METADATA[identifier];
  const record = MAME_CAPCOM_DRIVERS[identifier];
  if (record?.family !== "cps2") return null;
  const key = record.roms?.find(rom => rom.region === "key" && rom.bytes === 20 && /^[0-9a-f]{8}$/.test(rom.crc32));
  return key ? { name: key.name, crc32: key.crc32 } : null;
}

function validateCPS2KeyHex(value, system, driver) {
  const hex = normalizeCPS2KeyHex(value);
  if (!hex) return null;
  const metadata = cps2DriverMetadata(system, driver);
  if (!metadata) throw new Error("该 ROM 驱动不需要 CPS2 key。 ");
  const actualCRC32 = crc32Buffer(Buffer.from(hex, "hex"));
  if (actualCRC32 !== metadata.crc32) {
    throw new Error(`CPS2 key 与驱动 ${driver} 不匹配（应为 ${metadata.name} / CRC32 ${metadata.crc32}）。`);
  }
  return hex;
}

function loadBundledCPS2KeyTable() {
  const file = path.join(__dirname, "resources", "cps2-keys.json");
  let document;
  try { document = JSON.parse(fs.readFileSync(file, "utf8")); }
  catch (error) {
    if (error.code === "ENOENT") {
      console.warn("未打包 CPS2 key 表；CPS2 ROM 需要在 ZIP 内提供匹配的 .key 文件。");
      return Object.freeze({});
    }
    throw new Error(`无法读取服务端 CPS2 key 表：${error.message}`);
  }
  if (document?.schemaVersion !== 1 || document?.format !== "cps2-key-20" || !document.keys || typeof document.keys !== "object") {
    throw new Error("服务端 CPS2 key 表格式无效。");
  }
  const result = {};
  for (const [driver, key] of Object.entries(document.keys)) {
    // A private installation may intentionally omit keys. Keep the driver
    // classified as CPS2 and surface a per-ROM "missing key" state instead
    // of preventing the server from starting.
    if (typeof key === "string" && cps2DriverMetadata("arcade", driver)) {
      result[driver] = validateCPS2KeyHex(key, "arcade", driver);
    }
  }
  return Object.freeze(result);
}

const BUNDLED_CPS2_KEYS = loadBundledCPS2KeyTable();

function bundledCPS2KeyHex(system, driver) {
  if (!cps2DriverMetadata(system, driver)) return null;
  return BUNDLED_CPS2_KEYS[String(driver || "").toLowerCase()] || null;
}

function nesROMInfo(header) {
  if (header.length < 16 || header.toString("ascii", 0, 4) !== "NES\x1a") return null;
  return {
    format: (header[7] & 0x0c) === 0x08 ? "NES 2.0" : "iNES",
    prgROMBytes: header[4] * 16_384, chrROMBytes: header[5] * 8_192,
    mirroring: header[6] & 8 ? "four-screen" : header[6] & 1 ? "vertical" : "horizontal",
    battery: Boolean(header[6] & 2), trainer: Boolean(header[6] & 4)
  };
}

async function hashFile(file) {
  const hash = crypto.createHash("sha256");
  let bytes = 0; let crc = 0xffffffff;
  await new Promise((resolve, reject) => {
    const stream = fs.createReadStream(file);
    stream.on("data", chunk => { hash.update(chunk); crc = crc32Update(crc, chunk); bytes += chunk.length; });
    stream.once("error", reject); stream.once("end", resolve);
  });
  return { sha256: hash.digest("hex"), crc32: crc32String(crc), bytes };
}

async function readFileRange(file, length, position = 0) {
  const handle = await fsp.open(file, "r");
  try {
    const data = Buffer.alloc(length); const { bytesRead } = await handle.read(data, 0, length, position);
    return data.subarray(0, bytesRead);
  } finally { await handle.close(); }
}

function zipEndOfCentralDirectory(data) {
  for (let offset = data.length - 22; offset >= 0; offset--) {
    if (data.readUInt32LE(offset) === 0x06054b50) return offset;
  }
  return -1;
}

async function readZIPCentralDirectory(file) {
  const bytes = (await fsp.stat(file)).size;
  const tailLength = Math.min(bytes, 65_557);
  const tailOffset = bytes - tailLength;
  const tail = await readFileRange(file, tailLength, tailOffset);
  const eocd = zipEndOfCentralDirectory(tail);
  if (eocd < 0 || eocd + 22 > tail.length) throw new Error("ZIP ROM 缺少中央目录，文件可能未下载完整。 ");
  const disk = tail.readUInt16LE(eocd + 4);
  const centralDisk = tail.readUInt16LE(eocd + 6);
  const diskEntries = tail.readUInt16LE(eocd + 8);
  const entryCount = tail.readUInt16LE(eocd + 10);
  const centralBytes = tail.readUInt32LE(eocd + 12);
  const centralOffset = tail.readUInt32LE(eocd + 16);
  if (disk !== 0 || centralDisk !== 0 || diskEntries !== entryCount || entryCount === 0xffff ||
      centralBytes === 0xffffffff || centralOffset === 0xffffffff) {
    throw new Error("不支持分卷或 ZIP64 ROM 压缩包。 ");
  }
  if (entryCount > 4096 || centralBytes > 16 * 1024 * 1024 || centralOffset + centralBytes > bytes) {
    throw new Error("ZIP ROM 中央目录超出安全限制。 ");
  }
  const central = await readFileRange(file, centralBytes, centralOffset);
  if (central.length !== centralBytes) throw new Error("ZIP ROM 中央目录不完整。 ");
  const entries = [];
  let offset = 0;
  for (let index = 0; index < entryCount; index++) {
    if (offset + 46 > central.length || central.readUInt32LE(offset) !== 0x02014b50) {
      throw new Error("ZIP ROM 中央目录结构无效。 ");
    }
    const nameBytes = central.readUInt16LE(offset + 28);
    const extraBytes = central.readUInt16LE(offset + 30);
    const commentBytes = central.readUInt16LE(offset + 32);
    const next = offset + 46 + nameBytes + extraBytes + commentBytes;
    if (next > central.length) throw new Error("ZIP ROM 中央目录条目不完整。 ");
    entries.push({
      name: central.subarray(offset + 46, offset + 46 + nameBytes).toString("utf8"),
      flags: central.readUInt16LE(offset + 8),
      method: central.readUInt16LE(offset + 10),
      crc32: central.readUInt32LE(offset + 16).toString(16).padStart(8, "0"),
      compressedBytes: central.readUInt32LE(offset + 20),
      bytes: central.readUInt32LE(offset + 24),
      localOffset: central.readUInt32LE(offset + 42)
    });
    offset = next;
  }
  return entries;
}

function portableMAMEArcadeDriver(driver, record) {
  return {
    schemaVersion: 1,
    source: `MAME ${MAME_CAPCOM_CATALOG.source.version}`,
    driver,
    ...(record.parent ? { parent: record.parent } : {}),
    hardware: record.family,
    title: record.title,
    rotation: record.rotation,
    inputProfile: record.inputProfile,
    executable: Boolean(record.executable),
    ...(record.unsupportedReason ? { unsupportedReason: record.unsupportedReason } : {}),
    ...(record.cps1Board ? { cps1Board: record.cps1Board } : {}),
    roms: record.roms.map(rom => ({
      name: rom.name, bytes: rom.bytes, crc32: rom.crc32,
      region: rom.region, load: rom.load,
      ...(rom.loadOffset ? { loadOffset: rom.loadOffset } : {}),
      ...(rom.optional ? { optional: true } : {})
    }))
  };
}

/**
 * Identifies a Capcom archive from physical chip size+CRC vectors. The
 * basename is consulted only to resolve a tie between multiple MAME sets that
 * have each already passed their immutable identity vector.
 */
async function identifyMAMECapcomArchive(
  file, originalName = path.basename(file), preferredDriver = null
) {
  if (extension(originalName) !== "zip") return null;
  const entries = (await readZIPCentralDirectory(file)).filter(entry => !entry.name.endsWith("/"));
  const present = new Set(entries.map(entry => `${entry.bytes}:${entry.crc32.toLowerCase()}`));
  const candidates = new Set();
  for (const identity of present) {
    for (const driver of MAME_CAPCOM_IDENTITY_INDEX.get(identity) || []) candidates.add(driver);
  }
  const matches = [];
  for (const driver of candidates) {
    const record = MAME_CAPCOM_DRIVERS[driver];
    const identity = record.identity || [];
    if (!identity.length || !identity.every(chip => present.has(`${chip.bytes}:${chip.crc32}`))) continue;
    const required = (record.roms || []).filter(rom => !rom.optional);
    const matchedRequired = required.filter(rom => present.has(`${rom.bytes}:${rom.crc32}`)).length;
    const key = (record.roms || []).find(rom => rom.region === "key" && present.has(`${rom.bytes}:${rom.crc32}`));
    matches.push({
      driver, record, matchedRequired, missingRequired: required.length - matchedRequired,
      identityCount: identity.length, keyMatched: Boolean(key)
    });
  }
  matches.sort((left, right) =>
    Number(right.keyMatched) - Number(left.keyMatched) ||
    right.matchedRequired - left.matchedRequired ||
    left.missingRequired - right.missingRequired ||
    right.identityCount - left.identityCount ||
    left.driver.localeCompare(right.driver)
  );
  if (!matches.length) return null;
  const best = matches[0];
  const tied = matches.filter(candidate =>
    candidate.keyMatched === best.keyMatched &&
    candidate.matchedRequired === best.matchedRequired &&
    candidate.missingRequired === best.missingRequired
  );
  const basename = baseName(originalName).toLowerCase();
  const preferred = normalized(preferredDriver).toLowerCase();
  let selected = tied.find(candidate => candidate.driver === basename) ||
    tied.find(candidate => candidate.driver === preferred) ||
    (tied.length === 1 ? best : null);
  if (matches.length > 1) {
    const { sha256: archiveSHA256 } = await hashFile(file);
    selected = exactCPS2ArchiveMatch(matches, archiveSHA256) || selected;
  }
  if (!selected) {
    return { ambiguous: tied.slice(0, 12).map(candidate => candidate.driver) };
  }
  return {
    driver: selected.driver,
    title: selected.record.title,
    family: selected.record.family,
    missingRequired: selected.missingRequired,
    descriptor: portableMAMEArcadeDriver(selected.driver, selected.record)
  };
}

async function extractZIPEntry(file, entry, { maximumBytes = 4096, purpose = "CPS2 key" } = {}) {
  if (entry.flags & 1) throw new Error(`ZIP 成员 ${entry.name} 已加密，无法读取 ${purpose}。`);
  if (entry.bytes > maximumBytes || entry.compressedBytes > maximumBytes * 2) {
    throw new Error(`ZIP 成员 ${entry.name} 超出 ${purpose} 安全限制。`);
  }
  const header = await readFileRange(file, 30, entry.localOffset);
  if (header.length !== 30 || header.readUInt32LE(0) !== 0x04034b50) throw new Error(`ZIP 成员 ${entry.name} 的本地文件头无效。`);
  const nameBytes = header.readUInt16LE(26);
  const extraBytes = header.readUInt16LE(28);
  const compressed = await readFileRange(file, entry.compressedBytes, entry.localOffset + 30 + nameBytes + extraBytes);
  if (compressed.length !== entry.compressedBytes) throw new Error(`ZIP 成员 ${entry.name} 数据不完整。`);
  let result;
  if (entry.method === 0) result = compressed;
  else if (entry.method === 8) result = zlib.inflateRawSync(compressed, { maxOutputLength: maximumBytes });
  else throw new Error(`ZIP 成员 ${entry.name} 使用了不支持的压缩方式。`);
  if (result.length !== entry.bytes || crc32Buffer(result) !== entry.crc32) throw new Error(`ZIP 成员 ${entry.name} CRC32 校验失败。`);
  return result;
}

const MAX_MEGA_DRIVE_ROM_BYTES = 0x400000 + 512;
const MAX_SNES_ROM_BYTES = 8 * 1024 * 1024 + 512;

function isZIPMetadataEntry(entry) {
  const name = String(entry?.name || "").replaceAll("\\", "/");
  return name.endsWith("/") || name.startsWith("__MACOSX/") || path.posix.basename(name) === ".DS_Store";
}

async function extractSingleConsoleROMFromZIP(file, requestedSystem = null) {
  let entries;
  try { entries = await readZIPCentralDirectory(file); }
  catch { return null; }
  entries = entries.filter(entry => !isZIPMetadataEntry(entry));
  if (entries.length !== 1) return null;
  const entry = entries[0];
  const format = [
    { system: "snes", extensions: EXTENSIONS.snes, maximumBytes: MAX_SNES_ROM_BYTES, purpose: "Super NES ROM", fallback: "game.sfc" },
    { system: "megaDrive", extensions: EXTENSIONS.megaDrive, maximumBytes: MAX_MEGA_DRIVE_ROM_BYTES, purpose: "Mega Drive ROM", fallback: "game.bin" },
    { system: "gameBoy", extensions: new Set(["gb"]), unavailable: "Game Boy / Game Boy Color 已从当前开发与产品范围移除，未开放导入。" },
    { system: "gameBoyColor", extensions: new Set(["gbc"]), unavailable: "Game Boy / Game Boy Color 已从当前开发与产品范围移除，未开放导入。" },
    { system: "gameBoyAdvance", extensions: new Set(["gba"]), unavailable: "Game Boy Advance 不在当前开发范围内，未开放导入。" }
  ].find(candidate => candidate.extensions.has(extension(entry.name)));
  if (!format) return null;
  if (format.unavailable) throw new Error(format.unavailable);
  if (requestedSystem && requestedSystem !== format.system) return null;
  const data = await extractZIPEntry(file, entry, {
    maximumBytes: format.maximumBytes,
    purpose: format.purpose
  });
  return { system: format.system, name: safeName(path.posix.basename(entry.name), format.fallback), data };
}

function snesCoprocessorFirmwareNameFromArchiveLabel(value) {
  const label = baseName(String(value || "")).trim();
  const match = label.match(/^(dsp1b|dsp1|dsp2|dsp3|dsp4|cx4|st010|st011|st018)(.*)$/i);
  if (!match) return null;
  const suffix = match[2].trim();
  if (!suffix) return `${match[1].toLowerCase()}.rom`;
  // Preserve No-Intro and browser-generated names such as:
  // ST010 (Japan, USA) (Enhancement Chip) (2).zip.  Parenthetical region,
  // language, revision and duplicate suffixes are metadata, not identities.
  if (!/^\s*(?:\([^()]*\)\s*)+$/.test(match[2]) || !/\(\s*enhancement chip\s*\)/i.test(suffix)) return null;
  return `${match[1].toLowerCase()}.rom`;
}

// No-Intro distributes enhancement-chip firmware as a ZIP whose one `.bin`
// member keeps the same human-readable archive stem (for example
// `CX4 (World) (Enhancement Chip).zip`). Recognize that container before the
// generic single-ROM ZIP path can mistake `.bin` for a Mega Drive cartridge.
// The uploaded file and its member are never renamed; only the private,
// manifest-facing copy receives the stable cx4.rom/dspN.rom/stNNN.rom slot.
async function extractSNESCoprocessorFirmwareFromZIP(file, originalName) {
  if (extension(originalName) !== "zip") return null;
  const outerFirmware = snesCoprocessorFirmwareNameFromArchiveLabel(originalName);
  if (!outerFirmware) return null;
  const entries = (await readZIPCentralDirectory(file)).filter(entry => !isZIPMetadataEntry(entry));
  if (entries.length !== 1) throw new Error("Super NES 增强芯片固件 ZIP 必须只包含一个固件文件。");
  const entry = entries[0];
  const innerFirmware = snesCoprocessorFirmwareNameFromArchiveLabel(path.posix.basename(entry.name));
  if (innerFirmware !== outerFirmware || !["bin", "rom"].includes(extension(entry.name))) {
    throw new Error("Super NES 增强芯片固件 ZIP 的外层名称与内部固件名称不一致。");
  }
  const specification = SNES_COPROCESSOR_FIRMWARE.get(outerFirmware);
  if (entry.bytes !== specification.bytes) {
    throw new Error(`${path.basename(originalName)} 内的 ${path.posix.basename(entry.name)} 必须是精确 ${specification.bytes} 字节。`);
  }
  const data = await extractZIPEntry(file, entry, {
    maximumBytes: specification.bytes,
    purpose: "Super NES 协处理器固件"
  });
  return { name: outerFirmware, originalName: path.basename(originalName), memberName: path.posix.basename(entry.name), data };
}

async function validateNeoGeoBIOSArchive(file) {
  const info = await fsp.stat(file);
  if (!info.isFile() || info.size <= 0 || info.size > MAX_NEOGEO_BIOS_BYTES) {
    throw new Error("Neo Geo BIOS 必须是 16 MB 以内的普通 ZIP 文件。");
  }
  const entries = await readZIPCentralDirectory(file);
  for (const expected of NEOGEO_BIOS_COMPONENTS) {
    const entry = entries.find(item => item.bytes === expected.bytes && item.crc32 === expected.crc32);
    if (!entry) {
      throw new Error(`neogeo.zip 缺少 ${expected.name}（${expected.role}，CRC32 ${expected.crc32}）。`);
    }
    await extractZIPEntry(file, entry, { maximumBytes: expected.bytes, purpose: "Neo Geo BIOS" });
  }
  return hashFile(file);
}

async function validatePGMBIOSArchive(file) {
  const info = await fsp.stat(file);
  if (!info.isFile() || info.size <= 0 || info.size > MAX_PGM_BIOS_BYTES) {
    throw new Error("PGM BIOS 必须是 16 MB 以内的普通 ZIP 文件。");
  }
  const entries = await readZIPCentralDirectory(file);
  for (const expected of PGM_BIOS_COMPONENTS) {
    const entry = entries.find(item => item.bytes === expected.bytes && item.crc32 === expected.crc32);
    if (!entry) {
      throw new Error(`pgm.zip 缺少 ${expected.name}（${expected.role}，CRC32 ${expected.crc32}）。`);
    }
    await extractZIPEntry(file, entry, { maximumBytes: expected.bytes, purpose: "PGM BIOS" });
  }
  return hashFile(file);
}

async function validateFDSBIOSFile(file) {
  const info = await fsp.stat(file);
  if (!info.isFile() || info.size !== FDS_BIOS_BYTES) {
    throw new Error("FDS BIOS 必须是 8 KiB 的普通文件。");
  }
  const data = await fsp.readFile(file);
  const sha1 = crypto.createHash("sha1").update(data).digest("hex");
  if (!FDS_BIOS_SHA1.has(sha1)) {
    throw new Error("FDS BIOS 与 MAME 固定的官方 2C33 BIOS 身份不匹配。");
  }
  return { ...(await hashFile(file)), sha1 };
}

function validateFDSLogicalSide(side) {
  if (!side.length || side[0] !== 1) return;
  let offset = 0;
  const requireBlock = (type, length) => {
    if (length <= 0 || offset + length > side.length || side[offset] !== type) {
      throw new Error("FDS 磁盘块结构无效或已截断。");
    }
    offset += length;
  };
  requireBlock(1, 0x38);
  if (offset + 2 > side.length || side[offset] !== 2) throw new Error("FDS 磁盘缺少文件数量块。");
  const fileCount = side[offset + 1];
  offset += 2;
  for (let index = 0; index < fileCount; index++) {
    if (offset + 0x10 > side.length || side[offset] !== 3) throw new Error("FDS 磁盘缺少文件头块。");
    const fileBytes = side[offset + 0x0d] | (side[offset + 0x0e] << 8);
    offset += 0x10;
    requireBlock(4, 1 + fileBytes);
  }
}

function fdsCRC16(bytes, includeSyncByte) {
  let crc = 0;
  const advance = byte => {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) crc = (crc & 1) ? ((crc >>> 1) ^ 0x8408) : (crc >>> 1);
  };
  if (includeSyncByte) advance(0x80);
  for (const byte of bytes) advance(byte);
  return crc & 0xffff;
}

function validateQuickDiskSide(side) {
  if (side.length !== 65_536 || side[0] !== 1) throw new Error("QD 磁盘面格式无效。");
  let offset = 0;
  const consume = (type, length) => {
    if (offset + length + 2 > side.length || side[offset] !== type) throw new Error("QD 磁盘块结构无效或已截断。");
    const payload = side.subarray(offset, offset + length);
    const stored = side[offset + length] | (side[offset + length + 1] << 8);
    if (stored !== fdsCRC16(payload, true) && stored !== fdsCRC16(payload, false)) {
      throw new Error("QD 磁盘块 CRC-16/KERMIT 不匹配。");
    }
    offset += length + 2;
  };
  consume(1, 0x38);
  if (offset + 4 > side.length || side[offset] !== 2) throw new Error("QD 磁盘缺少文件数量块。");
  const fileCount = side[offset + 1];
  consume(2, 2);
  for (let index = 0; index < fileCount; index++) {
    if (offset + 0x12 > side.length || side[offset] !== 3) throw new Error("QD 磁盘缺少文件头块。");
    const fileBytes = side[offset + 0x0d] | (side[offset + 0x0e] << 8);
    consume(3, 0x10);
    consume(4, 1 + fileBytes);
  }
}

async function validateFDSImage(file, fileName) {
  const data = await fsp.readFile(file);
  const ext = extension(fileName);
  if (ext === "qd") {
    if (!data.length || data.length % 65_536 !== 0) throw new Error("QD 镜像大小必须是 65,536 字节磁盘面的整数倍。");
    for (let offset = 0; offset < data.length; offset += 65_536) validateQuickDiskSide(data.subarray(offset, offset + 65_536));
    return { format: "QD", sides: data.length / 65_536 };
  }
  let offset = 0; let sides;
  if (data.length >= 16 && data.subarray(0, 4).equals(Buffer.from([0x46, 0x44, 0x53, 0x1a]))) {
    sides = data[4]; offset = 16;
    if (!sides || data.length < offset + sides * 65_500) throw new Error("FDS 文件头声明的磁盘面数据不完整。");
  } else {
    if (!data.length || data.length % 65_500 !== 0) throw new Error("FDS 镜像大小必须是 65,500 字节磁盘面的整数倍。");
    sides = data.length / 65_500;
  }
  for (let index = 0; index < sides; index++) {
    validateFDSLogicalSide(data.subarray(offset + index * 65_500, offset + (index + 1) * 65_500));
  }
  return { format: "FDS", sides };
}

async function detectCPS2KeyInArchive(file, system, driver) {
  const metadata = cps2DriverMetadata(system, driver);
  if (!metadata) return { required: false, hex: null, source: null, status: "not-required" };
  if (extension(file) !== "zip") return { required: true, hex: null, source: null, status: "manual-required" };
  const entries = await readZIPCentralDirectory(file);
  const expectedName = metadata.name.toLowerCase();
  const namedEntry = entries.find(entry => path.basename(entry.name).toLowerCase() === expectedName);
  if (namedEntry && (namedEntry.bytes !== 20 || namedEntry.crc32 !== metadata.crc32)) {
    throw new Error(`ROM 内的 ${metadata.name} 与驱动 ${driver} 不匹配。`);
  }
  const matching = entries.find(entry => entry.bytes === 20 && entry.crc32 === metadata.crc32 && entry.name.toLowerCase().endsWith(".key"));
  if (!matching) return { required: true, hex: null, source: null, status: "missing" };
  const key = await extractZIPEntry(file, matching);
  return { required: true, hex: key.toString("hex"), source: "archive", status: "archive" };
}

async function availableCPS2KeyForROM(file, system, driver) {
  const archived = await detectCPS2KeyInArchive(file, system, driver);
  if (!archived.required || archived.hex) return archived;
  const bundled = bundledCPS2KeyHex(system, driver);
  if (!bundled) return archived;
  return { required: true, hex: bundled, source: "manual", status: "builtin" };
}

async function resolvedManifestCPS2Key(manifest, romPath) {
  const driver = manifest.rom?.driver || ((manifest.system === "arcade" || manifest.system === "neoGeo") ? baseName(romPath) : null);
  const metadata = cps2DriverMetadata(manifest.system, driver);
  const declaration = manifest.emulation?.cps2Key;
  if (!metadata) {
    if (declaration) throw new Error("该 ROM 驱动不需要 CPS2 key，请移除 manifest.json 中的 emulation.cps2Key。 ");
    return { required: false, hex: null, source: null, status: "not-required", driver };
  }
  let configuredHex = null;
  if (declaration) {
    if (declaration.format !== "cps2-key-20") throw new Error("CPS2 key format 必须为 cps2-key-20。 ");
    if (declaration.source != null && !["archive", "manual"].includes(declaration.source)) throw new Error("CPS2 key source 只能是 archive 或 manual。 ");
    configuredHex = validateCPS2KeyHex(declaration.hex, manifest.system, driver);
  }
  const archived = await detectCPS2KeyInArchive(romPath, manifest.system, driver);
  if (configuredHex && archived.hex && configuredHex !== archived.hex) {
    throw new Error("ROM 压缩包内的 CPS2 key 与 manifest.json 不一致。 ");
  }
  const bundled = bundledCPS2KeyHex(manifest.system, driver);
  const hex = configuredHex || archived.hex || bundled;
  const configuredStatus = archived.hex ? "verified" : (configuredHex === bundled ? "builtin" : "manifest");
  return {
    required: true,
    hex,
    source: configuredHex ? (declaration.source || "manual") : (archived.source || (bundled ? "manual" : null)),
    status: configuredHex ? configuredStatus : (archived.hex ? archived.status : (bundled ? "builtin" : archived.status)),
    driver
  };
}

function portableIdentifier(value) {
  return typeof value === "string" && value.length >= 1 && value.length <= 64 &&
    !/[^A-Za-z0-9_.-]/.test(value);
}

function portableSHA256(value) {
  return typeof value === "string" && value.length === 64 && !/[^0-9a-f]/.test(value);
}

function portableRevision(value) {
  return typeof value === "string" && (value.length === 40 || value.length === 64) &&
    !/[^0-9a-fA-F]/.test(value);
}

function validatePortableFileDescriptor(file, purpose, allowArcadeDescriptor = false) {
  const parts = String(file?.path || "").split("/");
  if (!file || typeof file.path !== "string" || file.path.startsWith("/") || file.path.includes("\\") ||
      /[\u0000-\u001f\u007f]/.test(file.path) || !parts.length ||
      parts.some(part => !part || part === "." || part === "..") ||
      !Number.isSafeInteger(file.bytes) || file.bytes <= 0 ||
      !portableSHA256(file.sha256) ||
      (!allowArcadeDescriptor && (file.driver != null || file.arcade != null))) {
    throw new Error(`${purpose}文件描述或 SHA-256 无效。`);
  }
}

function validatePortableManifestHardware(manifest) {
  const schemaVersion = manifest?.schemaVersion ?? 1;
  if (schemaVersion !== 1 && schemaVersion !== 2) throw new Error(`不支持 manifest 格式版本 ${schemaVersion}。`);
  if (!MANIFEST_SYSTEMS.includes(manifest?.system) || !manifest?.rom?.path ||
      !EXTENSIONS[manifest.system]?.has(extension(manifest.rom.path))) {
    throw new Error("manifest 的主机或 ROM 扩展名无效。");
  }
  if (schemaVersion === 1) {
    if (manifest.hardware != null) throw new Error("manifest v1 不能声明 hardware；请升级为 v2。");
    return;
  }
  validatePortableFileDescriptor(manifest.rom, "ROM ", true);
  const hardware = manifest.hardware;
  const models = {
    nes: new Set(["nes", "famicom", "famicom-disk-system"]),
    neoGeo: new Set(["arcade-neogeo-mvs"]),
    arcade: new Set(["arcade-cps1", "arcade-cps2", "arcade-sega-outrun", "arcade-sega-system16"]),
    megaDrive: new Set(["sega-mega-drive"]), pgm: new Set(["arcade-igs-pgm1"]),
    snes: new Set(["super-nintendo", "super-famicom"])
  };
  const boardPrefixes = {
    nes: ["nes-", "fds-"], neoGeo: ["neogeo-"], arcade: ["cps1-", "cps2-", "sega-arcade-"],
    megaDrive: ["mega-drive-"], pgm: ["pgm-"], snes: ["snes-"]
  };
  const inputs = {
    nes: new Set(["nes-standard"]), neoGeo: new Set(["arcade-digital"]), arcade: new Set(["arcade-digital"]),
    megaDrive: new Set(["mega-drive-3-button", "mega-drive-6-button"]), pgm: new Set(["arcade-digital"]),
    snes: new Set(["snes-standard", "snes-super-scope"])
  };
  const persistence = {
    nes: new Set(["nes-battery", "fds-side"]),
    neoGeo: new Set(["neogeo-backup-ram", "neogeo-memory-card"]), arcade: new Set(["cps1-eeprom"]),
    megaDrive: new Set(["mega-drive-sram", "mega-drive-eeprom"]), pgm: new Set(["pgm-nvram"]),
    snes: new Set(["snes-sram", "snes-rtc"])
  };
  const regions = new Set(["japan", "usa", "europe", "world", "asia", "korea", "taiwan", "hong-kong"]);
  if (!hardware || hardware.schemaVersion !== 1 || !models[manifest.system]?.has(hardware.model) ||
      !regions.has(hardware.region) || !portableIdentifier(hardware.cartridge?.board) ||
      !boardPrefixes[manifest.system].some(prefix => hardware.cartridge.board.startsWith(prefix)) ||
      !Array.isArray(hardware.cartridge.features) || hardware.cartridge.features.length > 32 ||
      new Set(hardware.cartridge.features).size !== hardware.cartridge.features.length ||
      !hardware.cartridge.features.every(portableIdentifier)) {
    throw new Error("manifest v2 的 model、region 或 cartridge 无效。");
  }
  if (manifest.system === "nes") {
    const diskImage = ["fds", "qd"].includes(extension(manifest.rom.path));
    const diskModel = hardware.model === "famicom-disk-system";
    const diskBoard = hardware.cartridge.board.startsWith("fds-");
    const kinds = new Set(Array.isArray(hardware.persistence)
      ? hardware.persistence.map(item => item.kind) : []);
    if (diskImage !== diskModel || diskImage !== diskBoard ||
        (diskImage ? kinds.has("nes-battery") : kinds.has("fds-side"))) {
      throw new Error("FDS ROM、model、卡带板或持久化声明不一致。");
    }
  }
  if (!Array.isArray(hardware.inputs) || !hardware.inputs.length || hardware.inputs.length > 8 ||
      new Set(hardware.inputs.map(input => input.port)).size !== hardware.inputs.length ||
      !hardware.inputs.every(input => Number.isSafeInteger(input.port) && input.port >= 0 && input.port <= 7 && inputs[manifest.system].has(input.kind))) {
    throw new Error("manifest v2 的输入设备无效或与 system 不一致。");
  }
  if (!Array.isArray(hardware.firmware) || hardware.firmware.length > 16 ||
      new Set(hardware.firmware.map(item => `${item.role}:${item.slot}`)).size !== hardware.firmware.length ||
      !hardware.firmware.every(item => ["system-firmware", "coprocessor-firmware"].includes(item.role) && Number.isSafeInteger(item.slot) && item.slot >= 0 && item.slot <= 0xffffffff)) {
    throw new Error("manifest v2 的固件 role/slot 无效。");
  }
  for (const firmware of hardware.firmware) validatePortableFileDescriptor(firmware.file, "固件");
  if (!Array.isArray(hardware.persistence) || hardware.persistence.length > 16 ||
      new Set(hardware.persistence.map(item => `${item.kind}:${item.slot}`)).size !== hardware.persistence.length ||
      !hardware.persistence.every(item => persistence[manifest.system].has(item.kind) && Number.isSafeInteger(item.slot) && item.slot >= 0 && item.slot <= 0xffffffff && Number.isSafeInteger(item.bytes) && item.bytes > 0 && item.bytes <= 128 * 1024 * 1024)) {
    throw new Error("manifest v2 的持久化区域无效或与 system 不一致。");
  }
  if (manifest.system === "megaDrive") {
    if (!["japan", "usa", "europe", "world"].includes(hardware.region) ||
        hardware.inputs.length > 2 || !hardware.inputs.some(input => input.port === 0) ||
        !hardware.inputs.every(input => input.port === 0 || input.port === 1) ||
        hardware.persistence.length > 1 ||
        hardware.persistence.some(item => item.slot !== 0)) {
      throw new Error("Mega Drive 首发地区、手柄端口或持久化 slot 无效。");
    }
    const medium = hardware.persistence[0] || null;
    const board = hardware.cartridge.board;
    const match = /^mega-drive-eeprom-(sega-171|ea-p1000x|acclaim-16m|acclaim-32m|codemasters-jcart)-(x24c01|x24c02|24c01|24c02|24c04|24c08|24c16|24c32|24c64|24c65|24c128|24c256|24c512)$/.exec(board);
    const capacities = { x24c01: 128, x24c02: 256, "24c01": 128, "24c02": 256,
      "24c04": 512, "24c08": 1024, "24c16": 2048, "24c32": 4096,
      "24c64": 8192, "24c65": 8192, "24c128": 16384,
      "24c256": 32768, "24c512": 65536 };
    if (medium?.kind === "mega-drive-eeprom") {
      if (!match || medium.bytes !== capacities[match[2]]) {
        throw new Error("Mega Drive EEPROM 必须声明精确 PCB、芯片与容量。");
      }
    } else if (board.startsWith("mega-drive-eeprom-")) {
      throw new Error("Mega Drive EEPROM PCB 缺少 EEPROM 持久化声明。");
    }
  }
  if (manifest.system === "snes") {
    const firmware = hardware.firmware;
    // SA-1 reopened on 2026-09-11: the self-developed core runs it on the
    // hosted straight-line scheduler (SN7-SA1-HOSTED-20260911.json), the
    // condition the recorded unsupported boundary named. It publishes with
    // its own 256 KiB BW-RAM ceiling. Super FX uses the GSU-RAM board's exact
    // 32 KiB expansion RAM; that size is not encoded in early Star Fox
    // headers. The standard boards keep their 128 KiB ceiling.
    // Other enhancement-chip identities are published by the server before
    // their product cores open. This lets the owner curate the ROM library
    // once; current Apple/Android clients continue to reject these exact board
    // identities until their own gates are complete.
    const publishedBoards = new Set([
      "snes-lorom", "snes-hirom", "snes-exhirom", "snes-sa1", "snes-superfx", "snes-necdsp",
      "snes-obc1", "snes-sdd1", "snes-cx4", "snes-spc7110", "snes-spc7110-rtc",
      "snes-st010", "snes-st011", "snes-st018"
    ]);
    const persistenceCeiling =
      ["snes-sa1", "snes-sdd1"].includes(hardware.cartridge.board) ? 256 * 1024 : 128 * 1024;
    const isSuperFX = hardware.cartridge.board === "snes-superfx";
    const isOBC1 = hardware.cartridge.board === "snes-obc1";
    const hasRTC = hardware.cartridge.board === "snes-spc7110-rtc";
    const requiredCoprocessorFirmware = new Map([
      ["snes-necdsp", { bytes: 0x2000, names: new Set(["dsp1.rom", "dsp1b.rom", "dsp2.rom", "dsp3.rom", "dsp4.rom"]) }],
      ["snes-cx4", { bytes: 0x0c00, names: new Set(["cx4.rom"]) }],
      ["snes-st010", { bytes: 0x0d000, names: new Set(["st010.rom"]) }],
      ["snes-st011", { bytes: 0x0d000, names: new Set(["st011.rom"]) }],
      ["snes-st018", { bytes: 0x28000, names: new Set(["st018.rom"]) }]
    ]).get(hardware.cartridge.board) || null;
    const exactSNESInputs = isOBC1 ?
      hardware.inputs.length === 1 && hardware.inputs[0].port === 1 &&
        hardware.inputs[0].kind === "snes-super-scope" :
      hardware.inputs.length <= 2 && hardware.inputs.some(input => input.port === 0) &&
        hardware.inputs.every(input => input.kind === "snes-standard");
    const systemFirmware = firmware.filter(item => item.role === "system-firmware");
    const coprocessorFirmware = firmware.filter(item => item.role === "coprocessor-firmware");
    if (!publishedBoards.has(hardware.cartridge.board) ||
        !hardware.cartridge.features.every(feature => feature === "battery" || feature === "rtc") ||
        (hardware.cartridge.features.includes("battery") &&
          !hardware.persistence.some(item => item.kind === "snes-sram")) ||
        (hardware.cartridge.features.includes("rtc") !== hasRTC) ||
        (isSuperFX && (hardware.cartridge.features.includes("battery") !==
          (hardware.persistence.length === 1) ||
          (hardware.persistence.length === 1 &&
            hardware.persistence[0].bytes !== 32 * 1024))) ||
        (isOBC1 && (!hardware.cartridge.features.includes("battery") ||
          hardware.persistence.length !== 1 || hardware.persistence[0].bytes !== 8 * 1024)) ||
        !exactSNESInputs ||
        !hardware.inputs.every(input => input.port === 0 || input.port === 1) ||
        hardware.persistence.length > (hasRTC ? 2 : 1) ||
        !hardware.persistence.every(item =>
          (item.kind === "snes-sram" && item.slot === 0 && item.bytes <= persistenceCeiling) ||
          (hasRTC && item.kind === "snes-rtc" && item.slot === 1 && item.bytes === 16)) ||
        (hasRTC && !hardware.persistence.some(item => item.kind === "snes-rtc")) ||
        systemFirmware.length !== 1 || systemFirmware[0].slot !== 0 || systemFirmware[0].file.bytes !== 64 ||
        firmware.length !== systemFirmware.length + coprocessorFirmware.length ||
        coprocessorFirmware.length !== (requiredCoprocessorFirmware ? 1 : 0) ||
        (requiredCoprocessorFirmware && (coprocessorFirmware[0].slot !== 0 ||
          coprocessorFirmware[0].file.bytes !== requiredCoprocessorFirmware.bytes ||
          !requiredCoprocessorFirmware.names.has(path.basename(coprocessorFirmware[0].file.path).toLowerCase())))) {
      throw new Error("Super NES 卡带 manifest 与板型不一致：必须包含 64 字节 IPL、精确的 SRAM/RTC 声明；DSP、Cx4 与 ST 系列还必须包含对应大小的 coprocessor-firmware。");
    }
  }
  if (!Array.isArray(hardware.referenceTraces) || hardware.referenceTraces.length > 32 ||
      new Set(hardware.referenceTraces.map(trace => trace.id)).size !== hardware.referenceTraces.length) {
    throw new Error("manifest v2 的参考轨迹无效。");
  }
  for (const trace of hardware.referenceTraces) {
    validatePortableFileDescriptor(trace.file, "参考轨迹");
    const checkpoints = trace.checkpoints;
    if (!portableIdentifier(trace.id) || extension(trace.file.path) !== "json" ||
        !Number.isSafeInteger(trace.hardResetSeed) || trace.hardResetSeed < 0 ||
        !Number.isSafeInteger(trace.rtcEpoch) ||
        !Array.isArray(checkpoints) || !checkpoints.length || checkpoints.length > 4096 ||
        !checkpoints.every((frame, index) => Number.isSafeInteger(frame) && frame >= 0 && (!index || frame > checkpoints[index - 1])) ||
        !Array.isArray(trace.references) || !trace.references.length || trace.references.length > 8 ||
        new Set(trace.references.map(reference => reference.name)).size !== trace.references.length ||
        !trace.references.every(reference => portableIdentifier(reference.name) && portableRevision(reference.revision) && portableSHA256(reference.binarySHA256))) {
      throw new Error("manifest v2 的参考轨迹检查点或 reference 身份无效。");
    }
  }
}

async function verifyPortableHardwareFiles(manifest, manifestPath) {
  if (manifest.schemaVersion !== 2) return;
  const descriptors = [
    ...manifest.hardware.firmware.map(item => [item.file, "固件"]),
    ...manifest.hardware.referenceTraces.map(item => [item.file, "参考轨迹"])
  ];
  for (const [file, label] of descriptors) {
    const absolute = resolvedWithin(path.dirname(manifestPath), file.path);
    const details = await hashFile(absolute);
    if (details.bytes !== file.bytes || details.sha256 !== file.sha256) {
      throw new Error(`${label}文件大小或 SHA-256 不匹配。`);
    }
  }
}

async function validateROMFile(file, fileName, system, details) {
  const bytes = Number(details?.bytes) || (await fsp.stat(file)).size;
  if (system === "nes") {
    if (["fds", "qd"].includes(extension(fileName))) {
      await validateFDSImage(file, fileName);
      return;
    }
    const header = await readFileRange(file, 16);
    if (header.toString("ascii", 0, 4) !== "NES\x1a") throw new Error("NES ROM 缺少有效的 iNES/NES 2.0 文件头。 ");
    const minimum = 16 + (header[6] & 4 ? 512 : 0) + header[4] * 16_384 + header[5] * 8_192;
    if (header[4] === 0 || bytes < minimum) throw new Error("NES ROM 的 PRG/CHR 数据不完整，拒绝导入。 ");
    return;
  }
  if (system === "snes") {
    await analyzeSNESROM(file);
    return;
  }
  if (system === "megaDrive") {
    if (bytes < 512 || bytes > 0x400000 + 512 || (bytes & 1) !== 0) {
      throw new Error("Mega Drive ROM 大小超出核心支持范围或不是偶数字节。");
    }
    const probe = await readFileRange(file, Math.min(bytes, 0x4200));
    const ascii = offset => probe.length >= offset + 4 && probe.toString("ascii", offset, offset + 4);
    let linearBytes = 0;
    if (ascii(0x100) === "SEGA" || ascii(0x100) === "ESAG") {
      linearBytes = bytes;
    } else if (bytes > 512 && ascii(0x300) === "SEGA") {
      linearBytes = bytes - 512;
    } else if (bytes > 512 && (bytes - 512) % 0x4000 === 0 && probe.length > 512 + 0x2081 &&
               probe[512 + 0x2080] === 0x53 && probe[512 + 0x80] === 0x45 &&
               probe[512 + 0x2081] === 0x47 && probe[512 + 0x81] === 0x41) {
      linearBytes = bytes - 512;
    } else {
      const half = bytes / 2;
      const upper = await readFileRange(file, 2, half + 0x80);
      const split = upper.length === 2 && upper[0] === 0x53 && probe[0x80] === 0x45 &&
        upper[1] === 0x47 && probe[0x81] === 0x41;
      if (split) linearBytes = bytes;
    }
    if (!linearBytes || linearBytes > 0x400000 || (linearBytes & 1) !== 0) {
      throw new Error("Mega Drive ROM 缺少可识别的 SEGA 卡带头，或者排列格式不受核心支持。");
    }
    return;
  }
  const prefix = await readFileRange(file, 8);
  const ext = extension(fileName);
  const minimumArchiveBytes = 64 * 1024;
  if (bytes < minimumArchiveBytes) throw new Error(`压缩 ROM 仅 ${Math.max(1, Math.round(bytes / 1024))} KB，明显小于可用的 Neo Geo/Arcade ROM 集。`);
  if (ext === "zip") {
    if (prefix.readUInt32LE(0) !== 0x04034b50) throw new Error("ROM 压缩包不是有效的 ZIP 文件。 ");
    const tailLength = Math.min(bytes, 66_000);
    const tail = await readFileRange(file, tailLength, bytes - tailLength);
    const eocd = zipEndOfCentralDirectory(tail);
    if (eocd < 0) throw new Error("ZIP ROM 缺少中央目录，文件可能未下载完整。 ");
    const entries = tail.readUInt16LE(eocd + 10);
    if (entries < 2) throw new Error("ZIP ROM 内没有足够的游戏芯片文件，拒绝导入。 ");
    return;
  }
  if (ext === "7z") {
    if (!prefix.subarray(0, 6).equals(Buffer.from([0x37, 0x7a, 0xbc, 0xaf, 0x27, 0x1c]))) throw new Error("ROM 压缩包不是有效的 7z 文件。 ");
    return;
  }
  throw new Error("不支持的 ROM 文件格式。 ");
}

async function copyIfAbsent(source, destination) {
  await fsp.mkdir(path.dirname(destination), { recursive: true });
  try { await fsp.access(destination); }
  catch { await fsp.copyFile(source, destination); }
}

async function moveOrCopy(source, destination) {
  await fsp.mkdir(path.dirname(destination), { recursive: true });
  try { await fsp.rename(source, destination); }
  catch (error) {
    if (error.code !== "EXDEV") throw error;
    await fsp.copyFile(source, destination); await fsp.unlink(source);
  }
}

async function atomicJSON(file, object) {
  await fsp.mkdir(path.dirname(file), { recursive: true });
  const temporary = `${file}.${randomID()}.tmp`;
  await fsp.writeFile(temporary, `${JSON.stringify(object, null, 2)}\n`);
  await fsp.rename(temporary, file);
}

function defaultCatalog() {
  const createdAt = now();
  return {
    schemaVersion: 1, createdAt, updatedAt: createdAt,
    settings: { title: "FC Emulator Library", sourceDirectory: process.env.FC_LIBRARY_SOURCE_DIRECTORY || "", preferredSearchSites: DEFAULT_PREFERRED_SEARCH_SITES, preferredSearchSitesVersion: PREFERRED_SEARCH_SITES_VERSION, coverDirectory: "", autoMatchThreshold: 0.88 },
    games: [], collections: []
  };
}

function createService(options = {}) {
  const dataRoot = path.resolve(options.dataRoot || process.env.FC_LIBRARY_DATA_DIR || path.join(__dirname, "data"));
  const publicRoot = path.join(__dirname, "public");
  const paths = {
    dataRoot, publicRoot,
    catalog: path.join(dataRoot, "catalog.json"),
    uploads: path.join(dataRoot, "uploads"),
    managedROMs: path.join(dataRoot, "managed", "roms"),
    managedArtwork: path.join(dataRoot, "managed", "artwork"),
    managedBIOS: path.join(dataRoot, "managed", "bios"),
    managedNeoGeoBIOS: path.join(dataRoot, "managed", "bios", "neogeo.zip"),
    managedFDSBIOS: path.join(dataRoot, "managed", "bios", "disksys.rom"),
    managedPGMBIOS: path.join(dataRoot, "managed", "bios", "pgm.zip"),
    managedSNESIPL: path.join(dataRoot, "managed", "bios", "spc700.rom"),
    saves: path.join(dataRoot, "saves"),
    dropbox: path.join(dataRoot, "dropbox"),
    credentials: path.join(dataRoot, "credentials.json"),
    tasks: path.join(dataRoot, "background-tasks.json"),
    researchCache: path.join(dataRoot, "rom-research-cache.json"),
    sourceListCache: path.join(dataRoot, "source-list-cache.json"),
    webCoverTemp: path.join(os.tmpdir(), "FCEmulatorLibraryServer", "web-cover-previews"),
    exportParent: path.join(dataRoot, "export"),
    exportRoot: path.join(dataRoot, "export", "FCEmulatorLibrary")
  };
  let catalog = defaultCatalog();
  let coverCandidates = [];
  const webCoverSearches = new Map();
  const libretroIndexes = new Map();
  const webSearchRuns = new Map();
  const webSearchDiagnostics = new Map();
  const automaticResearch = new Map();
  const backgroundTasks = new Map();
  const pendingBackgroundTasks = [];
  let activeBackgroundTasks = 0;
  let persistTasksTimer = null;
  let sourceRevision = 1;
  let sourceListCache = null;
  let sourceHealthCache = null;
  const canonicalMigrationRoots = new Set();
  let researchCache = { bySHA256: {}, byCRC32: {} };
  let researchCacheWrite = Promise.resolve();
  let deepSeekKey = runtimeSecret("DEEPSEEK_API_KEY", "FCEmulatorLibraryServer.DeepSeek");
  let deepSeekKeySource = process.env.DEEPSEEK_API_KEY ? "环境变量" : (deepSeekKey ? "macOS Keychain" : "未配置");
  let managementToken = String(process.env.FC_LIBRARY_TOKEN || "");
  let writeQueue = Promise.resolve();

  async function initialize() {
    await fsp.rm(paths.webCoverTemp, { recursive: true, force: true });
    await Promise.all([paths.uploads, paths.managedROMs, paths.managedArtwork, paths.managedBIOS, paths.saves, paths.dropbox, paths.exportParent, paths.webCoverTemp]
      .map(directory => fsp.mkdir(directory, { recursive: true })));
    try { catalog = JSON.parse(await fsp.readFile(paths.catalog, "utf8")); }
    catch (error) { if (error.code !== "ENOENT") throw error; await save(); }
    catalog.games ||= []; catalog.collections ||= []; catalog.settings ||= defaultCatalog().settings;
    catalog.settings.sourceDirectory ??= process.env.FC_LIBRARY_SOURCE_DIRECTORY || "";
    catalog.settings.preferredSearchSites = normalisePreferredSearchSites(catalog.settings.preferredSearchSites?.length ? catalog.settings.preferredSearchSites : DEFAULT_PREFERRED_SEARCH_SITES);
    let upgradedPreferredSearchSites = false;
    if ((Number(catalog.settings.preferredSearchSitesVersion) || 1) < PREFERRED_SEARCH_SITES_VERSION) {
      catalog.settings.preferredSearchSites = normalisePreferredSearchSites([
        ...catalog.settings.preferredSearchSites, ...ADDED_PREFERRED_SEARCH_SITES_V2
      ]);
      catalog.settings.preferredSearchSitesVersion = PREFERRED_SEARCH_SITES_VERSION;
      upgradedPreferredSearchSites = true;
    }
    if (String(catalog.settings.sourceDirectory || "").trim()) {
      try {
        const root = path.resolve(catalog.settings.sourceDirectory);
        const [stored, indexStat] = await Promise.all([fsp.readFile(paths.sourceListCache, "utf8").then(JSON.parse), fsp.stat(path.join(root, "library.json"))]);
        const indexSignature = `${indexStat.size}:${indexStat.mtimeMs}`;
        if (stored.directory === root && stored.indexSignature === indexSignature && Array.isArray(stored.value?.roms)) {
          sourceRevision = Math.max(1, Number(stored.revision) || 1);
          stored.value.revision = sourceRevision;
          for (const rom of stored.value.roms) rom.automaticResearch = null;
          sourceListCache = { key: `${root}:${sourceRevision}`, value: stored.value };
        }
      } catch (error) { if (error.code !== "ENOENT") console.warn(`无法读取资料库索引快照：${error.message}`); }
    }
    // Keep editable credentials outside catalog.json.  The file is created
    // with mode 0600 only on hosts without a usable macOS Keychain.
    try {
      const credentials = JSON.parse(await fsp.readFile(paths.credentials, "utf8"));
      if (!deepSeekKey && typeof credentials.deepSeekApiKey === "string" && credentials.deepSeekApiKey.trim()) {
        deepSeekKey = credentials.deepSeekApiKey.trim(); deepSeekKeySource = "服务器私有配置";
      }
      if (!managementToken && typeof credentials.managementToken === "string") managementToken = credentials.managementToken.trim();
    } catch (error) { if (error.code !== "ENOENT") console.warn(`无法读取服务器私有配置：${error.message}`); }
    try {
      const persisted = JSON.parse(await fsp.readFile(paths.tasks, "utf8"));
      for (const saved of Array.isArray(persisted.tasks) ? persisted.tasks : []) {
        const item = { ...saved };
        if (item.state === "queued" || item.state === "running") {
          item.state = "failed"; item.completedAt = now(); item.error = "服务重启，任务已中断；可以重新加入队列。"; item.message = item.error;
        }
        backgroundTasks.set(item.id, item);
      }
    } catch (error) { if (error.code !== "ENOENT") console.warn(`无法读取后台任务记录：${error.message}`); }
    try {
      const storedResearch = JSON.parse(await fsp.readFile(paths.researchCache, "utf8"));
      researchCache = { bySHA256: storedResearch.bySHA256 || {}, byCRC32: storedResearch.byCRC32 || {} };
    } catch (error) { if (error.code !== "ENOENT") console.warn(`无法读取 ROM 指纹资料缓存：${error.message}`); }
    // Covers are supplied by explicit upload or the web-search workflow.  Do
    // not scan a host-local artwork library during normal operation.
    coverCandidates = [];
    if (String(catalog.settings.sourceDirectory || "").trim()) {
      try { await reconcileCanonicalArcadeDrivers(); }
      catch (error) { console.warn(`无法核对街机 driver：${error.message}`); }
      try { await reconcileCanonicalArcadeCollections(); }
      catch (error) { console.warn(`无法核对街机自动合集：${error.message}`); }
    }
    if (upgradedPreferredSearchSites) await save();
  }

  async function save() {
    catalog.updatedAt = now();
    await atomicJSON(paths.catalog, catalog);
  }

  async function savePrivateCredentials(credentials) {
    await fsp.mkdir(paths.dataRoot, { recursive: true });
    let existing = {};
    try { existing = JSON.parse(await fsp.readFile(paths.credentials, "utf8")); } catch (error) { if (error.code !== "ENOENT") throw error; }
    const temporary = `${paths.credentials}.${randomID()}.tmp`;
    await fsp.writeFile(temporary, `${JSON.stringify({ ...existing, ...credentials })}\n`, { mode: 0o600 });
    await fsp.chmod(temporary, 0o600);
    await fsp.rename(temporary, paths.credentials);
  }

  async function configureDeepSeekKey(value) {
    const key = String(value || "").trim();
    if (!key) throw new Error("DeepSeek API Key 不能为空。 ");
    if (key.length < 12 || /[\r\n]/.test(key)) throw new Error("DeepSeek API Key 格式无效。 ");
    // Keychain is preferred on macOS.  NAS/Linux falls back to a mode-0600
    // private file under FC_LIBRARY_DATA_DIR; it is never returned by an API
    // and never mixed into catalog.json or any exported library file.
    if (storeKeychainSecret("FCEmulatorLibraryServer.DeepSeek", key)) {
      await savePrivateCredentials({ deepSeekApiKey: null }); deepSeekKeySource = "macOS Keychain";
    } else {
      await savePrivateCredentials({ deepSeekApiKey: key }); deepSeekKeySource = "服务器私有配置";
    }
    deepSeekKey = key;
  }

  async function configureManagementToken(value) {
    const token = String(value || "").trim();
    if (token.length < 16 || /[\r\n]/.test(token)) throw new Error("管理 Token 至少需要 16 个字符。 ");
    await savePrivateCredentials({ managementToken: token });
    managementToken = token;
  }

  function publicSettings() {
    return {
      ...catalog.settings,
      deepSeekConfigured: Boolean(deepSeekKey),
      deepSeekKeySource: deepSeekKey ? deepSeekKeySource : "未配置",
      managementTokenConfigured: Boolean(managementToken),
      libraryProtectionEnabled: Boolean(managementToken && process.env.FC_LIBRARY_PROTECT_LIBRARY === "1")
    };
  }

  function serializedCatalog() {
    return {
      ...catalog, settings: publicSettings(),
      exportURL: "/library/library.json",
      exportDirectory: paths.exportRoot,
      coverCandidateCount: coverCandidates.length,
      games: catalog.games.map(game => {
        const driver = game.arcadeDriver || ((game.system === "arcade" || game.system === "neoGeo") ? baseName(game.originalName) : null);
        const required = Boolean(cps2DriverMetadata(game.system, driver));
        const hardware = arcadeHardware(game.system, driver);
        return {
          ...game, arcadeDriver: driver, arcadeHardware: hardware?.label || null,
          arcadeHardwareID: hardware?.id || null, cps2KeyRequired: required,
          cps2KeyStatus: required ? (game.cps2Key ? "manual" : "missing") : "not-required",
          coverURL: game.cover ? `/api/games/${encodeURIComponent(game.id)}/cover` : null
        };
      })
    };
  }

  function publicTask(task) {
    const result = task.result?.summary ? { summary: task.result.summary, checkedAt: task.result.checkedAt, full: task.result.full } : task.result || null;
    return {
      id: task.id, type: task.type, title: task.title, state: task.state,
      createdAt: task.createdAt, startedAt: task.startedAt || null, completedAt: task.completedAt || null,
      completed: task.completed || 0, total: task.total || 0, message: task.message || "",
      error: task.error || null, canCancel: task.state === "queued" || task.state === "running", result
    };
  }

  function listBackgroundTasks() {
    return [...backgroundTasks.values()].sort((left, right) => Date.parse(right.createdAt) - Date.parse(left.createdAt))
      .slice(0, 30).map(publicTask);
  }

  function scheduleTaskPersistence() {
    if (persistTasksTimer) return;
    persistTasksTimer = setTimeout(() => {
      persistTasksTimer = null;
      const tasks = listBackgroundTasks();
      atomicJSON(paths.tasks, { schemaVersion: 1, updatedAt: now(), tasks }).catch(error => console.warn(`无法保存后台任务：${error.message}`));
    }, 100);
  }

  function pumpBackgroundTasks() {
    const concurrency = Math.min(3, Math.max(1, Number(process.env.FC_LIBRARY_TASK_CONCURRENCY) || 1));
    while (activeBackgroundTasks < concurrency && pendingBackgroundTasks.length) {
      const queued = pendingBackgroundTasks.shift();
      const item = backgroundTasks.get(queued.id);
      if (!item || item.cancelRequested) {
        if (item) { item.state = "cancelled"; item.completedAt = now(); item.message = "任务已取消。"; scheduleTaskPersistence(); }
        continue;
      }
      activeBackgroundTasks++;
      item.state = "running"; item.startedAt = now(); item.message = "正在处理…"; scheduleTaskPersistence();
      void (async () => {
        try {
          item.result = await queued.run(item);
          item.state = item.cancelRequested ? "cancelled" : "completed";
          item.completedAt = now(); item.message = item.cancelRequested ? "任务已取消。" : (item.message || "已完成。");
        } catch (error) {
          item.state = item.cancelRequested ? "cancelled" : "failed"; item.completedAt = now(); item.error = error.message || "后台任务失败。"; item.message = item.error;
        } finally {
          activeBackgroundTasks--; scheduleTaskPersistence(); pumpBackgroundTasks();
        }
      })();
    }
  }

  function startBackgroundTask({ type, title, total = 0 }, task) {
    const item = { id: randomID(), type, title, total, completed: 0, createdAt: now(), state: "queued", message: "等待执行…" };
    backgroundTasks.set(item.id, item);
    pendingBackgroundTasks.push({ id: item.id, run: task }); scheduleTaskPersistence(); pumpBackgroundTasks();
    return publicTask(item);
  }

  function cancelBackgroundTask(id) {
    const item = backgroundTasks.get(id);
    if (!item || !["queued", "running"].includes(item.state)) throw new Error("后台任务不存在或已经结束。 ");
    item.cancelRequested = true; item.message = item.state === "queued" ? "正在取消…" : "将在当前游戏处理完成后取消…";
    scheduleTaskPersistence(); pumpBackgroundTasks();
    return publicTask(item);
  }

  function transientResearchError(error) {
    return error?.name === "AbortError" || /(?:超时|timeout|请求失败 \((?:429|5\d\d)\)|fetch failed|ECONNRESET|ENOTFOUND)/i.test(String(error?.message || ""));
  }

  async function withResearchRetry(action, task = null) {
    let lastError;
    for (let attempt = 1; attempt <= 3; attempt++) {
      if (task?.cancelRequested) throw new Error("任务已取消。 ");
      try { return await action(); }
      catch (error) {
        lastError = error;
        if (attempt === 3 || !transientResearchError(error)) throw error;
        if (task) task.message = `联网暂时失败，正在进行第 ${attempt + 1} 次尝试…`;
        await new Promise(resolve => setTimeout(resolve, 750 * (2 ** (attempt - 1))));
      }
    }
    throw lastError;
  }

  async function withWrite(task) {
    const mutation = async () => {
      const result = await task();
      sourceRevision++;
      sourceListCache = null;
      sourceHealthCache = null;
      await fsp.rm(paths.sourceListCache, { force: true });
      return result;
    };
    const next = writeQueue.then(mutation, mutation);
    writeQueue = next.catch(() => {});
    return next;
  }

  async function readHeader(file) {
    const handle = await fsp.open(file, "r");
    try { const data = Buffer.alloc(16); await handle.read(data, 0, data.length, 0); return data; }
    finally { await handle.close(); }
  }

  function validateGameInput(input, existing = {}) {
    const game = { ...existing };
    for (const key of ["title", "sortTitle", "chineseTitle", "description", "englishDescription", "region"]) {
      if (Object.hasOwn(input, key)) game[key] = String(input[key] || "").trim() || null;
    }
    if (Object.hasOwn(input, "system")) {
      if (!SYSTEMS.includes(input.system)) throw new Error("不支持的主机类型。");
      game.system = input.system;
    }
    if (Object.hasOwn(input, "category")) {
      if (!(CATEGORIES.includes(input.category) || input.category === "教育" || input.category === "多人")) throw new Error("不支持的分类。");
      game.category = categoryForSystem(input.category, game.system);
    }
    for (const key of ["mapper", "players", "releaseYear"]) {
      if (Object.hasOwn(input, key)) {
        const value = input[key] === "" || input[key] == null ? null : Number(input[key]);
        if (value != null && (!Number.isInteger(value) || value < 0 || value > 10000)) throw new Error(`${key} 必须是合理的整数。`);
        game[key] = value;
      }
    }
    if (Object.hasOwn(input, "cps2Key")) {
      const driver = game.arcadeDriver || ((game.system === "arcade" || game.system === "neoGeo") ? baseName(game.originalName || "") : null);
      const key = validateCPS2KeyHex(input.cps2Key, game.system, driver);
      if (key) game.cps2Key = key;
      else delete game.cps2Key;
    }
    const currentDriver = game.arcadeDriver || ((game.system === "arcade" || game.system === "neoGeo") ? baseName(game.originalName || "") : null);
    if (!cps2DriverMetadata(game.system, currentDriver)) delete game.cps2Key;
    if (!game.title) throw new Error("游戏名称不能为空。");
    if (!EXTENSIONS[game.system].has(game.extension)) throw new Error(`${game.system} 不支持 .${game.extension} 文件。`);
    return game;
  }

  async function ingestFile(source, originalName, options = {}) {
    const fileName = safeName(originalName);
    if (["gb", "gbc"].includes(extension(fileName))) {
      throw new Error("Game Boy / Game Boy Color 已从当前开发与产品范围移除，未开放导入。");
    }
    if (extension(fileName) === "gba") {
      throw new Error("Game Boy Advance 不在当前开发范围内，未开放导入。");
    }
    if (extension(fileName) === "zip" && (!options.system || ["snes", "megaDrive"].includes(options.system))) {
      const cartridge = await extractSingleConsoleROMFromZIP(source, options.system || null);
      if (cartridge) {
        const extracted = path.join(paths.uploads, `${randomID()}-${cartridge.name}`);
        await fsp.writeFile(extracted, cartridge.data, { flag: "wx" });
        try { return await ingestFile(extracted, cartridge.name, { ...options, system: cartridge.system }); }
        finally { await fsp.rm(extracted, { force: true }); }
      }
    }
    const detected = options.system || detectedSystem(fileName);
    if (!detected || !EXTENSIONS[detected]?.has(extension(fileName))) {
      throw new Error("仅支持 NES/FDS (.nes/.fds/.qd)、Super NES (.sfc/.smc 或仅含一个卡带文件的 .zip)、Mega Drive (.bin/.md/.gen 或仅含一个卡带文件的 .zip) 与 Neo Geo/Arcade (.zip/.7z) ROM。");
    }
    if (detected === "snes") throw new Error("Super NES 上传需要先配置公共资料库目录和用户自有的 spc700.rom。");
    const fileHash = await hashFile(source);
    // Confirm bytes ourselves for PGM: a caller-supplied hash is not identity.
    const pgmDriver = identifyPGMArchive(fileHash);
    if (pgmDriver && [options.system, options.metadata?.system].some(value => value && value !== "pgm")) {
      throw new Error("此 ROM 已按完整文件身份识别为 PGM，不能指定为其他系统。");
    }
    if (!pgmDriver && (options.system === "pgm" || options.metadata?.system === "pgm")) {
      throw new Error("PGM ROM 尚未匹配已验证的文件身份。");
    }
    // Reject tiny/truncated containers before reading their central directory
    // for MAME identities, preserving the more actionable integrity error.
    await validateROMFile(source, fileName, detected, fileHash);
    const mameArcade = ["zip", "7z"].includes(extension(fileName))
      ? await identifyMAMECapcomArchive(source, fileName) : null;
    if (mameArcade?.ambiguous) {
      throw new Error(`ROM 芯片同时匹配多个 MAME driver：${mameArcade.ambiguous.join("、")}。请使用标准 driver 文件名消除歧义。`);
    }
    const system = pgmDriver ? "pgm" : options.system || (mameArcade?.driver ? "arcade" : detected);
    if (!system || !EXTENSIONS[system]?.has(extension(fileName))) {
      throw new Error("仅支持 NES/FDS、Super NES、Mega Drive 与 Neo Geo/Arcade ROM。");
    }
    const duplicate = catalog.games.find(game => game.sha256 === fileHash.sha256);
    if (duplicate) {
      if (pgmDriver && (duplicate.system !== "pgm" || duplicate.arcadeDriver !== pgmDriver)) {
        duplicate.system = "pgm";
        duplicate.arcadeDriver = pgmDriver;
        delete duplicate.arcadeDescriptor;
        duplicate.updatedAt = now();
        if (!options.skipSave) await save();
      }
      const driver = duplicate.arcadeDriver || ((duplicate.system === "arcade" || duplicate.system === "neoGeo") ? baseName(duplicate.originalName) : null);
      const available = await availableCPS2KeyForROM(path.join(paths.managedROMs, duplicate.storedName), duplicate.system, driver);
      if (!duplicate.cps2Key && available.hex) {
        duplicate.cps2Key = available.hex; duplicate.updatedAt = now();
        if (!options.skipSave) await save();
      }
      return { game: duplicate, duplicate: true };
    }
    const storedName = `${fileHash.sha256}.${extension(fileName)}`;
    const storedPath = path.join(paths.managedROMs, storedName);
    await copyIfAbsent(source, storedPath);
    const header = system === "nes" && extension(fileName) === "nes" ? await readHeader(storedPath) : Buffer.alloc(0);
    const romInfo = system === "nes" ? romInfoForNESFile(fileName, header) : null;
    const generated = {
      id: `${slug(titleFromFile(fileName))}-${fileHash.sha256.slice(0, 10)}`,
      originalName: fileName,
      title: mameArcade?.title || titleFromFile(fileName), sortTitle: null, chineseTitle: null, description: null, englishDescription: null,
      system, category: "其他", mapper: system === "nes" ? mapperForNESFile(fileName, header) : 0,
      region: null, releaseYear: null, players: null,
      extension: extension(fileName), sha256: fileHash.sha256, crc32: fileHash.crc32, bytes: fileHash.bytes, romInfo,
      storedName, cover: null, createdAt: now(), updatedAt: now(),
      ...(pgmDriver ? { arcadeDriver: pgmDriver } : mameArcade?.driver ? { arcadeDriver: mameArcade.driver, arcadeDescriptor: mameArcade.descriptor } : {})
    };
    const driver = mameArcade?.driver || ((system === "arcade" || system === "neoGeo") ? baseName(fileName) : null);
    const detectedKey = await availableCPS2KeyForROM(storedPath, system, driver);
    if (detectedKey.hex) generated.cps2Key = detectedKey.hex;
    generated.id = uniqueID(generated.id, catalog.games.map(game => game.id));
    const game = validateGameInput(options.metadata || {}, generated);
    catalog.games.push(game);
    if (!options.skipSave) await save();
    return { game, duplicate: false };
  }

  async function ingestTemporaryUpload(file, originalName, options = {}) {
    return withWrite(async () => {
      try { return await ingestFile(file, originalName, options); }
      finally { await fsp.rm(file, { force: true }); }
    });
  }

  async function refreshCoverCandidates() {
    const root = String(catalog.settings.coverDirectory || "").trim();
    if (!root) { coverCandidates = []; return []; }
    const resolved = path.resolve(root);
    let info;
    try { info = await fsp.stat(resolved); } catch { coverCandidates = []; return []; }
    if (!info.isDirectory()) { coverCandidates = []; return []; }
    const results = [];
    async function walk(directory) {
      const entries = await fsp.readdir(directory, { withFileTypes: true });
      for (const entry of entries) {
        const item = path.join(directory, entry.name);
        if (entry.isDirectory()) await walk(item);
        else if (entry.isFile() && IMAGE_EXTENSIONS.has(extension(entry.name))) {
          results.push({ id: sha256(item).slice(0, 20), file: item, name: entry.name, title: titleFromFile(entry.name) });
        }
      }
    }
    await walk(resolved);
    coverCandidates = results.sort((a, b) => a.name.localeCompare(b.name));
    return coverCandidates;
  }

  async function storeCover(game, source, originalName, sourceLabel) {
    const ext = extension(originalName);
    if (!IMAGE_EXTENSIONS.has(ext)) throw new Error("封面仅支持 PNG、JPG 或 WebP。");
    const details = await hashFile(source);
    const storedName = `${details.sha256}.${ext}`;
    await copyIfAbsent(source, path.join(paths.managedArtwork, storedName));
    game.cover = { storedName, extension: ext, sha256: details.sha256, bytes: details.bytes, source: sourceLabel || "upload", updatedAt: now() };
    game.updatedAt = now();
    return game.cover;
  }

  async function matchCover(game, candidateID) {
    const candidate = coverCandidates.find(item => item.id === candidateID);
    if (!candidate) throw new Error("选择的封面已不存在，请刷新封面目录。");
    await storeCover(game, candidate.file, candidate.name, "matched");
    return candidate;
  }

  async function autoMatchCover(game, strict = true) {
    if (game.cover || !coverCandidates.length) return null;
    const candidates = coverCandidates.map(item => ({ ...item, score: Math.max(scoreMatch(game.title, item.title), scoreMatch(game.chineseTitle || "", item.title)) }))
      .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
    const winner = candidates[0];
    const threshold = Number(catalog.settings.autoMatchThreshold || 0.88);
    if (!winner || winner.score < (strict ? threshold : 1.01)) return null;
    await matchCover(game, winner.id);
    return winner;
  }

  function coverMatches(game) {
    return coverCandidates.map(item => ({ id: item.id, name: item.name, title: item.title,
      score: Math.max(scoreMatch(game.title, item.title), scoreMatch(game.chineseTitle || "", item.title)) }))
      .filter(item => item.score > 0).sort((a, b) => b.score - a.score || a.name.localeCompare(b.name)).slice(0, 30);
  }

  function systemSearchName(system) {
    return ({ nes: "Nintendo Entertainment System NES", megaDrive: "Sega Mega Drive Genesis",
      neoGeo: "Neo Geo", arcade: "arcade" })[system] || system;
  }

  function searchEvidence(game) {
    return JSON.stringify({
      originalFileName: game.originalName, parsedTitle: game.title, chineseTitle: game.chineseTitle || null,
      arcadeDriver: game.arcadeDriver || null,
      englishDescription: String(game.englishDescription || "").slice(0, 800) || null,
      chineseDescription: String(game.description || "").slice(0, 800) || null,
      platform: systemSearchName(game.system), mapper: game.system === "nes" ? game.mapper : undefined,
      bytes: game.bytes, crc32: game.crc32 || null, sha256: game.sha256, romHeader: game.romInfo || null
    });
  }

  function normalisePreferredSearchSites(value) {
    const values = Array.isArray(value) ? value : String(value || "").split(/[\n,]/);
    const seen = new Set();
    return values.map(item => String(item || "").trim()).map(item => {
      if (!item) return "";
      try {
        const url = new URL(/^https?:\/\//i.test(item) ? item : "https://" + item);
        if (url.protocol !== "https:" && url.protocol !== "http:") return "";
        url.hash = "";
        return url.href;
      } catch { return ""; }
    }).filter(url => url && !seen.has(url) && seen.add(url)).slice(0, 20);
  }

  function preferredSearchInstruction(fallbackToPublic = false) {
    const sites = normalisePreferredSearchSites(catalog.settings.preferredSearchSites);
    if (!sites.length) return "No preferred websites are configured; search the public web normally.";
    const domains = [...new Set(sites.map(site => new URL(site).hostname))];
    const internalSearch = [];
    if (domains.includes("gamesdb.launchbox-app.com")) internalSearch.push("LaunchBox: https://gamesdb.launchbox-app.com/games/search");
    if (domains.includes("www.arcadeartwork.org")) internalSearch.push("Arcade Artwork: https://www.arcadeartwork.org/search.php");
    if (domains.includes("flyers.arcade-museum.com")) internalSearch.push("The Arcade Flyer Archive: https://flyers.arcade-museum.com/");
    if (domains.includes("www.coverbrowser.com")) internalSearch.push("Cover Browser: https://www.coverbrowser.com/search");
    if (domains.includes("archive.org")) internalSearch.push("Internet Archive public search: https://archive.org/advancedsearch.php");
    if (domains.includes("thumbnails.libretro.com")) internalSearch.push("Libretro Thumbnails: use only the platform's Named_Boxarts directory, never Named_Snaps or Named_Titles");
    if (domains.includes("adb.arcadeitalia.net")) internalSearch.push("Arcade Italia MAME database: https://adb.arcadeitalia.net/lista_mame.php");
    if (domains.includes("www.progettosnaps.net")) internalSearch.push("Progetto-SNAPS flyers: https://www.progettosnaps.net/flyers/");
    if (domains.includes("www.gamesdatabase.org")) internalSearch.push("Games Database: https://www.gamesdatabase.org/");
    if (fallbackToPublic) return "Search the public web for verified flat artwork, but prefer these configured sources when possible: " + domains.join(", ") + ". Do not use or bypass credential-required APIs.";
    return "Search these configured websites first: " + domains.join(", ") + ". First use each available site-internal search page: " + internalSearch.join("; ") + ". If none provides verifiable flat artwork, then make one public-web fallback search. ScreenScraper and MobyGames APIs require separately configured provider credentials; do not fabricate or bypass credentials.";
  }

  function preferredSearchScope() {
    return [...new Set(normalisePreferredSearchSites(catalog.settings.preferredSearchSites).map(site => new URL(site).hostname))];
  }

  function reserveWebSearch(gameID) {
    const nowTime = Date.now();
    const recent = (webSearchRuns.get(gameID) || []).filter(time => nowTime - time < 60_000);
    if (recent.length >= 3) throw new Error("此游戏的联网识别请求过于频繁，请稍后再试。");
    recent.push(nowTime); webSearchRuns.set(gameID, recent);
  }

  function webSearchKey(game) {
    const identity = game.searchID || game.id;
    const evidence = [game.title, game.chineseTitle, game.description, game.englishDescription,
      game.system, game.region, game.sha256,
      ...normalisePreferredSearchSites(catalog.settings.preferredSearchSites)].map(value => String(value || "")).join("\n");
    return `${identity}:${sha256(evidence).slice(0, 16)}`;
  }

  function recordWebSearchDiagnostic(game, response, payload) {
    const previous = webSearchDiagnostics.get(webSearchKey(game)) || {};
    const output = (payload.output || []).map(item => ({
      type: item.type || null, status: item.status || null,
      text: (item.content || []).map(part => String(part.text || "")).join("\n").slice(0, 2_000)
    }));
    webSearchDiagnostics.set(webSearchKey(game), {
      ...previous,
      checkedAt: now(), httpStatus: response.status, responseStatus: payload.status || null,
      error: payload.error?.message || null, outputText: String(payload.output_text || "").slice(0, 2_000), output
    });
  }

  function recordSearchStage(game, name, startedAt, details = {}) {
    const key = webSearchKey(game); const previous = webSearchDiagnostics.get(key) || {};
    const stages = [...(previous.stages || []).filter(stage => stage.name !== name), { name, durationMs: Date.now() - startedAt, ...details }];
    webSearchDiagnostics.set(key, { ...previous, checkedAt: now(), stages });
  }

  function webSearchDiagnostic(game) {
    return webSearchDiagnostics.get(webSearchKey(game)) || null;
  }

  function cachedWebCoverResult(game) {
    const search = webCoverSearches.get(webSearchKey(game));
    if (!search || search.expiresAt < Date.now()) { if (search) webCoverSearches.delete(webSearchKey(game)); return null; }
    return {
      query: search.query || game.title,
      scope: preferredSearchScope(),
      fallbackUsed: Boolean(search.fallbackUsed),
      cached: true,
      candidates: [...search.candidates.values()].map(({ id, title, source }) => ({ id, title, source }))
    };
  }

  function responseOutputText(payload) {
    return payload.output_text || payload.output?.filter(item => item.type === "message")
      .flatMap(item => item.content || []).filter(item => item.type === "output_text").map(item => item.text).join("\n") || "";
  }

  function parseResearchJSON(content, fallbackTitle) {
    try { return JSON.parse(content); }
    catch {
      // Some DeepSeek web-search turns expose their verified tool plan as
      // text instead of honouring JSON mode. Keep only public URLs from that
      // plan; they still go through the same SSRF checks and image validation
      // before they can become a cover.
      const seen = new Set();
      const candidates = [...String(content).matchAll(/https?:\/\/[^\s<>"']+/gi)].map(match => match[0])
        .filter(url => { if (seen.has(url)) return false; seen.add(url); return true; })
        .slice(0, 8).map(url => ({
          title: fallbackTitle,
          image_url: /\.(?:png|jpe?g|webp)(?:[?#].*)?$/i.test(url) ? url : null,
          source_url: url
        }));
      const saysArtwork = /\b(?:box[ _-]?(?:art|front)|cover(?:\s+art)?|flyer|poster|marquee)\b/i.test(String(content));
      return {
        query: fallbackTitle,
        candidates: saysArtwork ? candidates.map(candidate => ({ ...candidate, title: `${fallbackTitle} box art`, artwork_type: "box_art" })) : candidates,
        metadata: {}
      };
    }
  }

  function posterCandidate(item) {
    let artworkType = String(item.artwork_type || item.artworkType || "").toLowerCase();
    const framing = String(item.framing || "").toLowerCase();
    const mediaLabel = String(item.media_label || item.mediaLabel || "").trim();
    const allowed = new Set(["box_art", "flyer", "poster", "cover", "marquee"]);
    const flatArtwork = new Set(["flat_cover_scan", "flat_poster", "flat_flyer", "flat_marquee"]);
    const imageURL = String(item.image_url || "").trim();
    const source = String(item.source_url || "").trim();
    const evidence = [String(item.title || ""), mediaLabel, imageURL, source].join(" ");
    // DeepSeek sometimes omits the framing field even after it has found a
    // clearly labelled database asset.  Trust explicit source media labels,
    // but never infer a cover from a cartridge label, screenshot, or product
    // photo.  In particular, LaunchBox lists "Nintendo Box Art" alongside
    // "Famicom Cartridge Label" for the same game.
    if (/screenshot|screen[ _-]?shot|gameplay|in[ _-]?game|ingame|title[ _-]?screen|snapshot|cartridge|cart[ _-]?only|label|physical[ _-]?product|product[ _-]?photo|console[ _-]?photo|photographed|photo of/i.test(evidence)) return null;
    if (!artworkType && /box[ _-]?art|box[ _-]?front|cover/i.test(evidence)) artworkType = "box_art";
    else if (!artworkType && /flyer/i.test(evidence)) artworkType = "flyer";
    else if (!artworkType && /poster/i.test(evidence)) artworkType = "poster";
    else if (!artworkType && /marquee/i.test(evidence)) artworkType = "marquee";
    if (!allowed.has(artworkType)) return null;
    if (framing && !flatArtwork.has(framing)) return null;
    if (!/^https?:\/\//i.test(source) || (imageURL && !/^https?:\/\//i.test(imageURL))) return null;
    return { artworkType, imageURL: imageURL || null, source };
  }

  function launchBoxPlatformName(system) {
    return ({ nes: "Nintendo Entertainment System", megaDrive: "Sega Genesis",
      snes: "Super Nintendo Entertainment System", neoGeo: "SNK Neo Geo AES", arcade: "Arcade" })[system] || "";
  }

  // A web-search response is excellent at identifying a ROM, but it is not a
  // dependable image index: some DeepSeek turns return metadata and an empty
  // candidates array.  LaunchBox has a public, platform-filtered results page
  // and labels every image type, so use it as a narrowly scoped supplement to
  // the configured-source search—not as an unrestricted image scraper.
  async function launchBoxBoxArtCandidates(game) {
    if (!preferredSearchScope().includes("gamesdb.launchbox-app.com")) return [];
    const title = String(game.title || "").trim();
    if (!title) return [];
    try {
      const params = new URLSearchParams({ title });
      const platform = launchBoxPlatformName(game.system);
      if (platform) params.set("platform", platform);
      const resultsURL = `https://gamesdb.launchbox-app.com/games/results/?${params}`;
      const sourceTimeout = Number(process.env.FC_LIBRARY_PREFERRED_SOURCE_TIMEOUT_MS || 6_000);
      const resultsHTML = await fetchRemoteHTML(resultsURL, sourceTimeout);
      const matches = [...resultsHTML.matchAll(/<a\b[^>]*href=["']\/?games\/details\/([^"']+)["'][^>]*>[\s\S]{0,2200}?<h3\b[^>]*>\s*([^<]+?)\s*<\/h3>/gi)]
        .map(match => ({ slug: match[1], title: match[2].replace(/&amp;/g, "&").trim(), score: scoreMatch(title, match[2]) }))
        .filter(match => match.score >= 0.94)
        .sort((left, right) => right.score - left.score || left.title.length - right.title.length);
      const match = matches[0];
      if (!match) return [];
      const source = `https://gamesdb.launchbox-app.com/games/images/${match.slug}`;
      const imagesHTML = await fetchRemoteHTML(source, sourceTimeout);
      const result = [];
      for (const tag of imagesHTML.match(/<a\b[^>]*>/gi) || []) {
        const imageURL = htmlAttribute(tag, "href");
        const mediaLabel = htmlAttribute(tag, "data-title").replace(/&amp;/g, "&");
        if (!/^https:\/\/images\.launchbox-app\.com\//i.test(imageURL) || !/\bbox\s*-?\s*(?:front|art)\b/i.test(mediaLabel)) continue;
        const candidate = posterCandidate({ title: `${match.title} / ${mediaLabel}`, media_label: mediaLabel,
          artwork_type: "box_art", framing: "flat_cover_scan", image_url: imageURL, source_url: source });
        if (candidate) result.push({ id: randomID(), title: `${match.title} / ${mediaLabel}`.slice(0, 240), trustedSource: "LaunchBox", ...candidate });
      }
      return result.slice(0, 4);
    } catch (error) {
      console.warn(`LaunchBox 封面补偿检索失败：${error?.message || "未知错误"}`);
      return [];
    }
  }

  function configuredArchiveIdentifiers() {
    const identifiers = new Set();
    for (const value of normalisePreferredSearchSites(catalog.settings.preferredSearchSites)) {
      const url = new URL(value);
      if (url.hostname !== "archive.org" && url.hostname !== "www.archive.org") continue;
      const match = url.pathname.match(/^\/(?:download|details)\/([^/]+)/);
      if (match) identifiers.add(decodeURIComponent(match[1]));
    }
    return [...identifiers].slice(0, 8);
  }

  async function archiveArtworkCandidates(game) {
    const identifiers = configuredArchiveIdentifiers();
    if (!identifiers.length) return [];
    const candidates = [];
    await Promise.all(identifiers.map(async identifier => {
      try {
        const metadata = await fetchRemoteJSON(`https://archive.org/metadata/${encodeURIComponent(identifier)}`, Number(process.env.FC_LIBRARY_PREFERRED_SOURCE_TIMEOUT_MS || 6_000));
        for (const file of Array.isArray(metadata.files) ? metadata.files : []) {
          const name = String(file?.name || "");
          if (!/\.(?:png|jpe?g|webp)$/i.test(name) || /(?:thumb|screenshot|screen[ _-]?shot|gameplay|title[ _-]?screen|back|spine|cart|label)/i.test(name)) continue;
          const candidateTitle = titleFromFile(path.posix.basename(name));
          const match = Math.max(scoreMatch(game.title, candidateTitle), scoreMatch(game.chineseTitle || "", candidateTitle), scoreMatch(titleFromFile(game.originalName || ""), candidateTitle));
          if (match < 0.72) continue;
          const imageURL = `https://archive.org/download/${encodeURIComponent(identifier)}/${name.split("/").map(encodeURIComponent).join("/")}`;
          candidates.push({
            id: randomID(), title: `${candidateTitle} / Internet Archive cover`, artworkType: "box_art",
            imageURL, source: `https://archive.org/details/${encodeURIComponent(identifier)}`,
            trustedSource: "Internet Archive", titleScore: match
          });
        }
      } catch (error) { console.warn(`Internet Archive 封面检索失败（${identifier}）：${error?.message || "未知错误"}`); }
    }));
    return candidates.sort((left, right) => (right.titleScore || 0) - (left.titleScore || 0)).slice(0, 4);
  }

  async function libretroBoxArtCandidates(game) {
    if (!preferredSearchScope().includes("thumbnails.libretro.com")) return [];
    const playlists = libretroPlaylists(game.system);
    if (!playlists.length) return [];
    const sourceTimeout = Number(process.env.FC_LIBRARY_PREFERRED_SOURCE_TIMEOUT_MS || 6_000);
    const matches = await Promise.allSettled(playlists.map(async playlist => {
      const directoryURL = `https://thumbnails.libretro.com/${encodeURIComponent(playlist)}/Named_Boxarts/`;
      let cached = libretroIndexes.get(directoryURL);
      if (!cached || cached.expiresAt < Date.now()) {
        const html = await fetchRemoteHTML(directoryURL, sourceTimeout, 5 * 1024 * 1024);
        cached = { expiresAt: Date.now() + 12 * 60 * 60_000, entries: libretroThumbnailEntries(html, directoryURL) };
        libretroIndexes.set(directoryURL, cached);
      }
      return libretroBoxArtMatches(cached.entries, game, 4).map(match => ({
        id: randomID(),
        title: `${baseName(match.fileName)} / Libretro ${game.system === "arcade" ? "arcade flyer" : "box art"}`.slice(0, 240),
        artworkType: game.system === "arcade" ? "flyer" : "box_art",
        imageURL: match.imageURL,
        source: directoryURL,
        trustedSource: "Libretro",
        titleScore: match.titleScore
      }));
    }));
    for (const result of matches) if (result.status === "rejected") {
      console.warn(`Libretro 封面索引读取失败：${result.reason?.message || "未知错误"}`);
    }
    const seen = new Set();
    return matches.flatMap(result => result.status === "fulfilled" ? result.value : []).filter(candidate => {
      if (seen.has(candidate.imageURL)) return false;
      seen.add(candidate.imageURL); return true;
    }).sort((left, right) => right.titleScore - left.titleScore).slice(0, 4);
  }

  async function directPreferredCoverCandidates(game) {
    const providers = Array.isArray(options.preferredCoverProviders) ? options.preferredCoverProviders : [launchBoxBoxArtCandidates, archiveArtworkCandidates, libretroBoxArtCandidates];
    const results = await Promise.allSettled(providers.map(provider => provider(game)));
    const seen = new Set();
    return results.flatMap(result => result.status === "fulfilled" ? result.value : []).filter(candidate => {
      const identity = candidate.imageURL || candidate.source;
      if (!identity || seen.has(identity)) return false;
      seen.add(identity); return true;
    }).slice(0, 8);
  }

  async function supplementPreferredCoverCandidates(game, candidates, preferredCandidates = null) {
    const preferred = preferredCandidates || await directPreferredCoverCandidates(game);
    const seen = new Set();
    return [...preferred, ...candidates].filter(candidate => {
      const identity = candidate.imageURL || candidate.source;
      if (!identity || seen.has(identity)) return false;
      seen.add(identity); return true;
    }).slice(0, 4);
  }

  async function completeWebSearchResponse({ game, endpoint, instructions, input, payload, maxOutputTokens, signal }) {
    let current = payload;
    // DeepSeek's Responses API is stateless. A web_search_call is an output
    // item, not the final answer: feed it back unchanged so the service can
    // restore its search results and let the model write the JSON conclusion.
    for (let round = 0; round < 3; round++) {
      const content = responseOutputText(current);
      if (content.trim()) return content;
      if (!(current.output || []).some(item => item.type === "web_search_call")) return "{}";
      const response = await fetch(endpoint, {
        method: "POST", signal,
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${deepSeekKey}` },
        body: JSON.stringify({
          model: process.env.DEEPSEEK_WEB_SEARCH_MODEL || "deepseek-v4-flash", instructions,
          input: [{ role: "user", content: input }, ...(current.output || [])],
          // The search results above are already restored by DeepSeek. Force
          // this continuation to synthesise them instead of starting another
          // search-only turn that can end without a message.
          tools: [{ type: "web_search" }], tool_choice: "none",
          reasoning: { effort: "none" }, max_output_tokens: maxOutputTokens,
          text: { format: { type: "json_object" } }
        })
      });
      if (!response.ok) throw new Error(`DeepSeek Web Search 请求失败 (${response.status})`);
      current = await response.json();
      recordWebSearchDiagnostic(game, response, current);
    }
    return responseOutputText(current) || "{}";
  }

  function localROMResearch(game) {
    const title = String(game.title || game.originalName || "未命名游戏").trim();
    const metadata = { title, sortTitle: title };
    if (SYSTEMS.includes(game.system)) metadata.system = game.system;
    if (typeof game.region === "string" && game.region.trim()) metadata.region = game.region.trim();
    return {
      metadata, candidates: [], query: title, scope: preferredSearchScope(), fallbackUsed: false,
      localFallback: true,
      message: "未配置 DeepSeek API Key，已使用 ROM 文件名、主机、地区和 ROM 头信息建立本地资料；配置 Key 后可联网补充译名、说明和海报。"
    };
  }

  function cachedFingerprintMetadata(game) {
    const entry = (game.sha256 && researchCache.bySHA256[String(game.sha256).toLowerCase()]) || (game.crc32 && researchCache.byCRC32[String(game.crc32).toLowerCase()]);
    return entry?.metadata && typeof entry.metadata === "object" ? structuredClone(entry.metadata) : null;
  }

  function rememberFingerprintMetadata(game, metadata) {
    if (!metadata || !Object.keys(metadata).length) return;
    const entry = { metadata: structuredClone(metadata), updatedAt: now(), source: "DeepSeek Web Search" };
    if (game.sha256) researchCache.bySHA256[String(game.sha256).toLowerCase()] = entry;
    if (game.crc32) researchCache.byCRC32[String(game.crc32).toLowerCase()] = entry;
    researchCacheWrite = researchCacheWrite.then(() => atomicJSON(paths.researchCache, { schemaVersion: 1, ...researchCache })).catch(error => console.warn(`无法保存 ROM 指纹资料缓存：${error.message}`));
  }

  async function createWebCoverSearch(game, fallbackToPublic = false) {
    const searchKey = webSearchKey(game);
    const cachedResult = cachedWebCoverResult(game);
    if (cachedResult) return cachedResult;
    // Query the configured, explicitly labelled artwork database first.  A
    // successful result avoids a slow agentic web-search call altogether.
    const preferredStartedAt = Date.now();
    const preferredCandidates = await cacheSearchCandidates(await directPreferredCoverCandidates(game), game);
    recordSearchStage(game, "优先站点直查", preferredStartedAt, { candidates: preferredCandidates.length });
    if (preferredCandidates.length) {
      webCoverSearches.set(searchKey, { expiresAt: Date.now() + 10 * 60_000, query: game.title, fallbackUsed: false, candidates: new Map(preferredCandidates.map(item => [item.id, item])) });
      return { query: game.title, scope: preferredSearchScope(), fallbackUsed: false, candidates: preferredCandidates.map(({ id, title, source }) => ({ id, title, source })) };
    }
    if (!deepSeekKey) {
      webCoverSearches.set(searchKey, { expiresAt: Date.now() + 10 * 60_000, query: game.title, fallbackUsed: false, candidates: new Map() });
      return { query: game.title, scope: preferredSearchScope(), fallbackUsed: false, localFallback: true, candidates: [], message: "已直查配置的公开封面站点，但没有找到可验证的图片；配置 DeepSeek API Key 后可继续搜索公开网页。" };
    }
    reserveWebSearch(searchKey);
    const endpoint = process.env.DEEPSEEK_RESPONSES_BASE_URL || "https://api.deepseek.com/responses";
    const controller = new AbortController();
    // Web Search includes a server-side search round trip.  Thirty seconds is
    // regularly insufficient even when the API is healthy, so keep a bounded
    // but practical default while allowing NAS deployments to tune it.
    const timeout = setTimeout(() => controller.abort(), Number(process.env.DEEPSEEK_TIMEOUT_MS || 90_000));
    try {
      const instructions = 'Act as a ROM-cover research agent. First use web search to identify the exact game and platform from the supplied ROM evidence. Then search specifically for official posters, arcade flyers, front box art, cabinet marquee art, publisher key art, or flat cover scans from reliable game databases and archives. NEVER use gameplay, in-game screenshots, title screens, MAME snapshots, video thumbnails, physical cartridges, cartridge labels, photographed boxes, console hardware, shelves, desks, or product photos as a cover. A usable image is flat artwork only, filling the image frame without a photographed physical object around it. For LaunchBox, inspect the game Images page and choose an asset explicitly labelled Nintendo Box Art or Box Front; reject Famicom Cartridge Label. Preserve the source page media label verbatim in media_label. If flat poster-like artwork cannot be verified, return no candidate. Evaluate source/platform/region consistency before answering. Return JSON only: {"query":"string","candidates":[{"title":"string","media_label":"exact source media label","artwork_type":"box_art|flyer|poster|cover|marquee","framing":"flat_cover_scan|flat_poster|flat_flyer|flat_marquee","image_url":"absolute direct image URL or null","source_url":"specific evidence page URL"}]}. Include at most 8 evidence-backed candidates, best first. A candidate must have a specific source page from web search. If the page has no direct image URL in the search result, use null; the manager will safely inspect og:image metadata. Never invent URLs or output tool-call markup.';
      const researchInput = `Find box art using this ROM evidence: ${searchEvidence(game)}. Current region: ${game.region || "unknown"}. Use the filename, platform, mapper, size, CRC and ROM header only to disambiguate variants.`;
      const restrictedInput = researchInput + " " + preferredSearchInstruction(fallbackToPublic);
      const response = await fetch(endpoint, {
        method: "POST", signal: controller.signal,
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${deepSeekKey}` },
        body: JSON.stringify({
          model: process.env.DEEPSEEK_WEB_SEARCH_MODEL || "deepseek-v4-flash",
          instructions, input: restrictedInput,
          // A specifically selected web_search tool can finish with only
          // web_search_call items and no assistant message.  `required`
          // still guarantees a server-side search, then permits the model to
          // return the JSON result consumed by this manager.
          tools: [{ type: "web_search" }], tool_choice: "required",
          reasoning: { effort: "none" }, max_output_tokens: 1_200,
          text: { format: { type: "json_object" } }
        })
      });
      if (!response.ok) throw new Error(`DeepSeek Web Search 请求失败 (${response.status})`);
      const payload = await response.json();
      recordSearchStage(game, "DeepSeek 首次响应", preferredStartedAt, { httpStatus: response.status });
      recordWebSearchDiagnostic(game, response, payload);
      const content = await completeWebSearchResponse({ game, endpoint, instructions, input: restrictedInput, payload, maxOutputTokens: 1_200, signal: controller.signal });
      const parsed = parseResearchJSON(content, game.title);
      const seen = new Set();
      let candidates = (Array.isArray(parsed.candidates) ? parsed.candidates : []).map(item => {
        const poster = posterCandidate(item);
        if (!poster) return null;
        const { imageURL, source, artworkType } = poster;
        const identity = imageURL || source;
        if (seen.has(identity)) return null;
        seen.add(identity);
        return { id: randomID(), title: String(item.title || game.title).slice(0, 240), artworkType, imageURL, source };
      }).filter(Boolean).slice(0, 8);
      candidates = await supplementPreferredCoverCandidates(game, candidates, []);
      const cachedCandidates = await cacheSearchCandidates(candidates, game);
      const fallbackUsed = fallbackToPublic || cachedCandidates.some(candidate => !preferredSearchScope().includes(new URL(candidate.source).hostname));
      webCoverSearches.set(searchKey, { expiresAt: Date.now() + 10 * 60_000, query: String(parsed.query || game.title).slice(0, 240), fallbackUsed, candidates: new Map(cachedCandidates.map(item => [item.id, item])) });
      return { query: String(parsed.query || game.title).slice(0, 240), scope: preferredSearchScope(), fallbackUsed, candidates: cachedCandidates.map(({ id, title, source }) => ({ id, title, source })) };
    } catch (error) {
      if (error.name === "AbortError") throw new Error("DeepSeek Web Search 超时。");
      throw error;
    } finally { clearTimeout(timeout); }
  }

  async function searchGameMetadata(game, fallbackToPublic = false, researchOptions = {}) {
    const includeCoverCandidates = researchOptions.includeCoverCandidates !== false;
    const fingerprintMetadata = cachedFingerprintMetadata(game);
    if (fingerprintMetadata) {
      const candidates = includeCoverCandidates ? await cacheSearchCandidates(await directPreferredCoverCandidates(game), game) : [];
      if (candidates.length) webCoverSearches.set(webSearchKey(game), { expiresAt: Date.now() + 10 * 60_000, query: game.title, metadata: fingerprintMetadata, fallbackUsed: false, candidates: new Map(candidates.map(item => [item.id, item])) });
      return { metadata: fingerprintMetadata, scope: preferredSearchScope(), fallbackUsed: false, fingerprintCache: true, candidates: candidates.map(({ id, title, source }) => ({ id, title, source })) };
    }
    if (!deepSeekKey) {
      const local = localROMResearch(game);
      const candidates = includeCoverCandidates ? await cacheSearchCandidates(await directPreferredCoverCandidates(game), game) : [];
      if (candidates.length) {
        webCoverSearches.set(webSearchKey(game), { expiresAt: Date.now() + 10 * 60_000, query: game.title, metadata: local.metadata, fallbackUsed: false, candidates: new Map(candidates.map(item => [item.id, item])) });
      }
      return { ...local, candidates: candidates.map(({ id, title, source }) => ({ id, title, source })), message: candidates.length ? "未配置 DeepSeek，已使用 ROM 本地信息并从公开优先站点找到封面。" : local.message };
    }
    const searchKey = webSearchKey(game);
    reserveWebSearch(searchKey);
    const endpoint = process.env.DEEPSEEK_RESPONSES_BASE_URL || "https://api.deepseek.com/responses";
    const preferredStartedAt = Date.now();
    const preferredCandidatesPromise = includeCoverCandidates ? directPreferredCoverCandidates(game) : Promise.resolve([]);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), Number(process.env.DEEPSEEK_TIMEOUT_MS || 90_000));
    try {
      const driverRule = ' For Arcade or Neo Geo, arcadeDriver is the immutable hardware-driver identity. Match that exact parent/clone/hack set; never borrow a subtitle, description, year, or artwork from a similarly named parent, clone, bootleg, or hack.';
      const metadataContract = '{"title":"canonical English title in Latin letters only","chineseTitle":"Simplified Chinese title|null","system":"nes|megaDrive|neoGeo|arcade","region":"string|null","releaseYear":number|null,"players":number|null,"category":"one allowed Chinese category|null","sortTitle":"English sort title|null","description":"Simplified Chinese description|null","englishDescription":"English description|null"}';
      const sharedRules = 'The title MUST be English in Latin letters, never Chinese, Japanese, Korean, or pinyin. Translate non-English names and descriptions into both Simplified Chinese and English. For NES, category describes gameplay and must not be 街机 merely because the game was ported from an arcade release. Use null for unsupported facts. Never invent facts, URLs, or tool-call markup. Categories allowed: 经典, 动作, 闯关, 射击, 格斗, 体育, 竞速, 益智, 冒险, 角色扮演, 策略, 模拟, 街机, 破解, 其他.';
      const instructions = (includeCoverCandidates
        ? 'Act as a game-research agent. Use web search to identify the exact game from ROM evidence and cross-check platform and region using multiple results when possible. Find only reliable flat poster, flyer, box-art, marquee, or cover source pages; reject gameplay, screenshots, title screens, thumbnails, cartridges, labels, photographed boxes, hardware and product photos. For LaunchBox choose only Nintendo Box Art or Box Front. Return JSON only: {"metadata":' + metadataContract + ',"candidates":[{"title":"string","media_label":"exact source media label","artwork_type":"box_art|flyer|poster|cover|marquee","framing":"flat_cover_scan|flat_poster|flat_flyer|flat_marquee","image_url":"absolute direct image URL or null","source_url":"specific evidence page URL"}]}. Candidates must be evidence-backed and best first. '
        : 'Act as a game metadata research agent. Identify the exact game from ROM evidence and cross-check platform and region using multiple web results when possible. Research names, release facts and descriptions only; do not search for artwork. Return JSON only: {"metadata":' + metadataContract + '}. ') + sharedRules + driverRule;
      const researchInput = `Identify this game using ROM evidence: ${searchEvidence(game)}. Current region: ${game.region || "unknown"}. Use the filename, platform, mapper, size, CRC and ROM header to disambiguate variants, then verify findings with web search.`;
      const restrictedInput = researchInput + " " + preferredSearchInstruction(fallbackToPublic);
      const response = await fetch(endpoint, {
        method: "POST", signal: controller.signal,
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${deepSeekKey}` },
        body: JSON.stringify({
          model: process.env.DEEPSEEK_WEB_SEARCH_MODEL || "deepseek-v4-flash",
          instructions, input: restrictedInput,
          tools: [{ type: "web_search" }], tool_choice: "required",
          reasoning: { effort: "none" }, max_output_tokens: 1_600,
          text: { format: { type: "json_object" } }
        })
      });
      if (!response.ok) throw new Error(`DeepSeek Web Search 请求失败 (${response.status})`);
      const payload = await response.json();
      recordWebSearchDiagnostic(game, response, payload);
      const content = await completeWebSearchResponse({ game, endpoint, instructions, input: restrictedInput, payload, maxOutputTokens: 1_600, signal: controller.signal });
      const parsed = parseResearchJSON(content, game.title);
      const input = parsed.metadata && typeof parsed.metadata === "object" ? parsed.metadata : {};
      const metadata = {};
      for (const key of ["title", "chineseTitle", "region", "sortTitle", "description", "englishDescription"]) {
        if (typeof input[key] === "string" && input[key].trim()) metadata[key] = input[key].trim().slice(0, key === "description" ? 2_000 : 240);
      }
      if (SYSTEMS.includes(input.system)) metadata.system = input.system;
      if (CATEGORIES.includes(input.category) || input.category === "教育" || input.category === "多人") metadata.category = categoryForSystem(input.category, game.system);
      for (const key of ["releaseYear", "players"]) if (Number.isInteger(input[key]) && input[key] >= 0 && input[key] <= 10_000) metadata[key] = input[key];
      rememberFingerprintMetadata(game, metadata);
      const seen = new Set();
      let candidates = (includeCoverCandidates && Array.isArray(parsed.candidates) ? parsed.candidates : []).map(item => {
        const poster = posterCandidate(item);
        if (!poster) return null;
        const { imageURL, source, artworkType } = poster;
        const identity = imageURL || source;
        if (seen.has(identity)) return null;
        seen.add(identity);
        return { id: randomID(), title: String(item.title || metadata.title || game.title).slice(0, 240), artworkType, imageURL, source };
      }).filter(Boolean).slice(0, 8);
      const preferredCandidates = await preferredCandidatesPromise;
      if (includeCoverCandidates) {
        recordSearchStage(game, "优先站点直查", preferredStartedAt, { candidates: preferredCandidates.length });
        candidates = await supplementPreferredCoverCandidates(game, candidates, preferredCandidates);
      }
      const cachedCandidates = await cacheSearchCandidates(candidates, game);
      const fallbackUsed = fallbackToPublic || cachedCandidates.some(candidate => !preferredSearchScope().includes(new URL(candidate.source).hostname));
      if (includeCoverCandidates) webCoverSearches.set(searchKey, { expiresAt: Date.now() + 10 * 60_000, query: game.title, metadata, fallbackUsed, candidates: new Map(cachedCandidates.map(item => [item.id, item])) });
      return { metadata, scope: preferredSearchScope(), fallbackUsed, fallbackAttempted: includeCoverCandidates, candidates: cachedCandidates.map(({ id, title, source }) => ({ id, title, source })) };
    } catch (error) {
      if (error.name === "AbortError") throw new Error("DeepSeek Web Search 超时。");
      throw error;
    } finally { clearTimeout(timeout); }
  }

  function webCoverCandidate(game, candidateID) {
    const searchKey = webSearchKey(game);
    const search = webCoverSearches.get(searchKey);
    if (!search || search.expiresAt < Date.now()) { webCoverSearches.delete(searchKey); throw new Error("搜索结果已过期，请重新搜索封面。"); }
    const candidate = search.candidates.get(candidateID);
    if (!candidate) throw new Error("封面候选不存在。");
    return candidate;
  }

  async function downloadRemoteImage(source) {
    if (typeof options.downloadRemoteImage === "function") return options.downloadRemoteImage(source);
    let url = await safeRemoteURL(source);
    for (let redirectCount = 0; redirectCount <= 3; redirectCount++) {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), Number(process.env.FC_LIBRARY_IMAGE_DOWNLOAD_TIMEOUT_MS || 20_000));
      let response;
      try { response = await fetch(url, { signal: controller.signal, redirect: "manual", headers: { "User-Agent": "FCEmulatorLibrary/1.0", Accept: "image/avif,image/webp,image/png,image/jpeg,*/*" } }); }
      finally { clearTimeout(timeout); }
      if ([301, 302, 303, 307, 308].includes(response.status)) {
        const location = response.headers.get("location");
        if (!location) throw new Error("封面图片重定向无效。");
        url = await safeRemoteURL(new URL(location, url).href); continue;
      }
      if (!response.ok) throw new Error(`下载封面失败 (${response.status})`);
      const type = response.headers.get("content-type")?.split(";")[0].toLowerCase() || "";
      if (!IMAGE_EXTENSIONS.has(type.replace("image/", "").replace("jpeg", "jpeg"))) throw new Error("搜索结果不是支持的 PNG、JPG 或 WebP 图片。");
      const limit = Number(process.env.FC_LIBRARY_MAX_COVER_MB || 20) * 1024 * 1024;
      const chunks = []; let bytes = 0;
      for await (const chunk of response.body) { bytes += chunk.length; if (bytes > limit) throw new Error("封面图片超过大小限制。"); chunks.push(chunk); }
      return { data: Buffer.concat(chunks), contentType: type, sourceURL: url.href };
    }
    throw new Error("封面图片重定向次数过多。");
  }

  function htmlAttribute(tag, name) {
    const match = tag.match(new RegExp(`\\b${name}\\s*=\\s*(["'])(.*?)\\1|\\b${name}\\s*=\\s*([^\\s>]+)`, "i"));
    return (match?.[2] || match?.[3] || "").trim();
  }

  async function fetchRemoteHTML(source, timeoutMilliseconds = Number(process.env.FC_LIBRARY_IMAGE_DOWNLOAD_TIMEOUT_MS || 20_000), maximumBytes = 2 * 1024 * 1024) {
    if (typeof options.fetchRemoteHTML === "function") return options.fetchRemoteHTML(source, timeoutMilliseconds, maximumBytes);
    let url = await safeRemoteURL(source);
    for (let redirectCount = 0; redirectCount <= 3; redirectCount++) {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), timeoutMilliseconds);
      let response;
      try { response = await fetch(url, { signal: controller.signal, redirect: "manual", headers: { "User-Agent": "FCEmulatorLibrary/1.0", Accept: "text/html,application/xhtml+xml" } }); }
      finally { clearTimeout(timeout); }
      if ([301, 302, 303, 307, 308].includes(response.status)) {
        const location = response.headers.get("location");
        if (!location) throw new Error("网页重定向无效。 ");
        url = await safeRemoteURL(new URL(location, url).href); continue;
      }
      if (!response.ok) throw new Error(`读取网页失败 (${response.status})`);
      if (!response.headers.get("content-type")?.toLowerCase().includes("text/html")) throw new Error("来源不是 HTML 页面。 ");
      const chunks = []; let bytes = 0; const limit = maximumBytes;
      for await (const chunk of response.body) { bytes += chunk.length; if (bytes > limit) throw new Error("网页内容过大。 "); chunks.push(chunk); }
      return Buffer.concat(chunks).toString("utf8");
    }
    throw new Error("网页重定向次数过多。 ");
  }

  async function fetchRemoteJSON(source, timeoutMilliseconds = Number(process.env.FC_LIBRARY_IMAGE_DOWNLOAD_TIMEOUT_MS || 20_000)) {
    let url = await safeRemoteURL(source);
    for (let redirectCount = 0; redirectCount <= 3; redirectCount++) {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), timeoutMilliseconds);
      let response;
      try { response = await fetch(url, { signal: controller.signal, redirect: "manual", headers: { "User-Agent": "FCEmulatorLibrary/1.0", Accept: "application/json" } }); }
      finally { clearTimeout(timeout); }
      if ([301, 302, 303, 307, 308].includes(response.status)) {
        const location = response.headers.get("location");
        if (!location) throw new Error("JSON 来源重定向无效。 ");
        url = await safeRemoteURL(new URL(location, url).href); continue;
      }
      if (!response.ok) throw new Error(`读取 JSON 来源失败 (${response.status})`);
      const chunks = []; let bytes = 0; const limit = 4 * 1024 * 1024;
      for await (const chunk of response.body) { bytes += chunk.length; if (bytes > limit) throw new Error("JSON 来源内容过大。 "); chunks.push(chunk); }
      try { return JSON.parse(Buffer.concat(chunks).toString("utf8")); }
      catch { throw new Error("JSON 来源内容无效。 "); }
    }
    throw new Error("JSON 来源重定向次数过多。 ");
  }

  async function coverImageFromPage(source) {
    let url = await safeRemoteURL(source);
    for (let redirectCount = 0; redirectCount <= 3; redirectCount++) {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), Number(process.env.FC_LIBRARY_IMAGE_DOWNLOAD_TIMEOUT_MS || 20_000));
      let response;
      try { response = await fetch(url, { signal: controller.signal, redirect: "manual", headers: { "User-Agent": "FCEmulatorLibrary/1.0", Accept: "text/html,application/xhtml+xml" } }); }
      finally { clearTimeout(timeout); }
      if ([301, 302, 303, 307, 308].includes(response.status)) {
        const location = response.headers.get("location");
        if (!location) throw new Error("封面来源页面重定向无效。 ");
        url = await safeRemoteURL(new URL(location, url).href); continue;
      }
      if (!response.ok) throw new Error(`读取封面来源页面失败 (${response.status})`);
      if (!response.headers.get("content-type")?.toLowerCase().includes("text/html")) throw new Error("封面来源不是 HTML 页面。 ");
      const chunks = []; let bytes = 0; const limit = 2 * 1024 * 1024;
      for await (const chunk of response.body) { bytes += chunk.length; if (bytes > limit) throw new Error("封面来源页面过大。 "); chunks.push(chunk); }
      const tags = Buffer.concat(chunks).toString("utf8").match(/<meta\b[^>]*>/gi) || [];
      for (const tag of tags) {
        const key = (htmlAttribute(tag, "property") || htmlAttribute(tag, "name")).toLowerCase();
        if (key !== "og:image" && key !== "twitter:image" && key !== "twitter:image:src") continue;
        const content = htmlAttribute(tag, "content").replaceAll("&amp;", "&");
        if (content) return (await safeRemoteURL(new URL(content, url).href)).href;
      }
      throw new Error("封面来源页面没有公开的 og:image。 ");
    }
    throw new Error("封面来源页面重定向次数过多。 ");
  }

  async function downloadCandidateImage(candidate) {
    if (candidate.imageURL) {
      try { return await downloadRemoteImage(candidate.imageURL); }
      catch (error) {
        if (!candidate.source || candidate.source === candidate.imageURL) throw error;
      }
    }
    return downloadRemoteImage(await coverImageFromPage(candidate.source));
  }

  async function cacheCandidateImage(candidate) {
    const image = await downloadCandidateImage(candidate);
    const dimensions = imageDimensions(image.data, image.contentType);
    if (!dimensions || dimensions.width < 120 || dimensions.height < 120 || dimensions.width * dimensions.height < 40_000) {
      throw new Error("封面候选分辨率过低或无法识别尺寸。 ");
    }
    const ext = extensionForImage(image.contentType);
    const temporary = path.join(paths.webCoverTemp, `${randomID()}.${ext}`);
    await fsp.writeFile(temporary, image.data, { flag: "wx" });
    return { ...candidate, temporary, contentType: image.contentType, width: dimensions.width, height: dimensions.height };
  }

  function coverCandidateScore(candidate, game) {
    const titleScore = Number(candidate.titleScore) || Math.max(scoreMatch(game?.title || "", candidate.title || ""), scoreMatch(game?.chineseTitle || "", candidate.title || ""));
    const pixels = Math.max(1, Number(candidate.width) * Number(candidate.height));
    const resolution = Math.min(1, Math.log2(pixels / 40_000 + 1) / 4);
    const source = candidate.trustedSource === "LaunchBox" ? 0.32 : candidate.trustedSource === "Libretro" ? 0.28 : candidate.trustedSource === "Internet Archive" ? 0.24 : 0;
    const artwork = candidate.artworkType === "box_art" || candidate.artworkType === "poster" || candidate.artworkType === "flyer" ? 0.12 : 0;
    return titleScore * 0.55 + resolution * 0.2 + source + artwork;
  }

  async function cacheSearchCandidates(candidates, game = null) {
    const cached = [];
    // Three verified alternatives are enough for the editor, while fetching
    // eight remote images serially can make a search feel stalled.
    for (let start = 0; start < Math.min(candidates.length, 3); start += 3) {
      const batch = await Promise.allSettled(candidates.slice(start, start + 3).map(cacheCandidateImage));
      for (const result of batch) {
        if (result.status === "fulfilled") cached.push({ ...result.value, qualityScore: coverCandidateScore(result.value, game) });
        else console.warn(`封面候选预取失败：${result.reason?.message || "未知错误"}`);
      }
    }
    return cached.sort((left, right) => right.qualityScore - left.qualityScore || (right.width * right.height) - (left.width * left.height));
  }

  async function cachedCandidateImage(candidate) {
    if (candidate.temporary) {
      try { await fsp.access(candidate.temporary); return candidate.temporary; }
      catch { throw new Error("封面预览已过期，请重新搜索。 "); }
    }
    return (await cacheCandidateImage(candidate)).temporary;
  }

  function extensionForImage(type, fallback = "png") {
    return ({ "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp" })[type] || fallback;
  }

  async function scanDirectory(root) {
    const files = [];
    async function visit(directory) {
      for (const entry of await fsp.readdir(directory, { withFileTypes: true })) {
        const item = path.join(directory, entry.name);
        if (entry.isDirectory()) await visit(item);
        else if (entry.isFile() && detectedSystem(entry.name)) files.push(item);
      }
    }
    await visit(root);
    const results = [];
    for (const file of files) results.push(await ingestFile(file, path.basename(file), { skipSave: true }));
    await save();
    return results;
  }

  async function scanDropbox() { return scanDirectory(paths.dropbox); }

  async function resolvedSourceDirectory() {
    const configured = String(catalog.settings.sourceDirectory || "").trim();
    if (!configured) throw new Error("请先保存服务器上的导入目录绝对路径。");
    const root = path.resolve(configured);
    const relativeToData = path.relative(paths.dataRoot, root);
    if (!relativeToData.startsWith("..") && !path.isAbsolute(relativeToData)) throw new Error("导入目录不能是服务自身的 data 目录或其子目录。");
    let info;
    try { info = await fsp.stat(root); } catch { throw new Error("导入目录不存在或服务无权读取。"); }
    if (!info.isDirectory()) throw new Error("导入目录必须是文件夹。");
    return root;
  }

  function clearNeoGeoBIOSDeclaration(index) {
    if (!index.bios?.neoGeo) return false;
    const remaining = { ...index.bios };
    delete remaining.neoGeo;
    if (Object.keys(remaining).length) index.bios = remaining;
    else delete index.bios;
    return true;
  }

  async function synchronizeCanonicalNeoGeoBIOS(root, index) {
    const file = path.join(root, "neogeo.zip");
    try {
      const details = await validateNeoGeoBIOSArchive(file);
      const declaration = { path: "neogeo.zip", bytes: details.bytes, sha256: details.sha256 };
      if (index.bios?.neoGeo?.path === declaration.path &&
          index.bios.neoGeo.bytes === declaration.bytes &&
          index.bios.neoGeo.sha256 === declaration.sha256) return false;
      index.bios = { ...(index.bios || {}), neoGeo: declaration };
      return true;
    } catch (error) {
      if (error.code !== "ENOENT") console.warn(`忽略无效的 neogeo.zip：${error.message}`);
      return clearNeoGeoBIOSDeclaration(index);
    }
  }

  function clearPGMBIOSDeclaration(index) {
    if (!index.bios?.pgm) return false;
    const remaining = { ...index.bios };
    delete remaining.pgm;
    if (Object.keys(remaining).length) index.bios = remaining;
    else delete index.bios;
    return true;
  }

  async function synchronizeCanonicalPGMBIOS(root, index) {
    const file = path.join(root, "pgm.zip");
    try {
      const details = await validatePGMBIOSArchive(file);
      const declaration = { path: "pgm.zip", bytes: details.bytes, sha256: details.sha256 };
      if (index.bios?.pgm?.path === declaration.path &&
          index.bios.pgm.bytes === declaration.bytes &&
          index.bios.pgm.sha256 === declaration.sha256) return false;
      index.bios = { ...(index.bios || {}), pgm: declaration };
      return true;
    } catch (error) {
      if (error.code !== "ENOENT") console.warn(`忽略无效的 pgm.zip：${error.message}`);
      return clearPGMBIOSDeclaration(index);
    }
  }

  function clearFDSBIOSDeclaration(index) {
    if (!index.bios?.fds) return false;
    const remaining = { ...index.bios };
    delete remaining.fds;
    if (Object.keys(remaining).length) index.bios = remaining;
    else delete index.bios;
    return true;
  }

  async function synchronizeCanonicalFDSBIOS(root, index) {
    const file = path.join(root, "disksys.rom");
    try {
      const details = await validateFDSBIOSFile(file);
      const declaration = { path: "disksys.rom", bytes: details.bytes, sha256: details.sha256 };
      if (index.bios?.fds?.path === declaration.path &&
          index.bios.fds.bytes === declaration.bytes &&
          index.bios.fds.sha256 === declaration.sha256) return false;
      index.bios = { ...(index.bios || {}), fds: declaration };
      return true;
    } catch (error) {
      if (error.code !== "ENOENT") console.warn(`忽略无效的 disksys.rom：${error.message}`);
      return clearFDSBIOSDeclaration(index);
    }
  }

  async function readCanonicalLibrary(root, { create = false } = {}) {
    const indexPath = path.join(root, "library.json");
    try {
      const index = JSON.parse(await fsp.readFile(indexPath, "utf8"));
      if (!index || !Array.isArray(index.games)) throw new Error("library.json 缺少 games 游戏清单。");
      // Older libraries predate per-game revisions. Backfill a stable marker
      // once in the small root index so Apple TV can skip unchanged manifests
      // after its first sync; game packages themselves remain untouched.
      const fallbackRevision = index.updatedAt || now();
      let revisionsAdded = false;
      const shouldMigrateCategories = !canonicalMigrationRoots.has(path.resolve(root));
      for (const item of index.games) {
        if (!item.updatedAt) {
          item.updatedAt = item.addedAt || fallbackRevision;
          revisionsAdded = true;
        }
        // Migrate legacy cross-cutting labels when the server reads an older
        // exported library. Updating the manifest and its index revision
        // together prevents clients from retaining stale category caches.
        try {
          if (!shouldMigrateCategories) continue;
          const manifestPath = resolvedWithin(root, item.manifest);
          const manifest = JSON.parse(await fsp.readFile(manifestPath, "utf8"));
          const canonical = categoryForSystem(manifest.category, manifest.system);
          if (canonical !== manifest.category && (manifest.category === "教育" || manifest.category === "多人")) {
            manifest.category = canonical;
            await atomicJSON(manifestPath, manifest);
            item.updatedAt = now();
            revisionsAdded = true;
          }
        } catch (error) {
          if (error.code !== "ENOENT") console.warn(`无法迁移分类：${item.id || item.manifest}：${error.message}`);
        }
      }
      if (shouldMigrateCategories) canonicalMigrationRoots.add(path.resolve(root));
      if (!index.updatedAt) {
        index.updatedAt = fallbackRevision;
        revisionsAdded = true;
      }
      if (await synchronizeCanonicalNeoGeoBIOS(root, index)) {
        index.updatedAt = now();
        revisionsAdded = true;
      }
      if (await synchronizeCanonicalFDSBIOS(root, index)) {
        index.updatedAt = now();
        revisionsAdded = true;
      }
      if (await synchronizeCanonicalPGMBIOS(root, index)) {
        index.updatedAt = now();
        revisionsAdded = true;
      }
      if (revisionsAdded) await atomicJSON(indexPath, index);
      return { root, indexPath, index };
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      if (!create) {
        const missing = new Error("此目录还不是 FC Emulator 资料库：缺少 library.json。可直接上传首个 ROM 来创建资料库。");
        missing.code = "FC_LIBRARY_INDEX_MISSING";
        throw missing;
      }
      const index = { schemaVersion: 1, title: catalog.settings.title || "FC Emulator Library", games: [] };
      await fsp.mkdir(path.join(root, "Games"), { recursive: true });
      await atomicJSON(indexPath, index);
      return { root, indexPath, index };
    }
  }

  async function configuredCanonicalLibrary(options) {
    const root = await resolvedSourceDirectory();
    return readCanonicalLibrary(root, options);
  }

  async function touchCanonicalGame(id) {
    const library = await configuredCanonicalLibrary();
    const item = library.index.games.find(game => String(game.id) === String(id));
    if (!item) return null;
    const updatedAt = now();
    item.updatedAt = updatedAt;
    library.index.updatedAt = updatedAt;
    await atomicJSON(library.indexPath, library.index);
    return updatedAt;
  }

  function canonicalCollectionsPath(library) {
    const relative = typeof library.index.collections === "string" && library.index.collections.trim()
      ? library.index.collections.trim()
      : "collections.json";
    return resolvedWithin(library.root, relative);
  }

  async function readCanonicalCollections(library) {
    const collectionsPath = canonicalCollectionsPath(library);
    try {
      const document = JSON.parse(await fsp.readFile(collectionsPath, "utf8"));
      if (document?.schemaVersion !== 1 || !Array.isArray(document.collections)) {
        throw new Error("collections.json 格式无效。");
      }
      return { path: collectionsPath, document };
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      return { path: collectionsPath, document: { schemaVersion: 1, collections: [] } };
    }
  }

  function canonicalCollectionTitles(document, gameID, system) {
    return document.collections.filter(collection => {
      const games = Array.isArray(collection.games) ? collection.games.map(String) : [];
      const systems = Array.isArray(collection.systems) ? collection.systems : [];
      return games.includes(String(gameID)) || systems.includes(system);
    }).map(collection => String(collection.title || "").trim()).filter(Boolean);
  }

  async function updateCanonicalGameCollections(library, gameID, system, titles) {
    const state = await readCanonicalCollections(library);
    const selected = [...new Set(titles.map(value => String(value).trim()).filter(Boolean))].slice(0, 20);
    for (const collection of state.document.collections) {
      if (Array.isArray(collection.games)) {
        collection.games = [...new Set(collection.games.map(String).filter(id => id !== String(gameID)))];
        if (!collection.games.length) delete collection.games;
      }
    }
    const usedIDs = state.document.collections.map(collection => String(collection.id || "")).filter(Boolean);
    for (const title of selected) {
      let collection = state.document.collections.find(item => String(item.title || "").trim() === title);
      if (!collection) {
        const id = uniqueID(slug(title) || "collection", usedIDs);
        usedIDs.push(id);
        collection = { id, title };
        state.document.collections.push(collection);
      }
      const games = Array.isArray(collection.games) ? collection.games.map(String) : [];
      if (!games.includes(String(gameID))) games.push(String(gameID));
      collection.games = games;
    }
    state.document.collections = state.document.collections.filter(collection =>
      (Array.isArray(collection.games) && collection.games.length) ||
      (Array.isArray(collection.systems) && collection.systems.length)
    );
    library.index.collections = path.relative(library.root, state.path).replaceAll("\\", "/");
    await atomicJSON(state.path, state.document);
    await atomicJSON(library.indexPath, library.index);
    return canonicalCollectionTitles(state.document, gameID, system);
  }

  async function ensureCanonicalArcadeCollection(library, gameID, system, driver) {
    const state = await readCanonicalCollections(library);
    const target = automaticArcadeCollection(system, driver);
    const automaticIDs = new Set(["capcom", "sega", "sega-system16", "sega-system-16", "system16"]);
    let changed = false;
    for (const collection of state.document.collections) {
      if (!automaticIDs.has(String(collection.id || "").toLowerCase()) || !Array.isArray(collection.games)) continue;
      const games = collection.games.map(String);
      const filtered = games.filter(id => id !== String(gameID));
      if (filtered.length !== games.length) {
        changed = true;
        if (filtered.length) collection.games = filtered;
        else delete collection.games;
      }
    }
    if (target) {
      let collection = state.document.collections.find(item =>
        String(item.id || "").toLowerCase() === target.id ||
        normalized(item.title) === normalized(target.title)
      );
      if (!collection) {
        collection = { ...target };
        state.document.collections.push(collection);
        changed = true;
      }
      const games = Array.isArray(collection.games) ? collection.games.map(String) : [];
      if (!games.includes(String(gameID))) {
        collection.games = [...games, String(gameID)];
        changed = true;
      }
    }
    if (!changed) return;
    state.document.collections = state.document.collections.filter(collection =>
      (Array.isArray(collection.games) && collection.games.length) ||
      (Array.isArray(collection.systems) && collection.systems.length)
    );
    library.index.collections = path.relative(library.root, state.path).replaceAll("\\", "/");
    library.index.updatedAt = now();
    await atomicJSON(state.path, state.document);
    await atomicJSON(library.indexPath, library.index);
    sourceRevision += 1;
    sourceListCache = null;
  }

  async function reconcileCanonicalArcadeCollections() {
    const library = await configuredCanonicalLibrary();
    const state = await readCanonicalCollections(library);
    const automaticIDs = new Set(["capcom", "sega", "sega-system16", "sega-system-16", "system16"]);
    const targets = new Map();
    const unreadable = [];

    for (const item of library.index.games) {
      if (!item?.id || typeof item.manifest !== "string") continue;
      try {
        const manifestPath = resolvedWithin(library.root, item.manifest);
        const manifest = JSON.parse(await fsp.readFile(manifestPath, "utf8"));
        const driver = manifest.rom?.driver || baseName(manifest.rom?.path || "");
        const target = automaticArcadeCollection(manifest.system, driver);
        if (!target) continue;
        const games = targets.get(target.id) || [];
        if (!games.includes(String(item.id))) games.push(String(item.id));
        targets.set(target.id, games);
      } catch (error) {
        unreadable.push(`${item.id}: ${error.message}`);
      }
    }
    if (unreadable.length) {
      throw new Error(`有 ${unreadable.length} 个游戏清单无法读取，未改动合集（${unreadable.slice(0, 3).join("；")}）`);
    }

    const before = JSON.stringify(state.document);
    for (const collection of state.document.collections) {
      if (automaticIDs.has(String(collection.id || "").toLowerCase())) delete collection.games;
    }
    for (const [targetID, games] of targets) {
      const target = targetID === "capcom"
        ? { id: "capcom", title: "Capcom", symbol: "arcade.stick.console" }
        : { id: "sega-system16", title: "SEGA", symbol: "arcade.stick.console" };
      let collection = state.document.collections.find(item =>
        String(item.id || "").toLowerCase() === target.id ||
        normalized(item.title) === normalized(target.title)
      );
      if (!collection) {
        collection = { ...target };
        state.document.collections.push(collection);
      }
      collection.games = games;
    }
    state.document.collections = state.document.collections.filter(collection =>
      (Array.isArray(collection.games) && collection.games.length) ||
      (Array.isArray(collection.systems) && collection.systems.length)
    );
    if (JSON.stringify(state.document) === before) return { changed: false, collections: Object.fromEntries(targets) };

    const updatedAt = now();
    library.index.collections = path.relative(library.root, state.path).replaceAll("\\", "/");
    library.index.updatedAt = updatedAt;
    await atomicJSON(state.path, state.document);
    await atomicJSON(library.indexPath, library.index);
    sourceRevision += 1;
    sourceListCache = null;
    return { changed: true, updatedAt, collections: Object.fromEntries(targets) };
  }

  async function reconcileCanonicalArcadeDrivers(onlyIDs = null) {
    const library = await configuredCanonicalLibrary();
    const selectedIDs = onlyIDs == null ? null : new Set(
      (Array.isArray(onlyIDs) ? onlyIDs : [onlyIDs]).map(String)
    );
    const updated = [];
    const ambiguous = [];
    const invalid = [];
    let changed = false;
    for (const item of library.index.games) {
      if (!item?.id || typeof item.manifest !== "string") continue;
      if (selectedIDs && !selectedIDs.has(String(item.id))) continue;
      let manifestPath;
      let manifest;
      try {
        manifestPath = resolvedWithin(library.root, item.manifest);
        manifest = JSON.parse(await fsp.readFile(manifestPath, "utf8"));
        if (!["arcade", "neoGeo"].includes(manifest.system) || extension(manifest.rom?.path || "") !== "zip") continue;
        const romPath = resolvedWithin(path.dirname(manifestPath), manifest.rom.path);
      const previousDriver = normalized(manifest.rom.driver).toLowerCase();
      const identity = await identifyMAMECapcomArchive(
        romPath, path.basename(manifest.rom.path), previousDriver
      );
        if (!identity) continue;
        if (identity.ambiguous) {
          ambiguous.push({ id: String(item.id), drivers: identity.ambiguous });
          continue;
        }
        const before = JSON.stringify(manifest);
        manifest.system = "arcade";
        manifest.rom.driver = identity.driver;
        manifest.rom.arcade = identity.descriptor;
        const key = await availableCPS2KeyForROM(romPath, "arcade", identity.driver);
      if (key.hex && (!manifest.emulation?.cps2Key || previousDriver !== identity.driver)) {
          manifest.emulation = { ...(manifest.emulation || {}), cps2Key: {
            format: "cps2-key-20", hex: key.hex, source: key.source
          } };
        }
        if (JSON.stringify(manifest) !== before) {
          await atomicJSON(manifestPath, manifest);
          item.updatedAt = now();
          updated.push(String(item.id));
          changed = true;
        }
      } catch (error) {
        invalid.push({ id: String(item.id), error: error.message });
      }
    }
    if (changed) {
      library.index.updatedAt = now();
      await atomicJSON(library.indexPath, library.index);
      sourceRevision += 1;
      sourceListCache = null;
    }
    return { changed, updated, ambiguous, invalid };
  }

  async function replaceCanonicalCollectionGameID(library, oldID, newID) {
    const state = await readCanonicalCollections(library);
    let changed = false;
    for (const collection of state.document.collections) {
      if (!Array.isArray(collection.games)) continue;
      const games = collection.games.map(String);
      if (!games.includes(String(oldID))) continue;
      collection.games = [...new Set(games.map(id => id === String(oldID) ? String(newID) : id))];
      changed = true;
    }
    if (changed) await atomicJSON(state.path, state.document);
  }

  function gamePackageDirectory(index) {
    const first = Array.isArray(index.games) ? index.games.find(item => typeof item?.manifest === "string") : null;
    const firstPart = first?.manifest?.replaceAll("\\", "/").split("/")[0];
    return firstPart && /^[A-Za-z0-9._-]+$/.test(firstPart) ? firstPart : "Games";
  }

  async function addROMToCanonicalLibrary(temporary, originalName) {
    const library = await configuredCanonicalLibrary({ create: true });
    const fileName = safeName(originalName);
    if (["gb", "gbc"].includes(extension(fileName))) {
      throw new Error("Game Boy / Game Boy Color 已从当前开发与产品范围移除，未开放导入。");
    }
    if (extension(fileName) === "gba") {
      throw new Error("Game Boy Advance 不在当前开发范围内，未开放导入。");
    }
    if (extension(fileName) === "zip") {
      const cartridge = await extractSingleConsoleROMFromZIP(temporary);
      if (cartridge) {
        const extracted = path.join(paths.uploads, `${randomID()}-${cartridge.name}`);
        await fsp.writeFile(extracted, cartridge.data, { flag: "wx" });
        try { return await addROMToCanonicalLibrary(extracted, cartridge.name); }
        finally { await fsp.rm(extracted, { force: true }); }
      }
    }
    const detected = detectedSystem(fileName);
    if (!detected || !EXTENSIONS[detected]?.has(extension(fileName))) {
      throw new Error("仅支持 NES/FDS (.nes/.fds/.qd)、Super NES (.sfc/.smc 或仅含一个卡带文件的 .zip)、Mega Drive (.bin/.md/.gen 或仅含一个卡带文件的 .zip) 与 Neo Geo/Arcade (.zip/.7z) ROM。");
    }
    const fileHash = await hashFile(temporary);
    await validateROMFile(temporary, fileName, detected, fileHash);
    const snesInfo = detected === "snes" ? await analyzeSNESROM(temporary) : null;
    const snesIPL = detected === "snes" ? await snesIPLStatus() : null;
    if (detected === "snes" && !snesIPL?.valid) {
      throw new Error("上传 Super NES ROM 前，请先在管理页上传用户自有的 64 字节 spc700.rom。");
    }
    const snesCoprocessor = snesInfo?.coprocessorFirmware
      ? await snesNECDSPFirmwareStatus(snesInfo.coprocessorFirmware) : null;
    if (snesCoprocessor && !snesCoprocessor.valid) {
      throw new Error(`上传这张增强芯片卡带前，请先在管理页上传用户自有的 ${snesInfo.coprocessorFirmwareBytes} 字节 ${snesInfo.coprocessorFirmware}。`);
    }
    const mameArcade = ["zip", "7z"].includes(extension(fileName))
      ? await identifyMAMECapcomArchive(temporary, fileName) : null;
    if (mameArcade?.ambiguous) {
      throw new Error(`ROM 芯片同时匹配多个 MAME driver：${mameArcade.ambiguous.join("、")}。请使用标准 driver 文件名消除歧义。`);
    }
    const system = mameArcade?.driver ? "arcade" : detected;
    if (!system || !EXTENSIONS[system]?.has(extension(fileName))) {
      throw new Error("仅支持 NES/FDS、Super NES、Mega Drive 与 Neo Geo/Arcade ROM。");
    }
    for (const item of library.index.games) {
      const manifestPath = resolvedWithin(library.root, item.manifest);
      const manifest = JSON.parse(await fsp.readFile(manifestPath, "utf8"));
      if (manifest?.rom?.sha256 === fileHash.sha256) {
        const source = await sourceLibraryGame(String(item.id));
        const game = source.game.cps2KeyRequired && !source.manifest.emulation?.cps2Key
          ? await updateSourceLibraryGame(String(item.id), {}, { skipHistory: true })
          : source.game;
        return { game, duplicate: true };
      }
    }
    const header = system === "nes" && extension(fileName) === "nes" ? await readHeader(temporary) : Buffer.alloc(0);
    const romInfo = system === "nes" ? romInfoForNESFile(fileName, header) : null;
    const id = uniqueID(`${slug(titleFromFile(fileName))}-${fileHash.sha256.slice(0, 10)}`, library.index.games.map(item => String(item.id)));
    const packageDirectory = gamePackageDirectory(library.index);
    const packagesRoot = path.join(library.root, packageDirectory);
    const staging = path.join(packagesRoot, `.staging-${randomID()}`);
    const gameRoot = path.join(packagesRoot, id);
    const romRelative = `rom/${fileName}`;
    const romDestination = path.join(staging, romRelative);
    const addedAt = now();
    const arcadeDriver = mameArcade?.driver || ((system === "neoGeo" || system === "arcade") ? baseName(fileName) : null);
    const detectedCPS2Key = await availableCPS2KeyForROM(temporary, system, arcadeDriver);
    const manifest = {
      schemaVersion: system === "snes" ? 2 : 1, id, title: mameArcade?.title || titleFromFile(fileName), system,
      mapper: system === "nes" ? mapperForNESFile(fileName, header) : 0, category: "其他",
      createdAt: addedAt,
      rom: {
        path: romRelative, bytes: fileHash.bytes, sha256: fileHash.sha256,
        ...(arcadeDriver ? { driver: arcadeDriver } : {}),
        ...(mameArcade?.descriptor ? { arcade: mameArcade.descriptor } : {})
      },
      ...(system === "snes" ? { hardware: {
        schemaVersion: 1,
        model: snesInfo.model,
        region: snesInfo.region,
        cartridge: { board: snesInfo.board, features: [
          ...(snesInfo.sramBytes ? ["battery"] : []), ...(snesInfo.rtcBytes ? ["rtc"] : [])
        ] },
        firmware: [{ role: "system-firmware", slot: 0, file: {
          path: "firmware/spc700.rom", bytes: SNES_IPL_BYTES, sha256: snesIPL.sha256
        } }, ...(snesCoprocessor ? [{ role: "coprocessor-firmware", slot: 0, file: {
          path: `firmware/${snesInfo.coprocessorFirmware}`,
          bytes: snesInfo.coprocessorFirmwareBytes, sha256: snesCoprocessor.sha256
        } }] : [])],
        inputs: snesInfo.board === "snes-obc1"
          ? [{ port: 1, kind: "snes-super-scope" }]
          : [{ port: 0, kind: "snes-standard" }, { port: 1, kind: "snes-standard" }],
        persistence: [
          ...(snesInfo.sramBytes ? [{ kind: "snes-sram", slot: 0, bytes: snesInfo.sramBytes }] : []),
          ...(snesInfo.rtcBytes ? [{ kind: "snes-rtc", slot: 1, bytes: snesInfo.rtcBytes }] : [])
        ],
        referenceTraces: []
      } } : {}),
      ...(detectedCPS2Key.hex ? { emulation: { cps2Key: {
        format: "cps2-key-20", hex: detectedCPS2Key.hex, source: detectedCPS2Key.source
      } } } : {})
    };
    try {
      await fsp.mkdir(staging, { recursive: true });
      await fsp.mkdir(path.dirname(romDestination), { recursive: true });
      await fsp.copyFile(temporary, romDestination);
      if (system === "snes") {
        const firmwareDestination = path.join(staging, "firmware", "spc700.rom");
        await fsp.mkdir(path.dirname(firmwareDestination), { recursive: true });
        await fsp.copyFile(path.join(library.root, "spc700.rom"), firmwareDestination);
        const copiedIPL = await validateSNESIPL(firmwareDestination);
        if (copiedIPL.sha256 !== snesIPL.sha256) throw new Error("复制到游戏包的 SPC700 IPL 校验值发生变化。");
        if (snesCoprocessor) {
          const firmwareDestination = path.join(staging, "firmware", snesInfo.coprocessorFirmware);
          const image = await readSNESNECDSPFirmware(library.root, snesInfo.coprocessorFirmware);
          if (!image) throw new Error(`资料库中找不到 ${snesInfo.coprocessorFirmware}。`);
          await fsp.writeFile(firmwareDestination, image);
          const copiedFirmware = await validateSNESNECDSPFirmware(
            firmwareDestination, snesInfo.coprocessorFirmware
          );
          if (copiedFirmware.sha256 !== snesCoprocessor.sha256) {
            throw new Error("复制到游戏包的协处理器固件校验值发生变化。");
          }
        }
      }
      validatePortableManifestHardware(manifest);
      await atomicJSON(path.join(staging, "manifest.json"), manifest);
      await fsp.rename(staging, gameRoot);
      library.index.games.push({ id, manifest: `${packageDirectory}/${id}/manifest.json`, addedAt, updatedAt: addedAt });
      library.index.updatedAt = addedAt;
      await atomicJSON(library.indexPath, library.index);
    } catch (error) {
      await fsp.rm(staging, { recursive: true, force: true });
      throw error;
    }
    await ensureCanonicalArcadeCollection(library, id, system, arcadeDriver);
    const game = (await sourceLibraryGame(id)).game;
    game.crc32 = fileHash.crc32; game.romInfo = romInfo;
    return { game, duplicate: false };
  }

  async function auditSourceLibrary({ full = false, onProgress = null } = {}) {
    const library = await configuredCanonicalLibrary();
    const cacheKey = `${library.root}:${sourceRevision}`;
    if (!full && !onProgress && sourceHealthCache?.key === cacheKey) return sourceHealthCache.value;
    const summary = {
      games: library.index.games.length, checked: 0, valid: 0, missingManifest: 0, missingROM: 0,
      invalidROM: 0, missingCover: 0, incompleteMetadata: 0, duplicateROM: 0, orphanPackage: 0
    };
    const issues = [];
    const addIssue = (kind, item, message) => {
      if (issues.length < 250) issues.push({ kind, id: String(item?.id || ""), title: String(item?.title || item?.id || "未命名游戏"), message });
    };
    const indexedManifests = new Set();
    const hashes = new Map();
    const ids = new Set();
    for (let position = 0; position < library.index.games.length; position++) {
      const item = library.index.games[position];
      summary.checked++;
      if (ids.has(String(item.id))) addIssue("duplicate-id", item, "library.json 中存在重复游戏 ID。");
      ids.add(String(item.id));
      let manifestPath;
      try { manifestPath = resolvedWithin(library.root, item.manifest); indexedManifests.add(path.resolve(manifestPath)); }
      catch (error) { summary.missingManifest++; addIssue("invalid-manifest-path", item, error.message); continue; }
      let manifest;
      try { manifest = JSON.parse(await fsp.readFile(manifestPath, "utf8")); }
      catch (error) { summary.missingManifest++; addIssue("missing-manifest", item, "manifest.json 不存在或 JSON 无效。"); continue; }
      const issueItem = { ...item, title: manifest.chineseTitle || manifest.title || item.id };
      try { validatePortableManifestHardware(manifest); }
      catch (error) { summary.invalidROM++; addIssue("invalid-manifest", issueItem, error.message); continue; }
      let romPath;
      try { romPath = resolvedWithin(path.dirname(manifestPath), manifest.rom.path); await fsp.access(romPath); }
      catch { summary.missingROM++; addIssue("missing-rom", issueItem, "ROM 文件不存在或路径越界。"); continue; }
      const missingMetadata = [
        ["英文名", manifest.title], ["中文名", manifest.chineseTitle], ["中文说明", manifest.description]
      ].filter(([, value]) => !String(value || "").trim()).map(([label]) => label);
      if (missingMetadata.length) { summary.incompleteMetadata++; addIssue("incomplete-metadata", issueItem, `缺少${missingMetadata.join("、")}。`); }
      if (!manifest.artwork?.cover?.path) { summary.missingCover++; addIssue("missing-cover", issueItem, "尚未选择封面。"); }
      else {
        try {
          const cover = resolvedWithin(path.dirname(manifestPath), manifest.artwork.cover.path);
          await fsp.access(cover);
          if (full && manifest.artwork.cover.sha256) {
            const details = await hashFile(cover);
            if (details.sha256 !== manifest.artwork.cover.sha256) throw new Error("封面 SHA-256 不匹配。");
          }
        } catch (error) { addIssue("invalid-cover", issueItem, error.message || "封面文件不存在或校验失败。"); }
      }
      try {
        const details = full ? await hashFile(romPath) : { sha256: String(manifest.rom.sha256 || ""), bytes: Number(manifest.rom.bytes) || 0 };
        if (full) {
          await validateROMFile(romPath, path.basename(romPath), manifest.system, details);
          if (manifest.rom.sha256 && details.sha256 !== manifest.rom.sha256) throw new Error("ROM SHA-256 不匹配。");
          if (Number.isFinite(manifest.rom.bytes) && details.bytes !== manifest.rom.bytes) throw new Error("ROM 文件大小不匹配。");
          await verifyPortableHardwareFiles(manifest, manifestPath);
        }
        const key = details.sha256 || manifest.rom.sha256;
        if (key) {
          if (hashes.has(key)) { summary.duplicateROM++; addIssue("duplicate-rom", issueItem, `与 ${hashes.get(key)} 的 ROM SHA-256 相同。`); }
          else hashes.set(key, String(item.id));
        }
        summary.valid++;
      } catch (error) { summary.invalidROM++; addIssue("invalid-rom", issueItem, error.message || "ROM 校验失败。"); }
      if (onProgress && (position === library.index.games.length - 1 || position % 8 === 7)) onProgress(position + 1, library.index.games.length, issueItem.title);
    }
    const packageRoot = path.join(library.root, gamePackageDirectory(library.index));
    try {
      for (const entry of await fsp.readdir(packageRoot, { withFileTypes: true })) {
        if (!entry.isDirectory() || entry.name.startsWith(".")) continue;
        const manifestPath = path.resolve(packageRoot, entry.name, "manifest.json");
        if (!indexedManifests.has(manifestPath) && fs.existsSync(manifestPath)) {
          summary.orphanPackage++; addIssue("orphan-package", { id: entry.name, title: entry.name }, "游戏包存在，但没有写入 library.json。 ");
        }
      }
    } catch { /* index-level errors already describe unavailable packages */ }
    const result = { canonicalLibrary: true, full, directory: library.root, checkedAt: now(), revision: sourceRevision, summary, issues };
    if (!full) sourceHealthCache = { key: cacheKey, value: result };
    return result;
  }

  async function scanSourceDirectory(options = {}) {
    return auditSourceLibrary(options);
  }

  async function importPortableLibrary(root) {
    const index = JSON.parse(await fsp.readFile(path.join(root, "library.json"), "utf8"));
    if (!Array.isArray(index.games)) throw new Error("library.json 缺少游戏清单。");
    const results = [];
    for (const item of index.games) {
      const manifestPath = resolvedWithin(root, item.manifest);
      const manifest = JSON.parse(await fsp.readFile(manifestPath, "utf8"));
      validatePortableManifestHardware(manifest);
      if (!manifest?.rom?.path || !SYSTEMS.includes(manifest.system)) throw new Error(`游戏清单无效或当前不支持导入：${item.id || item.manifest}`);
      const romPath = resolvedWithin(path.dirname(manifestPath), manifest.rom.path);
      const fileHash = await hashFile(romPath);
      if (manifest.rom.sha256 && manifest.rom.sha256 !== fileHash.sha256) throw new Error(`ROM 校验失败：${item.id || manifest.title}`);
      if (Number.isFinite(manifest.rom.bytes) && manifest.rom.bytes !== fileHash.bytes) throw new Error(`ROM 大小不匹配：${item.id || manifest.title}`);
      const metadata = {
        title: manifest.title, sortTitle: manifest.sortTitle, chineseTitle: manifest.chineseTitle,
        description: manifest.description, englishDescription: manifest.englishDescription, region: manifest.region, system: manifest.system,
        category: CATEGORIES.includes(manifest.category) || manifest.category === "教育" || manifest.category === "多人" ? categoryForSystem(manifest.category, manifest.system) : "其他",
        mapper: manifest.mapper, players: manifest.players, releaseYear: manifest.releaseYear
      };
      const result = await ingestFile(romPath, path.basename(romPath), { system: manifest.system, metadata, fileHash, skipSave: true });
      if (manifest.artwork?.cover?.path && !result.game.cover) {
        const coverPath = resolvedWithin(path.dirname(manifestPath), manifest.artwork.cover.path);
        const coverHash = await hashFile(coverPath);
        if (manifest.artwork.cover.sha256 && manifest.artwork.cover.sha256 !== coverHash.sha256) throw new Error(`封面校验失败：${item.id || manifest.title}`);
        await storeCover(result.game, coverPath, path.basename(coverPath), "portable-library");
      }
      results.push(result);
    }
    await save();
    return results;
  }

  async function listSourceROMs() {
    const library = await configuredCanonicalLibrary();
    const cacheKey = `${library.root}:${sourceRevision}`;
    if (sourceListCache?.key === cacheKey) return sourceListCache.value;
    const collectionState = await readCanonicalCollections(library);
    const orderedGames = library.index.games.map((item, index) => ({ item, index })).sort((left, right) => {
      const leftTime = Date.parse(left.item.addedAt || "") || 0;
      const rightTime = Date.parse(right.item.addedAt || "") || 0;
      return rightTime - leftTime || right.index - left.index;
    });
    const roms = (await mapWithConcurrency(orderedGames, Number(process.env.FC_LIBRARY_MANIFEST_CONCURRENCY) || 24, async ({ item }) => {
      const manifestPath = resolvedWithin(library.root, item.manifest);
      const manifest = JSON.parse(await fsp.readFile(manifestPath, "utf8"));
      try { validatePortableManifestHardware(manifest); }
      catch { return null; }
      if (!manifest?.rom?.path) return null;
      const romPath = resolvedWithin(path.dirname(manifestPath), manifest.rom.path);
      const arcadeDriver = (manifest.system === "arcade" || manifest.system === "neoGeo")
        ? (manifest.rom.driver || baseName(romPath)) : null;
      const hardware = arcadeHardware(manifest.system, arcadeDriver);
      return {
        id: String(item.id || manifest.id), title: String(manifest.chineseTitle || manifest.title || item.id), englishTitle: String(manifest.title || item.id), chineseTitle: manifest.chineseTitle || null,
        path: path.relative(library.root, romPath), system: manifest.system, category: categoryForSystem(manifest.category || "其他", manifest.system),
        hardware: manifest.hardware || null,
        mapper: Number.isInteger(manifest.mapper) ? manifest.mapper : null, bytes: Number(manifest.rom.bytes) || 0,
        releaseYear: Number.isInteger(manifest.releaseYear) ? manifest.releaseYear : null,
        arcadeDriver, arcadeHardware: hardware?.label || null, arcadeHardwareID: hardware?.id || null,
        collections: [...new Set([
          ...canonicalCollectionTitles(collectionState.document, String(item.id || manifest.id), manifest.system),
          // Compatibility with manager builds that stored collection titles
          // in each manifest before the shared root-level contract existed.
          ...(Array.isArray(manifest.collections) ? manifest.collections : [])
        ])],
        addedAt: item.addedAt || manifest.createdAt || null,
        hasCover: Boolean(manifest.artwork?.cover?.path),
        missingMetadata: [["英文名", manifest.title], ["中文名", manifest.chineseTitle], ["中文说明", manifest.description]].filter(([, value]) => !String(value || "").trim()).map(([label]) => label),
        incompleteMetadata: !String(manifest.title || "").trim() || !String(manifest.chineseTitle || "").trim() || !String(manifest.description || "").trim(),
        automaticResearch: sourceResearchState(String(item.id || manifest.id))
      };
    })).filter(Boolean);
    const versionCounts = new Map();
    for (const rom of roms) {
      const key = normalized(rom.englishTitle || rom.title).replace(/\b(?:usa|japan|europe|asia|rev|version|v)\b.*$/i, "").trim();
      if (key) versionCounts.set(key, (versionCounts.get(key) || 0) + 1);
      rom.versionKey = key;
    }
    for (const rom of roms) rom.versionCount = versionCounts.get(rom.versionKey) || 1;
    const result = { directory: library.root, title: library.index.title || catalog.settings.title, roms, canonicalLibrary: true, revision: sourceRevision };
    sourceListCache = { key: cacheKey, value: result };
    try {
      const indexStat = await fsp.stat(library.indexPath);
      await atomicJSON(paths.sourceListCache, { schemaVersion: 1, directory: library.root, revision: sourceRevision, indexSignature: `${indexStat.size}:${indexStat.mtimeMs}`, value: result });
    } catch (error) { console.warn(`无法保存资料库索引快照：${error.message}`); }
    return result;
  }

  async function sourceROMPage(url) {
    if (url.searchParams.get("refresh") === "1") {
      sourceRevision++; sourceListCache = null; sourceHealthCache = null;
      await fsp.rm(paths.sourceListCache, { force: true });
    }
    const library = await listSourceROMs();
    const query = normalized(url.searchParams.get("q") || "");
    const system = String(url.searchParams.get("system") || "");
    const category = String(url.searchParams.get("category") || "");
    const collection = String(url.searchParams.get("collection") || "");
    const status = String(url.searchParams.get("status") || "");
    const sort = String(url.searchParams.get("sort") || "added");
    let roms = library.roms.filter(rom => {
      if (query && !normalized([rom.title, rom.englishTitle, rom.chineseTitle, rom.path, rom.arcadeDriver, rom.arcadeHardware, ...(rom.collections || [])].join(" ")).includes(query)) return false;
      if (system && rom.system !== system) return false;
      if (category && rom.category !== category) return false;
      if (collection && !(rom.collections || []).includes(collection)) return false;
      if (status === "missing-cover" && rom.hasCover) return false;
      if (status === "incomplete" && !rom.incompleteMetadata) return false;
      if (status === "researching" && rom.automaticResearch?.state !== "running") return false;
      if (status === "failed" && rom.automaticResearch?.state !== "failed") return false;
      if (status === "variants" && rom.versionCount <= 1) return false;
      return true;
    });
    roms.sort((left, right) => {
      if (sort === "title") return String(left.title).localeCompare(String(right.title), "zh-Hans-CN");
      if (sort === "year") return (right.releaseYear || 0) - (left.releaseYear || 0) || String(left.title).localeCompare(String(right.title), "zh-Hans-CN");
      if (sort === "size") return (right.bytes || 0) - (left.bytes || 0);
      return (Date.parse(right.addedAt || "") || 0) - (Date.parse(left.addedAt || "") || 0);
    });
    const total = roms.length;
    const limit = Math.min(200, Math.max(20, Number(url.searchParams.get("limit")) || 100));
    const offset = Math.min(total, Math.max(0, Number(url.searchParams.get("offset")) || 0));
    return {
      ...library, roms: roms.slice(offset, offset + limit), total, offset, limit, truncated: offset + limit < total,
      facets: {
        systems: [...new Set(library.roms.map(rom => rom.system).filter(Boolean))].sort(),
        categories: [...new Set(library.roms.map(rom => rom.category).filter(Boolean))].sort((left, right) => left.localeCompare(right, "zh-Hans-CN")),
        collections: [...new Set(library.roms.flatMap(rom => rom.collections || []))].sort((left, right) => left.localeCompare(right, "zh-Hans-CN"))
      }
    };
  }

  async function sourceHealthSnapshot() {
    const library = await listSourceROMs();
    const cacheKey = `${library.directory}:${sourceRevision}`;
    if (sourceHealthCache?.key === cacheKey) return sourceHealthCache.value;
    const missingCover = library.roms.filter(rom => !rom.hasCover);
    const incomplete = library.roms.filter(rom => rom.incompleteMetadata);
    const issues = [];
    for (const rom of incomplete) if (issues.length < 250) issues.push({ kind: "incomplete-metadata", id: rom.id, title: rom.title, message: `缺少${rom.missingMetadata.join("、")}。` });
    for (const rom of missingCover) if (issues.length < 250) issues.push({ kind: "missing-cover", id: rom.id, title: rom.title, message: "尚未选择封面。" });
    const result = {
      canonicalLibrary: true, full: false, lightweight: true, directory: library.directory, checkedAt: now(), revision: sourceRevision,
      summary: { games: library.roms.length, checked: library.roms.length, valid: library.roms.length, missingManifest: 0, missingROM: 0, invalidROM: 0, missingCover: missingCover.length, incompleteMetadata: incomplete.length, duplicateROM: 0, orphanPackage: 0 },
      issues
    };
    sourceHealthCache = { key: cacheKey, value: result };
    return result;
  }

  async function sourceLibraryCover(id) {
    const source = await sourceLibraryGame(id);
    if (!source.manifest.artwork?.cover?.path) throw new Error("该游戏没有封面。");
    const cover = resolvedWithin(path.dirname(source.manifestPath), source.manifest.artwork.cover.path);
    if (!IMAGE_EXTENSIONS.has(extension(cover))) throw new Error("封面格式不受支持。");
    return cover;
  }

  async function sourceLibraryArtwork(id, type) {
    if (type === "background") type = "backdrop";
    if (!ARTWORK_TYPES.has(type)) throw new Error("不支持的素材类型。 ");
    const source = await sourceLibraryGame(id);
    const relative = source.manifest.artwork?.[type]?.path || (type === "backdrop" ? source.manifest.artwork?.background?.path : null);
    if (!relative) throw new Error(`该游戏没有${type}素材。`);
    const artwork = resolvedWithin(path.dirname(source.manifestPath), relative);
    if (!IMAGE_EXTENSIONS.has(extension(artwork))) throw new Error("素材格式不受支持。 ");
    return artwork;
  }

  async function sourceLibraryGame(id) {
    const library = await configuredCanonicalLibrary();
    const item = library.index.games.find(game => String(game.id) === id);
    if (!item) throw new Error("资料库中没有此游戏。");
    const manifestPath = resolvedWithin(library.root, item.manifest);
    const manifest = JSON.parse(await fsp.readFile(manifestPath, "utf8"));
    validatePortableManifestHardware(manifest);
    const romPath = resolvedWithin(path.dirname(manifestPath), manifest.rom?.path || "");
    const collectionState = await readCanonicalCollections(library);
    const collections = [...new Set([
      ...canonicalCollectionTitles(collectionState.document, id, manifest.system),
      ...(Array.isArray(manifest.collections) ? manifest.collections : [])
    ])];
    const artwork = { ...(manifest.artwork || {}) };
    if (!artwork.backdrop && artwork.background) artwork.backdrop = artwork.background;
    const cps2Key = await resolvedManifestCPS2Key(manifest, romPath);
    const arcadeDriver = manifest.rom?.driver || ((manifest.system === "neoGeo" || manifest.system === "arcade") ? baseName(romPath) : null);
    const hardware = arcadeHardware(manifest.system, arcadeDriver);
    return {
      root: library.root, item, manifestPath, manifest, romPath,
      game: {
        id, sourceID: id, originalName: path.basename(romPath), title: manifest.title || id,
        sortTitle: manifest.sortTitle || null, chineseTitle: manifest.chineseTitle || null, description: manifest.description || null, englishDescription: manifest.englishDescription || null,
        system: manifest.system, category: CATEGORIES.includes(manifest.category) || manifest.category === "教育" || manifest.category === "多人" ? categoryForSystem(manifest.category, manifest.system) : "其他",
        hardware: manifest.hardware || null,
        mapper: Number.isInteger(manifest.mapper) ? manifest.mapper : 0, region: manifest.region || null,
        releaseYear: Number.isInteger(manifest.releaseYear) ? manifest.releaseYear : null,
        players: Number.isInteger(manifest.players) ? manifest.players : null,
        extension: extension(romPath), sha256: manifest.rom?.sha256 || "", bytes: Number(manifest.rom?.bytes) || 0,
        arcadeDriver, arcadeHardware: hardware?.label || null,
        arcadeHardwareID: hardware?.id || null, searchID: `source:${id}`,
        cps2KeyRequired: cps2Key.required, cps2Key: cps2Key.hex,
        cps2KeySource: cps2Key.source, cps2KeyStatus: cps2Key.status,
        collections, fieldLocks: manifest.fieldLocks && typeof manifest.fieldLocks === "object" ? manifest.fieldLocks : {}, fieldSources: manifest.fieldSources && typeof manifest.fieldSources === "object" ? manifest.fieldSources : {},
        research: manifest.research && typeof manifest.research === "object" ? manifest.research : null,
        automaticResearch: sourceResearchState(id),
        coverURL: manifest.artwork?.cover?.path ? `/api/source-roms/${encodeURIComponent(id)}/cover` : null,
        artwork: Object.fromEntries([...ARTWORK_TYPES].filter(type => artwork[type]?.path).map(type => [type, `/api/source-roms/${encodeURIComponent(id)}/artwork/${type}`]))
      }
    };
  }

  async function sourceResearchGame(id) {
    const source = await sourceLibraryGame(id);
    const details = await hashFile(source.romPath);
    const header = source.game.system === "nes" && extension(source.romPath) === "nes"
      ? await readHeader(source.romPath) : Buffer.alloc(0);
    return {
      ...source.game, sha256: details.sha256, crc32: details.crc32, bytes: details.bytes,
      romInfo: source.game.system === "nes" ? romInfoForNESFile(source.romPath, header) : null
    };
  }

  async function storeSourceSearchCover(id, candidate) {
    const image = await downloadRemoteImage(candidate.imageURL);
    const temporary = path.join(paths.uploads, `${randomID()}-cover.${extensionForImage(image.contentType)}`);
    await fsp.writeFile(temporary, image.data, { flag: "wx" });
    try { return await storeSourceLibraryCover(id, temporary, path.basename(temporary)); }
    finally { await fsp.rm(temporary, { force: true }); }
  }

  function sourceSnapshot(manifest) {
    const fields = ["title", "sortTitle", "chineseTitle", "description", "englishDescription", "region", "system", "category", "mapper", "players", "releaseYear", "hardware", "fieldLocks", "fieldSources", "research"];
    return Object.fromEntries(fields.filter(key => Object.hasOwn(manifest, key)).map(key => [key, structuredClone(manifest[key])]));
  }

  function recordSourceHistory(manifest, action) {
    const history = Array.isArray(manifest.history) ? manifest.history : [];
    history.unshift({ id: randomID(), action, createdAt: now(), snapshot: sourceSnapshot(manifest) });
    manifest.history = history.slice(0, 20);
  }

  async function updateSourceLibraryGame(id, input, options = {}) {
    const source = await sourceLibraryGame(id);
    if (!options.skipHistory) recordSourceHistory(source.manifest, options.fromResearch ? "联网识别更新资料" : "手工编辑资料");
    // The ROM file decides the system, not the web: a research answer that
    // names a system the file cannot belong to (a .sfc called "nes") would
    // otherwise fail the extension check and abort the whole update.
    if (options.fromResearch && Object.hasOwn(input, "system")
      && !(EXTENSIONS[input.system]?.has(source.game.extension))) {
      input = { ...input };
      delete input.system;
    }
    const updated = validateGameInput(input, source.game);
    const fields = ["title", "sortTitle", "chineseTitle", "description", "englishDescription", "region", "system", "category", "mapper", "players", "releaseYear"];
    source.manifest.fieldLocks = { ...(source.manifest.fieldLocks || {}) };
    source.manifest.fieldSources = { ...(source.manifest.fieldSources || {}) };
    if (Object.hasOwn(input, "collections")) {
      const collections = (Array.isArray(input.collections) ? input.collections : String(input.collections || "").split(/[，,\n]/)).map(value => String(value).trim()).filter(Boolean);
      const library = await configuredCanonicalLibrary();
      await updateCanonicalGameCollections(library, id, updated.system, collections);
      // Stop emitting the pre-contract per-game representation. It remains
      // readable above so old libraries migrate naturally when edited.
      delete source.manifest.collections;
    }
    if (input.fieldLocks && typeof input.fieldLocks === "object") for (const key of fields) if (Object.hasOwn(input.fieldLocks, key)) source.manifest.fieldLocks[key] = Boolean(input.fieldLocks[key]);
    for (const key of fields) {
      if (options.fromResearch && source.manifest.fieldLocks[key]) continue;
      if (options.fillMissing && source.manifest[key] != null && source.manifest[key] !== "") continue;
      if (key === "mapper") source.manifest.mapper = Number.isInteger(updated.mapper) ? updated.mapper : 0;
      else if (updated[key] == null || updated[key] === "") delete source.manifest[key];
      else source.manifest[key] = updated[key];
      if (Object.hasOwn(input, key)) source.manifest.fieldSources[key] = options.fromResearch ? "DeepSeek Web Search" : "手工编辑";
    }
    if (!Object.keys(source.manifest.fieldLocks).length) delete source.manifest.fieldLocks;
    if (!Object.keys(source.manifest.fieldSources).length) delete source.manifest.fieldSources;
    if ((source.manifest.system === "neoGeo" || source.manifest.system === "arcade") && source.manifest.rom) {
      source.manifest.rom.driver = source.manifest.rom.driver || baseName(source.romPath);
    }
    const driver = source.manifest.rom?.driver || baseName(source.romPath);
    const keyMetadata = cps2DriverMetadata(source.manifest.system, driver);
    if (Object.hasOwn(input, "cps2Key")) {
      const keyHex = validateCPS2KeyHex(input.cps2Key, source.manifest.system, driver);
      if (keyHex) {
        const archived = await detectCPS2KeyInArchive(source.romPath, source.manifest.system, driver);
        if (archived.hex && archived.hex !== keyHex) throw new Error("ROM 压缩包内的 CPS2 key 与填写值不一致。 ");
        source.manifest.emulation = { ...(source.manifest.emulation || {}), cps2Key: {
          format: "cps2-key-20", hex: keyHex, source: archived.hex === keyHex ? "archive" : "manual"
        } };
      } else if (source.manifest.emulation) {
        delete source.manifest.emulation.cps2Key;
        if (!Object.keys(source.manifest.emulation).length) delete source.manifest.emulation;
      }
    } else if (!keyMetadata && source.manifest.emulation?.cps2Key) {
      delete source.manifest.emulation.cps2Key;
      if (!Object.keys(source.manifest.emulation).length) delete source.manifest.emulation;
    }
    if (keyMetadata && !source.manifest.emulation?.cps2Key) {
      const available = await availableCPS2KeyForROM(source.romPath, source.manifest.system, driver);
      if (available.hex) source.manifest.emulation = { ...(source.manifest.emulation || {}), cps2Key: {
        format: "cps2-key-20", hex: available.hex, source: available.source
      } };
    }
    await resolvedManifestCPS2Key(source.manifest, source.romPath);
    await atomicJSON(source.manifestPath, source.manifest);
    await touchCanonicalGame(id);
    await ensureCanonicalArcadeCollection(
      await configuredCanonicalLibrary(), id, source.manifest.system, driver
    );
    // A title supplied by the automatic researcher or the editor is the
    // canonical English title. Keep the ROM filename aligned with it.
    if (Object.hasOwn(input, "title")) {
      await renameSourceROMForEnglishTitle(id);
      return renameSourcePackageForEnglishTitle(id);
    }
    return (await sourceLibraryGame(id)).game;
  }

  /// One-time migration for private libraries created before manifest v1
  /// gained emulation.cps2Key. It prefers a key verified inside the exact ROM
  /// ZIP, then uses the CRC-verified private table bundled with this service.
  async function migrateSourceCPS2Keys() {
    return withWrite(async () => {
      const library = await configuredCanonicalLibrary();
      const result = { checked: 0, migrated: [], alreadyConfigured: [], missing: [], invalid: [] };
      for (const item of library.index.games) {
        let source;
        try { source = await sourceLibraryGame(String(item.id)); }
        catch (error) {
          if (/CPS2 key|ZIP ROM|\.key/i.test(error.message || "")) result.invalid.push({ id: String(item.id), error: error.message });
          continue;
        }
        if (!source.game.cps2KeyRequired) continue;
        result.checked++;
        if (source.manifest.emulation?.cps2Key) {
          result.alreadyConfigured.push(String(item.id));
        } else if (source.game.cps2Key && ["archive", "builtin"].includes(source.game.cps2KeyStatus)) {
          await updateSourceLibraryGame(String(item.id), { cps2Key: source.game.cps2Key }, { skipHistory: true });
          result.migrated.push(String(item.id));
        } else {
          result.missing.push(String(item.id));
        }
      }
      return result;
    });
  }

  async function renameSourceROMForEnglishTitle(id) {
    const source = await sourceLibraryGame(id);
    const currentName = path.basename(source.romPath);
    // The independent arcade catalog chooses its driver from the archive
    // basename (for example, `sfz2al.zip` or `mslug3.zip`). Titles and artwork
    // are editable metadata, but the hardware-driver filename is immutable.
    if (isArcadeDriverArchive(source.manifest.system, currentName)) return source.game;
    let nextName = englishROMFileName(source.manifest.title, currentName);
    if (nextName === currentName) return source.game;
    const romDirectory = path.dirname(source.romPath);
    let destination = path.join(romDirectory, nextName);
    try {
      const existing = await hashFile(destination);
      if (existing.sha256 === source.manifest.rom.sha256) {
        await fsp.rm(source.romPath, { force: true });
      } else {
        const suffix = String(source.manifest.rom.sha256 || source.game.id).slice(0, 8);
        nextName = safeName(baseName(nextName) + "-" + suffix + "." + extension(nextName));
        destination = path.join(romDirectory, nextName);
        await fsp.access(destination);
        throw new Error("无法重命名 ROM：目标文件已存在（" + nextName + "）。");
      }
    } catch (error) {
      if (error.code === "ENOENT") await fsp.rename(source.romPath, destination);
      else throw error;
    }
    const previousPath = source.manifest.rom.path;
    source.manifest.rom.path = "rom/" + nextName;
    try { await atomicJSON(source.manifestPath, source.manifest); }
    catch (error) {
      source.manifest.rom.path = previousPath;
      if (await fsp.stat(destination).then(() => true).catch(() => false)) await fsp.rename(destination, source.romPath);
      throw error;
    }
    return (await sourceLibraryGame(id)).game;
  }

  async function renameSourcePackageForEnglishTitle(id) {
    const library = await configuredCanonicalLibrary();
    const item = library.index.games.find(game => String(game.id) === id);
    if (!item) throw new Error("资料库中没有此游戏。");
    const source = await sourceLibraryGame(id);
    const desired = englishGamePackageID(source.manifest.title, source.manifest.rom?.sha256, id);
    const nextID = uniqueID(desired, library.index.games.map(game => String(game.id)).filter(candidate => candidate !== id));
    if (nextID === id) return source.game;
    const packageDirectory = path.posix.dirname(path.posix.dirname(item.manifest));
    if (!packageDirectory || packageDirectory === ".") throw new Error("资料库清单中的游戏目录无效。");
    const oldRoot = path.dirname(source.manifestPath);
    const newRoot = path.join(library.root, packageDirectory, nextID);
    const oldID = source.manifest.id;
    const oldManifest = item.manifest;
    await fsp.rename(oldRoot, newRoot);
    source.manifest.id = nextID;
    item.id = nextID;
    item.manifest = packageDirectory + "/" + nextID + "/manifest.json";
    item.updatedAt = now();
    library.index.updatedAt = item.updatedAt;
    try {
      await atomicJSON(path.join(newRoot, "manifest.json"), source.manifest);
      await atomicJSON(library.indexPath, library.index);
      await replaceCanonicalCollectionGameID(library, id, nextID);
    } catch (error) {
      source.manifest.id = oldID;
      item.id = id;
      item.manifest = oldManifest;
      await fsp.rename(newRoot, oldRoot).catch(() => {});
      throw error;
    }
    return (await sourceLibraryGame(nextID)).game;
  }

  async function normaliseSourceEnglishName(id) {
    const source = await sourceLibraryGame(id);
    if (isArcadeDriverArchive(source.manifest.system, path.basename(source.romPath))) {
      throw new Error("Arcade / Neo Geo 驱动包必须保留原始文件名，不能按显示名称重命名。 ");
    }
    await renameSourceROMForEnglishTitle(id);
    return renameSourcePackageForEnglishTitle(id);
  }

  async function storeSourceLibraryCover(id, temporary, originalName) {
    return storeSourceLibraryArtwork(id, "cover", temporary, originalName);
  }

  async function storeSourceLibraryArtwork(id, type, temporary, originalName) {
    if (type === "background") type = "backdrop";
    if (!ARTWORK_TYPES.has(type)) throw new Error("不支持的素材类型。 ");
    const ext = extension(originalName);
    if (!IMAGE_EXTENSIONS.has(ext)) throw new Error("素材仅支持 PNG、JPG 或 WebP。");
    const source = await sourceLibraryGame(id);
    recordSourceHistory(source.manifest, `更新${type}素材`);
    const directory = path.join(path.dirname(source.manifestPath), "artwork");
    const destination = path.join(directory, `${type}.${ext}`);
    await fsp.mkdir(directory, { recursive: true });
    const staging = path.join(directory, `.${type}-${randomID()}.${ext}`);
    await fsp.copyFile(temporary, staging); await fsp.rename(staging, destination);
    const details = await hashFile(destination);
    const previous = source.manifest.artwork?.[type]?.path || (type === "backdrop" ? source.manifest.artwork?.background?.path : null);
    source.manifest.artwork = { ...(source.manifest.artwork || {}), [type]: { path: `artwork/${type}.${ext}`, bytes: details.bytes, sha256: details.sha256 } };
    if (type === "backdrop") delete source.manifest.artwork.background;
    await atomicJSON(source.manifestPath, source.manifest);
    await touchCanonicalGame(id);
    if (previous && previous !== source.manifest.artwork[type].path) await fsp.rm(resolvedWithin(path.dirname(source.manifestPath), previous), { force: true });
    return (await sourceLibraryGame(id)).game;
  }

  async function sourceHistory(id) {
    const source = await sourceLibraryGame(id);
    return (Array.isArray(source.manifest.history) ? source.manifest.history : []).map(entry => ({ id: entry.id, action: entry.action, createdAt: entry.createdAt }));
  }

  async function restoreSourceHistory(id, historyID) {
    const source = await sourceLibraryGame(id);
    const entry = (source.manifest.history || []).find(item => item.id === historyID);
    if (!entry?.snapshot) throw new Error("历史记录不存在。 ");
    recordSourceHistory(source.manifest, `恢复历史：${entry.action || "资料版本"}`);
    for (const key of ["title", "sortTitle", "chineseTitle", "description", "englishDescription", "region", "system", "category", "mapper", "players", "releaseYear", "fieldLocks", "fieldSources", "research"]) {
      if (Object.hasOwn(entry.snapshot, key)) source.manifest[key] = structuredClone(entry.snapshot[key]); else delete source.manifest[key];
    }
    await atomicJSON(source.manifestPath, source.manifest);
    await touchCanonicalGame(id);
    return (await sourceLibraryGame(id)).game;
  }

  async function deleteSourceLibraryCover(id) {
    const source = await sourceLibraryGame(id);
    const relative = source.manifest.artwork?.cover?.path;
    if (!relative) return source.game;
    const cover = resolvedWithin(path.dirname(source.manifestPath), relative);
    await fsp.rm(cover, { force: true });
    delete source.manifest.artwork.cover;
    if (!Object.keys(source.manifest.artwork).length) delete source.manifest.artwork;
    await atomicJSON(source.manifestPath, source.manifest);
    await touchCanonicalGame(id);
    return (await sourceLibraryGame(id)).game;
  }

  function sourceResearchState(id) { return automaticResearch.get(`source:${id}`) || null; }

  async function performAutomaticSourceResearch(id, task = null, options = {}) {
    const key = `source:${id}`;
    automaticResearch.set(key, { state: "running", startedAt: now(), message: "正在识别游戏资料…" });
    try {
      const researchGame = await sourceResearchGame(id);
      const sourceBeforeResearch = await sourceLibraryGame(id);
      const missingMetadata = !String(sourceBeforeResearch.manifest.title || "").trim() || !String(sourceBeforeResearch.manifest.chineseTitle || "").trim() || !String(sourceBeforeResearch.manifest.description || "").trim();
      const result = options.fillMissing && !missingMetadata
        ? { metadata: {}, localFallback: false }
        : await withResearchRetry(() => searchGameMetadata(researchGame, false, { includeCoverCandidates: false }), task);
      let currentID = id;
      await withWrite(async () => {
        if (Object.keys(result.metadata || {}).length) currentID = (await updateSourceLibraryGame(id, result.metadata, { fillMissing: Boolean(options.fillMissing), fromResearch: true })).sourceID;
      });

      const afterMetadata = await sourceLibraryGame(currentID);
      const hadCover = Boolean(afterMetadata.manifest.artwork?.cover?.path);
      let coverResult = { candidates: [], localFallback: false };
      if (!hadCover) {
        const runningState = automaticResearch.get(key);
        if (runningState) runningState.message = "资料识别完成，正在使用新资料搜索封面…";
        if (task) task.message = `${currentID}：资料识别完成，正在搜索封面…`;
        const enrichedResearchGame = await sourceResearchGame(currentID);
        coverResult = await withResearchRetry(() => createWebCoverSearch(enrichedResearchGame), task);
        const firstCandidate = coverResult.candidates?.[0];
        if (firstCandidate) {
          const candidate = webCoverCandidate(enrichedResearchGame, firstCandidate.id);
          const temporary = await cachedCandidateImage(candidate);
          await withWrite(() => storeSourceLibraryCover(currentID, temporary, path.basename(temporary)));
        }
      }

      const candidates = coverResult.candidates || [];
      await withWrite(async () => {
        const refreshed = await sourceLibraryGame(currentID);
        refreshed.manifest.research = {
          source: result.localFallback || coverResult.localFallback ? "本地 ROM 识别" : "DeepSeek Web Search",
          confidence: result.localFallback ? 0.3 : Math.min(0.98, 0.45 + Object.keys(result.metadata || {}).length * 0.06 + (candidates.length || hadCover ? 0.12 : 0)),
          updatedAt: now()
        };
        await atomicJSON(refreshed.manifestPath, refreshed.manifest);
      });
      const message = hadCover
        ? "已自动识别资料；保留现有封面。"
        : candidates.length
          ? (result.localFallback ? "已先按本地 ROM 信息建立资料，再从公开站点选择封面。" : "已先识别资料，再使用新资料选择封面。")
          : result.localFallback ? "已按本地 ROM 信息建立资料；未配置 DeepSeek，尚未联网补充封面。" : "已自动识别资料；未找到可验证的封面。";
      automaticResearch.delete(key);
      automaticResearch.set(`source:${currentID}`, { state: "completed", completedAt: now(), message });
      if (task) { task.message = `${currentID}：${message}`; task.completed++; }
      return { id: currentID, message, candidates: candidates.length };
    } catch (error) {
      automaticResearch.set(key, { state: "failed", completedAt: now(), message: error.message || "自动识别失败。" });
      if (task) { task.message = `${id}：${error.message || "自动识别失败。"}`; task.completed++; }
      throw error;
    }
  }

  function startAutomaticSourceResearch(id) {
    const key = `source:${id}`;
    if (automaticResearch.get(key)?.state === "running") return null;
    return startBackgroundTask({ type: "auto-research", title: `自动识别 ${id}`, total: 1 }, task => performAutomaticSourceResearch(id, task));
  }

  async function repairableSourceIDs() {
    const library = await listSourceROMs();
    return library.roms.filter(rom => rom.incompleteMetadata || !rom.hasCover).map(rom => String(rom.id));
  }

  async function startSourceRepairTask() {
    if ([...backgroundTasks.values()].some(task => task.type === "repair-metadata" && (task.state === "queued" || task.state === "running"))) {
      throw new Error("自动补全任务已经在后台运行。 ");
    }
    const ids = await repairableSourceIDs();
    if (!ids.length) throw new Error("资料库没有可自动补全的游戏。 ");
    return startBackgroundTask({ type: "repair-metadata", title: `自动补全 ${ids.length} 个缺失项`, total: ids.length }, async task => {
      const outcome = { completed: 0, failed: 0 };
      for (const id of ids) {
        if (task.cancelRequested) break;
        try { await performAutomaticSourceResearch(id, task, { fillMissing: true }); outcome.completed++; }
        catch { outcome.failed++; }
      }
      task.message = outcome.failed ? `已补全 ${outcome.completed} 个，失败 ${outcome.failed} 个。` : `已补全 ${outcome.completed} 个游戏。`;
      return outcome;
    });
  }

  function sourceIDsFromInput(input) {
    const values = Array.isArray(input?.ids) ? input.ids : [];
    return [...new Set(values.map(value => String(value || "").trim()).filter(Boolean))].slice(0, 100);
  }

  async function startSourceBulkTask(input) {
    const ids = sourceIDsFromInput(input);
    if (!ids.length) throw new Error("请先选择至少一个游戏。 ");
    const action = String(input?.action || "");
    if (action === "research") {
      return startBackgroundTask({ type: "bulk-research", title: `批量联网识别 ${ids.length} 个游戏`, total: ids.length }, async task => {
        const outcome = { completed: 0, failed: 0 };
        for (const id of ids) {
          if (task.cancelRequested) break;
          try { await performAutomaticSourceResearch(id, task); outcome.completed++; }
          catch { outcome.failed++; }
        }
        task.message = outcome.failed ? `已完成 ${outcome.completed} 个，失败 ${outcome.failed} 个。` : `已完成 ${outcome.completed} 个游戏。`;
        return outcome;
      });
    }
    if (action === "delete") {
      return startBackgroundTask({ type: "bulk-delete", title: `批量删除 ${ids.length} 个游戏`, total: ids.length }, async task => {
        let deleted = 0;
        for (const id of ids) {
          if (task.cancelRequested) break;
          await withWrite(() => deleteSourceLibraryGame(id)); deleted++; task.completed++; task.message = `已删除 ${deleted} / ${ids.length} 个游戏。`;
        }
        return { deleted };
      });
    }
    throw new Error("不支持的批量操作。 ");
  }

  async function deleteSourceLibraryGame(id) {
    const library = await configuredCanonicalLibrary();
    const item = library.index.games.find(game => String(game.id) === id);
    if (!item) throw new Error("资料库中没有此游戏。 ");
    const manifestPath = resolvedWithin(library.root, item.manifest);
    const gameRoot = path.dirname(manifestPath);
    const relative = path.relative(library.root, gameRoot);
    if (!relative || relative.startsWith("..") || path.isAbsolute(relative)) throw new Error("拒绝删除资料库外的路径。 ");
    // Canonical collections store explicit game IDs separately from the
    // package index. Remove the ID before deleting the package so clients do
    // not retain a dangling collection entry after a successful deletion.
    await updateCanonicalGameCollections(library, id, "", []);
    library.index.games = library.index.games.filter(game => String(game.id) !== id);
    library.index.updatedAt = now();
    await atomicJSON(library.indexPath, library.index);
    await fsp.rm(gameRoot, { recursive: true, force: true });
    automaticResearch.delete(`source:${id}`);
  }

  async function listDirectories(requestedPath) {
    const browseRoot = path.resolve(process.env.FC_LIBRARY_DIRECTORY_BROWSE_ROOT || path.parse(paths.dataRoot).root);
    const requested = path.resolve(String(requestedPath || catalog.settings.sourceDirectory || browseRoot));
    const relative = path.relative(browseRoot, requested);
    if (relative.startsWith("..") || path.isAbsolute(relative)) throw new Error("该目录不在允许浏览的范围内。");
    const volumesOnly = String(process.env.FC_LIBRARY_DIRECTORY_BROWSE_VOLUMES_ONLY || "").toLowerCase() === "yes";
    const firstSegment = relative.split(path.sep).filter(Boolean)[0];
    if (volumesOnly && firstSegment && !/^volume\d+$/.test(firstSegment)) {
      throw new Error("在 DSM 中只能浏览存储空间目录（/volume1、/volume2 等）。");
    }
    let info;
    try { info = await fsp.stat(requested); } catch { throw new Error("目录不存在或服务无权读取。"); }
    if (!info.isDirectory()) throw new Error("只能浏览文件夹。");
    const entries = await fsp.readdir(requested, { withFileTypes: true });
    const directories = entries.filter(entry => entry.isDirectory() && !entry.name.startsWith(".")
      && (!volumesOnly || requested !== browseRoot || /^volume\d+$/.test(entry.name))).map(entry => ({ name: entry.name, path: path.join(requested, entry.name) }))
      .sort((left, right) => left.name.localeCompare(right.name, "zh-Hans-CN")).slice(0, 500);
    return { path: requested, parent: requested === browseRoot ? null : path.dirname(requested), directories };
  }

  async function canonicalLibraryIfConfigured() {
    if (!String(catalog.settings.sourceDirectory || "").trim()) return null;
    return configuredCanonicalLibrary();
  }

  async function neoGeoBIOSStatus() {
    let file = paths.managedNeoGeoBIOS;
    let relativePath = "neogeo.zip";
    try {
      const canonical = await canonicalLibraryIfConfigured();
      if (canonical) {
        relativePath = canonical.index.bios?.neoGeo?.path || "neogeo.zip";
        file = resolvedWithin(canonical.root, relativePath);
      }
      const details = await validateNeoGeoBIOSArchive(file);
      return {
        configured: true,
        valid: true,
        path: relativePath,
        bytes: details.bytes,
        sha256: details.sha256,
        components: NEOGEO_BIOS_COMPONENTS.map(({ role, name, bytes, crc32 }) => ({ role, name, bytes, crc32 }))
      };
    } catch (error) {
      if (error.code === "ENOENT") return { configured: false, valid: false, path: relativePath };
      return { configured: true, valid: false, path: relativePath, error: error.message };
    }
  }

  async function storeNeoGeoBIOS(source, originalName = "neogeo.zip") {
    if (safeName(originalName).toLowerCase() !== "neogeo.zip") {
      throw new Error("Neo Geo MVS BIOS 必须命名为 neogeo.zip。");
    }
    const sourceDetails = await validateNeoGeoBIOSArchive(source);
    const canonical = await canonicalLibraryIfConfigured();
    const destination = canonical ? path.join(canonical.root, "neogeo.zip") : paths.managedNeoGeoBIOS;
    const staging = `${destination}.${randomID()}.tmp`;
    await fsp.mkdir(path.dirname(destination), { recursive: true });
    try {
      await fsp.copyFile(source, staging);
      const stagedDetails = await validateNeoGeoBIOSArchive(staging);
      if (stagedDetails.bytes !== sourceDetails.bytes || stagedDetails.sha256 !== sourceDetails.sha256) {
        throw new Error("复制后的 neogeo.zip 校验值发生变化。");
      }
      await fsp.chmod(staging, 0o644);
      await fsp.rename(staging, destination);
    } finally {
      await fsp.rm(staging, { force: true });
    }
    if (canonical) {
      canonical.index.bios = {
        ...(canonical.index.bios || {}),
        neoGeo: { path: "neogeo.zip", bytes: sourceDetails.bytes, sha256: sourceDetails.sha256 }
      };
      canonical.index.updatedAt = now();
      await atomicJSON(canonical.indexPath, canonical.index);
    }
    return neoGeoBIOSStatus();
  }

  async function pgmBIOSStatus() {
    let file = paths.managedPGMBIOS;
    let relativePath = "pgm.zip";
    try {
      const canonical = await canonicalLibraryIfConfigured();
      if (canonical) {
        relativePath = canonical.index.bios?.pgm?.path || "pgm.zip";
        file = resolvedWithin(canonical.root, relativePath);
      }
      const details = await validatePGMBIOSArchive(file);
      return {
        configured: true,
        valid: true,
        path: relativePath,
        bytes: details.bytes,
        sha256: details.sha256,
        components: PGM_BIOS_COMPONENTS.map(({ role, name, bytes, crc32 }) => ({ role, name, bytes, crc32 }))
      };
    } catch (error) {
      if (error.code === "ENOENT") return { configured: false, valid: false, path: relativePath };
      return { configured: true, valid: false, path: relativePath, error: error.message };
    }
  }

  async function storePGMBIOS(source, originalName = "pgm.zip") {
    if (safeName(originalName).toLowerCase() !== "pgm.zip") {
      throw new Error("PGM BIOS 必须命名为 pgm.zip。");
    }
    const sourceDetails = await validatePGMBIOSArchive(source);
    const canonical = await canonicalLibraryIfConfigured();
    const destination = canonical ? path.join(canonical.root, "pgm.zip") : paths.managedPGMBIOS;
    const staging = `${destination}.${randomID()}.tmp`;
    await fsp.mkdir(path.dirname(destination), { recursive: true });
    try {
      await fsp.copyFile(source, staging);
      const stagedDetails = await validatePGMBIOSArchive(staging);
      if (stagedDetails.bytes !== sourceDetails.bytes || stagedDetails.sha256 !== sourceDetails.sha256) {
        throw new Error("复制后的 pgm.zip 校验值发生变化。");
      }
      await fsp.chmod(staging, 0o644);
      await fsp.rename(staging, destination);
    } finally {
      await fsp.rm(staging, { force: true });
    }
    if (canonical) {
      canonical.index.bios = {
        ...(canonical.index.bios || {}),
        pgm: { path: "pgm.zip", bytes: sourceDetails.bytes, sha256: sourceDetails.sha256 }
      };
      canonical.index.updatedAt = now();
      await atomicJSON(canonical.indexPath, canonical.index);
    }
    return pgmBIOSStatus();
  }

  async function fdsBIOSStatus() {
    let file = paths.managedFDSBIOS;
    let relativePath = "disksys.rom";
    try {
      const canonical = await canonicalLibraryIfConfigured();
      if (canonical) {
        relativePath = canonical.index.bios?.fds?.path || "disksys.rom";
        file = resolvedWithin(canonical.root, relativePath);
      }
      const details = await validateFDSBIOSFile(file);
      return { configured: true, valid: true, path: relativePath, bytes: details.bytes, sha256: details.sha256, sha1: details.sha1 };
    } catch (error) {
      if (error.code === "ENOENT") return { configured: false, valid: false, path: relativePath };
      return { configured: true, valid: false, path: relativePath, error: error.message };
    }
  }

  async function storeFDSBIOS(source, originalName = "disksys.rom") {
    if (safeName(originalName).toLowerCase() !== "disksys.rom") {
      throw new Error("FDS BIOS 必须命名为 disksys.rom。");
    }
    const sourceDetails = await validateFDSBIOSFile(source);
    const canonical = await canonicalLibraryIfConfigured();
    const destination = canonical ? path.join(canonical.root, "disksys.rom") : paths.managedFDSBIOS;
    const staging = `${destination}.${randomID()}.tmp`;
    await fsp.mkdir(path.dirname(destination), { recursive: true });
    try {
      await fsp.copyFile(source, staging);
      const stagedDetails = await validateFDSBIOSFile(staging);
      if (stagedDetails.sha256 !== sourceDetails.sha256) throw new Error("复制后的 disksys.rom 校验值发生变化。");
      await fsp.chmod(staging, 0o644);
      await fsp.rename(staging, destination);
    } finally {
      await fsp.rm(staging, { force: true });
    }
    if (canonical) {
      canonical.index.bios = {
        ...(canonical.index.bios || {}),
        fds: { path: "disksys.rom", bytes: sourceDetails.bytes, sha256: sourceDetails.sha256 }
      };
      canonical.index.updatedAt = now();
      await atomicJSON(canonical.indexPath, canonical.index);
    }
    return fdsBIOSStatus();
  }

  async function validateSNESIPL(file) {
    const details = await hashFile(file);
    if (details.bytes !== SNES_IPL_BYTES) {
      throw new Error("SPC700 IPL 必须是精确 64 字节的普通文件。");
    }
    return details;
  }

  async function snesIPLStatus() {
    let file = paths.managedSNESIPL;
    let relativePath = "spc700.rom";
    try {
      const canonical = await canonicalLibraryIfConfigured();
      if (canonical) file = path.join(canonical.root, relativePath);
      const details = await validateSNESIPL(file);
      return { configured: true, valid: true, path: relativePath, bytes: details.bytes, sha256: details.sha256 };
    } catch (error) {
      if (error.code === "ENOENT") return { configured: false, valid: false, path: relativePath };
      return { configured: true, valid: false, path: relativePath, error: error.message };
    }
  }

  async function validateSNESNECDSPFirmware(file, name, half = null) {
    const firmwareName = safeName(name).toLowerCase();
    const specification = SNES_COPROCESSOR_FIRMWARE.get(firmwareName);
    if (!specification || (half && !specification.halves?.[half])) {
      throw new Error("未知的 Super NES 协处理器固件名或分片。");
    }
    const details = await hashFile(file);
    const expected = half ? specification.halves[half] : specification.bytes;
    if (details.bytes !== expected) {
      throw new Error(half
        ? `${specification.architecture} ${half === "program" ? "程序" : "数据"} ROM 必须是精确 ${expected} 字节的普通文件。`
        : `${firmwareName} 必须是精确 ${expected} 字节的普通文件。`);
    }
    return details;
  }

  async function snesNECDSPFirmwareRoot() {
    const canonical = await canonicalLibraryIfConfigured();
    return canonical ? canonical.root : paths.managedBIOS;
  }

  // The complete 8192-byte image for `dspN.rom`: the single file when the user
  // supplied it, otherwise the program and data halves joined. Null when
  // nothing is configured; throws when what is there is unusable.
  async function readSNESNECDSPFirmware(root, name) {
    const specification = SNES_COPROCESSOR_FIRMWARE.get(name);
    if (!specification) throw new Error("未知的 Super NES 协处理器固件名。");
    try {
      await validateSNESNECDSPFirmware(path.join(root, name), name);
      return await fsp.readFile(path.join(root, name));
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
    if (!specification.halves) return null;
    const base = name.replace(/\.rom$/, "");
    const halves = {};
    for (const half of ["program", "data"]) {
      try {
        await validateSNESNECDSPFirmware(path.join(root, `${base}.${half}.rom`), name, half);
        halves[half] = await fsp.readFile(path.join(root, `${base}.${half}.rom`));
      } catch (error) {
        if (error.code !== "ENOENT") throw error;
      }
    }
    if (!halves.program && !halves.data) return null;
    if (!halves.program || !halves.data) {
      throw new Error(`只有 ${base}.${halves.program ? "program" : "data"}.rom，还缺 ${base}.${halves.program ? "data" : "program"}.rom。`);
    }
    return Buffer.concat([halves.program, halves.data]);
  }

  async function snesNECDSPFirmwareStatus(name) {
    const relativePath = safeName(name).toLowerCase();
    if (!SNES_COPROCESSOR_FIRMWARE_NAMES.has(relativePath)) throw new Error("未知的 Super NES 协处理器固件名。");
    try {
      const image = await readSNESNECDSPFirmware(await snesNECDSPFirmwareRoot(), relativePath);
      if (!image) return { configured: false, valid: false, path: relativePath };
      return { configured: true, valid: true, path: relativePath, bytes: image.length,
        sha256: crypto.createHash("sha256").update(image).digest("hex") };
    } catch (error) {
      return { configured: true, valid: false, path: relativePath, error: error.message };
    }
  }

  async function snesNECDSPFirmwareStatuses() {
    const statuses = {};
    for (const name of SNES_COPROCESSOR_FIRMWARE_NAMES) statuses[name] = await snesNECDSPFirmwareStatus(name);
    return statuses;
  }

  async function storeSNESNECDSPFirmware(source, originalName) {
    const upload = snesNECDSPFirmwareUploadName(originalName);
    if (!upload) {
      throw new Error("固件必须命名为 dsp1/1b/2/3/4.rom、cx4.rom、st010/011/018.rom，或 DSP/ST 固件的 .program.rom / .data.rom 两半。");
    }
    const sourceDetails = await validateSNESNECDSPFirmware(source, upload.base, upload.half);
    const canonical = String(catalog.settings.sourceDirectory || "").trim()
      ? await configuredCanonicalLibrary({ create: true }) : null;
    const destination = canonical ? path.join(canonical.root, upload.name) : path.join(paths.managedBIOS, upload.name);
    const staging = `${destination}.${randomID()}.tmp`;
    await fsp.mkdir(path.dirname(destination), { recursive: true });
    try {
      await fsp.copyFile(source, staging);
      const stagedDetails = await validateSNESNECDSPFirmware(staging, upload.base, upload.half);
      if (stagedDetails.sha256 !== sourceDetails.sha256) throw new Error("复制后的协处理器固件校验值发生变化。");
      await fsp.chmod(staging, 0o644);
      await fsp.rename(staging, destination);
    } finally {
      await fsp.rm(staging, { force: true });
    }
    return snesNECDSPFirmwareStatus(upload.base);
  }

  async function storeSNESCoprocessorFirmwareArchive(source, originalName) {
    const extracted = await extractSNESCoprocessorFirmwareFromZIP(source, originalName);
    if (!extracted) return null;
    const temporary = path.join(paths.uploads, `${randomID()}-${extracted.name}`);
    await fsp.writeFile(temporary, extracted.data, { flag: "wx", mode: 0o600 });
    try {
      const firmware = await storeSNESNECDSPFirmware(temporary, extracted.name);
      return {
        kind: "snesCoprocessorFirmware",
        firmware,
        originalName: extracted.originalName,
        memberName: extracted.memberName
      };
    } finally {
      await fsp.rm(temporary, { force: true });
    }
  }

  async function storeSNESIPL(source, originalName = "spc700.rom") {
    if (safeName(originalName).toLowerCase() !== "spc700.rom") {
      throw new Error("Super NES SPC700 IPL 必须命名为 spc700.rom。");
    }
    const sourceDetails = await validateSNESIPL(source);
    const canonical = String(catalog.settings.sourceDirectory || "").trim()
      ? await configuredCanonicalLibrary({ create: true }) : null;
    const destination = canonical ? path.join(canonical.root, "spc700.rom") : paths.managedSNESIPL;
    const staging = `${destination}.${randomID()}.tmp`;
    await fsp.mkdir(path.dirname(destination), { recursive: true });
    try {
      await fsp.copyFile(source, staging);
      const stagedDetails = await validateSNESIPL(staging);
      if (stagedDetails.sha256 !== sourceDetails.sha256) throw new Error("复制后的 SPC700 IPL 校验值发生变化。");
      await fsp.chmod(staging, 0o644);
      await fsp.rename(staging, destination);
    } finally {
      await fsp.rm(staging, { force: true });
    }
    return snesIPLStatus();
  }

  async function exportLibrary() {
    const canonical = await canonicalLibraryIfConfigured();
    if (canonical) {
      return {
        games: canonical.index.games.length,
        directory: canonical.root,
        url: "/library/",
        indexURL: "/library/library.json",
        canonicalLibrary: true
      };
    }
    return withWrite(async () => {
      const stage = path.join(paths.exportParent, `.staging-${randomID()}`, "FCEmulatorLibrary");
      const games = [...catalog.games].sort((a, b) => (a.sortTitle || a.title).localeCompare(b.sortTitle || b.title, "zh-Hans-CN"));
      await fsp.mkdir(stage, { recursive: true });
      const indexGames = [];
      for (const game of games) {
        const gameRoot = path.join(stage, "games", game.id);
        const romRelative = `rom/${safeName(game.originalName)}`;
        const romDestination = path.join(gameRoot, romRelative);
        const managedROM = path.join(paths.managedROMs, game.storedName);
        await copyIfAbsent(managedROM, romDestination);
        const arcadeDriver = game.arcadeDriver || ((game.system === "neoGeo" || game.system === "arcade") ? baseName(game.originalName) : null);
        const archivedCPS2Key = await detectCPS2KeyInArchive(managedROM, game.system, arcadeDriver);
        const availableCPS2Key = archivedCPS2Key.hex ? archivedCPS2Key : await availableCPS2KeyForROM(managedROM, game.system, arcadeDriver);
        const configuredCPS2Key = game.cps2Key ? validateCPS2KeyHex(game.cps2Key, game.system, arcadeDriver) : null;
        if (configuredCPS2Key && archivedCPS2Key.hex && configuredCPS2Key !== archivedCPS2Key.hex) {
          throw new Error(`游戏 ${game.title} 的 ROM 内 CPS2 key 与资料库填写值不一致。`);
        }
        const cps2Key = configuredCPS2Key || availableCPS2Key.hex;
        let cover;
        if (game.cover) {
          const coverRelative = `artwork/cover.${game.cover.extension}`;
          await copyIfAbsent(path.join(paths.managedArtwork, game.cover.storedName), path.join(gameRoot, coverRelative));
          cover = { path: coverRelative, bytes: game.cover.bytes, sha256: game.cover.sha256 };
        }
        const manifest = {
          schemaVersion: 1, id: game.id, title: game.title,
          ...(game.sortTitle ? { sortTitle: game.sortTitle } : {}), system: game.system, mapper: game.mapper || 0,
          ...(game.region ? { region: game.region } : {}),
          ...(game.releaseYear ? { releaseYear: game.releaseYear } : {}),
          ...(game.players ? { players: game.players } : {}),
          category: categoryForSystem(game.category, game.system), ...(game.chineseTitle ? { chineseTitle: game.chineseTitle } : {}),
          ...(game.description ? { description: game.description } : {}),
          ...(game.englishDescription ? { englishDescription: game.englishDescription } : {}),
          rom: {
            path: romRelative, bytes: game.bytes, sha256: game.sha256,
            ...(arcadeDriver ? { driver: arcadeDriver } : {}),
            ...(game.arcadeDescriptor ? { arcade: game.arcadeDescriptor } : {})
          },
          ...(cps2Key ? { emulation: { cps2Key: {
            format: "cps2-key-20", hex: cps2Key,
            source: archivedCPS2Key.hex === cps2Key ? "archive" : "manual"
          } } } : {}),
          ...(cover ? { artwork: { cover } } : {})
        };
        await atomicJSON(path.join(gameRoot, "manifest.json"), manifest);
        indexGames.push({ id: game.id, manifest: `games/${game.id}/manifest.json` });
      }
      if (catalog.collections.length) {
        await atomicJSON(path.join(stage, "collections.json"), { schemaVersion: 1, collections: catalog.collections });
      }
      let neoGeoBIOS;
      try {
        const details = await validateNeoGeoBIOSArchive(paths.managedNeoGeoBIOS);
        await fsp.copyFile(paths.managedNeoGeoBIOS, path.join(stage, "neogeo.zip"));
        neoGeoBIOS = { path: "neogeo.zip", bytes: details.bytes, sha256: details.sha256 };
      } catch (error) {
        if (error.code !== "ENOENT") throw error;
      }
      let fdsBIOS;
      try {
        const details = await validateFDSBIOSFile(paths.managedFDSBIOS);
        await fsp.copyFile(paths.managedFDSBIOS, path.join(stage, "disksys.rom"));
        fdsBIOS = { path: "disksys.rom", bytes: details.bytes, sha256: details.sha256 };
      } catch (error) {
        if (error.code !== "ENOENT") throw error;
      }
      let pgmBIOS;
      try {
        const details = await validatePGMBIOSArchive(paths.managedPGMBIOS);
        await fsp.copyFile(paths.managedPGMBIOS, path.join(stage, "pgm.zip"));
        pgmBIOS = { path: "pgm.zip", bytes: details.bytes, sha256: details.sha256 };
      } catch (error) {
        if (error.code !== "ENOENT") throw error;
      }
      await atomicJSON(path.join(stage, "library.json"), {
        schemaVersion: 1, title: catalog.settings.title || "FC Emulator Library", games: indexGames,
        ...(catalog.collections.length ? { collections: "collections.json" } : {}),
        ...((neoGeoBIOS || fdsBIOS || pgmBIOS) ? { bios: {
          ...(neoGeoBIOS ? { neoGeo: neoGeoBIOS } : {}),
          ...(fdsBIOS ? { fds: fdsBIOS } : {}),
          ...(pgmBIOS ? { pgm: pgmBIOS } : {})
        } } : {})
      });
      const backup = path.join(paths.exportParent, ".previous-FCEmulatorLibrary");
      await fsp.rm(backup, { recursive: true, force: true });
      try { await fsp.rename(paths.exportRoot, backup); } catch (error) { if (error.code !== "ENOENT") throw error; }
      await fsp.rename(stage, paths.exportRoot);
      await fsp.rm(path.dirname(stage), { recursive: true, force: true });
      // Apple TV expects a directory root and appends `library.json` itself.
      // Keep the index URL separate so the management UI cannot accidentally
      // hand the client `/library/library.json` as its root.
      return {
        games: games.length,
        directory: paths.exportRoot,
        url: "/library/",
        indexURL: "/library/library.json"
      };
    });
  }

  async function libraryRootForServing() {
    if (!String(catalog.settings.sourceDirectory || "").trim()) return paths.exportRoot;
    // Serving one file under /library/ only needs the library root. Reading the
    // whole index and re-validating the three BIOS archives here cost ~1.5s on
    // every request, and a client sync fetches one manifest per game: a 1165
    // game library spent over half an hour on this alone. The index repair and
    // BIOS synchronisation still run on the API paths that read the catalogue.
    const root = await resolvedSourceDirectory();
    try {
      const info = await fsp.stat(path.join(root, "library.json"));
      if (!info.isFile()) throw Object.assign(new Error("ENOENT"), { code: "ENOENT" });
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      const missing = new Error("此目录还不是 FC Emulator 资料库：缺少 library.json。可直接上传首个 ROM 来创建资料库。");
      missing.code = "FC_LIBRARY_INDEX_MISSING";
      throw missing;
    }
    return root;
  }

  async function serveFile(res, file, cache = "no-store", req = null) {
    try {
      const info = await fsp.stat(file);
      if (!info.isFile()) return false;
      const eTag = `"fc-file-${info.size.toString(16)}-${Math.trunc(info.mtimeMs).toString(16)}"`;
      const lastModified = info.mtime.toUTCString();
      const headers = {
        "Content-Type": MIME_TYPES[path.extname(file).toLowerCase()] || "application/octet-stream",
        "Content-Length": info.size,
        "Cache-Control": cache,
        "ETag": eTag,
        "Last-Modified": lastModified,
        "Accept-Ranges": "bytes",
        "X-Content-Type-Options": "nosniff"
      };
      const ifNoneMatch = req?.headers?.["if-none-match"];
      const ifModifiedSince = req?.headers?.["if-modified-since"];
      const modifiedSince = ifModifiedSince ? new Date(ifModifiedSince) : null;
      if (ifNoneMatch === eTag || (!ifNoneMatch && modifiedSince && !Number.isNaN(modifiedSince.valueOf()) && info.mtime <= modifiedSince)) {
        res.writeHead(304, { "Cache-Control": cache, "ETag": eTag, "Last-Modified": lastModified });
        res.end();
        return true;
      }
      const rangeHeader = req?.headers?.range;
      const ifRange = req?.headers?.["if-range"];
      const ifRangeDate = ifRange && ifRange !== eTag ? new Date(ifRange) : null;
      const rangeValidatorMatches = !ifRange || ifRange === eTag || (
        ifRangeDate && !Number.isNaN(ifRangeDate.valueOf()) &&
        Math.trunc(info.mtimeMs / 1000) * 1000 <= ifRangeDate.valueOf()
      );
      let range = null;
      if (rangeHeader && rangeValidatorMatches) {
        const match = /^bytes=(\d*)-(\d*)$/.exec(String(rangeHeader).trim());
        if (match && info.size > 0 && (match[1] || match[2])) {
          if (match[1]) {
            const start = Number(match[1]);
            const requestedEnd = match[2] ? Number(match[2]) : info.size - 1;
            if (Number.isSafeInteger(start) && Number.isSafeInteger(requestedEnd) &&
                start >= 0 && requestedEnd >= start && start < info.size) {
              range = { start, end: Math.min(requestedEnd, info.size - 1) };
            }
          } else {
            const suffix = Number(match[2]);
            if (Number.isSafeInteger(suffix) && suffix > 0) {
              range = { start: Math.max(0, info.size - suffix), end: info.size - 1 };
            }
          }
        }
        if (!range) {
          res.writeHead(416, {
            "Content-Range": `bytes */${info.size}`,
            "Accept-Ranges": "bytes",
            "Cache-Control": cache,
            "ETag": eTag,
            "Last-Modified": lastModified,
            "X-Content-Type-Options": "nosniff"
          });
          res.end();
          return true;
        }
      }
      if (range) {
        const partialHeaders = {
          ...headers,
          "Content-Length": range.end - range.start + 1,
          "Content-Range": `bytes ${range.start}-${range.end}/${info.size}`
        };
        res.writeHead(206, partialHeaders);
        if (req?.method === "HEAD") res.end();
        else fs.createReadStream(file, range).pipe(res);
      } else {
        res.writeHead(200, headers);
        if (req?.method === "HEAD") res.end();
        else fs.createReadStream(file).pipe(res);
      }
      return true;
    } catch (error) { if (error.code === "ENOENT") return false; throw error; }
  }

  function serveData(res, data, contentType, cache = "no-store") {
    res.writeHead(200, { "Content-Type": contentType, "Content-Length": data.length, "Cache-Control": cache, "X-Content-Type-Options": "nosniff" });
    res.end(data);
  }

  function authorized(req, library = false) {
    const configured = managementToken;
    if (!configured) return true;
    if (library && process.env.FC_LIBRARY_PROTECT_LIBRARY !== "1") return true;
    const auth = req.headers.authorization || "";
    const queryToken = new URL(req.url, "http://library.local").searchParams.get("token") || "";
    return auth === `Bearer ${configured}` || auth === `Basic ${Buffer.from(`admin:${configured}`).toString("base64")}` || queryToken === configured;
  }

  function fail(res, status, message) { json(res, status, { error: message }); }
  function json(res, status, value) { res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" }); res.end(`${JSON.stringify(value)}\n`); }
  async function bodyJSON(req) {
    const chunks = []; let total = 0;
    for await (const chunk of req) { total += chunk.length; if (total > 1_000_000) throw new Error("请求过大。"); chunks.push(chunk); }
    try { return JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}"); } catch { throw new Error("JSON 请求无效。"); }
  }
  async function uploadRequest(req, temp, maximumBytes = null) {
    const maximum = maximumBytes ?? Number(process.env.FC_LIBRARY_MAX_UPLOAD_MB || 2048) * 1024 * 1024;
    const advertised = Number(req.headers["content-length"] || 0);
    if (advertised > maximum) throw new Error(`文件超过 ${Math.floor(maximum / 1024 / 1024)} MB 上传限制。`);
    let received = 0;
    const limiter = new (require("node:stream").Transform)({ transform(chunk, _, callback) {
      received += chunk.length; callback(received > maximum ? new Error("文件超过上传限制。") : null, chunk);
    }});
    await pipeline(req, limiter, fs.createWriteStream(temp, { flags: "wx" }));
    if (!received) throw new Error("没有收到文件。");
  }

  // Save data is deliberately separate from the exported ROM library.  A
  // public `/library` share must never expose a player's battery RAM or save
  // state, while the authenticated manager API can retain it across an Apple
  // TV cache purge.  The key is an immutable ROM SHA-256 supplied by the
  // client, never a filename or a game title.
  function saveKey(system, romSHA256) {
    if (!SAVE_SYSTEMS.includes(system) || !/^[a-f0-9]{64}$/i.test(romSHA256)) {
      throw new Error("存档键无效。 ");
    }
    return `${system}-${romSHA256.toLowerCase()}`;
  }

  function saveETag(version) { return `"fc-save-${version}"`; }

  async function saveBody(req) {
    const maximum = Math.min(24, Math.max(1, Number(process.env.FC_LIBRARY_MAX_SAVE_MB || 20))) * 1024 * 1024;
    const advertised = Number(req.headers["content-length"] || 0);
    if (advertised > maximum) throw new Error(`存档超过 ${Math.floor(maximum / 1024 / 1024)} MB 限制。`);
    const chunks = []; let received = 0;
    for await (const chunk of req) {
      received += chunk.length;
      if (received > maximum) throw new Error(`存档超过 ${Math.floor(maximum / 1024 / 1024)} MB 限制。`);
      chunks.push(chunk);
    }
    if (!received) throw new Error("没有收到存档数据。 ");
    return Buffer.concat(chunks);
  }

  async function loadSave(system, romSHA256) {
    const key = saveKey(system, romSHA256);
    const metadataFile = path.join(paths.saves, `${key}.json`);
    const payloadFile = path.join(paths.saves, `${key}.bin`);
    try {
      const [metadata, payload] = await Promise.all([
        fsp.readFile(metadataFile, "utf8").then(JSON.parse), fsp.readFile(payloadFile)
      ]);
      if (!Number.isSafeInteger(metadata.version) || metadata.version < 1 || typeof metadata.identity !== "string") {
        throw new Error("服务器存档元数据无效。 ");
      }
      return { key, metadata, payload, metadataFile, payloadFile };
    } catch (error) {
      if (error.code === "ENOENT") return { key, metadata: null, payload: null, metadataFile, payloadFile };
      throw error;
    }
  }

  async function storeSave(system, romSHA256, payload, identity, ifMatch) {
    if (!/^[A-Za-z0-9._:-]{1,256}$/.test(identity)) throw new Error("存档身份无效。 ");
    return withWrite(async () => {
      const current = await loadSave(system, romSHA256);
      const currentETag = current.metadata ? saveETag(current.metadata.version) : null;
      if ((current.metadata && !ifMatch) || (ifMatch && ifMatch !== currentETag)) {
        const error = new Error("存档版本冲突。请先下载服务器版本后再决定保留哪个版本。 ");
        error.code = "FC_SAVE_CONFLICT";
        throw error;
      }
      const version = (current.metadata?.version || 0) + 1;
      const metadata = { schemaVersion: 1, system, romSHA256: romSHA256.toLowerCase(), identity, version, updatedAt: now(), bytes: payload.length };
      const temporary = `${current.payloadFile}.${randomID()}.tmp`;
      await fsp.mkdir(paths.saves, { recursive: true });
      await fsp.writeFile(temporary, payload, { flag: "wx", mode: 0o600 });
      await fsp.rename(temporary, current.payloadFile);
      await atomicJSON(current.metadataFile, metadata);
      return { metadata, eTag: saveETag(version) };
    });
  }

  async function request(req, res) {
    const url = new URL(req.url, "http://library.local");
    const pathname = decodeURIComponent(url.pathname);
    try {
      if (pathname.startsWith("/library")) {
        if (!authorized(req, true)) return fail(res, 401, "资料库需要 Bearer Token。"), undefined;
        const relative = pathname === "/library" || pathname === "/library/" ? "library.json" : safeRelative(pathname.slice("/library/".length));
        const libraryRoot = await libraryRootForServing();
        const target = path.resolve(libraryRoot, relative);
        if (!target.startsWith(`${libraryRoot}${path.sep}`) && target !== libraryRoot) return fail(res, 400, "无效资料库路径。");
        if (!(await serveFile(res, target, "public, max-age=60", req))) fail(res, 404, "资料库文件不存在。请确认资料库目录。 ");
        return;
      }
      if (pathname === "/" || pathname === "/index.html") return void (await serveFile(res, path.join(publicRoot, "index.html")) || fail(res, 404, "管理界面缺失。"));
      if (pathname.startsWith("/assets/")) {
        const target = path.resolve(publicRoot, safeRelative(pathname.slice("/assets/".length)));
        if (!target.startsWith(`${publicRoot}${path.sep}`)) return fail(res, 400, "无效静态资源路径。");
        if (!(await serveFile(res, target, "public, max-age=300"))) fail(res, 404, "资源不存在。");
        return;
      }
      if (!pathname.startsWith("/api/")) return fail(res, 404, "不存在的页面。");
      if (!authorized(req)) return fail(res, 401, "管理 API 需要 Bearer Token。"), undefined;
      const saveMatch = pathname.match(/^\/api\/saves\/(nes|megaDrive|neoGeo|arcade)\/([a-fA-F0-9]{64})$/);
      if (saveMatch) {
        const [, system, romSHA256] = saveMatch;
        if (req.method === "GET") {
          const saved = await loadSave(system, romSHA256);
          if (!saved.metadata || !saved.payload) return fail(res, 404, "服务器没有此存档。 ");
          res.writeHead(200, {
            "Content-Type": "application/vnd.fc-emulator.save",
            "Content-Length": saved.payload.length,
            "Cache-Control": "no-store",
            "ETag": saveETag(saved.metadata.version),
            "X-FC-Save-Identity": saved.metadata.identity,
            "X-FC-Save-Version": String(saved.metadata.version),
            "X-Content-Type-Options": "nosniff"
          });
          return res.end(saved.payload);
        }
        if (req.method === "PUT") {
          const identity = String(req.headers["x-fc-save-identity"] || "");
          const result = await storeSave(system, romSHA256, await saveBody(req), identity, String(req.headers["if-match"] || ""));
          return json(res, 200, { version: result.metadata.version, updatedAt: result.metadata.updatedAt, bytes: result.metadata.bytes, eTag: result.eTag });
        }
      }
      if (req.method === "GET" && pathname === "/api/health") return json(res, 200, { ok: true, dataRoot: paths.dataRoot, exported: fs.existsSync(path.join(paths.exportRoot, "library.json")) });
      if (req.method === "GET" && pathname === "/api/catalog") return json(res, 200, serializedCatalog());
      if (req.method === "GET" && pathname === "/api/neogeo-bios") return json(res, 200, await neoGeoBIOSStatus());
      if (req.method === "POST" && pathname === "/api/neogeo-bios") {
        const name = safeName(url.searchParams.get("name"), "neogeo.zip");
        const temporary = path.join(paths.uploads, `${randomID()}-neogeo.zip`);
        await uploadRequest(req, temporary, MAX_NEOGEO_BIOS_BYTES);
        try { return json(res, 201, await withWrite(() => storeNeoGeoBIOS(temporary, name))); }
        finally { await fsp.rm(temporary, { force: true }); }
      }
      if (req.method === "GET" && pathname === "/api/fds-bios") return json(res, 200, await fdsBIOSStatus());
      if (req.method === "POST" && pathname === "/api/fds-bios") {
        const name = safeName(url.searchParams.get("name"), "disksys.rom");
        const temporary = path.join(paths.uploads, `${randomID()}-disksys.rom`);
        await uploadRequest(req, temporary, FDS_BIOS_BYTES);
        try { return json(res, 201, await withWrite(() => storeFDSBIOS(temporary, name))); }
        finally { await fsp.rm(temporary, { force: true }); }
      }
      if (req.method === "GET" && pathname === "/api/snes-ipl") return json(res, 200, await snesIPLStatus());
      if (req.method === "POST" && pathname === "/api/snes-ipl") {
        const name = safeName(url.searchParams.get("name"), "spc700.rom");
        const temporary = path.join(paths.uploads, `${randomID()}-spc700.rom`);
        await uploadRequest(req, temporary, SNES_IPL_BYTES);
        try { return json(res, 201, await withWrite(() => storeSNESIPL(temporary, name))); }
        finally { await fsp.rm(temporary, { force: true }); }
      }
      if (req.method === "GET" && ["/api/snes-coprocessor-firmware", "/api/snes-necdsp-firmware"].includes(pathname)) {
        return json(res, 200, await snesNECDSPFirmwareStatuses());
      }
      if (req.method === "POST" && ["/api/snes-coprocessor-firmware", "/api/snes-necdsp-firmware"].includes(pathname)) {
        const name = safeName(url.searchParams.get("name"), "dsp1b.rom");
        const temporary = path.join(paths.uploads, `${randomID()}-coprocessor.rom`);
        await uploadRequest(req, temporary, SNES_COPROCESSOR_MAX_FIRMWARE_BYTES);
        try { return json(res, 201, await withWrite(() => storeSNESNECDSPFirmware(temporary, name))); }
        finally { await fsp.rm(temporary, { force: true }); }
      }
      if (req.method === "GET" && pathname === "/api/pgm-bios") return json(res, 200, await pgmBIOSStatus());
      if (req.method === "POST" && pathname === "/api/pgm-bios") {
        const name = safeName(url.searchParams.get("name"), "pgm.zip");
        const temporary = path.join(paths.uploads, `${randomID()}-pgm.zip`);
        await uploadRequest(req, temporary, MAX_PGM_BIOS_BYTES);
        try { return json(res, 201, await withWrite(() => storePGMBIOS(temporary, name))); }
        finally { await fsp.rm(temporary, { force: true }); }
      }
      if (req.method === "GET" && pathname === "/api/settings") return json(res, 200, { settings: publicSettings(), paths: { dropbox: paths.dropbox, exportRoot: paths.exportRoot } });
      if (req.method === "GET" && pathname === "/api/directories") return json(res, 200, await listDirectories(url.searchParams.get("path")));
      if (req.method === "GET" && pathname === "/api/tasks") return json(res, 200, { tasks: listBackgroundTasks(), sourceRevision });
      const cancelTaskMatch = pathname.match(/^\/api\/tasks\/([^/]+)\/cancel$/);
      if (req.method === "POST" && cancelTaskMatch) return json(res, 200, { task: cancelBackgroundTask(decodeURIComponent(cancelTaskMatch[1])) });
      if (req.method === "GET" && pathname === "/api/source-health") return json(res, 200, await sourceHealthSnapshot());
      if (req.method === "POST" && pathname === "/api/source-audit") {
        const input = await bodyJSON(req);
        const full = Boolean(input.full);
        const library = await configuredCanonicalLibrary();
        const task = startBackgroundTask({ type: full ? "full-audit" : "quick-audit", title: full ? "完整校验资料库" : "快速扫描资料库", total: library.index.games.length }, async item => {
          const result = await auditSourceLibrary({ full, onProgress(completed, total, title) { item.completed = completed; item.total = total; item.message = `正在检查：${title}`; } });
          item.completed = result.summary.checked; item.message = `校验完成：${result.summary.valid} 个有效，${result.issues.length} 个待处理项。`;
          return result;
        });
        return json(res, 202, { task });
      }
      if (req.method === "POST" && pathname === "/api/source-repair") return json(res, 202, { task: await startSourceRepairTask() });
      if (req.method === "GET" && pathname === "/api/source-roms") return json(res, 200, await sourceROMPage(url));
      if (req.method === "POST" && pathname === "/api/source-roms/bulk") return json(res, 202, { task: await startSourceBulkTask(await bodyJSON(req)) });
      const sourceArtworkMatch = pathname.match(/^\/api\/source-roms\/([^/]+)\/artwork\/(cover|backdrop|background|logo)$/);
      if (sourceArtworkMatch && req.method === "GET") {
        const artwork = await sourceLibraryArtwork(decodeURIComponent(sourceArtworkMatch[1]), sourceArtworkMatch[2]);
        return void (await serveFile(res, artwork, "private, max-age=300") || fail(res, 404, "素材文件缺失。"));
      }
      const sourceCoverMatch = pathname.match(/^\/api\/source-roms\/([^/]+)\/cover$/);
      if (req.method === "GET" && sourceCoverMatch) {
        const cover = await sourceLibraryCover(decodeURIComponent(sourceCoverMatch[1]));
        return void (await serveFile(res, cover, "private, max-age=300") || fail(res, 404, "封面文件缺失。"));
      }
      const sourceGameMatch = pathname.match(/^\/api\/source-roms\/([^/]+)(?:\/(.+))?$/);
      if (sourceGameMatch) {
        const id = decodeURIComponent(sourceGameMatch[1]); const action = sourceGameMatch[2] || "";
        if (req.method === "GET" && !action) return json(res, 200, (await sourceLibraryGame(id)).game);
        if (req.method === "PATCH" && !action) {
          const input = await bodyJSON(req);
          return json(res, 200, await withWrite(() => updateSourceLibraryGame(id, input)));
        }
        if (req.method === "DELETE" && !action) {
          await withWrite(() => deleteSourceLibraryGame(id));
          return json(res, 204, {});
        }
        if (req.method === "POST" && action === "cover") {
          const name = safeName(url.searchParams.get("name"), "cover.png");
          const temporary = path.join(paths.uploads, `${randomID()}-${name}`); await uploadRequest(req, temporary);
          try { return json(res, 201, await withWrite(() => storeSourceLibraryCover(id, temporary, name))); }
          finally { await fsp.rm(temporary, { force: true }); }
        }
        const artworkUpload = action.match(/^artwork\/(backdrop|background|logo)$/);
        if (req.method === "POST" && artworkUpload) {
          const name = safeName(url.searchParams.get("name"), `${artworkUpload[1]}.png`);
          const temporary = path.join(paths.uploads, `${randomID()}-${name}`); await uploadRequest(req, temporary);
          try { return json(res, 201, await withWrite(() => storeSourceLibraryArtwork(id, artworkUpload[1], temporary, name))); }
          finally { await fsp.rm(temporary, { force: true }); }
        }
        if (req.method === "POST" && action === "metadata-search") return json(res, 200, await searchGameMetadata(await sourceResearchGame(id)));
        if (req.method === "POST" && action === "cover-search") return json(res, 200, await createWebCoverSearch(await sourceResearchGame(id)));
        if (req.method === "POST" && action === "auto-research") { startAutomaticSourceResearch(id); return json(res, 202, { accepted: true }); }
        if (req.method === "DELETE" && action === "cover") return json(res, 200, await withWrite(() => deleteSourceLibraryCover(id)));
        if (req.method === "POST" && action === "rename-rom") return json(res, 200, await withWrite(() => normaliseSourceEnglishName(id)));
        if (req.method === "GET" && action === "history") return json(res, 200, { entries: await sourceHistory(id) });
        const historyRestore = action.match(/^history\/([^/]+)\/restore$/);
        if (req.method === "POST" && historyRestore) return json(res, 200, await withWrite(() => restoreSourceHistory(id, historyRestore[1])));
        if (req.method === "GET" && action === "search-diagnostic") return json(res, 200, { diagnostic: webSearchDiagnostic((await sourceLibraryGame(id)).game) });
        const sourceSearchMatch = action.match(/^cover-search\/([^/]+)\/(preview|select)$/);
        if (sourceSearchMatch) {
          const game = await sourceLibraryGame(id);
          const candidate = webCoverCandidate(game.game, sourceSearchMatch[1]);
          if (req.method === "GET" && sourceSearchMatch[2] === "preview") {
            const temporary = await cachedCandidateImage(candidate);
            return void (await serveFile(res, temporary, "private, max-age=120") || fail(res, 404, "封面预览已过期，请重新搜索。"));
          }
          if (req.method === "POST" && sourceSearchMatch[2] === "select") {
            const updated = await withWrite(async () => {
              const temporary = await cachedCandidateImage(candidate);
              return storeSourceLibraryCover(id, temporary, path.basename(temporary));
            });
            return json(res, 201, updated);
          }
        }
      }
      if (req.method === "PATCH" && pathname === "/api/settings") {
        const input = await bodyJSON(req);
        await withWrite(async () => {
          if (Object.hasOwn(input, "title")) catalog.settings.title = String(input.title || "").trim() || "FC Emulator Library";
          if (Object.hasOwn(input, "sourceDirectory")) catalog.settings.sourceDirectory = String(input.sourceDirectory || "").trim();
          if (Object.hasOwn(input, "preferredSearchSites")) catalog.settings.preferredSearchSites = normalisePreferredSearchSites(input.preferredSearchSites);
          if (Object.hasOwn(input, "coverDirectory")) catalog.settings.coverDirectory = String(input.coverDirectory || "").trim();
          if (Object.hasOwn(input, "autoMatchThreshold")) catalog.settings.autoMatchThreshold = Math.min(1, Math.max(0, Number(input.autoMatchThreshold) || 0.88));
          if (Object.hasOwn(input, "deepSeekApiKey") && String(input.deepSeekApiKey || "").trim()) await configureDeepSeekKey(input.deepSeekApiKey);
          if (Object.hasOwn(input, "managementToken") && String(input.managementToken || "").trim()) await configureManagementToken(input.managementToken);
          if (String(catalog.settings.sourceDirectory || "").trim()) {
            try {
              const canonical = await configuredCanonicalLibrary();
              canonical.index.title = catalog.settings.title;
              await atomicJSON(canonical.indexPath, canonical.index);
            } catch (error) { if (error.code !== "FC_LIBRARY_INDEX_MISSING") throw error; }
          }
          await refreshCoverCandidates(); await save();
        });
        return json(res, 200, { settings: publicSettings(), candidates: coverCandidates.length });
      }
      if (req.method === "POST" && pathname === "/api/cover-candidates/refresh") { await refreshCoverCandidates(); return json(res, 200, { candidates: coverCandidates.length }); }
      if (req.method === "POST" && pathname === "/api/upload") {
        const name = safeName(url.searchParams.get("name"));
        if (name.toLowerCase() === "neogeo.zip") {
          const temporary = path.join(paths.uploads, `${randomID()}-neogeo.zip`);
          await uploadRequest(req, temporary, MAX_NEOGEO_BIOS_BYTES);
          try {
            const bios = await withWrite(() => storeNeoGeoBIOS(temporary, name));
            return json(res, 201, { kind: "neoGeoBIOS", bios });
          } finally { await fsp.rm(temporary, { force: true }); }
        }
        if (name.toLowerCase() === "disksys.rom") {
          const temporary = path.join(paths.uploads, `${randomID()}-disksys.rom`);
          await uploadRequest(req, temporary, FDS_BIOS_BYTES);
          try {
            const bios = await withWrite(() => storeFDSBIOS(temporary, name));
            return json(res, 201, { kind: "fdsBIOS", bios });
          } finally { await fsp.rm(temporary, { force: true }); }
        }
        if (name.toLowerCase() === "spc700.rom") {
          const temporary = path.join(paths.uploads, `${randomID()}-spc700.rom`);
          await uploadRequest(req, temporary, SNES_IPL_BYTES);
          try {
            const ipl = await withWrite(() => storeSNESIPL(temporary, name));
            return json(res, 201, { kind: "snesIPL", ipl });
          } finally { await fsp.rm(temporary, { force: true }); }
        }
        if (snesNECDSPFirmwareUploadName(name)) {
          const temporary = path.join(paths.uploads, `${randomID()}-necdsp.rom`);
          await uploadRequest(req, temporary, SNES_COPROCESSOR_MAX_FIRMWARE_BYTES);
          try {
            const firmware = await withWrite(() => storeSNESNECDSPFirmware(temporary, name));
            return json(res, 201, { kind: "snesCoprocessorFirmware", firmware });
          } finally { await fsp.rm(temporary, { force: true }); }
        }
        if (name.toLowerCase() === "pgm.zip") {
          const temporary = path.join(paths.uploads, `${randomID()}-pgm.zip`);
          await uploadRequest(req, temporary, MAX_PGM_BIOS_BYTES);
          try {
            const bios = await withWrite(() => storePGMBIOS(temporary, name));
            return json(res, 201, { kind: "pgmBIOS", bios });
          } finally { await fsp.rm(temporary, { force: true }); }
        }
        const temp = path.join(paths.uploads, `${randomID()}-${name}`);
        await uploadRequest(req, temp);
        try {
          const firmwareArchive = await withWrite(() => storeSNESCoprocessorFirmwareArchive(temp, name));
          if (firmwareArchive) return json(res, 201, firmwareArchive);
          const result = String(catalog.settings.sourceDirectory || "").trim()
            ? await withWrite(() => addROMToCanonicalLibrary(temp, name))
            : await ingestTemporaryUpload(temp, name, { system: url.searchParams.get("system") || undefined });
          if (!result.duplicate && result.game.sourceID) startAutomaticSourceResearch(result.game.sourceID);
          return json(res, 201, { ...result, game: { ...result.game, coverURL: result.game.coverURL || (result.game.cover ? `/api/games/${result.game.id}/cover` : null) } });
        } finally { await fsp.rm(temp, { force: true }); }
      }
      if (req.method === "POST" && pathname === "/api/scan") return json(res, 200, { imported: await withWrite(scanDropbox) });
      if (req.method === "POST" && pathname === "/api/scan-source") return json(res, 200, await scanSourceDirectory(await bodyJSON(req)));
      if (req.method === "POST" && pathname === "/api/export") return json(res, 200, await exportLibrary());
      const gameMatch = pathname.match(/^\/api\/games\/([^/]+)(?:\/(.+))?$/);
      if (gameMatch) {
        const id = decodeURIComponent(gameMatch[1]); const action = gameMatch[2] || "";
        const game = catalog.games.find(item => item.id === id);
        if (!game) return fail(res, 404, "游戏不存在。");
        if (req.method === "GET" && action === "cover") {
          if (!game.cover) return fail(res, 404, "游戏没有封面。");
          return void (await serveFile(res, path.join(paths.managedArtwork, game.cover.storedName), "public, max-age=300") || fail(res, 404, "封面文件缺失。"));
        }
        if (req.method === "GET" && action === "cover-candidates") return json(res, 200, { candidates: coverMatches(game) });
        if (req.method === "POST" && action === "metadata-search") return json(res, 200, await searchGameMetadata(game));
        if (req.method === "POST" && action === "cover-search") {
          const result = await createWebCoverSearch(game);
          return json(res, 200, result);
        }
        const webSearchMatch = action.match(/^cover-search\/([^/]+)\/(preview|select)$/);
        if (webSearchMatch) {
          const candidate = webCoverCandidate(game, webSearchMatch[1]);
          if (req.method === "GET" && webSearchMatch[2] === "preview") {
            const temporary = await cachedCandidateImage(candidate);
            return void (await serveFile(res, temporary, "private, max-age=120") || fail(res, 404, "封面预览已过期，请重新搜索。"));
          }
          if (req.method === "POST" && webSearchMatch[2] === "select") {
            const temporary = await cachedCandidateImage(candidate);
            await withWrite(async () => { await storeCover(game, temporary, path.basename(temporary), candidate.source); await save(); });
            return json(res, 201, { cover: game.cover });
          }
        }
        if (req.method === "GET" && action.startsWith("candidate/")) {
          const candidate = coverCandidates.find(item => item.id === action.slice("candidate/".length));
          if (!candidate) return fail(res, 404, "封面候选不存在。");
          return void (await serveFile(res, candidate.file, "public, max-age=300") || fail(res, 404, "封面候选已消失。"));
        }
        if (req.method === "PATCH" && !action) {
          const input = await bodyJSON(req); await withWrite(async () => { Object.assign(game, validateGameInput(input, game), { updatedAt: now() }); await save(); });
          return json(res, 200, game);
        }
        if (req.method === "DELETE" && !action) {
          await withWrite(async () => { catalog.games = catalog.games.filter(item => item.id !== id); await save(); });
          return json(res, 204, {});
        }
        if (req.method === "POST" && action === "auto-match") {
          const result = await withWrite(async () => { game.cover = null; const matched = await autoMatchCover(game, true); await save(); return matched; });
          return json(res, 200, { matched: result });
        }
        if (req.method === "POST" && action === "match-cover") {
          const input = await bodyJSON(req); const candidate = await withWrite(async () => { const matched = await matchCover(game, input.candidateID); await save(); return matched; });
          return json(res, 200, { candidate, cover: game.cover });
        }
        if (req.method === "POST" && action === "cover") {
          const name = safeName(url.searchParams.get("name"), "cover.png");
          const temp = path.join(paths.uploads, `${randomID()}-${name}`); await uploadRequest(req, temp);
          try { await withWrite(async () => { await storeCover(game, temp, name, "upload"); await save(); }); }
          finally { await fsp.rm(temp, { force: true }); }
          return json(res, 201, { cover: game.cover });
        }
      }
      return fail(res, 404, "不存在的 API。");
    } catch (error) {
      if (error.code === "FC_SAVE_CONFLICT") return fail(res, 412, error.message);
      console.error(error);
      return fail(res, 400, error.message || "服务器处理请求时出错。");
    }
  }

  function makeServer() { return http.createServer((req, res) => request(req, res)); }
  return { initialize, paths, makeServer, exportLibrary, ingestFile, addROMToCanonicalLibrary, scanDropbox, get catalog() { return catalog; }, refreshCoverCandidates, serializedCatalog, listSourceROMs, sourceROMPage, sourceLibraryGame, updateSourceLibraryGame, deleteSourceLibraryGame, migrateSourceCPS2Keys, reconcileCanonicalArcadeDrivers, reconcileCanonicalArcadeCollections, storeSourceLibraryArtwork, auditSourceLibrary, createWebCoverSearch, performAutomaticSourceResearch, startBackgroundTask, cancelBackgroundTask, listBackgroundTasks, normaliseSourceEnglishName, neoGeoBIOSStatus, storeNeoGeoBIOS, fdsBIOSStatus, storeFDSBIOS, snesIPLStatus, storeSNESIPL, snesNECDSPFirmwareStatus, snesNECDSPFirmwareStatuses, storeSNESNECDSPFirmware, storeSNESCoprocessorFirmwareArchive, pgmBIOSStatus, storePGMBIOS };
}

function slug(value) {
  const ascii = normalized(value).replace(/\s+/g, "-").replace(/[^\p{L}\p{N}-]/gu, "").slice(0, 48);
  return ascii || "game";
}
function isArcadeDriverArchive(system, fileName) {
  return (system === "neoGeo" || system === "arcade") && (extension(fileName) === "zip" || extension(fileName) === "7z");
}
function uniqueID(candidate, used) { let result = candidate, suffix = 2; const existing = new Set(used); while (existing.has(result)) result = `${candidate}-${suffix++}`; return result; }

async function main() {
  const service = createService(); await service.initialize();
  const port = Number(process.env.FC_LIBRARY_PORT || 8282);
  const host = process.env.FC_LIBRARY_HOST || "0.0.0.0";
  service.makeServer().listen(port, host, () => {
    console.log(`FC Emulator Library Server: http://${host}:${port}`);
    console.log(`资料库导出地址: http://<此服务器IP>:${port}/library/`);
    console.log(`数据目录: ${service.paths.dataRoot}`);
  });
}

if (require.main === module) main().catch(error => { console.error(error); process.exitCode = 1; });
module.exports = {
  identifyPGMArchive,
  createService, mapperFromHeader, scoreMatch, titleFromFile, detectedSystem,
  arcadeHardware, arcadeManufacturer, automaticArcadeCollection, categoryForSystem,
  identifyMAMECapcomArchive, portableMAMEArcadeDriver, exactCPS2ArchiveMatch,
  libretroThumbnailEntries, libretroBoxArtMatches, libretroPlaylists,
  isArcadeDriverArchive, imageDimensions, normalizeCPS2KeyHex,
  validateCPS2KeyHex, detectCPS2KeyInArchive, validateNeoGeoBIOSArchive,
  validatePGMBIOSArchive,
  validateFDSBIOSFile, validateFDSImage, validatePortableManifestHardware,
  analyzeSNESROM
};
