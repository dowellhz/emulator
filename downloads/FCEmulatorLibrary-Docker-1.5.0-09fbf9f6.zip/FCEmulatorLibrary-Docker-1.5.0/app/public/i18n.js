(function (root) {
  "use strict";
  const catalogs = Object.create(null);
  const registry = root.FCLocales;
  if (!registry) throw new Error("Locale registry must load before i18n.js");
  const storageKey = "fc-library-ui-language";
  const normalize = registry.normalize;
  let saved = null, requested = null;
  try { saved = normalize(root.localStorage?.getItem(storageKey)); } catch {}
  try { requested = normalize(new URL(root.location.href).searchParams.get("uiLang")); } catch {}
  let language = requested || saved || registry.match(root.navigator?.languages || [root.navigator?.language]);
  let changeGuard = null;
  function t(source, parameters = {}) {
    const key = String(source ?? "");
    const text = language === "zh-CN" ? key : catalogs[language]?.[key] ?? catalogs.en?.[key] ?? key;
    return text.replace(/\{([a-zA-Z_][a-zA-Z0-9_]*)\}/g, (match, key) =>
      Object.hasOwn(parameters, key) ? String(parameters[key] ?? "") : match);
  }
  function addMessages(catalog, locale = "en") {
    if (!registry.languages.some(item => item.code === locale)) throw new Error(`Unsupported locale: ${locale}`);
    const messages = catalogs[locale] ||= Object.create(null);
    for (const [source, translated] of Object.entries(catalog)) {
      if (typeof translated !== "string") throw new TypeError("UI translation must be a string");
      if (Object.hasOwn(messages, source) && messages[source] !== translated) {
        throw new Error(`Conflicting UI translation: ${source}`);
      }
      messages[source] = translated;
    }
  }
  function apply(container = root.document) {
    if (!container?.querySelectorAll) return;
    const nodes = [container, ...container.querySelectorAll("[data-i18n], [data-i18n-placeholder], [data-i18n-title], [data-i18n-aria-label]")];
    for (const node of nodes) {
      if (!node.getAttribute) continue;
      const source = node.getAttribute("data-i18n");
      if (source !== null) node.textContent = t(source);
      for (const attribute of ["placeholder", "title", "aria-label"]) {
        const value = node.getAttribute(`data-i18n-${attribute}`);
        if (value !== null) node.setAttribute(attribute, t(value));
      }
    }
    // Template contents are separate document fragments. Translate their
    // explicitly marked labels before game cards are cloned from them.
    container.querySelectorAll("template").forEach(template => {
      if (template.content) apply(template.content);
    });
    if (root.document?.documentElement) root.document.documentElement.lang = language;
    const select = root.document?.getElementById("interface-language");
    if (select) {
      if (select.replaceChildren && root.document.createElement) {
        select.replaceChildren(...registry.languages.map(item => {
          const option = root.document.createElement("option");
          option.value = item.code; option.textContent = item.name; return option;
        }));
      }
      select.value = language;
    }
  }
  async function setLanguage(value) {
    const next = normalize(value);
    if (!next || next === language) return false;
    if (changeGuard && !(await changeGuard(next))) {
      const select = root.document?.getElementById("interface-language");
      if (select) select.value = language;
      return false;
    }
    try { root.localStorage?.setItem(storageKey, next); } catch {}
    // A URL hint keeps an explicit choice usable with blocked localStorage.
    // Reloading rebuilds generated lists without altering user metadata.
    const destination = new URL(root.location.href);
    destination.searchParams.set("uiLang", next);
    root.location.assign(destination.href);
    return true;
  }
  root.FCI18n = Object.freeze({
    get language() { return language; },
    get prefersChineseTitles() { return !!registry.languages.find(item => item.code === language)?.chineseTitles; },
    languages: registry.languages, t, addMessages, apply,
    translateMessage: message => t(message),
    setChangeGuard: guard => { changeGuard = typeof guard === "function" ? guard : null; },
    setLanguage
  });
  if (root.document?.documentElement) root.document.documentElement.lang = language;
  root.document?.addEventListener("DOMContentLoaded", () => {
    apply();
    root.document.getElementById("interface-language")?.addEventListener("change", event => {
      void setLanguage(event.target.value);
    });
  });
})(typeof window !== "undefined" ? window : globalThis);
