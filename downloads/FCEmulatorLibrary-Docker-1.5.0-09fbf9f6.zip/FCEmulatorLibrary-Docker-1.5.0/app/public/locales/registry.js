// BCP-47 identifiers are persisted and sent in Accept-Language. Native names
// remain readable even when the current interface is in another language.
(function (root, factory) {
  const registry = factory();
  if (typeof module === 'object' && module.exports) module.exports = registry;
  else root.FCLocales = registry;
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';
  const languages = Object.freeze([
    { code: 'zh-CN', name: '简体中文', chineseTitles: true },
    { code: 'en', name: 'English' },
    { code: 'de', name: 'Deutsch' },
    { code: 'ja', name: '日本語' },
    { code: 'es', name: 'Español' },
    { code: 'ko', name: '한국어' },
    { code: 'zh-Hant', name: '繁體中文', chineseTitles: true }
  ].map(Object.freeze));
  function normalize(value) {
    if (typeof value !== 'string') return null;
    const tag = value.trim().replaceAll('_', '-').toLowerCase();
    if (/^zh(?:-|$)/.test(tag)) return /^zh-(?:hant|tw|hk|mo)(?:-|$)/.test(tag) ? 'zh-Hant' : 'zh-CN';
    return languages.find(item => item.code.toLowerCase() === tag || tag.startsWith(item.code.toLowerCase() + '-'))?.code || null;
  }
  function match(preferences, fallback = 'en') {
    for (const value of preferences) { const code = normalize(value); if (code) return code; }
    return fallback;
  }
  return Object.freeze({ languages, normalize, match, fallback: 'en' });
});
