# FC Emulator Library Server · 普通电脑安全包

适用于安装了 Docker Desktop 或 Docker Engine + Compose 插件的 Windows、macOS 和 Linux。
版本：`1.0.0-0030`。

官网公开 ZIP 只能从服务器目录运行 `./docker/build-public-bundle.sh` 生成；不得手工压缩工作区或使用私人部署内容替代。

本包只含服务器程序、网页和公开硬件元数据，不含 ROM、CPS2 key、`neogeo.zip` 或 `disksys.rom` BIOS、
密码、Token 或 API Key。容器以非 root 用户运行，根文件系统只读，并移除全部额外 Linux
capabilities；只允许写入 Docker 配置卷、你明确选择的资料库目录和临时内存盘。

## 安装

1. 安装 Docker Desktop，或在 Linux 安装 Docker Engine 与 Compose 插件。
2. 解压本包，在解压目录创建 `library` 文件夹。也可以复制 `.env.example` 为 `.env`，
   将 `FC_LIBRARY_HOST_PATH` 改为现有资料库的绝对路径。
3. 在当前目录运行：

   ```sh
   docker compose up -d --build
   ```

4. 在当前电脑打开 `http://127.0.0.1:8282/`。首次进入后应立即在设置中启用至少 16 个字符的管理 Token。

## 允许 Apple TV 连接

默认端口只绑定 `127.0.0.1`，局域网中的其他设备无法访问。需要 Apple TV 连接时，复制
`.env.example` 为 `.env`，把 `FC_LIBRARY_BIND_IP` 改为电脑实际的局域网 IP，例如
`192.168.1.20`，然后重新运行 `docker compose up -d`。只在受信任的家庭网络中开放端口
`8282`，不要在路由器上做公网端口转发。

Apple TV 中填写 `http://电脑局域网IP:8282/library/`；如果启用了管理 Token，同时填写同一个 Token。

## Linux 目录权限

容器使用 UID/GID `1000:1000`。如果 Linux 主机上的资料库目录不可写，请只对该目录调整属主：

```sh
sudo chown -R 1000:1000 /你的/FCEmulatorLibrary
```

不得对整个磁盘使用递归 `chmod 777`。

## 更新、日志与卸载

```sh
docker compose build --pull
docker compose up -d
docker compose logs -f server
docker compose down
```

`docker compose down` 不会删除配置卷或资料库。只有明确执行
`docker compose down --volumes` 才会删除 Docker 配置卷；宿主机资料库目录不会被删除。
