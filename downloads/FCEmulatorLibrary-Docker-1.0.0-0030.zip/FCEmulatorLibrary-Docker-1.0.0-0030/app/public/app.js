const state = { catalog: null, selected: null, token: sessionStorage.getItem("fc-library-token") || "", taskRefreshTimer: null, taskSignature: "", sourceRomsSignature: "", sourceRoms: [], selectedSourceIDs: new Set(), sourceOffset: 0, sourceLimit: 100, sourceTotal: 0, sourceRevision: 0 };
const $ = selector => document.querySelector(selector);
const categoryOptions = ["经典", "动作", "闯关", "射击", "格斗", "体育", "竞速", "益智", "冒险", "角色扮演", "策略", "模拟", "多人", "教育", "街机", "破解", "其他"];

function headers(extra = {}) { return state.token ? { ...extra, Authorization: `Bearer ${state.token}` } : extra; }
async function api(url, options = {}) {
  const response = await fetch(url, { ...options, headers: headers(options.headers || {}) });
  const value = await response.json().catch(() => ({}));
  if (!response.ok) { const error = new Error(value.error || `请求失败 (${response.status})`); error.status = response.status; throw error; }
  return value;
}
function setStatus(id, message, bad = false) { const node = $(id); node.textContent = message; node.classList.toggle("error", bad); }
function showNotice(message, bad = false) {
  const node = $("#notice"); node.textContent = message; node.hidden = false; node.classList.toggle("error", bad);
  clearTimeout(state.noticeTimer); state.noticeTimer = setTimeout(() => { node.hidden = true; }, bad ? 8_000 : 4_000);
}
function requestAction(message, { heading = "请确认", input = false, initial = "", danger = false } = {}) {
  return new Promise(resolve => {
    const dialog = $("#action-dialog"), inputNode = $("#action-input"), confirm = $("#action-confirm"), cancel = $("#action-cancel");
    $("#action-heading").textContent = heading; $("#action-message").textContent = message;
    inputNode.hidden = !input; inputNode.value = initial; confirm.classList.toggle("danger", danger);
    const finish = value => { confirm.onclick = null; cancel.onclick = null; dialog.oncancel = null; dialog.close(); resolve(value); };
    cancel.onclick = () => finish(null); confirm.onclick = () => finish(input ? inputNode.value : true);
    dialog.oncancel = event => { event.preventDefault(); finish(null); };
    dialog.showModal(); if (input) inputNode.focus(); else confirm.focus();
  });
}
function displayName(game) { return game.chineseTitle || game.title; }
function hasImmutableArcadeDriverName(game) { return ["arcade", "neoGeo"].includes(game?.system) && /\.(?:zip|7z)$/i.test(String(game?.originalName || "")); }
function systemLabel(game) {
  if (game?.arcadeHardware) return game.arcadeHardware;
  if (game?.system === "snes") return "Super NES";
  if (game?.system === "neoGeo") return "Neo Geo";
  if (game?.system === "arcade") return "Arcade";
  return game?.system || "ROM";
}
function assetURL(url) { const separator = url.includes("?") ? "&" : "?"; const token = state.token ? `token=${encodeURIComponent(state.token)}&` : ""; return `${url}${separator}${token}v=${Date.now()}`; }
function coverStyle(game) { return game.coverURL ? `background-image:url(${assetURL(game.coverURL)})` : ""; }
function formatBytes(bytes) { return bytes > 1024 * 1024 ? `${(bytes / 1024 / 1024).toFixed(1)} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`; }
function selectedAPI(action = "") { const root = state.selected?.sourceID ? `/api/source-roms/${encodeURIComponent(state.selected.sourceID)}` : `/api/games/${encodeURIComponent(state.selected?.id || "")}`; return action ? `${root}/${action}` : root; }
function searchScopeText() { const count = new Set((state.catalog?.settings?.preferredSearchSites || []).map(value => { try { return new URL(value).hostname; } catch { return ""; } }).filter(Boolean)).size; return count ? `仅搜索已配置的 ${count} 个站点` : "搜索公开网页"; }
function deepSeekReady() { return Boolean(state.catalog?.settings?.deepSeekConfigured); }
function settingsPayload() { return { title: $("#library-title").value, sourceDirectory: $("#source-directory").value, preferredSearchSites: $("#preferred-search-sites").value, deepSeekApiKey: $("#deepseek-api-key").value, managementToken: $("#management-token").value }; }

function normalizedLibraryRootURL(relativeURL) {
  const url = new URL(relativeURL || "/library/", location.origin);
  if (url.pathname.endsWith("/library.json")) url.pathname = url.pathname.slice(0, -"library.json".length);
  if (!url.pathname.endsWith("/")) url.pathname += "/";
  url.search = "";
  url.hash = "";
  return url;
}

function libraryLinkUsesLoopback(url) {
  const host = url.hostname.toLowerCase();
  return host === "localhost" || host === "127.0.0.1" || host === "::1" || host === "[::1]";
}

async function openLibraryLinkDialog(button) {
  button.disabled = true;
  try {
    const result = await api("/api/export", { method: "POST" });
    const rootURL = normalizedLibraryRootURL(result.url);
    $("#library-root-url").value = rootURL.href;
    const status = $("#library-link-status");
    status.classList.toggle("error", libraryLinkUsesLoopback(rootURL));
    status.textContent = libraryLinkUsesLoopback(rootURL)
      ? "当前管理页使用本机回环地址打开，Apple TV 无法访问。请用 NAS/电脑的局域网 IP 或 .local 主机名打开管理页后重新生成。"
      : `已生成 ${result.games} 个游戏的资料库根链接。`;
    $("#library-link-auth").textContent = state.catalog?.settings?.libraryProtectionEnabled
      ? "此服务器已保护资料库：Apple TV 的认证方式请选择 Bearer Token，并单独输入管理 Token。链接本身不会包含或泄露 Token。"
      : "链接不包含密码或 Token；请只在可信的家庭局域网内使用。";
    $("#library-link-dialog").showModal();
  } catch (error) {
    showNotice(error.message, true);
  } finally {
    button.disabled = false;
  }
}

async function copyLibraryLink() {
  const input = $("#library-root-url");
  try {
    if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(input.value);
    else { input.select(); document.execCommand("copy"); }
    $("#library-link-status").textContent = "地址已复制，可提交到 Apple TV 的浏览器配置页。";
    $("#library-link-status").classList.remove("error");
  } catch {
    input.select();
    $("#library-link-status").textContent = "浏览器未允许自动复制；地址已选中，请手动复制。";
  }
}

async function verifyLibraryLink() {
  const button = $("#verify-library-link");
  button.disabled = true;
  try {
    const rootURL = normalizedLibraryRootURL($("#library-root-url").value);
    const index = await api(new URL("library.json", rootURL).href);
    const count = Array.isArray(index.games) ? index.games.length : 0;
    $("#library-link-status").textContent = `索引验证通过：${count} 个游戏，schemaVersion ${index.schemaVersion}。`;
    $("#library-link-status").classList.remove("error");
  } catch (error) {
    $("#library-link-status").textContent = `索引验证失败：${error.message}`;
    $("#library-link-status").classList.add("error");
  } finally {
    button.disabled = false;
  }
}

async function load() {
  try {
    const [catalog, neoGeoBIOS, fdsBIOS] = await Promise.all([api("/api/catalog"), api("/api/neogeo-bios"), api("/api/fds-bios")]);
    state.catalog = catalog;
    state.neoGeoBIOS = neoGeoBIOS;
    $("#summary").textContent = `${state.catalog.games.length} 个游戏`;
    renderNeoGeoBIOSStatus(neoGeoBIOS);
    renderFDSBIOSStatus(fdsBIOS);
    $("#library-title").value = state.catalog.settings.title || "";
    $("#source-directory").value = state.catalog.settings.sourceDirectory || "";
    $("#preferred-search-sites").value = (state.catalog.settings.preferredSearchSites || []).join("\n");
    $("#deepseek-api-key").value = "";
    $("#management-token").value = "";
    $("#management-token-hint").textContent = state.catalog.settings.managementTokenConfigured ? "管理 Token 已启用；留空保存不会修改。" : "尚未设置管理 Token；同一局域网内可直接访问管理接口。建议立即设置。";
    $("#deepseek-key-hint").textContent = deepSeekReady()
      ? `已配置 DeepSeek（${state.catalog.settings.deepSeekKeySource || "服务器私有配置"}）。留空保存不会覆盖现有 Key；Key 不会显示在浏览器。`
      : "未配置 DeepSeek：上传、校验和本地 ROM 信息识别仍可用；联网识别、翻译和海报搜索将使用本地后备模式。";
    await loadSourceROMs();
    await loadDashboard();
    renderGames();
  } catch (error) { if (error.status === 401) requestToken(); else setStatus("#upload-status", error.message, true); }
}

function renderNeoGeoBIOSStatus(status) {
  const node = $("#bios-status");
  if (status?.valid) {
    node.textContent = `已验证 · ${formatBytes(status.bytes)} · ${status.sha256.slice(0, 10)}…`;
    node.classList.remove("error");
  } else if (status?.configured) {
    node.textContent = `文件无效：${status.error || "请重新上传"}`;
    node.classList.add("error");
  } else {
    node.textContent = "选择用户自有的 neogeo.zip";
    node.classList.remove("error");
  }
}

function renderFDSBIOSStatus(status) {
  const node = $("#fds-bios-status");
  if (status?.valid) {
    node.textContent = `已验证 · 8 KiB · ${status.sha256.slice(0, 10)}…`;
    node.classList.remove("error");
  } else if (status?.configured) {
    node.textContent = `文件无效：${status.error || "请重新上传"}`;
    node.classList.add("error");
  } else {
    node.textContent = "选择用户自有的 disksys.rom";
    node.classList.remove("error");
  }
}

function metric(label, value, level = "") {
  const node = document.createElement("div"); node.className = `metric ${level}`;
  const labelNode = document.createElement("span"); labelNode.textContent = label;
  const number = document.createElement("strong"); number.textContent = String(value);
  node.append(labelNode, number); return node;
}

function renderHealth(report) {
  const dashboard = $("#library-dashboard");
  if (!report) { dashboard.hidden = true; return; }
  state.health = report;
  dashboard.hidden = false;
  $("#health-checked-at").textContent = `上次快速检查：${new Date(report.checkedAt).toLocaleString("zh-CN")}`;
  const summary = report.summary;
  const metrics = $("#health-metrics"); metrics.replaceChildren(
    metric("游戏", summary.games), metric("有效", summary.valid), metric("无封面", summary.missingCover, summary.missingCover ? "warning" : ""),
    metric("资料不完整", summary.incompleteMetadata, summary.incompleteMetadata ? "warning" : ""), metric("文件异常", summary.missingROM + summary.invalidROM + summary.missingManifest, summary.missingROM + summary.invalidROM + summary.missingManifest ? "error" : ""),
    metric("重复 ROM", summary.duplicateROM, summary.duplicateROM ? "warning" : ""), metric("孤立游戏包", summary.orphanPackage, summary.orphanPackage ? "warning" : "")
  );
  const issues = $("#health-issues"); issues.replaceChildren();
  for (const issue of report.issues.slice(0, 50)) {
    const node = document.createElement("button"); node.type = "button"; node.className = "issue issue-link";
    const title = document.createElement("b"); title.textContent = issue.title;
    const message = document.createElement("span"); message.textContent = issue.message;
    node.title = "打开游戏编辑页"; node.onclick = () => openSourceEditor(issue.id);
    node.append(title, message); issues.append(node);
  }
  if (!report.issues.length) issues.innerHTML = '<p class="muted">资料库没有待处理项。</p>';
}

function taskSignature(tasks) { return JSON.stringify(tasks.map(task => [task.id, task.state, task.completed, task.total, task.message, task.completedAt, task.canCancel])); }
function sourceRomsSignature(response) { return JSON.stringify([response.directory, response.title, response.revision, response.total, response.offset, response.roms]); }

function renderTasks(tasks) {
  const list = $("#task-list"); list.replaceChildren();
  for (const task of tasks) {
    const node = document.createElement("div"); node.className = `task ${task.state}`;
    const title = document.createElement("b"); title.textContent = task.title;
    const detail = document.createElement("span");
    const progress = task.total ? ` ${task.completed || 0}/${task.total}` : "";
    detail.textContent = `${task.state === "running" ? "进行中" : task.state === "failed" ? "失败" : task.state === "cancelled" ? "已取消" : task.state === "queued" ? "等待中" : "已完成"}${progress} · ${task.message || ""}`;
    node.append(title, detail);
    if (task.canCancel) {
      const cancel = document.createElement("button"); cancel.type = "button"; cancel.className = "task-cancel"; cancel.textContent = "取消";
      cancel.onclick = async () => { cancel.disabled = true; try { await api(`/api/tasks/${encodeURIComponent(task.id)}/cancel`, { method: "POST" }); await pollTasks(); } catch (error) { showNotice(error.message, true); } };
      node.append(cancel);
    }
    list.append(node);
  }
  if (!tasks.length) list.innerHTML = '<p class="muted">没有正在执行或最近的后台任务。</p>';
}

function scheduleTaskRefresh(tasks) {
  if (state.taskRefreshTimer) { clearTimeout(state.taskRefreshTimer); state.taskRefreshTimer = null; }
  const active = tasks.some(task => task.state === "queued" || task.state === "running");
  if (active) state.taskRefreshTimer = setTimeout(() => { state.taskRefreshTimer = null; pollTasks(); }, 3_000);
}

async function pollTasks() {
  if (!state.catalog?.settings?.sourceDirectory) return;
  try {
    const response = await api("/api/tasks"); const tasks = response.tasks || [];
    const signature = taskSignature(tasks); const changed = signature !== state.taskSignature;
    if (changed) {
      state.taskSignature = signature; renderTasks(tasks);
      const active = tasks.some(task => task.state === "queued" || task.state === "running");
      const refreshDue = !active || Date.now() - (state.lastSourceRefreshAt || 0) >= 10_000;
      if (Number(response.sourceRevision) !== state.sourceRevision && refreshDue) await Promise.all([loadSourceROMs({ onlyIfChanged: true }), api("/api/source-health").then(renderHealth)]);
    }
    scheduleTaskRefresh(tasks);
  } catch (error) { /* A transient polling failure must not redraw the page. */ }
}

async function loadDashboard() {
  if (!state.catalog?.settings?.sourceDirectory) { $("#library-dashboard").hidden = true; return; }
  try {
    const [health, taskResponse] = await Promise.all([api("/api/source-health"), api("/api/tasks")]);
    const tasks = taskResponse.tasks || [];
    renderHealth(health); renderTasks(tasks); state.taskSignature = taskSignature(tasks); state.sourceRevision = Number(taskResponse.sourceRevision) || state.sourceRevision; scheduleTaskRefresh(tasks);
  } catch (error) { $("#library-dashboard").hidden = true; }
}

function updateBulkControls() {
  const count = state.selectedSourceIDs.size;
  $("#bulk-research").disabled = !count; $("#bulk-delete").disabled = !count;
  const visible = state.visibleSourceRoms || state.sourceRoms;
  $("#select-all-source").textContent = visible.length && visible.every(rom => state.selectedSourceIDs.has(rom.id)) ? "取消本页" : "全选本页";
  setStatus("#bulk-status", count ? `已选择 ${count} 个游戏。` : "");
}

function populateSourceFilter(selector, values, placeholder) {
  const select = $(selector); const previous = select.value;
  select.replaceChildren(new Option(placeholder, ""), ...values.map(value => new Option(value === "snes" ? "Super NES" : value, value)));
  select.value = values.includes(previous) ? previous : "";
}

async function loadSourceROMs({ onlyIfChanged = false, force = false } = {}) {
  const section = $("#source-roms");
  const managed = $("#managed-library");
  if (!state.catalog?.settings?.sourceDirectory) { section.hidden = true; managed.hidden = false; $("#summary").textContent = `${state.catalog.games.length} 个游戏`; return; }
  try {
    const params = new URLSearchParams({ offset: String(state.sourceOffset), limit: String(state.sourceLimit), q: $("#source-search").value.trim(), system: $("#source-system").value, category: $("#source-category").value, collection: $("#source-collection").value, status: $("#source-status").value, sort: $("#source-sort").value });
    if (force) params.set("refresh", "1");
    const response = await api(`/api/source-roms?${params}`);
    const signature = sourceRomsSignature(response);
    if (onlyIfChanged && signature === state.sourceRomsSignature) return false;
    state.sourceRomsSignature = signature;
    section.hidden = false; managed.hidden = true;
    state.sourceRevision = Number(response.revision) || state.sourceRevision;
    state.lastSourceRefreshAt = Date.now();
    state.sourceTotal = Number(response.total) || 0;
    state.sourceOffset = Number(response.offset) || 0;
    $("#summary").textContent = `${state.sourceTotal} 个游戏`;
    $("#library-title").value = response.title || state.catalog.settings.title || "";
    state.sourceRoms = response.roms;
    populateSourceFilter("#source-system", response.facets?.systems || [], "全部主机");
    populateSourceFilter("#source-category", response.facets?.categories || [], "全部分类");
    populateSourceFilter("#source-collection", response.facets?.collections || [], "全部收藏集");
    const roms = response.roms; state.visibleSourceRoms = roms;
    const first = state.sourceTotal ? state.sourceOffset + 1 : 0, last = state.sourceOffset + roms.length;
    $("#source-rom-count").textContent = `显示 ${first}–${last} / ${state.sourceTotal} 个 · 当前资料库：${response.directory}`;
    $("#source-prev").disabled = state.sourceOffset <= 0;
    $("#source-next").disabled = state.sourceOffset + state.sourceLimit >= state.sourceTotal;
    const list = $("#source-rom-list"); list.replaceChildren();
    for (const rom of roms) {
      const item = document.createElement("article"); item.className = "game-card source-game-card";
      const select = document.createElement("input"); select.type = "checkbox"; select.className = "source-select"; select.checked = state.selectedSourceIDs.has(rom.id);
      select.setAttribute("aria-label", `选择 ${rom.title || rom.id}`); select.onchange = () => { if (select.checked) state.selectedSourceIDs.add(rom.id); else state.selectedSourceIDs.delete(rom.id); updateBulkControls(); };
      const cover = document.createElement("div"); cover.className = "cover";
      if (rom.hasCover) cover.style.backgroundImage = `url(${assetURL(`/api/source-roms/${encodeURIComponent(rom.id)}/cover`)})`;
      else cover.textContent = systemLabel(rom).toUpperCase();
      const content = document.createElement("div"); content.className = "game-card-content";
      const system = document.createElement("span"); system.className = "pill"; system.textContent = systemLabel(rom);
      const title = document.createElement("h3"); title.textContent = rom.title || rom.path;
      const details = document.createElement("p"); details.className = "details";
      details.textContent = [rom.category, rom.system === "nes" && rom.mapper != null ? `Mapper ${rom.mapper}` : null, rom.versionCount > 1 ? `${rom.versionCount} 个版本` : null, rom.bytes ? formatBytes(rom.bytes) : null].filter(Boolean).join(" · ");
      const path = document.createElement("p"); path.className = "filename muted"; path.textContent = rom.path;
      if (rom.collections?.length) path.textContent += `\n收藏集：${rom.collections.join("、")}`;
      const research = rom.automaticResearch;
      const researchStatus = document.createElement("p"); researchStatus.className = "muted auto-research";
      if (research?.state === "running") researchStatus.textContent = research.message;
      else if (research?.state === "failed") researchStatus.textContent = `自动识别失败：${research.message}`;
      else if (research?.state === "completed") researchStatus.textContent = research.message;
      const edit = document.createElement("button"); edit.type = "button"; edit.textContent = "编辑"; edit.onclick = () => openSourceEditor(rom.id);
      content.append(system, title, details, path, researchStatus, edit); item.append(select, cover, content); list.append(item);
    }
    if (!roms.length) list.innerHTML = '<p class="muted">没有符合当前筛选条件的游戏。</p>';
    updateBulkControls();
    return true;
  } catch (error) { section.hidden = false; managed.hidden = true; $("#source-rom-count").textContent = error.message; $("#source-rom-list").replaceChildren(); }
}
function renderGames() {
  const root = $("#games"); root.replaceChildren();
  const query = $("#search").value.trim().toLocaleLowerCase();
  const games = state.catalog.games.filter(game => !query || [game.title, game.chineseTitle, game.originalName, game.system, game.arcadeHardware, game.category].join(" ").toLocaleLowerCase().includes(query))
    .sort((left, right) => Date.parse(right.createdAt || 0) - Date.parse(left.createdAt || 0));
  $("#game-count").textContent = query ? `找到 ${games.length} / ${state.catalog.games.length} 个游戏` : `共 ${games.length} 个游戏`;
  for (const game of games) {
    const node = $("#game-template").content.cloneNode(true);
    const cover = node.querySelector(".cover"); cover.style = coverStyle(game); cover.textContent = game.coverURL ? "" : systemLabel(game).toUpperCase();
    node.querySelector(".system").textContent = systemLabel(game);
    node.querySelector("h3").textContent = displayName(game);
    node.querySelector(".details").textContent = [game.category, game.system === "nes" ? `Mapper ${game.mapper ?? 0}` : null, formatBytes(game.bytes)].filter(Boolean).join(" · ");
    node.querySelector(".filename").textContent = game.originalName;
    node.querySelector(".edit").onclick = () => openEditor(game.id);
    root.append(node);
  }
  if (!games.length) root.innerHTML = `<p class="empty-state muted">${state.catalog.games.length ? "没有找到匹配的游戏。" : "上传 ROM 或扫描投放目录即可开始。"}</p>`;
}
async function uploadROMs(files) {
  if (!files.length) return;
  const results = [];
  for (const file of files) {
    setStatus("#upload-status", `正在上传 ${file.name}…`);
    try {
      const result = await api(`/api/upload?name=${encodeURIComponent(file.name)}`, { method: "POST", body: file });
      results.push(["neoGeoBIOS", "fdsBIOS"].includes(result.kind) ? `${file.name}（BIOS 已验证）` : result.duplicate ? `${file.name}（已存在）` : `${file.name}（已加入）`);
    }
    catch (error) { results.push(`${file.name}（${error.message}）`); }
  }
  setStatus("#upload-status", results.join("；")); await load();
}

async function uploadNeoGeoBIOS(file) {
  if (!file) return;
  if (file.name.toLowerCase() !== "neogeo.zip") {
    renderNeoGeoBIOSStatus({ configured: true, valid: false, error: "文件必须命名为 neogeo.zip" });
    return;
  }
  const node = $("#bios-status"); node.textContent = "正在上传并校验四个 MVS BIOS 组件…"; node.classList.remove("error");
  try {
    const status = await api(`/api/neogeo-bios?name=${encodeURIComponent(file.name)}`, { method: "POST", body: file });
    renderNeoGeoBIOSStatus(status);
    showNotice("Neo Geo MVS BIOS 已验证并写入私人资料库。");
  } catch (error) {
    renderNeoGeoBIOSStatus({ configured: true, valid: false, error: error.message });
  } finally {
    $("#bios-upload").value = "";
  }
}
async function uploadFDSBIOS(file) {
  if (!file) return;
  if (file.name.toLowerCase() !== "disksys.rom") {
    renderFDSBIOSStatus({ configured: true, valid: false, error: "文件必须命名为 disksys.rom" });
    return;
  }
  const node = $("#fds-bios-status"); node.textContent = "正在按 MAME 身份校验 8 KiB BIOS…"; node.classList.remove("error");
  try {
    const status = await api(`/api/fds-bios?name=${encodeURIComponent(file.name)}`, { method: "POST", body: file });
    renderFDSBIOSStatus(status);
    showNotice("FDS BIOS 已验证并写入私人资料库。");
  } catch (error) {
    renderFDSBIOSStatus({ configured: true, valid: false, error: error.message });
  } finally {
    $("#fds-bios-upload").value = "";
  }
}
async function saveSettings() {
  try {
    const payload = settingsPayload();
    await api("/api/settings", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    if (payload.managementToken.trim()) { state.token = payload.managementToken.trim(); sessionStorage.setItem("fc-library-token", state.token); }
    setStatus("#settings-status", "已保存。"); await load(); $("#settings-dialog").close();
  }
  catch (error) { setStatus("#settings-status", error.message, true); }
}
async function requestToken() { const token = await requestAction("这个服务器启用了访问令牌。请输入管理 Token：", { heading: "服务器认证", input: true, initial: state.token }); if (token != null) { state.token = token.trim(); sessionStorage.setItem("fc-library-token", state.token); load(); } }

function renderFieldLocks(game) {
  const form = $("#editor-form");
  for (const node of form.querySelectorAll(".field-lock")) node.remove();
  if (!game.sourceID) return;
  for (const name of ["title", "chineseTitle", "mapper", "players", "region", "releaseYear", "sortTitle", "description", "englishDescription"]) {
    const field = form.elements[name]; const label = field?.closest("label"); if (!label) continue;
    const locked = Boolean(game.fieldLocks?.[name]); const source = game.fieldSources?.[name] || "未记录来源";
    const button = document.createElement("button"); button.type = "button"; button.className = `field-lock ${locked ? "locked" : ""}`;
    button.textContent = locked ? "已锁定" : "允许自动更新"; button.title = `资料来源：${source}。点击${locked ? "解除锁定" : "锁定"}。`;
    button.onclick = async event => {
      event.preventDefault(); const fieldLocks = { ...(state.selected.fieldLocks || {}), [name]: !locked };
      try {
        const updated = await api(selectedAPI(), { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fieldLocks }) });
        state.selected = { ...state.selected, ...updated, fieldLocks }; renderFieldLocks(state.selected);
      } catch (error) { setStatus("#cover-search-status", error.message, true); }
    };
    label.append(button);
  }
}

function updateCPS2KeyField(game) {
  const form = $("#editor-form");
  const input = form.elements.cps2Key;
  const required = Boolean(game?.cps2KeyRequired && form.elements.system.value === "arcade");
  input.disabled = !required;
  if (!required) input.value = "";
  else if (document.activeElement !== input) input.value = game.cps2Key || "";
  const hints = {
    archive: "已从 ROM ZIP 自动检测；保存后会写入私人 manifest.json。",
    verified: "ROM ZIP 与 manifest.json 中的 key 完全一致。",
    builtin: "已由私人 Web 服务内置表自动匹配，并写入当前资料库的 manifest.json。",
    manifest: "已从私人 manifest.json 读取并通过驱动 CRC 校验。",
    manual: "已填写并通过驱动 CRC 校验。",
    missing: "该 CPS2 驱动需要 key，请填写 40 个十六进制字符。",
    "manual-required": "该压缩格式无法自动读取 key，请填写 40 个十六进制字符。"
  };
  $("#cps2-key-hint").textContent = required ? (hints[game.cps2KeyStatus] || hints.missing) : "当前驱动不需要 key。";
}

function openEditorFor(game) {
  state.selected = game;
  const form = $("#editor-form"); $("#editor-heading").textContent = displayName(game);
  for (const name of ["title", "chineseTitle", "mapper", "players", "region", "releaseYear", "sortTitle", "description", "englishDescription"]) form.elements[name].value = game[name] ?? "";
  form.elements.collections.value = (game.collections || []).join(", ");
  form.elements.system.value = game.system;
  form.elements.cps2Key.value = game.cps2Key || "";
  updateCPS2KeyField(game);
  form.elements.category.replaceChildren(...categoryOptions.map(value => new Option(value, value, false, value === game.category)));
  const preview = $("#cover-preview"); preview.style = coverStyle(game); preview.textContent = game.coverURL ? "" : "无封面";
  $("#artwork-summary").textContent = [game.artwork?.backdrop ? "背景" : null, game.artwork?.logo ? "Logo" : null].filter(Boolean).join(" · ") || "尚未添加背景或 Logo";
  const mapperInfo = game.system === "nes" ? `\nMapper：${game.mapper ?? 0}` : "";
  const fingerprint = game.crc32 ? ` · CRC32 ${game.crc32}` : "";
  const headerInfo = game.romInfo?.internalTitle ? `\nROM 内部标题：${game.romInfo.internalTitle}` : "";
  const confidence = game.research?.confidence ? `\n联网识别：${Math.round(game.research.confidence * 100)}% · ${game.research.source || ""}` : "";
  $("#file-info").textContent = `${game.originalName}\n${formatBytes(game.bytes)}${fingerprint} · SHA-256 ${game.sha256}${mapperInfo}${headerInfo}${confidence}`;
  const sourceGame = Boolean(game.sourceID), immutableDriverName = hasImmutableArcadeDriverName(game), renameButton = $("#rename-rom");
  $("#identify-game").hidden = false; $("#search-cover").hidden = false; $("#search-diagnostic").hidden = !sourceGame; $("#search-diagnostic-output").hidden = true;
  renameButton.hidden = !sourceGame; renameButton.disabled = immutableDriverName; renameButton.title = immutableDriverName ? "街机驱动包依赖原始 ZIP / 7z 文件名，不能重命名。" : "";
  setStatus("#cover-search-status", sourceGame ? "编辑的是当前资料库的 manifest.json；联网识别或封面搜索会直接更新该游戏包。" : "封面搜索会自动采用最匹配的海报并直接保存。");
  $("#candidate-list").replaceChildren();
  renderFieldLocks(game);
  $("#editor").showModal();
}
async function openEditor(id) {
  const game = state.catalog.games.find(item => item.id === id); if (game) openEditorFor(game);
}
async function openSourceEditor(id) {
  try { openEditorFor(await api(`/api/source-roms/${encodeURIComponent(id)}`)); }
  catch (error) { showNotice(error.message, true); }
}
async function saveGame(event) {
  if (event.submitter?.id !== "save-game") return;
  event.preventDefault(); if (!state.selected) return;
  try {
    const input = Object.fromEntries(new FormData(event.currentTarget));
    const endpoint = state.selected.sourceID ? `/api/source-roms/${encodeURIComponent(state.selected.sourceID)}` : `/api/games/${encodeURIComponent(state.selected.id)}`;
    await api(endpoint, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(input) });
    $("#editor").close(); await load();
  } catch (error) { showNotice(error.message, true); }
}
async function deleteGame() {
  if (!state.selected) return;
  const name = displayName(state.selected);
  if (!await requestAction(`确定删除「${name}」吗？\nROM、封面和该游戏的资料文件都会从当前资料库移除。`, { heading: "删除游戏", danger: true })) return;
  try {
    await api(selectedAPI(), { method: "DELETE" });
    $("#editor").close(); await load();
  } catch (error) { showNotice(error.message, true); }
}
function refreshEditorArtwork(updated) {
  if (!state.selected || !updated) return;
  const next = { ...state.selected };
  if (Object.hasOwn(updated, "coverURL")) next.coverURL = updated.coverURL;
  if (updated.artwork && typeof updated.artwork === "object") next.artwork = updated.artwork;
  state.selected = next;
  const preview = $("#cover-preview"); preview.style = coverStyle(next); preview.textContent = next.coverURL ? "" : "无封面";
  $("#artwork-summary").textContent = [next.artwork?.backdrop ? "背景" : null, next.artwork?.logo ? "Logo" : null].filter(Boolean).join(" · ") || "尚未添加背景或 Logo";
  if (next.sourceID && next.coverURL) {
    const listed = state.sourceRoms.find(game => game.id === next.sourceID);
    if (listed) listed.hasCover = true;
  }
}
async function uploadCover(file) {
  if (!file || !state.selected) return;
  const sourceID = state.selected.sourceID;
  const endpoint = sourceID ? `/api/source-roms/${encodeURIComponent(sourceID)}/cover` : `/api/games/${encodeURIComponent(state.selected.id)}/cover`;
  try {
    const updated = await api(`${endpoint}?name=${encodeURIComponent(file.name)}`, { method: "POST", body: file });
    refreshEditorArtwork(updated);
  }
  catch (error) { showNotice(error.message, true); }
}
async function uploadArtwork(type, file) {
  if (!file || !state.selected?.sourceID) return;
  try {
    const updated = await api(`${selectedAPI(`artwork/${type}`)}?name=${encodeURIComponent(file.name)}`, { method: "POST", body: file });
    refreshEditorArtwork(updated);
  } catch (error) { setStatus("#cover-search-status", error.message, true); }
}
function showCoverCandidates(response) {
  const list = $("#candidate-list"); list.replaceChildren();
  for (const candidate of response.candidates || []) {
    const candidateButton = document.createElement("button"); candidateButton.type = "button"; candidateButton.className = "candidate";
    candidateButton.style.backgroundImage = `url(${assetURL(selectedAPI(`cover-search/${encodeURIComponent(candidate.id)}/preview`))})`;
    candidateButton.title = `${candidate.title}\n来源：${candidate.source}`;
    candidateButton.setAttribute("aria-label", `使用封面：${candidate.title}`);
    candidateButton.onclick = async () => {
      await applyWebCoverCandidate(candidate);
    };
    list.append(candidateButton);
  }
}
async function applyWebCoverCandidate(candidate, automatically = false) {
  if (!state.selected) return;
  const updated = await api(selectedAPI(`cover-search/${encodeURIComponent(candidate.id)}/select`), { method: "POST" });
  refreshEditorArtwork(updated);
  setStatus("#cover-search-status", `${automatically ? "已自动采用" : "已采用"}封面：${candidate.title}。`);
}
async function searchCover() {
  if (!state.selected) return;
  const searchButton = $("#search-cover"); searchButton.disabled = true; setStatus("#cover-search-status", deepSeekReady() ? `正在优先检索已配置的封面站点；未命中时才使用一次 DeepSeek Web Search（${searchScopeText()}）…` : "DeepSeek 未配置；正在直接检索 LaunchBox 和 Internet Archive 等公开优先站点…");
  try {
    const response = await api(selectedAPI("cover-search"), { method: "POST" });
    const searchPlace = response.fallbackUsed ? "优先站点未命中后在公开网页" : "优先站点中";
    if (response.candidates?.length) {
      // The server returns candidates in verified best-first order.  Searching
      // for a cover is an explicit replacement action, so apply the first one
      // immediately instead of asking through a browser confirm dialog.
      await applyWebCoverCandidate(response.candidates[0], true);
    } else {
      setStatus("#cover-search-status", response.localFallback ? response.message : `优先站点和公开网页均未找到可用海报候选（${searchPlace}）。`);
    }
  } catch (error) { setStatus("#cover-search-status", error.message, true); }
  finally { searchButton.disabled = false; }
}
async function identifyGame() {
  if (!state.selected) return;
  const identifyButton = $("#identify-game"); identifyButton.disabled = true; setStatus("#cover-search-status", deepSeekReady() ? `正在通过 DeepSeek Web Search 识别资料；会先查优先站点，必要时在同一次搜索中回退公开网页（${searchScopeText()}）…` : "DeepSeek 未配置；将使用 ROM 文件名与头信息建立本地资料。 ");
  try {
    const response = await api(selectedAPI("metadata-search"), { method: "POST" });
    const metadata = response.metadata || {};
    // Research is a draft: expose it immediately so the user can inspect or
    // correct every field.  The existing form's Save button remains the sole
    // action that writes metadata back to the library.
    const form = $("#editor-form");
    for (const name of ["title", "chineseTitle", "region", "releaseYear", "players", "sortTitle", "description", "englishDescription"]) {
      if (metadata[name] != null && form.elements[name]) form.elements[name].value = metadata[name];
    }
    if (["nes", "neoGeo", "arcade"].includes(metadata.system)) form.elements.system.value = metadata.system;
    if (categoryOptions.includes(metadata.category)) form.elements.category.value = metadata.category;
    showCoverCandidates(response);
    const filled = Object.keys(metadata).length;
    setStatus("#cover-search-status", response.localFallback ? response.message : (response.candidates?.length ? `已将 ${filled} 项识别结果填入表单，并找到 ${response.candidates.length} 张封面候选${response.fallbackUsed ? "（已启用公开网页后备搜索）" : ""}。检查后点击“保存”才会写入资料库。` : `已将 ${filled} 项识别结果填入表单；优先站点及公开网页均没有可用海报。检查后点击“保存”才会写入资料库。` ));
  } catch (error) { setStatus("#cover-search-status", error.message, true); }
  finally { identifyButton.disabled = false; }
}
async function showSearchDiagnostic() {
  if (!state.selected?.sourceID) return;
  const output = $("#search-diagnostic-output");
  try {
    const response = await api(selectedAPI("search-diagnostic"));
    const diagnostic = response.diagnostic;
    output.hidden = false;
    output.textContent = diagnostic ? [
      `时间：${diagnostic.checkedAt || "未知"}`, `HTTP：${diagnostic.httpStatus ?? "未知"}`, `状态：${diagnostic.responseStatus || "未知"}`,
      diagnostic.error ? `错误：${diagnostic.error}` : null, diagnostic.outputText ? `输出：${diagnostic.outputText}` : null,
      ...(diagnostic.stages || []).map(stage => `阶段：${stage.name} · ${stage.durationMs} ms${stage.candidates != null ? ` · ${stage.candidates} 个候选` : ""}`),
      ...(diagnostic.output || []).map(item => `${item.type || "output"} / ${item.status || "unknown"}${item.text ? `\n${item.text}` : ""}`)
    ].filter(Boolean).join("\n\n") : "该游戏还没有 DeepSeek 搜索诊断；公开站点直查不会产生 DeepSeek 诊断。";
  } catch (error) { setStatus("#cover-search-status", error.message, true); }
}
async function renameROM() {
  if (!state.selected?.sourceID) return;
  if (hasImmutableArcadeDriverName(state.selected)) { showNotice("街机驱动包必须保留原始文件名，不能重命名。", true); return; }
  if (!await requestAction("将 ROM 重命名为不含空格的英文名称，保留扩展名。\n\n当前：" + state.selected.originalName, { heading: "重命名 ROM" })) return;
  const button = $("#rename-rom"); button.disabled = true;
  try {
    const game = await api(selectedAPI("rename-rom"), { method: "POST" });
    state.selected = game;
    await loadSourceROMs();
    await openEditor(game.id);
  } catch (error) { setStatus("#cover-search-status", error.message, true); }
  finally { button.disabled = false; }
}
async function showHistory() {
  if (!state.selected?.sourceID) return;
  try {
    const response = await api(selectedAPI("history")); const entries = response.entries || [];
    if (!entries.length) { setStatus("#cover-search-status", "尚没有可恢复的资料历史。 "); return; }
    const selected = await requestAction(`输入要恢复的序号：\n\n${entries.map((entry, index) => `${index + 1}. ${new Date(entry.createdAt).toLocaleString("zh-CN")} · ${entry.action}`).join("\n")}`, { heading: "资料历史", input: true });
    const index = Number(selected) - 1;
    if (!Number.isInteger(index) || !entries[index]) return;
    if (!await requestAction(`恢复到这条历史记录？\n${entries[index].action}`, { heading: "恢复资料" })) return;
    const game = await api(selectedAPI(`history/${encodeURIComponent(entries[index].id)}/restore`), { method: "POST" });
    await load(); await openSourceEditor(game.id);
  } catch (error) { setStatus("#cover-search-status", error.message, true); }
}
async function browseDirectory(path) {
  const query = path ? `?path=${encodeURIComponent(path)}` : "";
  const response = await api(`/api/directories${query}`);
  state.browsedDirectory = response.path;
  $("#directory-path").textContent = response.path;
  $("#directory-up").disabled = !response.parent;
  $("#directory-up").onclick = () => response.parent && browseDirectory(response.parent);
  const list = $("#directory-list"); list.replaceChildren();
  for (const directory of response.directories) {
    const button = document.createElement("button"); button.type = "button"; button.className = "directory-entry"; button.textContent = directory.name;
    button.onclick = () => browseDirectory(directory.path); list.append(button);
  }
  if (!response.directories.length) list.innerHTML = '<p class="muted">此目录没有可浏览的子目录。</p>';
}
async function openDirectoryBrowser() {
  try { await browseDirectory($("#source-directory").value.trim()); $("#directory-browser").showModal(); }
  catch (error) { setStatus("#settings-status", error.message, true); }
}

async function startAudit(full) {
  const button = full ? $("#full-audit") : $("#quick-audit"); button.disabled = true;
  try {
    const response = await api("/api/source-audit", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ full }) });
    setStatus("#upload-status", `${response.task.title}已加入后台任务。`); await loadDashboard();
  } catch (error) { setStatus("#upload-status", error.message, true); }
  finally { button.disabled = false; }
}

async function repairMissingMetadata() {
  const summary = state.health?.summary;
  const count = (summary?.incompleteMetadata || 0) + (summary?.missingCover || 0);
  if (!count) { setStatus("#upload-status", "没有需要自动补全的游戏。 "); return; }
  if (!await requestAction(`将把缺少资料或封面的游戏加入后台自动补全队列。\n\n当前约有 ${count} 项缺失（同一游戏可能同时缺资料和封面）。\n任务会按缺失字段处理；优先站点未命中时才使用 DeepSeek。已有资料和封面不会被覆盖。`, { heading: "自动补全资料" })) return;
  const button = $("#repair-missing"); button.disabled = true;
  try {
    const response = await api("/api/source-repair", { method: "POST" });
    setStatus("#upload-status", `${response.task.title}已加入后台任务，可继续使用网站。`); await load();
  } catch (error) { setStatus("#upload-status", error.message, true); }
  finally { button.disabled = false; }
}

async function runBulk(action) {
  const ids = [...state.selectedSourceIDs]; if (!ids.length) return;
  if (action === "delete" && !await requestAction(`确定删除选中的 ${ids.length} 个游戏吗？\nROM、封面和 manifest 都会从当前资料库移除。`, { heading: "批量删除", danger: true })) return;
  const button = action === "research" ? $("#bulk-research") : $("#bulk-delete"); button.disabled = true;
  try {
    const response = await api("/api/source-roms/bulk", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action, ids }) });
    state.selectedSourceIDs.clear(); updateBulkControls();
    setStatus("#bulk-status", `${response.task.title}已加入后台任务。`); await load();
  } catch (error) { setStatus("#bulk-status", error.message, true); }
  finally { button.disabled = false; }
}

$("#rom-upload").addEventListener("change", event => uploadROMs([...event.target.files]));
$("#bios-upload").addEventListener("change", event => uploadNeoGeoBIOS(event.target.files[0]));
$("#fds-bios-upload").addEventListener("change", event => uploadFDSBIOS(event.target.files[0]));
$("#open-settings").onclick = () => $("#settings-dialog").showModal();
$("#search").addEventListener("input", renderGames);
$("#save-settings").onclick = saveSettings;
$("#browse-source").onclick = openDirectoryBrowser;
$("#close-browser").onclick = () => $("#directory-browser").close();
$("#use-directory").onclick = () => { if (state.browsedDirectory) $("#source-directory").value = state.browsedDirectory; $("#directory-browser").close(); };
$("#scan-source").onclick = async () => {
  const button = $("#scan-source"); button.disabled = true;
  try {
    const sourceDirectory = $("#source-directory").value.trim();
    if (!sourceDirectory) throw new Error("请先输入或浏览选择导入目录。");
    setStatus("#settings-status", "正在保存资料库目录并校验清单…");
    await api("/api/settings", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(settingsPayload()) });
    const response = await api("/api/scan-source", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ full: false }) });
    setStatus("#settings-status", `扫描完成：${response.summary.valid} 个有效，${response.issues.length} 个待处理项。`); await load();
  } catch (error) { setStatus("#settings-status", error.message, true); }
  finally { button.disabled = false; }
};
$("#refresh-source-roms").onclick = () => loadSourceROMs({ force: true });
for (const selector of ["#source-system", "#source-category", "#source-collection", "#source-status", "#source-sort"]) $(selector).addEventListener("change", () => { state.sourceOffset = 0; loadSourceROMs(); });
$("#source-search").addEventListener("input", () => {
  clearTimeout(state.sourceFilterTimer);
  state.sourceFilterTimer = setTimeout(() => { state.sourceOffset = 0; loadSourceROMs(); }, 250);
});
$("#source-prev").onclick = () => { state.sourceOffset = Math.max(0, state.sourceOffset - state.sourceLimit); loadSourceROMs(); };
$("#source-next").onclick = () => { state.sourceOffset += state.sourceLimit; loadSourceROMs(); };
$("#quick-audit").onclick = () => startAudit(false);
$("#full-audit").onclick = () => startAudit(true);
$("#repair-missing").onclick = repairMissingMetadata;
$("#select-all-source").onclick = () => {
  const visible = state.visibleSourceRoms || state.sourceRoms;
  if (visible.length && visible.every(rom => state.selectedSourceIDs.has(rom.id))) for (const rom of visible) state.selectedSourceIDs.delete(rom.id);
  else for (const rom of visible) state.selectedSourceIDs.add(rom.id);
  loadSourceROMs();
};
$("#bulk-research").onclick = () => runBulk("research");
$("#bulk-delete").onclick = () => runBulk("delete");
$("#export").onclick = event => openLibraryLinkDialog(event.currentTarget);
$("#copy-library-link").onclick = copyLibraryLink;
$("#verify-library-link").onclick = verifyLibraryLink;
$("#close-library-link").onclick = () => $("#library-link-dialog").close();
$("#done-library-link").onclick = () => $("#library-link-dialog").close();
$("#editor-form").addEventListener("submit", saveGame);
$("#editor-form").elements.system.addEventListener("change", () => updateCPS2KeyField(state.selected));
$("#delete-game").onclick = deleteGame;
$("#cover-upload").addEventListener("change", event => uploadCover(event.target.files[0]));
$("#background-upload").addEventListener("change", event => uploadArtwork("backdrop", event.target.files[0]));
$("#logo-upload").addEventListener("change", event => uploadArtwork("logo", event.target.files[0]));
$("#identify-game").onclick = identifyGame;
$("#search-cover").onclick = searchCover;
$("#search-diagnostic").onclick = showSearchDiagnostic;
$("#rename-rom").onclick = renameROM;
$("#show-history").onclick = showHistory;
load();
