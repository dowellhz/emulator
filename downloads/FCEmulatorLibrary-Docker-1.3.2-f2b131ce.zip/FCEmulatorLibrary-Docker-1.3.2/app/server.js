#!/usr/bin/env node
/*
 * Retro Console Library Server
 *
 * A deliberately dependency-free, local-first ROM manager. The manager keeps
 * its own catalogue, hashes every artefact, and exports the exact portable
 * layout consumed by FCEmulatorTV's TVRemoteLibraryClient.
 */
const http = require("node:http");
const crypto = require("node:crypto");
const fsp = require("node:fs/promises");
const fs = require("node:fs");
const path = require("node:path");
const os = require("node:os");
const dns = require("node:dns/promises");
const net = require("node:net");
const { execFileSync } = require("node:child_process");
const { pipeline } = require("node:stream/promises");
const { URL } = require("node:url");
const zlib = require("node:zlib");
const CPS3 = require("./cps3.js");
const { crc32Update, crc32String, crc32Buffer } = require("./lib/crc32");
const { writeFileAtomic, writeJSONAtomic } = require("./lib/atomic-file");
const { now, randomID, sha256, extension, baseName, hashFile, safeRelative, resolvedWithin } = require("./lib/util");
const { SAVE_SYSTEMS, SAVE_ROUTE, SYSTEMS, MANIFEST_SYSTEMS, EXTENSIONS, GAME_BOY_SYSTEMS, GAME_BOY_CARTRIDGE_TYPES, MAX_GAME_BOY_ROM_BYTES } = require("./lib/systems");
const PCE = require("./lib/pce");
const PCECD = require("./lib/pcecd");
const { GBA_BIOS_BYTES, GBA_BIOS_NAME, MAX_GBA_ROM_BYTES, validateGBABIOSFile, validateGBAROMFile, gbaHardware } = require("./lib/gba");
const PS1 = require("./lib/ps1");
const MegaCD = require("./lib/megacd");
const Sega32X = require("./lib/sega32x");
// Upload cap for a single 32X adapter BIOS: the largest of the three images.
const SEGA32X_BIOS_MAX_BYTES = Math.max(...Sega32X.SEGA32X_BIOSES.map(bios => bios.bytes));
const NeoGeoPocket = require("./lib/neogeopocket");
// Upload cap for a single Neo Geo Pocket boot ROM: both the mono and color
// BIOS are 64 KiB.
const NGP_BIOS_MAX_BYTES = NeoGeoPocket.NEOGEOPOCKET_BIOS_MAX_BYTES;
// Upload cap for a single NGP NVRAM: a hair over the exact 0x3020 so the
// shape validator, not the HTTP cap, reports a wrong size.
const NGP_NVRAM_MAX_BYTES = NeoGeoPocket.NEOGEOPOCKET_NVRAM_BYTES + 0x400;
const { readFileRange, zipEndOfCentralDirectory, readZIPCentralDirectory, extractZIPEntry, isZIPMetadataEntry } = require("./lib/zip");
const { ARCADE_DEVICE_ROM_SETS, ARCADE_DEVICE_ROM_ARCHIVES } = require("./lib/arcade-device-roms");
const { identifyArcadeArchiveByContent, diagnoseArcadeArchive, catalogueDriver, neoGeoCatalogueDriver } = require("./lib/arcade-catalogue");
const { NEOGEO_SPLIT_SETS, identifyNeoGeoSplitSet, neoGeoSplitSetForArchive, findNeoGeoSplitParent, writeCompletedNeoGeoSplitSet, missingNeoGeoSplitParentMessage } = require("./lib/neogeo-split-sets");
const { FDS_BIOS_BYTES, FDS_BIOS_SHA1, validateFDSBIOSFile, validateFDSLogicalSide, fdsCRC16, validateQuickDiskSide, validateFDSImage } = require("./lib/fds");
const { fitCover } = require("./lib/image");
const { createVerifiedFiles } = require("./lib/verified-files");
const { portableIdentifier, portableSHA256, portableRevision, validatePortableFileDescriptor, validatePortableManifestHardware, verifyPortableHardwareFiles } = require("./lib/portable-manifest");
const { createWebResearch } = require("./lib/service/web-research");
const { createBIOSDeclarations } = require("./lib/service/bios-declarations");
const { createCanonicalLibrary } = require("./lib/service/canonical-library");
const { createLibraryIngest } = require("./lib/service/library-ingest");
const { createSourceLibrary } = require("./lib/service/source-library");
const { createSourceAutomation } = require("./lib/service/source-automation");
const { createCPS3Service } = require("./lib/service/cps3-service");
const { createBIOSStore } = require("./lib/service/bios-store");
const { createSNESFirmware } = require("./lib/service/snes-firmware");
const { createLibraryExport } = require("./lib/service/library-export");
const { createHTTPAPI } = require("./lib/service/http-api");
const { createCatalogIngest } = require("./lib/service/catalog-ingest");
const { createBackgroundTasks } = require("./lib/service/background-tasks");
// Public archive identities from FCArcadeCoreC.c PGM_DRIVER entries.
// Classification is not a claim that a protection device is executable.
const identities = [
  ["orlegend", "00df222abdc32b792e89fa77feabc1aad258bec484d29fe2f39d004df77ab8c2", 18114087],
  ["drgw2", "770dc66e7929d287cfa577edd9c5e6ddd89784dd026de7d40153549978ad040f", 3992536],
  ["killbld", "226850fcd4e6dd4f48edf887b7a833a827bb6f69287eb774e4f7f6a98a20411f", 16331490],
  ["olds", "93f398660c1a44a3b9905b0f937595c7ae7746b3e3699c81e9a8bbe337f9d4de", 23177711],
  ["kovsh", "ae9436146ddc44f58479046d3f516f5a929e8a8a7227d7fd6c6aa08a147404bb", 22366936],
  ["martmast", "aff4260f6a53f514832ea2e968422000259dd2b6d72394bb5467698c5ed7018d", 30619610],
  ["ddp2", "ccd2dbf21efa267515661485d8bf2d114d970d510d3cdeeb3ce2048d34d74eee", 14985208],
  ["killbldp", "e5c92d751f590aa34bb80d76dca710e2d4fb8a23990f7cb0717a41f4d34ec21a", 20043075],
  ["dmnfrnt", "e343160c045ac91e173d442c363e680200a42529f033366bfcb613dd8a29d6d2", 24995334]
];
// When a game whose package never recorded a creation time joined the
// library. The apps assume the same date for an index entry without one.
const UNDATED_GAME_ADDED_AT = "2026-09-01T00:00:00.000Z";
const DEFAULT_LIBRARY_TITLE = "Retro Console Library";
const LEGACY_DEFAULT_LIBRARY_TITLE = "FC Emulator Library";

function identifyPGMArchive({ sha256, bytes } = {}) {
  return identities.find(entry => entry[1] === sha256 && entry[2] === bytes)?.[0] || null;
}

const CATEGORIES = ["经典", "动作", "闯关", "射击", "格斗", "体育", "竞速", "益智", "冒险", "角色扮演", "策略", "模拟", "多人", "教育", "街机", "破解", "其他"];
const IMAGE_EXTENSIONS = new Set(["png", "jpg", "jpeg", "webp"]);
// `cover` and `backdrop` are the portable manifest v1 artwork keys consumed
// by Apple TV. `logo` is a manager-only extension and is intentionally
// ignored by clients that do not understand it.
const ARTWORK_TYPES = new Set(["cover", "backdrop", "logo"]);
const PREFERRED_SEARCH_SITES_VERSION = 2;
const ADDED_PREFERRED_SEARCH_SITES_V2 = [
  "https://thumbnails.libretro.com/",
  "https://adb.arcadeitalia.net/",
  "https://www.progettosnaps.net/flyers/",
  "https://www.gamesdatabase.org/"
];
const DEFAULT_PREFERRED_SEARCH_SITES = [
  "https://gamesdb.launchbox-app.com/",
  "https://www.arcadeartwork.org/",
  "https://flyers.arcade-museum.com/",
  "https://www.thecoverproject.net/",
  "https://www.coverbrowser.com/covers/nes-games",
  "https://archive.org/download/nes_classic_box_art/NES%20Box%20Art%20%28USA%29%20742%20Covers/",
  "https://www.arcadeartwork.org/index.php?%2Fcategory%2F698=",
  "https://archive.org/details/arcade-posters-b2-size",
  ...ADDED_PREFERRED_SEARCH_SITES_V2
];
const MIME_TYPES = {
  ".json": "application/json; charset=utf-8", ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
  ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp",
  ".nes": "application/octet-stream", ".fds": "application/octet-stream", ".qd": "application/octet-stream", ".rom": "application/octet-stream", ".smc": "application/octet-stream", ".sfc": "application/octet-stream", ".bin": "application/octet-stream", ".md": "application/octet-stream", ".gen": "application/octet-stream", ".gb": "application/octet-stream", ".gbc": "application/octet-stream",
  ".zip": "application/zip", ".7z": "application/x-7z-compressed", ".chd": "application/octet-stream"
};

// Driver identity metadata is kept beside the private server-side key table.
// The CRCs and filenames mirror the locked CPS2 chip catalogue consumed by
// FCArcadeCoreC/MAME; raw keys are never exposed by a Web endpoint.
const CPS2_KEY_METADATA = Object.freeze({
  "choko": { name: "choko.key", crc32: "08505e8b" },
  "ddsom": { name: "ddsom.key", crc32: "541e425d" },
  "mshvsf": { name: "mshvsf.key", crc32: "64660867" },
  "qndream": { name: "qndream.key", crc32: "97eee4ff" },
  "uecology": { name: "uecology.key", crc32: "0bab792d" },
  "1944u": { name: "1944u.key", crc32: "61734f5b" },
  "19xxar1": { name: "19xxa.key", crc32: "2cd32eb9" },
  "19xxu": { name: "19xx.key", crc32: "77e67ba1" },
  "armwar": { name: "armwar.key", crc32: "fe979382" },
  "avspu": {
    name: "avspu.key", crc32: "4e68e346",
    archiveSHA256: "47fdc2edbdd57cbfc366a7f162a182c8ae1f9fe0f52c4271048339214ec9c44e"
  },
  "csclub1": { name: "csclub.key", crc32: "903907d7" },
  "ddtodur1": { name: "ddtodu.key", crc32: "7c03ec9e" },
  "gigawing": { name: "gigawing.key", crc32: "5076c26b" },
  "mmatrix": { name: "mmatrix.key", crc32: "8ed66bc4" },
  "mpang": { name: "mpang.key", crc32: "95354b0f" },
  "mvsc": { name: "mvsc.key", crc32: "7e101e09" },
  "pzloop2": { name: "pzloop2.key", crc32: "ae13be78" },
  "sfz2al": { name: "sfz2al.key", crc32: "2904963e" },
  "sgemf": { name: "sgemf.key", crc32: "3d604021" }
});
const ARCADE_HARDWARE_CATALOG = require("./resources/arcade-hardware.json");
const MAME_CAPCOM_CATALOG = require("./resources/mame-capcom-drivers.json");
if (MAME_CAPCOM_CATALOG?.schemaVersion !== 1 || !MAME_CAPCOM_CATALOG.drivers) {
  throw new Error("MAME Capcom driver 资料格式无效。");
}
function exactCPS2ArchiveMatch(matches, archiveSHA256) {
  return matches.find(candidate =>
    CPS2_KEY_METADATA[candidate.driver]?.archiveSHA256 === archiveSHA256
  ) || null;
}
const MAME_CAPCOM_DRIVERS = MAME_CAPCOM_CATALOG.drivers;
const MAME_CAPCOM_IDENTITY_INDEX = new Map();
for (const [driver, record] of Object.entries(MAME_CAPCOM_DRIVERS)) {
  for (const chip of record.identity || []) {
    const identity = `${chip.bytes}:${String(chip.crc32).toLowerCase()}`;
    const drivers = MAME_CAPCOM_IDENTITY_INDEX.get(identity) || [];
    drivers.push(driver);
    MAME_CAPCOM_IDENTITY_INDEX.set(identity, drivers);
  }
}
const ARCADE_HARDWARE_BY_DRIVER = new Map(
  Object.entries(ARCADE_HARDWARE_CATALOG.families).flatMap(([id, family]) =>
    family.drivers.map(driver => [driver, { id, label: family.label }])
  )
);
// MAME's own description for the boards the Capcom table does not cover, so
// a Sega set uploaded under its MAME name is catalogued by that name rather
// than by whatever a web search associates with a nine-letter basename.
const ARCADE_HARDWARE_TITLES = new Map(
  Object.values(ARCADE_HARDWARE_CATALOG.families).flatMap(family =>
    Object.entries(family.titles || {})
  )
);

function arcadeCatalogTitle(driver) {
  const identifier = String(driver || "").trim().toLowerCase();
  return identifier ? ARCADE_HARDWARE_TITLES.get(identifier) || CPS3.cps3Driver(identifier)?.title || null : null;
}

// The words of a MAME description that name the game; the qualifiers in
// parentheses — region, revision, board — are not the name.
function arcadeSetName(description) {
  return String(description || "").replace(/\s*\([^)]*\)/g, " ").replace(/\s+/g, " ").trim();
}

// Whether a research answer names the game the catalogue says the set is:
// the same words, most of them, or one name inside the other by whole
// words ("Moonwalker" for "Michael Jackson's Moonwalker"). The web was sure
// that smgp was "Super Volleyball" and mwalk was "Metal Slug"; a set's
// identity is the catalogue's to give, and an answer about another game
// is thrown away whole.
function researchAnswerNamesTheSet(description, answerTitle) {
  const name = normalized(arcadeSetName(description)), answer = normalized(answerTitle);
  if (!name || !answer) return false;
  if (scoreMatch(name, answer) >= 0.6) return true;
  const nameWords = name.split(" "), answerWords = answer.split(" ");
  return containsWordSequence(nameWords, answerWords) || containsWordSequence(answerWords, nameWords);
}
// Platform detection is deliberately broader than the device core's current
// executable catalog. Known Capcom driver basenames must remain Arcade even
// while an individual driver is still being implemented by FCArcadeCoreC.
const CPS1_DRIVERS = new Set([
  "1941", "3wonders", "cawing", "dino", "ffight", "ghouls", "knights",
  "megaman", "mercs", "nemo", "pang3", "punisher", "sf2", "sf2ce",
  "slammast", "strider", "unsquad", "varth", "willow", "wof", "wofh"
]);
const KONAMI_TMNT2_DRIVERS = new Set(["ssriderseaa"]);
// Konami System GX sets the clients can run (FCArcadeCoreC FC_ARCADE_HARDWARE_KONAMI_GX2).
const KONAMI_GX_DRIVERS = new Set(["salmndr2", "fantjour", "soccerss", "vsnetscr", "gokuparo", "crzcross", "puzldama", "daiskiss", "tbyahhoo", "tokkae", "rungun2", "slamdnk2", "rushhero", "winspike", "dragoona", "le2", "tkmmpzdm", "opengolf", "racinfrc", "sexyparo"]);
const MAX_NEOGEO_BIOS_BYTES = 16 * 1024 * 1024;
const SNES_IPL_BYTES = 64;
// The project's own SPC700 boot program, used when the user has not supplied
// spc700.rom. Written from the documented port protocol, not from Nintendo's
// ROM: it sets SP=$EF, clears $00-$EF, shows $AA/$BB on ports 0/1, waits for
// $CC, then serves each command from ports 2/3 (destination or entry) and
// port 1 (non-zero: transfer a block, zero: jump), echoing port 0 back.
// A block arrives as data in port 1 with its index in port 0; each byte is
// stored, then the index is echoed; an index that jumps ahead is the next
// command. The jump enters with A=X=Y=0. Entry and reset vector are $FFC0,
// so drivers that re-enter the loader work, and the first byte is the stack
// set-up ($CD), which blargg's SPC tests read back to confirm the IPL is
// mapped. The transfer fast path is 25 cycles per byte, the same as
// Nintendo's, so games that upload large drivers boot in the same time.
// Verified against Nintendo's IPL on the ROM matrix recorded in
// FCEmulatorMac/Tools/FCReferenceRunner/SNES/SN-IPL.md.
//
//   FFC0 CD EF     mov x,#$EF        FFE1 5D     start: mov x,a
//   FFC2 BD        mov sp,x          FFE2 1F 00 00      jmp [!$0000+x]
//   FFC3 E8 00     mov a,#0          FFE5 EB F4  sync:  mov y,$F4
//   FFC5 5D        mov x,a           FFE7 D0 FC         bne sync
//   FFC6 AF  clear:mov (x)+,a        FFE9 7E F4  loop:  cmp y,$F4
//   FFC7 C8 F0     cmp x,#$F0        FFEB D0 0D         bne wait
//   FFC9 D0 FB     bne clear         FFED E4 F5         mov a,$F5
//   FFCB 8F AA F4  mov $F4,#$AA      FFEF CB F4         mov $F4,y
//   FFCE 8F BB F5  mov $F5,#$BB      FFF1 D7 00         mov [$00]+y,a
//   FFD1 78 CC F4  ready:cmp $F4,#$CC FFF3 FC           inc y
//   FFD4 D0 FB     bne ready         FFF4 D0 F3         bne loop
//   FFD6 BA F6  command:movw ya,$F6  FFF6 AB 01         inc $01
//   FFD8 DA 00     movw $00,ya       FFF8 2F EF         bra loop
//   FFDA BA F4     movw ya,$F4       FFFA 10 ED  wait:  bpl loop
//   FFDC C4 F4     mov $F4,a         FFFC 2F D8         bra command
//   FFDE DD        mov a,y           FFFE C0 FF         reset vector
//   FFDF D0 04     bne sync
const BUILT_IN_SNES_IPL = Buffer.from(
  "cdefbde8005dafc8f0d0fb8faaf48fbbf578ccf4d0fbbaf6da00baf4c4f4ddd004" +
  "5d1f0000ebf4d0fc7ef4d00de4f5cbf4d700fcd0f3ab012fef10ed2fd8c0ff", "hex");
const BUILT_IN_SNES_IPL_SHA256 = crypto.createHash("sha256").update(BUILT_IN_SNES_IPL).digest("hex");
// The Cx4's internal 1024-entry x 24-bit data ROM, used when the user has not
// supplied cx4.rom. It is NOT authored data: it is six closed-form math tables
// (reciprocal, sqrt, sin, asin, tan, cos) and reproduces byte-identically, so
// Cx4 games (Mega Man X2/X3) need no firmware file while emulation stays LLE.
// Mirrors fc_snes_cx4_synthesize_data_rom(); the synthesis gate and the proof
// that it is libm-independent live in
// .reference-sources/mstan--snesrecomp/tests/test_cx4_datarom.py.
const BUILT_IN_SNES_CX4 = (() => {
  const rom = new Array(1024).fill(0);
  const MAX24 = 0xffffff, TWO24 = 1 << 24, TAN = 1 << 16, RN = 1 << 23;
  for (let n = 0; n < 256; n++) rom[n] = n === 0 ? MAX24 : Math.floor(RN / n);
  for (let n = 0; n < 256; n++) {
    // floor(sqrt(n)*2**20) exactly, as isqrt(n<<40) with BigInt so no double
    // rounding can slip in; the Math.sqrt is only a starting guess.
    let v = BigInt(n) << 40n, x = v === 0n ? 0n : BigInt(Math.floor(Math.sqrt(Number(v))));
    while (x > 0n && x * x > v) x--;
    while ((x + 1n) * (x + 1n) <= v) x++;
    rom[256 + n] = Number(x);
  }
  for (let n = 0; n < 128; n++) {
    const a = Math.PI * n / 256;
    rom[512 + n] = Math.floor(TWO24 * Math.sin(a));
    rom[640 + n] = Math.floor((TWO24 / Math.PI) * Math.asin(n / 128));
    rom[768 + n] = n === 64 ? TAN : Math.floor(TAN * Math.tan(a)); // tan(45deg)==1
    rom[896 + n] = Math.min(Math.floor(TWO24 * Math.cos(a)), MAX24); // cos(0) saturates
  }
  const buffer = Buffer.alloc(3072); // 1024 x 24-bit words
  for (let n = 0; n < 1024; n++) {
    buffer[n * 3] = rom[n] & 0xff;
    buffer[n * 3 + 1] = (rom[n] >> 8) & 0xff;
    buffer[n * 3 + 2] = (rom[n] >> 16) & 0xff;
  }
  return buffer;
})();
const BUILT_IN_SNES_CX4_SHA256 = crypto.createHash("sha256").update(BUILT_IN_SNES_CX4).digest("hex");
// Cartridge coprocessor ROMs are owned by the user and never shipped. Sizes
// and concatenation order follow pinned ares v145 mia/medium/super-famicom.cpp:
// program ROM first, then data ROM. Cx4 contains only a data ROM.
const SNES_COPROCESSOR_FIRMWARE = new Map([
  ...["dsp1.rom", "dsp1b.rom", "dsp2.rom", "dsp3.rom", "dsp4.rom"].map(name =>
    [name, { architecture: "NEC uPD7725", bytes: 0x2000, halves: { program: 0x1800, data: 0x0800 } }]),
  ["cx4.rom", { architecture: "Hitachi HG51BS169", bytes: 0x0c00, halves: null }],
  ["st010.rom", { architecture: "NEC uPD96050", bytes: 0x0d000, halves: { program: 0x0c000, data: 0x1000 } }],
  ["st011.rom", { architecture: "NEC uPD96050", bytes: 0x0d000, halves: { program: 0x0c000, data: 0x1000 } }],
  ["st018.rom", { architecture: "SETA ARM6", bytes: 0x28000, halves: { program: 0x20000, data: 0x8000 } }]
]);
const SNES_COPROCESSOR_FIRMWARE_NAMES = new Set(SNES_COPROCESSOR_FIRMWARE.keys());
// Coprocessors the clients' core runs on a program of the project's own when
// no firmware is supplied (fc_snes_dsp_program_available in
// FCSNESDSPBuiltin.c — keep the two lists the same). Such a game needs no
// upload and its package carries no firmware; a user's dump, when present,
// still ships and the original runs instead.
const SNES_OWN_DSP_PROGRAMS = new Set(["dsp1.rom", "dsp1b.rom", "dsp2.rom", "dsp3.rom", "dsp4.rom", "st010.rom"]);
const SNES_COPROCESSOR_MAX_FIRMWARE_BYTES = Math.max(
  ...[...SNES_COPROCESSOR_FIRMWARE.values()].map(specification => specification.bytes)
);
const SNES_COPROCESSOR_HALF_PATTERN = /^((?:dsp[1-4]b?|st01[018]))\.(program|data)\.rom$/;
// The coprocessor ROMs a client keeps by name and a library publishes as
// files, like its BIOSes: every one but the Cx4's, whose data ROM every
// client synthesizes.
const SNES_COPROCESSOR_PUBLISHED_NAMES = [...SNES_COPROCESSOR_FIRMWARE_NAMES].filter(name => name !== "cx4.rom");
function snesNECDSPFirmwareUploadName(originalName) {
  const name = safeName(originalName).toLowerCase();
  if (SNES_COPROCESSOR_FIRMWARE_NAMES.has(name)) return { name, base: name, half: null };
  const half = SNES_COPROCESSOR_HALF_PATTERN.exec(name);
  if (half && SNES_COPROCESSOR_FIRMWARE_NAMES.has(`${half[1]}.rom`)) return { name, base: `${half[1]}.rom`, half: half[2] };
  return null;
}
// The 21-byte Super NES header title is JIS X 0201: ASCII plus half-width
// katakana (0xA1-0xDF). Decoding it here rather than through
// TextDecoder("shift_jis") matters: a Node built without full ICU (the
// Synology package's) throws on that encoding, the title then fell back to
// Latin-1, matched nothing, and SD Gundam GX was given DSP-1B instead of
// DSP-3. Normalised to NFKC, the form ares compares against.
function snesHeaderTitle(titleBytes) {
  let label = "";
  for (const byte of titleBytes) {
    if (byte >= 0x20 && byte <= 0x7e) label += String.fromCharCode(byte);
    else if (byte >= 0xa1 && byte <= 0xdf) label += String.fromCharCode(0xff61 + byte - 0xa1);
  }
  return label.trim().normalize("NFKC");
}

function snesNECDSPFirmwareName(titleBytes) {
  const label = snesHeaderTitle(titleBytes);
  if (label === "PILOTWINGS") return "dsp1.rom";
  if (label === "DUNGEON MASTER") return "dsp2.rom";
  if (label === "SDガンダムGX") return "dsp3.rom";
  if (label === "PLANETS CHAMP TG3000" || label === "TOP GEAR 3000") return "dsp4.rom";
  return "dsp1b.rom";
}
// Which uPD96050 an EXNEC board carries is a matter of its title, exactly as
// its firmware is. The authority is ares mia and bsnes' firmwareEXNEC: F1 ROC
// II and Exhaust Heat II are the ST010, and everything else is the ST011.
//
// This used to name ST011 only for "2DAN MORITA SHOUGI" and default everything
// else to ST010, which is the opposite default. The two rules agree on the two
// titles they both know, but on any other header they disagree, and the client
// compares the manifest's board against what it detects from the ROM itself:
// the server would have said ST010 while the emulator said ST011, and the
// cartridge would have been refused as a board mismatch. Keep this identical to
// fc_snes_exnec_oscillator_for_cartridge, including trimming only the trailing
// pad so a header with leading spaces cannot be read two ways.
function snesSTFirmwareName(titleBytes) {
  let label;
  try { label = new TextDecoder("shift_jis").decode(titleBytes); } catch { label = titleBytes.toString("latin1"); }
  label = label.replace(/\0/g, "").replace(/[ \0]+$/, "");
  return label === "F1 ROC II" || label === "EXHAUST HEAT2" ? "st010.rom" : "st011.rom";
}
// FCArcadeCoreC intentionally accepts one locked, reproducible MVS board
// profile. These size/CRC identities are the same defaults documented by
// MAME; the server stores only metadata and a user-supplied archive.
const MAX_PGM_BIOS_BYTES = 16 * 1024 * 1024;
// The three chips a PGM motherboard cannot start without, from the same pinned
// MAME inventory the emulator's PGM catalogue is generated from. pgm_p01s.u20
// is the older program revision and is not required, so an archive holding
// either program ROM is accepted.
const PGM_BIOS_COMPONENTS = Object.freeze([
  { role: "主程序", name: "pgm_p02s.u20", bytes: 0x20_000, crc32: "78c15fa2" },
  { role: "文字层", name: "pgm_t01s.rom", bytes: 0x200_000, crc32: "1a7123a0" },
  { role: "音色样本", name: "pgm_m01s.rom", bytes: 0x200_000, crc32: "45ae7159" }
]);

// Main BIOS images from the pinned MAME 0.289 `neogeo`/`aes` system BIOS
// tables, in the same preference order as FCArcadeNeoGeo.c: any one of them
// makes a neogeo.zip bootable. `option` is MAME's -bios name.
const NEOGEO_MAIN_BIOS_IMAGES = Object.freeze([
  { option: "euro", name: "sp-s2.sp1", bytes: 0x20_000, crc32: "9036d879" },
  { option: "euro-s1", name: "sp-s.sp1", bytes: 0x20_000, crc32: "c7f2fa45" },
  { option: "asia-mv1c", name: "sp-45.sp1", bytes: 0x80_000, crc32: "03cc9f6a" },
  { option: "asia-mv1b", name: "sp-s3.sp1", bytes: 0x20_000, crc32: "91b64be3" },
  { option: "us", name: "sp-u2.sp1", bytes: 0x20_000, crc32: "e72943de" },
  { option: "us-e", name: "sp-e.sp1", bytes: 0x20_000, crc32: "2723a5b5" },
  { option: "us-v2", name: "sp1-u2", bytes: 0x20_000, crc32: "62f021f4" },
  { option: "us-u4", name: "sp1-u4.bin", bytes: 0x20_000, crc32: "1179a30f" },
  { option: "us-u3", name: "sp1-u3.bin", bytes: 0x20_000, crc32: "2025b7a2" },
  { option: "japan", name: "vs-bios.rom", bytes: 0x20_000, crc32: "f0e8f27d" },
  { option: "japan-s2", name: "sp-j2.sp1", bytes: 0x20_000, crc32: "acede59c" },
  { option: "japan-s1", name: "sp1.jipan.1024", bytes: 0x20_000, crc32: "9fb0abe4" },
  { option: "japan-mv1b", name: "japan-j3.bin", bytes: 0x20_000, crc32: "dff6d41f" },
  { option: "japan-j3a", name: "sp1-j3.bin", bytes: 0x20_000, crc32: "fbc6d469" },
  { option: "japan-mv1c", name: "sp-j3.sp1", bytes: 0x80_000, crc32: "486cb450" },
  { option: "japan-hotel", name: "sp-1v1_3db8c.bin", bytes: 0x20_000, crc32: "162f0ebe" },
  { option: "unibios40", name: "uni-bios_4_0.rom", bytes: 0x20_000, crc32: "a7aab458" },
  { option: "unibios33", name: "uni-bios_3_3.rom", bytes: 0x20_000, crc32: "24858466" },
  { option: "unibios32", name: "uni-bios_3_2.rom", bytes: 0x20_000, crc32: "a4e8b9b3" },
  { option: "unibios31", name: "uni-bios_3_1.rom", bytes: 0x20_000, crc32: "0c58093f" },
  { option: "unibios30", name: "uni-bios_3_0.rom", bytes: 0x20_000, crc32: "a97c89a9" },
  { option: "unibios23", name: "uni-bios_2_3.rom", bytes: 0x20_000, crc32: "27664eb5" },
  { option: "unibios23o", name: "uni-bios_2_3o.rom", bytes: 0x20_000, crc32: "601720ae" },
  { option: "unibios22", name: "uni-bios_2_2.rom", bytes: 0x20_000, crc32: "2d50996a" },
  { option: "unibios21", name: "uni-bios_2_1.rom", bytes: 0x20_000, crc32: "8dabf76b" },
  { option: "unibios20", name: "uni-bios_2_0.rom", bytes: 0x20_000, crc32: "0c12c2ad" },
  { option: "unibios13", name: "uni-bios_1_3.rom", bytes: 0x20_000, crc32: "b24b44a0" },
  { option: "unibios12", name: "uni-bios_1_2.rom", bytes: 0x20_000, crc32: "4fa698e9" },
  { option: "unibios12o", name: "uni-bios_1_2o.rom", bytes: 0x20_000, crc32: "e19d3ce9" },
  { option: "unibios11", name: "uni-bios_1_1.rom", bytes: 0x20_000, crc32: "5dda0d84" },
  { option: "unibios10", name: "uni-bios_1_0.rom", bytes: 0x20_000, crc32: "0ce453a0" },
  { option: "asia", name: "neo-epo.bin", bytes: 0x20_000, crc32: "d27a71f1" },
  { option: "japan-aes", name: "neo-po.bin", bytes: 0x20_000, crc32: "16d0c132" },
  { option: "devel", name: "neodebug.rom", bytes: 0x20_000, crc32: "698ebb7d" }
]);

const NEOGEO_BIOS_COMPONENTS = Object.freeze([
  { role: "固定层", name: "sfix.sfix", bytes: 0x20_000, crc32: "c2ea0cfd" },
  { role: "音频 CPU", name: "sm1.sm1", bytes: 0x20_000, crc32: "94416d67" },
  { role: "缩放表", name: "000-lo.lo", bytes: 0x20_000, crc32: "5a86cff2" }
]);


function categoryForSystem(category, system) {
  return category === "街机" && (system === "nes" || system === "snes") ? "其他" : category;
}

function arcadeHardware(system, driver) {
  if (system === "neoGeo") return { id: "neoGeoMVS", label: "Neo Geo MVS" };
  if (system !== "arcade") return null;
  const identifier = String(driver || "").trim().toLowerCase();
  if (!identifier) return null;
  const mame = MAME_CAPCOM_DRIVERS[identifier];
  if (mame?.family === "cps1") return { id: "cps1", label: "CPS-1" };
  if (mame?.family === "cps2") return { id: "cps2", label: "CPS-2" };
  if (CPS1_DRIVERS.has(identifier)) return { id: "cps1", label: "CPS-1" };
  if (CPS2_KEY_METADATA[identifier]) return { id: "cps2", label: "CPS-2" };
  if (KONAMI_TMNT2_DRIVERS.has(identifier)) return { id: "konamiTMNT2", label: "Konami" };
  if (KONAMI_GX_DRIVERS.has(identifier)) return { id: "konamiGX", label: "Konami GX" };
  if (identifier === "outrun") return { id: "segaOutRun", label: "Sega Out Run" };
  if (CPS3.cps3Driver(identifier)) return { id: "cps3", label: "CPS-3" };
  return ARCADE_HARDWARE_BY_DRIVER.get(identifier) || null;
}

// The Sony ZN board carries several makers' games: its sets are shelved by
// the maker MAME names for each (arcade-hardware.json "manufacturers"), on
// the shelves that exist -- Capcom's (with Arika and Takara co-productions),
// Taito's and Namco's; the rest (Tecmo, Eighting/Raizing, ...) have none.
const SONY_ZN_MANUFACTURERS = ARCADE_HARDWARE_CATALOG.families.sonyZN?.manufacturers || {};

function sonyZNShelf(driver) {
  const maker = String(SONY_ZN_MANUFACTURERS[String(driver || "").trim().toLowerCase()] || "");
  if (/\bCapcom\b/.test(maker)) return "capcom";
  if (/\bTaito\b/.test(maker)) return "taito";
  if (/\bNamco\b/.test(maker)) return "namco";
  return null;
}

// The Double Dragon board (ddragon.cpp) also ran other makers' games (The
// Game Room's Dark Tower, Midas' Toffy, ...): only Technos' own sets and the
// bootlegs of them go on the Technos shelf, by the maker MAME names
// (arcade-hardware.json "manufacturers"); ddragon3.cpp is all Technos.
function technosShelf(hardwareID, driver) {
  const makers = ARCADE_HARDWARE_CATALOG.families[hardwareID]?.manufacturers || {};
  const maker = String(makers[String(driver || "").trim().toLowerCase()] || "");
  return /\bTechnos\b/.test(maker) || maker === "bootleg" ? "technos" : null;
}

function arcadeManufacturer(system, driver) {
  const hardware = arcadeHardware(system, driver);
  if (!hardware) return null;
  if (hardware.id === "sonyZN") return sonyZNShelf(driver);
  if (hardware.id === "cps1" || hardware.id === "cps2" || hardware.id === "cps3" ||
      hardware.id === "capcom1942" || hardware.id === "capcom1943" || hardware.id === "capcomCommando" ||
      hardware.id === "capcomGunsmoke" || hardware.id === "capcomGNG" || hardware.id === "capcomBionicc" ||
      hardware.id === "capcomVulgus" || hardware.id === "capcomExedexes" || hardware.id === "capcomLwings" ||
      hardware.id === "capcomBlktiger" || hardware.id === "capcomSidearms" || hardware.id === "capcomTigeroad" ||
      hardware.id === "capcomLastduel" ||
      // Capcom's board for Mitchell's games (pang): the Capcom shelf
      hardware.id === "capcomMitchell") return "capcom";
  if (hardware.id.startsWith("sega")) return "sega";
  if (hardware.id === "konamiGX" || hardware.id === "konamiMystwarr" || hardware.id === "konami68k" ||
      hardware.id === "konamiNemesis" || hardware.id === "konamiContra" || hardware.id === "konamiFrogger") return "konami";
  if (hardware.id === "taitoF2" || hardware.id === "taitoF3" || hardware.id === "taitoBublbobl") return "taito";
  if (hardware.id === "namcoSystem1" || hardware.id === "namcoSystem2" || hardware.id === "namcoSystem11" || hardware.id === "namcoSystem12" ||
      hardware.id === "namcoPacman" || hardware.id === "namcoGalaga" || hardware.id === "namcoGalaxian" ||
      hardware.id === "namcoMappy") return "namco";
  if (hardware.id === "psikyoSH") return "psikyo";
  if (hardware.id === "iremM62" || hardware.id === "iremM72" || hardware.id === "iremM92") return "irem";
  if (hardware.id === "seibuRaiden2") return "seibu";
  if (hardware.id === "cave68k" || hardware.id === "caveCV1K") return "cave";
  if (hardware.id === "technosDDragon" || hardware.id === "technosDDragon3") return technosShelf(hardware.id, driver);
  if (hardware.id === "dataEastCninja") return "dataeast";
  // Toaplan's boards, Raizing / Eighting's games on them included (their
  // MAME drivers live in toaplan/ and run on the same hardware).
  if (hardware.id === "toaplan1" || hardware.id === "toaplan2") return "toaplan";
  // midway8080bw: mw8080bw.cpp's invaders, which MAME credits to "Taito /
  // Midway" -- Taito's game on Midway's PCB #739, shelved with Midway.
  if (hardware.id === "midwayTUnit" || hardware.id === "midwayWUnit" || hardware.id === "midwayYUnit" ||
      hardware.id === "midway8080bw") return "midway";
  if (hardware.id === "nintendoDKong" || hardware.id === "nintendoPopeye") return "nintendo";
  return null;
}

function automaticArcadeCollection(system, driver) {
  switch (arcadeManufacturer(system, driver)) {
    case "capcom": return { id: "capcom", title: "Capcom", symbol: "arcade.stick.console" };
    case "sega": return { id: "sega-system16", title: "SEGA", symbol: "arcade.stick.console" };
    case "konami": return { id: "konami", title: "Konami", symbol: "arcade.stick.console" };
    case "taito": return { id: "taito", title: "Taito", symbol: "arcade.stick.console" };
    case "namco": return { id: "namco", title: "Namco", symbol: "arcade.stick.console" };
    case "psikyo": return { id: "psikyo", title: "Psikyo", symbol: "arcade.stick.console" };
    case "irem": return { id: "irem", title: "Irem", symbol: "arcade.stick.console" };
    case "seibu": return { id: "seibu", title: "Seibu", symbol: "arcade.stick.console" };
    case "cave": return { id: "cave", title: "Cave", symbol: "arcade.stick.console" };
    case "technos": return { id: "technos", title: "Technos", symbol: "arcade.stick.console" };
    case "dataeast": return { id: "data-east", title: "Data East", symbol: "arcade.stick.console" };
    case "toaplan": return { id: "toaplan", title: "Toaplan", symbol: "arcade.stick.console" };
    case "midway": return { id: "midway", title: "Midway", symbol: "arcade.stick.console" };
    case "nintendo": return { id: "nintendo", title: "Nintendo", symbol: "arcade.stick.console" };
    default: return null;
  }
}

// The shelves automaticArcadeCollection files games on, and the older ids
// of the SEGA one: rebuilt from the manifests, never edited by hand.
const AUTOMATIC_ARCADE_COLLECTION_IDS = Object.freeze([
  "capcom", "sega", "sega-system16", "sega-system-16", "system16", "konami", "taito", "namco", "psikyo", "irem", "technos", "data-east", "seibu", "cave", "toaplan", "midway", "nintendo"
]);

// A machine tag some ROM sets append to every file name: "Doom # 32X.32X",
// "Sonic # MD.md", "Doom - 32X". Only a trailing tag that names a machine
// goes; a "#" in a real title ("Mission #1", "C# Quest") stays, and so does
// a machine name inside one ("Doom 32X Resurrection").
const PLATFORM_TAG = String.raw`(?:Sega\s+)?32X|Super\s+32X|Genesis\s+32X|MD|GEN|Genesis|Mega\s*Drive|SMS|Master\s+System|GG|Game\s+Gear|SG-?1000|NES|FC|Famicom|FDS|SNES|SFC|Super\s+Famicom|GB|GBC|GBA|Game\s+Boy(?:\s+(?:Color|Advance))?|PCE|TG-?16|PC\s+Engine|PS1|PSX|PlayStation|MCD|SCD|Mega[\s-]*CD|Sega\s+CD|Neo\s*Geo`;
const PLATFORM_HASH_TAIL = new RegExp(String.raw`\s+#\s*(?:${PLATFORM_TAG})\s*$`, "i");
const BARE_32X_TAIL = /(\S)\s+(?:-\s+)?(?:Sega\s+)?32X\s*$/i;

function stripPlatformTag(title) {
  const value = String(title || "");
  const stripped = value.replace(PLATFORM_HASH_TAIL, "").replace(BARE_32X_TAIL, "$1").trim();
  return stripped || value.trim();
}

function titleFromFile(name) {
  return stripPlatformTag(baseName(name)
    .replace(/\s*[\[(][^\])]*[\])]/g, "")
    .replace(/\s+(?:Rev|PRG|v)\s*\d+(?:\.\d+)?\s*$/i, "")
    .replace(/\s+/g, " ").trim()) || "未命名游戏";
}

function normalized(value) {
  return String(value).normalize("NFKD").toLowerCase().replace(/&/g, " and ")
    .replace(/[^\p{L}\p{N}]+/gu, " ").trim();
}

// A numbered sequel is a different game from the one it follows: a number
// or a roman numeral. Words like "chapter" are not markers — "Ys II -
// Ancient Ys Vanished - The Final Chapter" is Ys II.
const SEQUEL_WORD = /^(?:\d+|[ivx]{1,4})$/;

const ROMAN_SEQUEL_NUMBERS = { ii: "2", iii: "3", iv: "4", v: "5", vi: "6", vii: "7", viii: "8", ix: "9" };
function romanSequelNumbers(value) {
  return value.split(" ").map(word => ROMAN_SEQUEL_NUMBERS[word] || word).join(" ");
}

// Whether `shorter` appears in `longer` as a run of whole words.
function containsWordSequence(longer, shorter) {
  if (!shorter.length || shorter.length > longer.length) return false;
  for (let start = 0; start + shorter.length <= longer.length; start++) {
    let same = true;
    for (let index = 0; index < shorter.length; index++) {
      if (longer[start + index] !== shorter[index]) { same = false; break; }
    }
    if (same) return true;
  }
  return false;
}

function scoreMatch(a, b) {
  // A sequel number is the same word as a numeral or in roman: "Mortal
  // Kombat 2" is "Mortal Kombat II". I and X are left alone — "Mega Man X"
  // is not Mega Man 10.
  a = romanSequelNumbers(normalized(a)); b = romanSequelNumbers(normalized(b));
  if (!a || !b) return 0;
  if (a === b) return 1;
  const left = a.split(" "), right = b.split(" ");
  const [shorter, longer] = left.length <= right.length ? [left, right] : [right, left];
  // One title inside the other counts only as whole words of two or more:
  // as the start of the longer title, which then goes on with a subtitle
  // or a region — "Ys II" in "Ys II - Ancient Ys Vanished", "Super Mario
  // Bros. 3" in "Super Mario Bros. 3 (Europe)" — or anywhere in it when
  // it makes up most of it, "Legend of Zelda" in "The Legend of Zelda".
  // Never across a numbered sequel. It used to be a substring test, which
  // put the "ys" of Ys inside "boys" and "Crystalis", the one word
  // "Baseball" inside every baseball game and "Double Dragon" inside its
  // own sequels; the library filled with the wrong covers.
  if (shorter.length >= 2 && containsWordSequence(longer, shorter)) {
    const isPrefix = shorter.every((word, index) => longer[index] === word);
    const extra = longer.filter(word => !shorter.includes(word));
    // A leading article is not part of how much of the title is covered:
    // "Spider-Man - Web of Fire" is most of "The Amazing Spider-Man: Web of Fire".
    const covered = longer[0] === "the" && shorter[0] !== "the" ? longer.length - 1 : longer.length;
    if (!extra.some(word => SEQUEL_WORD.test(word))
        && (isPrefix || shorter.length / covered >= 0.75)) return 0.94;
  }
  const leftSet = new Set(left), rightSet = new Set(right);
  let common = 0;
  for (const word of leftSet) if (rightSet.has(word)) common++;
  return common ? (2 * common) / (leftSet.size + rightSet.size) : 0;
}

function decodeHTMLText(value) {
  return String(value || "").replace(/&amp;/gi, "&").replace(/&quot;/gi, '"')
    .replace(/&#(?:x([0-9a-f]+)|(\d+));/gi, (_, hexadecimal, decimal) =>
      String.fromCodePoint(Number.parseInt(hexadecimal || decimal, hexadecimal ? 16 : 10)))
    .replace(/&#39;|&apos;/gi, "'").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">");
}

function libretroThumbnailEntries(html, directoryURL) {
  const entries = [];
  const seen = new Set();
  for (const match of String(html || "").matchAll(/<a\b[^>]*\bhref\s*=\s*(["'])(.*?)\1[^>]*>([\s\S]*?)<\/a>/gi)) {
    const href = decodeHTMLText(match[2]).trim();
    if (!/\.png(?:[?#].*)?$/i.test(href)) continue;
    let imageURL;
    try { imageURL = new URL(href, directoryURL).href; } catch { continue; }
    if (seen.has(imageURL)) continue;
    seen.add(imageURL);
    let fileName = href.split(/[?#]/, 1)[0].split("/").pop() || "";
    try { fileName = decodeURIComponent(fileName); } catch { /* retain the encoded filename */ }
    fileName = decodeHTMLText(fileName);
    const title = noIntroArticleFirst(titleFromFile(fileName));
    if (title) entries.push({ title, fileName, imageURL });
  }
  return entries;
}

// No-Intro files a leading article after the name: "Amazing Spider-Man,
// The - Web of Fire". Put it back in front so the words run as in the title.
function noIntroArticleFirst(title) {
  return String(title).replace(/^(.+?),\s+(The|A|An)(?=\s+-\s+|$)/i, "$2 $1");
}

// A display title is not a filesystem path ("Dr. Mario" must keep Mario),
// but it uses the same No-Intro annotations as a filename. Keep this separate
// from titleFromFile, whose baseName step intentionally removes extensions.
function libretroSearchTitle(value) {
  return noIntroArticleFirst(String(value || "")
    .replace(/\s*[\[(][^\])]*[\])]/g, "")
    .replace(/\s+(?:Rev|PRG|v)\s*\d+(?:\.\d+)?\s*$/i, "")
    .replace(/\s+/g, " ").trim());
}

function libretroBoxArtMatches(entries, game, limit = 4) {
  const evidence = [game?.title, game?.chineseTitle, game?.arcadeDescriptor?.title]
    .filter(Boolean).map(libretroSearchTitle);
  if (game?.originalName) evidence.push(titleFromFile(game.originalName));
  if (!evidence.length) return [];
  const originalBaseName = normalized(baseName(game?.originalName || ""));
  const gameEvidence = [game?.title, game?.originalName, game?.region].join(" ");
  const variantPattern = /\[(?:h|b|p|t|tr|o|f|a)(?:\s|\d|\]|_)|\b(?:bootleg|hack|prototype|proto|beta|sample|demo|pirate|bad dump|virtual console|anniversary collection|advance collection|world collection)\b/i;
  const gameIsVariant = variantPattern.test(gameEvidence);
  const normalizedRegion = normalized(game?.region || "");
  const evidenceWords = new Set(normalized(gameEvidence).split(" ").filter(Boolean));
  const detectedRegion = normalizedRegion ||
    ((evidenceWords.has("usa") || evidenceWords.has("us")) ? "usa" :
      (evidenceWords.has("japan") || evidenceWords.has("jp")) ? "japan" :
      (["europe", "euro", "eu", "pal"].some(word => evidenceWords.has(word))) ? "europe" :
      evidenceWords.has("world") ? "world" :
      (evidenceWords.has("china") || evidenceWords.has("cn")) ? "china" :
      (evidenceWords.has("taiwan") || evidenceWords.has("tw")) ? "taiwan" :
      (evidenceWords.has("korea") || evidenceWords.has("kr")) ? "korea" :
      (evidenceWords.has("brazil") || evidenceWords.has("br")) ? "brazil" :
      (evidenceWords.has("asia") || evidenceWords.has("asian")) ? "asia" : "");
  const regionAliases = ({
    usa: ["usa", "us", "world"], us: ["usa", "us", "world"],
    japan: ["japan", "jp"], jp: ["japan", "jp"],
    europe: ["europe", "euro", "eu", "pal"], eu: ["europe", "euro", "eu", "pal"],
    asia: ["asia", "asian"], china: ["china", "chinese", "cn"],
    taiwan: ["taiwan", "tw"], korea: ["korea", "korean", "kr"],
    brazil: ["brazil", "br"], world: ["world"]
  })[detectedRegion] || [];
  return entries.map(entry => {
    const titleScore = Math.max(...evidence.map(value => scoreMatch(value, entry.title)));
    const annotationWords = new Set([...entry.fileName.matchAll(/[\[(]([^\])]+)[\])]/g)]
      .flatMap(match => normalized(match[1]).split(" ")));
    const regionScore = regionAliases.some(alias => annotationWords.has(alias)) ? 0.03 : 0;
    const exactFileScore = originalBaseName && originalBaseName === normalized(baseName(entry.fileName)) ? 0.08 : 0;
    const variantPenalty = !gameIsVariant && variantPattern.test(entry.fileName) ? 0.12 : 0;
    return { ...entry, titleScore, rankingScore: titleScore + regionScore + exactFileScore - variantPenalty };
  }).filter(entry => entry.titleScore >= 0.88)
    .sort((left, right) => right.rankingScore - left.rankingScore || left.fileName.length - right.fileName.length || left.fileName.localeCompare(right.fileName))
    .slice(0, limit);
}

// The spellings a LaunchBox search is tried with, the title's own first:
// a No-Intro " - " subtitle as LaunchBox's ": ", and sequel numbers in roman.
const ROMAN_FOR_SEQUEL = { 2: "II", 3: "III", 4: "IV", 5: "V", 6: "VI", 7: "VII", 8: "VIII", 9: "IX" };
function launchBoxQueries(title) {
  const queries = [String(title || "").trim()];
  queries.push(queries[0].replace(/\s+-\s+/g, ": "));
  for (const query of [...queries]) queries.push(query.replace(/(^|\s)([2-9])(?=$|[\s:])/g, (_, space, digit) => space + ROMAN_FOR_SEQUEL[digit]));
  return [...new Set(queries.filter(Boolean))];
}

function libretroPlaylists(system) {
  return ({
    nes: ["Nintendo - Nintendo Entertainment System"],
    snes: ["Nintendo - Super Nintendo Entertainment System"],
    megaDrive: ["Sega - Mega Drive - Genesis"],
    sega32x: ["Sega - 32X"],
    megaCD: ["Sega - Mega-CD - Sega CD"],
    masterSystem: ["Sega - Master System - Mark III"],
    gameGear: ["Sega - Game Gear"],
    sg1000: ["Sega - SG-1000"],
    gameBoy: ["Nintendo - Game Boy"],
    gameBoyColor: ["Nintendo - Game Boy Color"],
    gameBoyAdvance: ["Nintendo - Game Boy Advance"],
    wonderSwan: ["Bandai - WonderSwan", "Bandai - WonderSwan Color"],
    neoGeoPocket: ["SNK - Neo Geo Pocket", "SNK - Neo Geo Pocket Color"],
    playStation: ["Sony - PlayStation"],
    pcEngine: ["NEC - PC Engine - TurboGrafx 16"],
    pcEngineCD: ["NEC - PC Engine CD - TurboGrafx-CD"],
    neoGeo: ["SNK - Neo Geo", "SNK - Neo Geo CD"],
    arcade: ["FBNeo - Arcade Games", "MAME"],
    pgm: ["FBNeo - Arcade Games", "MAME"]
  })[system] || [];
}

async function mapWithConcurrency(items, concurrency, mapper) {
  const results = new Array(items.length); let next = 0;
  async function worker() {
    while (true) {
      const index = next++;
      if (index >= items.length) return;
      results[index] = await mapper(items[index], index);
    }
  }
  await Promise.all(Array.from({ length: Math.min(items.length, Math.max(1, concurrency)) }, worker));
  return results;
}

function imageDimensions(data, contentType = "") {
  if (!Buffer.isBuffer(data) || data.length < 24) return null;
  if (contentType === "image/png" && data.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) {
    return { width: data.readUInt32BE(16), height: data.readUInt32BE(20) };
  }
  if (contentType === "image/jpeg" && data[0] === 0xff && data[1] === 0xd8) {
    let offset = 2;
    while (offset + 9 < data.length) {
      if (data[offset] !== 0xff) { offset++; continue; }
      const marker = data[offset + 1];
      if (marker === 0xd8 || marker === 0xd9) { offset += 2; continue; }
      const length = data.readUInt16BE(offset + 2);
      if (length < 2 || offset + 2 + length > data.length) break;
      if ((marker >= 0xc0 && marker <= 0xc3) || (marker >= 0xc5 && marker <= 0xc7) || (marker >= 0xc9 && marker <= 0xcb) || (marker >= 0xcd && marker <= 0xcf)) {
        return { width: data.readUInt16BE(offset + 7), height: data.readUInt16BE(offset + 5) };
      }
      offset += 2 + length;
    }
  }
  if (contentType === "image/webp" && data.toString("ascii", 0, 4) === "RIFF" && data.toString("ascii", 8, 12) === "WEBP") {
    const kind = data.toString("ascii", 12, 16);
    if (kind === "VP8X" && data.length >= 30) return { width: 1 + data.readUIntLE(24, 3), height: 1 + data.readUIntLE(27, 3) };
    if (kind === "VP8 " && data.length >= 30) return { width: data.readUInt16LE(26) & 0x3fff, height: data.readUInt16LE(28) & 0x3fff };
  }
  return null;
}

function detectedSystem(fileName) {
  const ext = extension(fileName);
  // Firmware and lock-on cartridges share ordinary game extensions. Keep
  // them out of generic folder/dropbox scans; their dedicated upload
  // endpoints validate and publish them separately.
  if (auxiliaryROMReason(fileName)) return null;
  if (["nes", "fds", "qd"].includes(ext)) return "nes";
  if (["sfc", "smc"].includes(ext)) return "snes";
  if (ext === "32x") return "sega32x";
  // Provisional: a .bin/.md/.gen with "SEGA 32X" at 0x100 is re-resolved to
  // sega32x by resolveMegaDriveSystem.
  if (["bin", "md", "gen"].includes(ext)) return "megaDrive";
  if (ext === "sms") return "masterSystem";
  if (ext === "gg") return "gameGear";
  if (ext === "sg") return "sg1000";
  // Provisional: resolveGameBoySystem reads the header's CGB flag.
  if (ext === "gb" || ext === "gbc") return "gameBoy";
  if (ext === "gba") return "gameBoyAdvance";
  // .ws and .wsc are one system; the core auto-detects color from the footer.
  if (ext === "ws" || ext === "wsc") return "wonderSwan";
  // .ngp and .ngc are one system; the core reads the color flag from the header.
  if (ext === "ngp" || ext === "ngc") return "neoGeoPocket";
  if (ext === PCE.PCE_EXTENSION) return "pcEngine";
  if (ext === PS1.PS1_PACKAGE_EXTENSION) return "playStation";
  if (ext === MegaCD.MEGACD_PACKAGE_EXTENSION) return "megaCD";
  if (ext === PCECD.PCECD_PACKAGE_EXTENSION) return "pcEngineCD";
  if (ext === CPS3.CPS3_PACKAGE_EXTENSION) return "arcade";
  const lowerName = String(fileName).toLowerCase();
  if (lowerName === "neogeo.zip" || lowerName === "pgm.zip") return null;
  if ((ext === "zip" || ext === "7z") && arcadeHardware("arcade", baseName(fileName))) return "arcade";
  if (ext === "zip" || ext === "7z") return "neoGeo";
  return null;
}

// Names used by Genesis Plus GX and PicoDrive for system/accessory images.
// These are not playable cartridges, despite their .sms/.gg/.bin suffixes.
// Content hashes also catch the same files after they have been renamed.
const AUXILIARY_ROM_NAMES = new Map([
  [GBA_BIOS_NAME, "Game Boy Advance BIOS"], ["gba.bin", "Game Boy Advance BIOS"],
  ["bios_e.sms", "Master System BIOS"], ["bios_u.sms", "Master System BIOS"],
  ["bios_j.sms", "Master System BIOS"], ["bios.gg", "Game Gear BIOS"],
  ["ggenie.bin", "Game Genie 配件 ROM"], ["areplay.bin", "Action Replay 配件 ROM"],
  ["sk.bin", "Sonic & Knuckles 锁定卡 ROM"],
  ["bios_cd_e.bin", "Mega CD BIOS"], ["bios_cd_u.bin", "Mega CD BIOS"],
  ["bios_cd_j.bin", "Mega CD BIOS"], ["eu_mcd2_9306.bin", "Mega CD BIOS"],
  ["eu_mcd2_9303.bin", "Mega CD BIOS"], ["eu_mcd1_9210.bin", "Mega CD BIOS"],
  ["us_scd2_9306.bin", "Mega CD BIOS"], ["us_scd2_9303.bin", "Mega CD BIOS"],
  ["us_scd1_9210.bin", "Mega CD BIOS"], ["segacdbios9303.bin", "Mega CD BIOS"],
  ["jp_mcd2_921222.bin", "Mega CD BIOS"], ["jp_mcd1_9112.bin", "Mega CD BIOS"],
  ["jp_mcd1_9111.bin", "Mega CD BIOS"]
]);

const AUXILIARY_ROM_SHA256 = new Map([
  ["477617917a12a30f9f43844909dc2de6e6a617430f5c9a36306c86414a670d50", "Master System BIOS"],
  ["67846e26764bd862f19179294347f7353a4166b62ac4198a5ec32933b7da486e", "Master System BIOS"],
  ["dd8b365521a9c08bb4c170da3592212580f7251f35a45d6083774d1c030bc3e3", "Game Gear BIOS"],
  ["017c9bbe4f4b2a6eea9c2f7bc3b03900097168c1aa2f3e2899e625a0f5ca20e7", "Game Genie 配件 ROM"],
  ["11619bf93c86a67e63a6d543b9337c0e325b9426e638a07d0d7f259a979a9a72", "Mega CD BIOS"],
  ["2c5358fcd8f2df22e14179426be6e30b466fb4134b6a397725a32f95a0b895d3", "Mega CD BIOS"]
]);

function auxiliaryROMReason(fileName, details = null) {
  const named = AUXILIARY_ROM_NAMES.get(path.basename(String(fileName)).toLowerCase());
  if (named) return named;
  return AUXILIARY_ROM_SHA256.get(String(details?.sha256 || "").toLowerCase()) || null;
}


// Header $0143 bit 7 asks for a Game Boy Color; $c0 requires one. A CGB
// cartridge always goes to gameBoyColor, whatever its extension says.
async function resolveGameBoySystem(file) {
  const header = await readFileRange(file, 0x150);
  if (header.length < 0x150) throw new Error("Game Boy ROM 不足 336 字节，缺少卡带头。");
  return (header[0x143] & 0x80) ? "gameBoyColor" : "gameBoy";
}

// A Mega Drive cartridge whose header at 0x100 reads "SEGA 32X" is a 32X game
// and runs on the adapter; everything else stays a plain Mega Drive ROM.
async function resolveMegaDriveSystem(file) {
  const header = await readFileRange(file, 0x110);
  return Sega32X.isSega32XCartridge(header) ? "sega32x" : "megaDrive";
}

function snesChecksum(rom) {
  let power = 1;
  while (power <= rom.length / 2) power *= 2;
  if (power === rom.length) {
    let linear = 0;
    for (const byte of rom) linear = (linear + byte) & 0xffff;
    return linear;
  }
  const extent = power * 2;
  const mirrored = (address, size) => {
    let branch = 1;
    while (branch <= size / 2) branch *= 2;
    if (branch === size) return address & (branch - 1);
    address &= branch * 2 - 1;
    return address < branch ? address : branch + mirrored(address - branch, size - branch);
  };
  let sum = 0;
  for (let offset = 0; offset < extent; offset++) sum = (sum + rom[mirrored(offset, rom.length)]) & 0xffff;
  return sum;
}

/// A Super NES game's hardware declaration, from its header analysis and the
/// firmware files its package carries: `ipl` and `coprocessor` are the
/// SPC700 IPL and the coprocessor dump ({ sha256 }), or null for a
/// coprocessor the clients run on their own program. Import and the
/// start-up reconcile of manifests written under older rules share it, so
/// the two cannot drift apart.
function snesHardwareDeclaration(snesInfo, ipl, coprocessor) {
  return {
    schemaVersion: 1,
    model: snesInfo.model,
    region: snesInfo.region,
    cartridge: { board: snesInfo.board, features: [
      ...(snesInfo.sramBytes ? ["battery"] : []), ...(snesInfo.rtcBytes ? ["rtc"] : [])
    ] },
    firmware: [{ role: "system-firmware", slot: 0, file: {
      path: "firmware/spc700.rom", bytes: SNES_IPL_BYTES, sha256: ipl.sha256
    } }, ...(coprocessor ? [{ role: "coprocessor-firmware", slot: 0, file: {
      path: `firmware/${snesInfo.coprocessorFirmware}`,
      bytes: snesInfo.coprocessorFirmwareBytes, sha256: coprocessor.sha256
    } }] : [])],
    inputs: snesInfo.board === "snes-obc1"
      ? [{ port: 1, kind: "snes-super-scope" }]
      : [{ port: 0, kind: "snes-standard" }, { port: 1, kind: "snes-standard" }],
    persistence: [
      ...(snesInfo.sramBytes ? [{ kind: "snes-sram", slot: 0, bytes: snesInfo.sramBytes }] : []),
      ...(snesInfo.rtcBytes ? [{ kind: "snes-rtc", slot: 1, bytes: snesInfo.rtcBytes }] : [])
    ],
    referenceTraces: []
  };
}

async function analyzeSNESROM(file) {
  const bytes = await fsp.readFile(file);
  const copierBytes = bytes.length % 0x8000 === 512 ? 512 : 0;
  const rom = bytes.subarray(copierBytes);
  if (rom.length < 0x8000 || rom.length > 8 * 1024 * 1024 || rom.length % 0x8000) {
    throw new Error("Super NES ROM 大小或 512 字节 copier header 无效。");
  }
  const actualChecksum = snesChecksum(rom);
  let best = null;
  let tied = false;
  for (const headerOffset of [0x7fc0, 0xffc0, 0x407fc0, 0x40ffc0]) {
    if (rom.length < headerOffset + 64) continue;
    const mapMode = rom[headerOffset + 21];
    const mode = mapMode & ~0x10;
    const addressLow = (headerOffset & 0x8000) === 0;
    const declaredLow = mode === 0x20 || mode === 0x22 || mode === 0x23;
    const declaredHigh = mode === 0x21 || mode === 0x25 || mode === 0x2a;
    const declaredAgrees = (declaredLow || declaredHigh) && declaredLow === addressLow;
    // Keep this admission rule identical to FCSNESCartridge.c.  Pinned bsnes
    // derives the mapping from the physical header address and uses the
    // declared map-mode only as a scoring tiebreak.  Contra III (USA) has a
    // 22-character internal title whose final "S" occupies this byte ($53).
    const romSizeCode = rom[headerOffset + 23];
    const ramSizeCode = rom[headerOffset + 24];
    // The header ROM-size code is advisory (bsnes sizes the ROM from the
    // image); it only contributes to the score below. The core parser
    // fc_snes_cartridge_inspect applies the same rule.
    if (ramSizeCode > 8) continue;
    const reset = rom.readUInt16LE(headerOffset + 60);
    if (reset < 0x8000) continue;
    const entry = (headerOffset & ~0x7fff) | (reset & 0x7fff);
    if (entry >= rom.length) continue;
    const checksum = rom.readUInt16LE(headerOffset + 30);
    const complement = rom.readUInt16LE(headerOffset + 28);
    const declaredBytes = romSizeCode <= 13 ? 1024 * (2 ** romSizeCode) : 0;
    const headerSRAMBytes = ramSizeCode ? 1024 * (2 ** ramSizeCode) : 0;
    let extent = 1;
    while (extent <= rom.length / 2) extent *= 2;
    if (extent !== rom.length) extent *= 2;
    let score = ((checksum ^ complement) === 0xffff ? 4 : 0)
      + (checksum === actualChecksum ? 8 : 0) + (extent === declaredBytes ? 2 : 0)
      + (headerOffset >= 0x400000 ? 4 : 0)
      + (declaredAgrees ? 2 : 0)
      + ([0x18, 0x78, 0x4c, 0x5c].includes(rom[entry]) ? 2 : 0);
    const cartridgeType = rom[headerOffset + 22];
    const cartridgeTypeHi = cartridgeType >> 4;
    const cartridgeTypeLo = cartridgeType & 0x0f;
    // Nintendo extended cartridge subtype lives immediately before the
    // 21-byte title. ares v145 uses it to distinguish Hitachi Cx4, SETA's
    // uPD96050 boards and ST018 rather than guessing from the game filename.
    const cartridgeSubType = rom[headerOffset - 1];
    const titleBytes = rom.subarray(headerOffset, headerOffset + 21);
    // SA-1 boards declare map mode $23 with cartridge type $32-$35; this is
    // the same title-independent identity the core parser derives.
    const isSA1 = mode === 0x23 && cartridgeType >= 0x32 && cartridgeType <= 0x35;
    // ares v145 mia/medium/super-famicom.cpp::board identifies GSU from the
    // chipset nibbles. GSU-RAM always supplies 32 KiB expansion RAM even
    // though early Star Fox headers declare no ordinary SRAM.
    const isSuperFX = mode === 0x20 && (cartridgeType & 0x0f) >= 0x03
      && (cartridgeType >> 4) === 0x01;
    const superFXType = cartridgeType & 0x0f;
    const superFXBattery = isSuperFX && (superFXType === 0x05 || superFXType === 0x06);
    // Same table, high nibble 0, low nibble 3-5: NEC's uPD7725 on a LoROM or
    // HiROM board (Pilotwings $03 without RAM, Super Mario Kart $05 with 2 KiB
    // battery RAM). The core parser derives the same identity.
    const isNECDSP = (mode === 0x20 || mode === 0x21) && (cartridgeType >> 4) === 0x0
      && (cartridgeType & 0x0f) >= 0x03 && (cartridgeType & 0x0f) <= 0x05;
    // ares mia chipset table: high nibble 2 selects OBC1. The production
    // SHVC-2E3M-01 board is LoROM type $25 with exactly 8 KiB battery RAM.
    const isOBC1 = mode === 0x20 && cartridgeType === 0x25;
    // ares mia board(): S-DD1 uses mapping $22 and cartridge family $4x;
    // SPC7110 uses mapping $2a, subtype 0, and $f5/$f9 (the latter adds RTC).
    const isSDD1 = mode === 0x22 && cartridgeTypeHi === 0x4 && cartridgeTypeLo >= 0x3;
    // The image has to be larger than the decompressor's own 1 MiB program
    // ROM, because the data ROM it reads sits behind that. The core requires
    // the same bound, and without it here a small image would be published as
    // SPC7110 and then refused by the client, which detects the board from the
    // very same header and compares.
    const isSPC7110 = mode === 0x2a && cartridgeTypeHi === 0x0f && cartridgeSubType === 0
      && (cartridgeTypeLo === 0x5 || cartridgeTypeLo === 0x9)
      && rom.length > 0x100000;
    const hasSPC7110RTC = isSPC7110 && cartridgeTypeLo === 0x9;
    // Extended subtype identities from the same function. These chips carry
    // internal ROMs which are supplied separately by the owner.
    const isCx4 = mode === 0x20 && cartridgeTypeHi === 0x0f && cartridgeTypeLo >= 0x3
      && cartridgeSubType === 0x10;
    const isST01x = mode === 0x20 && cartridgeTypeHi === 0x0f && cartridgeTypeLo >= 0x3
      && cartridgeSubType === 0x01;
    const isST018 = mode === 0x20 && cartridgeTypeHi === 0x0f && cartridgeTypeLo >= 0x3
      && cartridgeSubType === 0x02;
    const stFirmware = isST01x ? snesSTFirmwareName(titleBytes) : null;
    const sramBytes = isSuperFX ? (superFXBattery ? 32 * 1024 : 0) : headerSRAMBytes;
    const workRAMBytes = isSuperFX ? 32 * 1024 : headerSRAMBytes;
    const mapping = isSA1 ? "snes-sa1" : isSuperFX ? "snes-superfx" : isNECDSP ? "snes-necdsp"
      : isOBC1 ? "snes-obc1"
      : isSDD1 ? "snes-sdd1"
      : isSPC7110 ? (hasSPC7110RTC ? "snes-spc7110-rtc" : "snes-spc7110")
      : isCx4 ? "snes-cx4"
      : isST01x ? (stFirmware === "st010.rom" ? "snes-st010" : "snes-st011")
      : isST018 ? "snes-st018"
      : addressLow ? "snes-lorom" : mode === 0x25 || headerOffset >= 0x400000 ? "snes-exhirom" : "snes-hirom";
    const standard = (!declaredAgrees || [0x20, 0x21, 0x25].includes(mode)) && cartridgeType <= 2
      && (cartridgeType !== 0 || !sramBytes)
      && (mapping === "snes-exhirom"
        ? headerOffset === 0x40ffc0 && rom.length > 0x400000
        : headerOffset < 0x400000 && rom.length <= 0x400000)
      && sramBytes <= 128 * 1024;
    const supported = isSA1
      ? headerOffset < 0x400000 && rom.length <= 0x800000 && sramBytes <= 256 * 1024
      : isSuperFX ? headerOffset < 0x400000 && rom.length <= 0x800000
      : isNECDSP ? headerOffset < 0x400000 && rom.length <= 0x400000 && sramBytes <= 128 * 1024
      : isOBC1 ? headerOffset < 0x400000 && rom.length <= 0x400000 && sramBytes === 8 * 1024
      : isSDD1 ? headerOffset < 0x400000 && rom.length <= 0x800000 && sramBytes <= 256 * 1024
      : isSPC7110 ? headerOffset < 0x400000 && rom.length <= 0x800000 && sramBytes <= 128 * 1024
      : isCx4 || isST01x || isST018
        ? headerOffset < 0x400000 && rom.length <= 0x400000 && sramBytes <= 128 * 1024
      : standard;
    const coprocessorFirmware = isNECDSP ? snesNECDSPFirmwareName(titleBytes)
      : isCx4 ? "cx4.rom" : isST01x ? stFirmware : isST018 ? "st018.rom" : null;
    const candidate = { score, supported, board: mapping, sramBytes, workRAMBytes,
      regionCode: rom[headerOffset + 25],
      rtcBytes: hasSPC7110RTC ? 16 : 0,
      coprocessorFirmware,
      coprocessorFirmwareBytes: coprocessorFirmware
        ? SNES_COPROCESSOR_FIRMWARE.get(coprocessorFirmware).bytes : 0,
      // Kept for service API compatibility with 0038-0040 callers.
      necDSPFirmware: isNECDSP ? coprocessorFirmware : null };
    if (!best || score > best.score) { best = candidate; tied = false; }
    else if (score === best.score) tied = true;
  }
  if (!best) throw new Error("Super NES ROM 缺少有效的内部卡带头。");
  if (tied) throw new Error("Super NES ROM 存在歧义卡带头，拒绝猜测映射方式。");
  if (!best.supported) throw new Error("当前只支持标准 LoROM、HiROM、ExHiROM、SA-1、Super FX、DSP-1/2/3/4、OBC1、S-DD1、Cx4、SPC7110/RTC 与 ST010/011/018 卡带。");
  const pal = (best.regionCode >= 0x02 && best.regionCode <= 0x0c) || best.regionCode === 0x11;
  const region = best.regionCode === 0 ? "japan" : best.regionCode === 1 ? "usa"
    : best.regionCode === 0x0d ? "korea" : pal ? "europe" : "world";
  return { ...best, region, model: best.regionCode === 0 ? "super-famicom" : "super-nintendo" };
}

function safeName(value, fallback = "upload.bin") {
  const result = path.basename(String(value || "")).replace(/[\x00-\x1f<>:"/\\|?*]/g, "_").trim();
  return result || fallback;
}

function englishROMFileName(title, currentName) {
  const ext = extension(currentName);
  // The editable title is normally the English canonical name returned by
  // research. Keep the on-disk name portable, but never turn an untranslated
  // title into an unhelpful generic filename.
  const stem = String(title || "").normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^\x20-\x7e]/g, "")
    .replace(/[^A-Za-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  if (!/[A-Za-z0-9]/.test(stem)) return safeName(currentName);
 return safeName(stem + "." + ext, safeName(currentName));
}

function englishGamePackageID(title, sha256Value, fallback) {
  const stem = baseName(englishROMFileName(title, "rom.nes"));
  if (!/[A-Za-z0-9]/.test(stem)) return fallback;
  return stem + "-" + String(sha256Value || "").slice(0, 10);
}

function runtimeSecret(environmentName, keychainService) {
  if (process.env[environmentName]) return process.env[environmentName];
  if (process.platform !== "darwin") return "";
  try {
    return execFileSync("/usr/bin/security", ["find-generic-password", "-a", "FCEmulatorLibraryServer", "-s", keychainService, "-w"], {
      encoding: "utf8", stdio: ["ignore", "pipe", "ignore"]
    }).trim();
  } catch { return ""; }
}

function storeKeychainSecret(keychainService, value) {
  if (process.platform !== "darwin") return false;
  try {
    execFileSync("/usr/bin/security", ["add-generic-password", "-U", "-a", "FCEmulatorLibraryServer", "-s", keychainService, "-w", value], {
      stdio: ["ignore", "ignore", "ignore"]
    });
    return true;
  } catch { return false; }
}



function isPrivateAddress(address) {
  if (net.isIP(address) === 4) {
    const [a, b] = address.split(".").map(Number);
    return a === 0 || a === 10 || a === 127 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168);
  }
  const lower = address.toLowerCase();
  if (lower.startsWith("::ffff:")) return isPrivateAddress(lower.slice("::ffff:".length));
  return lower === "::1" || lower.startsWith("fc") || lower.startsWith("fd") || lower.startsWith("fe80:");
}

async function safeRemoteURL(value) {
  const url = new URL(value);
  if (!/^https?:$/.test(url.protocol) || url.username || url.password) throw new Error("封面地址必须是公开的 HTTP(S) 地址。");
  if (net.isIP(url.hostname)) {
    if (isPrivateAddress(url.hostname)) throw new Error("不允许访问内网封面地址。");
    return url;
  }
  const addresses = await dns.lookup(url.hostname, { all: true });
  if (!addresses.length || addresses.some(item => isPrivateAddress(item.address))) throw new Error("不允许访问解析到内网的封面地址。");
  return url;
}

function mapperFromHeader(header) {
  if (header.length < 16 || header.toString("ascii", 0, 4) !== "NES\x1a") return 0;
  let mapper = (header[6] >> 4) | (header[7] & 0xf0);
  if ((header[7] & 0x0c) === 0x08) mapper |= (header[8] & 0x0f) << 8;
  return mapper;
}

function mapperForNESFile(fileName, header) {
  return ["fds", "qd"].includes(extension(fileName)) ? 20 : mapperFromHeader(header);
}

function romInfoForNESFile(fileName, header) {
  const ext = extension(fileName);
  if (ext === "fds") return { format: "FDS" };
  if (ext === "qd") return { format: "QD" };
  return nesROMInfo(header);
}

function normalizeCPS2KeyHex(value) {
  const text = String(value || "").trim();
  if (!text) return null;
  const compact = text.replace(/\s+/g, "").toLowerCase();
  if (!/^[0-9a-f]{40}$/.test(compact)) throw new Error("CPS2 key 必须是 20 字节（40 个十六进制字符）。");
  return compact;
}

function cps2DriverMetadata(system, driver) {
  if (system !== "arcade") return null;
  const identifier = String(driver || "").toLowerCase();
  if (CPS2_KEY_METADATA[identifier]) return CPS2_KEY_METADATA[identifier];
  const record = MAME_CAPCOM_DRIVERS[identifier];
  if (record?.family !== "cps2") return null;
  const key = record.roms?.find(rom => rom.region === "key" && rom.bytes === 20 && /^[0-9a-f]{8}$/.test(rom.crc32));
  return key ? { name: key.name, crc32: key.crc32 } : null;
}

/* Every CPS2 driver that takes a key, with the key file MAME expects and
   its CRC32 — identities, never key bytes. The apps carry this list to check
   a key an owner types, so it is generated from here
   (scripts/generate-cps2-key-catalogue.js) and a test keeps the two equal. */
function cps2KeyCatalogue() {
  const drivers = new Set([...Object.keys(CPS2_KEY_METADATA), ...Object.keys(MAME_CAPCOM_DRIVERS)]);
  return [...drivers].sort()
    .map(driver => ({ driver, metadata: cps2DriverMetadata("arcade", driver) }))
    .filter(entry => entry.metadata)
    .map(({ driver, metadata }) => ({ driver, keyFileName: metadata.name, crc32: metadata.crc32 }));
}

function validateCPS2KeyHex(value, system, driver) {
  const hex = normalizeCPS2KeyHex(value);
  if (!hex) return null;
  const metadata = cps2DriverMetadata(system, driver);
  if (!metadata) throw new Error("该 ROM 驱动不需要 CPS2 key。 ");
  const actualCRC32 = crc32Buffer(Buffer.from(hex, "hex"));
  if (actualCRC32 !== metadata.crc32) {
    throw new Error(`CPS2 key 与驱动 ${driver} 不匹配（应为 ${metadata.name} / CRC32 ${metadata.crc32}）。`);
  }
  return hex;
}

/* The server's own key table. It defaults to the bundled copy, and
   FC_LIBRARY_CPS2_KEYS moves it somewhere writable — an installed package
   whose program directory is read-only still needs to record the keys its
   operator's own uploads supply. Resolved per call so the variable can be set
   before a service starts. */
function cps2KeyTableFile() {
  return process.env.FC_LIBRARY_CPS2_KEYS
    ? path.resolve(process.env.FC_LIBRARY_CPS2_KEYS)
    : path.join(__dirname, "resources", "cps2-keys.json");
}

function loadBundledCPS2KeyTable() {
  let document;
  try { document = JSON.parse(fs.readFileSync(cps2KeyTableFile(), "utf8")); }
  catch (error) {
    if (error.code === "ENOENT") {
      // A public build ships without the table. It is written on demand the
      // first time an uploaded archive yields a verified key.
      console.warn("未打包 CPS2 key 表；CPS2 ROM 需要在 ZIP 内提供匹配的 .key 文件。");
      return {};
    }
    throw new Error(`无法读取服务端 CPS2 key 表：${error.message}`);
  }
  if (document?.schemaVersion !== 1 || document?.format !== "cps2-key-20" || !document.keys || typeof document.keys !== "object") {
    throw new Error("服务端 CPS2 key 表格式无效。");
  }
  const result = {};
  for (const [driver, key] of Object.entries(document.keys)) {
    // A private installation may intentionally omit keys. Keep the driver
    // classified as CPS2 and surface a per-ROM "missing key" state instead
    // of preventing the server from starting.
    if (typeof key === "string" && cps2DriverMetadata("arcade", driver)) {
      result[driver] = validateCPS2KeyHex(key, "arcade", driver);
    }
  }
  return result;
}

const BUNDLED_CPS2_KEYS = loadBundledCPS2KeyTable();

function bundledCPS2KeyHex(system, driver) {
  if (!cps2DriverMetadata(system, driver)) return null;
  return BUNDLED_CPS2_KEYS[String(driver || "").toLowerCase()] || null;
}

/* Record a key an uploaded archive supplied, so the next ROM of the same
   driver — and a manifest regenerated from the table alone — still has it.
   `hex` is re-verified against the driver's MAME CRC32 before it is written,
   so a wrong key can never enter the table. The file is re-read first, which
   both merges a concurrent write and lets a public build, which ships with no
   table at all, create one from the operator's own ROMs. It stays server-only
   and 0600: clients never see this file, only the per-game manifest. */
async function rememberCPS2Key(system, driver, hex) {
  const identifier = String(driver || "").toLowerCase();
  const verified = validateCPS2KeyHex(hex, system, identifier);
  if (!verified) return false;
  // The file, not the in-memory table, decides whether this is already
  // recorded: the two differ whenever the table being written is not the one
  // this process loaded at start.
  const file = cps2KeyTableFile();
  let document = { schemaVersion: 1, format: "cps2-key-20", keys: {} };
  try {
    const existing = JSON.parse(await fsp.readFile(file, "utf8"));
    if (existing?.schemaVersion === 1 && existing?.format === "cps2-key-20" &&
        existing.keys && typeof existing.keys === "object") document = existing;
  } catch (error) { if (error.code !== "ENOENT") throw error; }
  if (document.keys[identifier] === verified) { BUNDLED_CPS2_KEYS[identifier] = verified; return false; }
  document.keys[identifier] = verified;
  await writeJSONAtomic(file, document, { mode: 0o600 });
  BUNDLED_CPS2_KEYS[identifier] = verified;
  return true;
}

function nesROMInfo(header) {
  if (header.length < 16 || header.toString("ascii", 0, 4) !== "NES\x1a") return null;
  return {
    format: (header[7] & 0x0c) === 0x08 ? "NES 2.0" : "iNES",
    prgROMBytes: header[4] * 16_384, chrROMBytes: header[5] * 8_192,
    mirroring: header[6] & 8 ? "four-screen" : header[6] & 1 ? "vertical" : "horizontal",
    battery: Boolean(header[6] & 2), trainer: Boolean(header[6] & 4)
  };
}





/* Whether a CPS1 set's graphics ROMs land where the clients' ordered loader
 * would put them: consecutive groups of four 16-bit lanes or eight byte
 * lanes, each group of one chip size, one group after another. Every CPS1
 * set in the MAME table does except Forgotten Worlds (cps1.cpp
 * ROM_START( forgottn )), whose groups mix 128 KiB byte lanes with 512 KiB
 * word lanes; for such a set the descriptor carries each chip's MAME region
 * offset as loadOffset, and the clients place every chip there. Every other
 * set's descriptor is left exactly as it was. */
function cps1GraphicsNeedOffsets(record) {
  if (record.family !== "cps1" || !record.executable) return false;
  const chips = (record.roms || []).filter(rom => rom.region === "graphics");
  if (chips.length <= 2) return false;
  let index = 0, offset = 0;
  while (index < chips.length) {
    const layout = chips[index].load;
    const lanes = layout === "interleave64Word" ? 4 : layout === "interleave64Byte" ? 8 : 0;
    if (!lanes || index + lanes > chips.length) return true;
    const step = lanes === 4 ? 2 : 1;
    for (let lane = 0; lane < lanes; lane++) {
      const chip = chips[index + lane];
      if (chip.load !== layout || chip.bytes !== chips[index].bytes || chip.offset !== offset + lane * step) return true;
    }
    offset += chips[index].bytes * lanes;
    index += lanes;
  }
  return false;
}

function portableMAMEArcadeDriver(driver, record) {
  const graphicsOffsets = cps1GraphicsNeedOffsets(record);
  return {
    schemaVersion: 1,
    source: `MAME ${MAME_CAPCOM_CATALOG.source.version}`,
    driver,
    ...(record.parent ? { parent: record.parent } : {}),
    hardware: record.family,
    title: record.title,
    rotation: record.rotation,
    inputProfile: record.inputProfile,
    executable: Boolean(record.executable),
    ...(record.unsupportedReason ? { unsupportedReason: record.unsupportedReason } : {}),
    ...(record.cps1Board ? { cps1Board: record.cps1Board } : {}),
    roms: record.roms.map(rom => ({
      name: rom.name, bytes: rom.bytes, crc32: rom.crc32,
      region: rom.region, load: rom.load,
      ...(rom.loadOffset ? { loadOffset: rom.loadOffset }
        : graphicsOffsets && rom.region === "graphics" && rom.offset ? { loadOffset: rom.offset } : {}),
      ...(rom.optional ? { optional: true } : {})
    }))
  };
}

/**
 * Identifies a Capcom archive from physical chip size+CRC vectors. The
 * basename is consulted only to resolve a tie between multiple MAME sets that
 * have each already passed their immutable identity vector.
 */
async function identifyMAMECapcomArchive(
  file, originalName = path.basename(file), preferredDriver = null
) {
  if (extension(originalName) !== "zip") return null;
  const entries = (await readZIPCentralDirectory(file)).filter(entry => !entry.name.endsWith("/"));
  const present = new Set(entries.map(entry => `${entry.bytes}:${entry.crc32.toLowerCase()}`));
  const candidates = new Set();
  for (const identity of present) {
    for (const driver of MAME_CAPCOM_IDENTITY_INDEX.get(identity) || []) candidates.add(driver);
  }
  const matches = [];
  for (const driver of candidates) {
    const record = MAME_CAPCOM_DRIVERS[driver];
    const identity = record.identity || [];
    if (!identity.length || !identity.every(chip => present.has(`${chip.bytes}:${chip.crc32}`))) continue;
    const required = (record.roms || []).filter(rom => !rom.optional);
    const matchedRequired = required.filter(rom => present.has(`${rom.bytes}:${rom.crc32}`)).length;
    const key = (record.roms || []).find(rom => rom.region === "key" && present.has(`${rom.bytes}:${rom.crc32}`));
    matches.push({
      driver, record, matchedRequired, missingRequired: required.length - matchedRequired,
      identityCount: identity.length, keyMatched: Boolean(key)
    });
  }
  matches.sort((left, right) =>
    Number(right.keyMatched) - Number(left.keyMatched) ||
    right.matchedRequired - left.matchedRequired ||
    left.missingRequired - right.missingRequired ||
    right.identityCount - left.identityCount ||
    left.driver.localeCompare(right.driver)
  );
  if (!matches.length) return null;
  const best = matches[0];
  const tied = matches.filter(candidate =>
    candidate.keyMatched === best.keyMatched &&
    candidate.matchedRequired === best.matchedRequired &&
    candidate.missingRequired === best.missingRequired
  );
  const basename = baseName(originalName).toLowerCase();
  const preferred = normalized(preferredDriver).toLowerCase();
  let selected = tied.find(candidate => candidate.driver === basename) ||
    tied.find(candidate => candidate.driver === preferred) ||
    (tied.length === 1 ? best : null);
  if (matches.length > 1) {
    const { sha256: archiveSHA256 } = await hashFile(file);
    selected = exactCPS2ArchiveMatch(matches, archiveSHA256) || selected;
  }
  if (!selected) {
    return { ambiguous: tied.slice(0, 12).map(candidate => candidate.driver) };
  }
  return {
    driver: selected.driver,
    title: selected.record.title,
    family: selected.record.family,
    missingRequired: selected.missingRequired,
    descriptor: portableMAMEArcadeDriver(selected.driver, selected.record)
  };
}

/**
 * Identifies an uploaded arcade archive (.zip/.7z) by its contents. The MAME
 * Capcom table goes first and is unchanged: it covers every CPS1/CPS2 set
 * MAME lists, not only the ones compiled into the core, and supplies the
 * portable descriptor those sets run from. Any other archive is matched
 * against the core's own driver catalogue (resources/arcade-drivers.json,
 * lib/arcade-catalogue.js), with the rule the clients apply. Neither looks
 * at the archive's name except to break a tie. Returns null when nothing
 * fits, { ambiguous } for an unbroken tie, else { driver, title, system,
 * source, ... } (system is "arcade", "neoGeo" or "pgm"; source is
 * "mame-capcom" or "core-catalogue").
 */
async function identifyArcadeArchive(file, originalName = path.basename(file), preferredDriver = null) {
  const capcom = await identifyMAMECapcomArchive(file, originalName, preferredDriver);
  if (capcom) return { ...capcom, source: "mame-capcom", ...(capcom.driver ? { system: "arcade" } : {}) };
  try {
    const content = await identifyArcadeArchiveByContent(file, originalName, preferredDriver);
    return content ? { ...content, source: "core-catalogue" } : null;
  } catch (error) {
    // A ZIP the Capcom pass could read is readable here too; a 7z whose
    // header this server cannot decode is identified by name, as before.
    if (extension(originalName) === "7z") return null;
    throw error;
  }
}

/* Whether an archive's filename names a driver in one of the server's
 * authoritative catalogues. This is diagnostic evidence only: it never
 * accepts bytes that content identification rejected. */
function knownArcadeDriverName(fileName) {
  const stem = baseName(String(fileName || "")).trim().toLowerCase();
  return Boolean(stem && (arcadeHardware("arcade", stem) || catalogueDriver(stem) || neoGeoCatalogueDriver(stem)));
}

function unidentifiedArcadeArchiveMessage(fileName) {
  return `无法识别街机 ROM 压缩包“${fileName}”：其中的 ROM 芯片不匹配本服务器支持的任何完整街机 ROM 组。` +
    "它可能属于尚未收录的硬件、其他 MAME/FBNeo 版本，或是不完整/损坏的包；服务器不会只按文件名放行。";
}

/* Rejection follows the same order as acceptance: exact supported content,
 * known-but-incomplete supported set, supported driver with different bytes,
 * known MAME/FBNeo driver whose board is not in this product, then unknown.
 * A filename never turns a rejection into an accepted game; it only selects
 * the useful explanation after content matching has failed. */
async function arcadeImportFailureMessage(file, fileName) {
  const diagnosis = await diagnoseArcadeArchive(file, fileName).catch(() => null);
  if (diagnosis?.status === "incomplete") {
    return `街机 ROM 组 ${diagnosis.driver} 不完整：只匹配 ${diagnosis.matchedRequired}/${diagnosis.totalRequired} 个必需芯片，` +
      `还缺 ${diagnosis.missingRequired} 个。FBNeo split/非合并包需要连同父 ROM 的共用芯片组成完整游戏包后再导入。`;
  }
  if (diagnosis?.status === "versionMismatch") {
    return `文件名对应核心已支持的 driver ${diagnosis.driver}，但压缩包的 ROM 芯片内容与该版本不匹配。` +
      "请确认没有混用其他 MAME/FBNeo 版本、改版或损坏文件；服务器不会只按文件名放行。";
  }
  if (knownArcadeDriverName(fileName)) {
    return `已识别文件名中的 MAME/FBNeo driver ${baseName(fileName)}，但当前自研内核尚未实现这套街机硬件或该版本。` +
      "ROM 未损坏也不能在当前客户端运行，更新内核和资料库服务器后才能导入。";
  }
  return unidentifiedArcadeArchiveMessage(fileName);
}

/* The package file name of an identified arcade set: the driver, so a
 * client or tool that reads the set from the file name agrees with
 * manifest.rom.driver whatever the upload was called. */
function arcadeROMFileName(identity, fileName) {
  return identity?.driver ? `${identity.driver}.${extension(fileName)}` : fileName;
}

// A Neo Geo cartridge always carries a P1 program ROM ("201-p1.p1",
// "p1.bin", ...). Anything zipped without one is some other board: filing it
// under Neo Geo would hand it to the Neo Geo core, which can only report a
// layout mismatch, and would send the metadata search looking for a Neo Geo
// game of that name.
async function looksLikeNeoGeoArchive(file, splitSets = NEOGEO_SPLIT_SETS) {
  try {
    const entries = await readZIPCentralDirectory(file);
    // A split clone (lib/neogeo-split-sets.js) carries only the chips that
    // differ from its parent: no P1, no M1, yet a Neo Geo cartridge.
    if (identifyNeoGeoSplitSet(entries, splitSets)) return true;
    const names = entries.map(entry => path.basename(String(entry.name || "")).toLowerCase());
    // The 68000 program: "p1" in SNK's names, "ep1" in Taito's, "pg1" on
    // some later boards (pbobblen's d96-07.ep1 and mslug4's 263-pg1.bin were
    // filed as generic arcade sets). Failing that, a cartridge's fixed
    // makeup — C1 sprites with an M1 Z80 program — identifies it.
    if (names.some(name => /(^|[^a-z0-9])(e?p|pg)1/.test(name))) return true;
    return names.some(name => /(^|[^a-z0-9])c1([^0-9]|$)/.test(name)) &&
      names.some(name => /(^|[^a-z0-9])m1([^0-9]|$)/.test(name));
  } catch {
    // An unreadable ZIP has no verified cartridge topology.  Returning true
    // here used to bypass the small/truncated archive guard and let the later
    // code report a less useful or, on some ingest paths, misclassify it.
    return false;
  }
}


const MAX_MEGA_DRIVE_ROM_BYTES = 0x400000 + 512;
// The Sega 8-bit core pages 4 MiB of ROM; a 512-byte copier header may precede it.
const MAX_SEGA8_ROM_BYTES = 0x400000 + 512;
const MAX_SNES_ROM_BYTES = 8 * 1024 * 1024 + 512;
// WonderSwan / WonderSwan Color cartridges are a power-of-two ROM the core
// word-swaps whole; the largest commercial carts are 128 Mbit (16 MiB).
const MAX_WONDERSWAN_ROM_BYTES = 16 * 1024 * 1024;


async function extractSingleConsoleROMFromZIP(file, requestedSystem = null) {
  let entries;
  try { entries = await readZIPCentralDirectory(file); }
  catch { return null; }
  entries = entries.filter(entry => !isZIPMetadataEntry(entry));
  if (entries.length !== 1) return null;
  const entry = entries[0];
  const format = [
    { system: "snes", extensions: EXTENSIONS.snes, maximumBytes: MAX_SNES_ROM_BYTES, purpose: "Super NES ROM", fallback: "game.sfc" },
    { system: "megaDrive", extensions: EXTENSIONS.megaDrive, maximumBytes: MAX_MEGA_DRIVE_ROM_BYTES, purpose: "Mega Drive ROM", fallback: "game.bin" },
    // 32X carts share megaDrive's .bin/.md/.gen; inside a ZIP only the explicit
    // .32x is taken for 32X, so a plain .bin stays a Mega Drive ROM here.
    { system: "sega32x", extensions: new Set(["32x"]), maximumBytes: MAX_MEGA_DRIVE_ROM_BYTES, purpose: "32X ROM", fallback: "game.32x" },
    { system: "masterSystem", extensions: EXTENSIONS.masterSystem, maximumBytes: MAX_SEGA8_ROM_BYTES, purpose: "Master System ROM", fallback: "game.sms" },
    { system: "gameGear", extensions: EXTENSIONS.gameGear, maximumBytes: MAX_SEGA8_ROM_BYTES, purpose: "Game Gear ROM", fallback: "game.gg" },
    { system: "sg1000", extensions: EXTENSIONS.sg1000, maximumBytes: MAX_SEGA8_ROM_BYTES, purpose: "SG-1000 ROM", fallback: "game.sg" },
    { system: "gameBoy", extensions: EXTENSIONS.gameBoy, maximumBytes: MAX_GAME_BOY_ROM_BYTES, purpose: "Game Boy ROM", fallback: "game.gb" },
    { system: "gameBoyAdvance", extensions: EXTENSIONS.gameBoyAdvance, maximumBytes: MAX_GBA_ROM_BYTES, purpose: "Game Boy Advance ROM", fallback: "game.gba" },
    { system: "wonderSwan", extensions: EXTENSIONS.wonderSwan, maximumBytes: MAX_WONDERSWAN_ROM_BYTES, purpose: "WonderSwan ROM", fallback: "game.ws" },
    { system: "neoGeoPocket", extensions: EXTENSIONS.neoGeoPocket, maximumBytes: NeoGeoPocket.MAX_NEOGEOPOCKET_ROM_BYTES, purpose: "Neo Geo Pocket ROM", fallback: "game.ngp" },
    { system: "pcEngine", extensions: EXTENSIONS.pcEngine, maximumBytes: PCE.MAX_PCE_ROM_BYTES, purpose: "PC Engine HuCard", fallback: "game.pce" }
  ].find(candidate => candidate.extensions.has(extension(entry.name)));
  if (!format) return null;
  if (format.unavailable) throw new Error(format.unavailable);
  const sameFamily = GAME_BOY_SYSTEMS.has(requestedSystem) && GAME_BOY_SYSTEMS.has(format.system);
  if (requestedSystem && requestedSystem !== format.system && !sameFamily) return null;
  const data = await extractZIPEntry(file, entry, {
    maximumBytes: format.maximumBytes,
    purpose: format.purpose
  });
  return { system: format.system, name: safeName(path.posix.basename(entry.name), format.fallback), data };
}

function snesCoprocessorFirmwareNameFromArchiveLabel(value) {
  const label = baseName(String(value || "")).trim();
  const match = label.match(/^(dsp1b|dsp1|dsp2|dsp3|dsp4|cx4|st010|st011|st018)(.*)$/i);
  if (!match) return null;
  const suffix = match[2].trim();
  if (!suffix) return `${match[1].toLowerCase()}.rom`;
  // Preserve No-Intro and browser-generated names such as:
  // ST010 (Japan, USA) (Enhancement Chip) (2).zip.  Parenthetical region,
  // language, revision and duplicate suffixes are metadata, not identities.
  if (!/^\s*(?:\([^()]*\)\s*)+$/.test(match[2]) || !/\(\s*enhancement chip\s*\)/i.test(suffix)) return null;
  return `${match[1].toLowerCase()}.rom`;
}

// No-Intro distributes enhancement-chip firmware as a ZIP whose one `.bin`
// member keeps the same human-readable archive stem (for example
// `CX4 (World) (Enhancement Chip).zip`). Recognize that container before the
// generic single-ROM ZIP path can mistake `.bin` for a Mega Drive cartridge.
// The uploaded file and its member are never renamed; only the private,
// manifest-facing copy receives the stable cx4.rom/dspN.rom/stNNN.rom slot.
async function extractSNESCoprocessorFirmwareFromZIP(file, originalName) {
  if (extension(originalName) !== "zip") return null;
  const outerFirmware = snesCoprocessorFirmwareNameFromArchiveLabel(originalName);
  if (!outerFirmware) return null;
  const entries = (await readZIPCentralDirectory(file)).filter(entry => !isZIPMetadataEntry(entry));
  if (entries.length !== 1) throw new Error("Super NES 增强芯片固件 ZIP 必须只包含一个固件文件。");
  const entry = entries[0];
  const innerFirmware = snesCoprocessorFirmwareNameFromArchiveLabel(path.posix.basename(entry.name));
  if (innerFirmware !== outerFirmware || !["bin", "rom"].includes(extension(entry.name))) {
    throw new Error("Super NES 增强芯片固件 ZIP 的外层名称与内部固件名称不一致。");
  }
  const specification = SNES_COPROCESSOR_FIRMWARE.get(outerFirmware);
  if (entry.bytes !== specification.bytes) {
    throw new Error(`${path.basename(originalName)} 内的 ${path.posix.basename(entry.name)} 必须是精确 ${specification.bytes} 字节。`);
  }
  const data = await extractZIPEntry(file, entry, {
    maximumBytes: specification.bytes,
    purpose: "Super NES 协处理器固件"
  });
  return { name: outerFirmware, originalName: path.basename(originalName), memberName: path.posix.basename(entry.name), data };
}

async function validateNeoGeoBIOSArchive(file) {
  const info = await fsp.stat(file);
  if (!info.isFile() || info.size <= 0 || info.size > MAX_NEOGEO_BIOS_BYTES) {
    throw new Error("Neo Geo BIOS 必须是 16 MB 以内的普通 ZIP 文件。");
  }
  const entries = await readZIPCentralDirectory(file);
  // Every known main BIOS image present is fully extracted and CRC-checked,
  // exactly as the core will do before booting the one it prefers.
  const mainImages = NEOGEO_MAIN_BIOS_IMAGES.filter(image =>
    entries.some(item => item.bytes === image.bytes && item.crc32 === image.crc32));
  if (mainImages.length === 0) {
    throw new Error(
      "neogeo.zip 缺少主 CPU BIOS：需要 MAME neogeo/aes 表中的任意一个系统 ROM"
      + "（例如 sp-s2.sp1，CRC32 9036d879，或 uni-bios_4_0.rom，CRC32 a7aab458）。"
    );
  }
  for (const image of mainImages) {
    const entry = entries.find(item => item.bytes === image.bytes && item.crc32 === image.crc32);
    await extractZIPEntry(file, entry, { maximumBytes: image.bytes, purpose: "Neo Geo BIOS" });
  }
  for (const expected of NEOGEO_BIOS_COMPONENTS) {
    const entry = entries.find(item => item.bytes === expected.bytes && item.crc32 === expected.crc32);
    if (!entry) {
      throw new Error(`neogeo.zip 缺少 ${expected.name}（${expected.role}，CRC32 ${expected.crc32}）。`);
    }
    await extractZIPEntry(file, entry, { maximumBytes: expected.bytes, purpose: "Neo Geo BIOS" });
  }
  return { ...(await hashFile(file)), mainImages: mainImages.map(image => image.option) };
}

async function validatePGMBIOSArchive(file) {
  const info = await fsp.stat(file);
  if (!info.isFile() || info.size <= 0 || info.size > MAX_PGM_BIOS_BYTES) {
    throw new Error("PGM BIOS 必须是 16 MB 以内的普通 ZIP 文件。");
  }
  const entries = await readZIPCentralDirectory(file);
  for (const expected of PGM_BIOS_COMPONENTS) {
    const entry = entries.find(item => item.bytes === expected.bytes && item.crc32 === expected.crc32);
    if (!entry) {
      throw new Error(`pgm.zip 缺少 ${expected.name}（${expected.role}，CRC32 ${expected.crc32}）。`);
    }
    await extractZIPEntry(file, entry, { maximumBytes: expected.bytes, purpose: "PGM BIOS" });
  }
  return hashFile(file);
}






async function detectCPS2KeyInArchive(file, system, driver) {
  const metadata = cps2DriverMetadata(system, driver);
  if (!metadata) return { required: false, hex: null, source: null, status: "not-required" };
  if (extension(file) !== "zip") return { required: true, hex: null, source: null, status: "manual-required" };
  const entries = await readZIPCentralDirectory(file);
  const expectedName = metadata.name.toLowerCase();
  const namedEntry = entries.find(entry => path.basename(entry.name).toLowerCase() === expectedName);
  if (namedEntry && (namedEntry.bytes !== 20 || namedEntry.crc32 !== metadata.crc32)) {
    throw new Error(`ROM 内的 ${metadata.name} 与驱动 ${driver} 不匹配。`);
  }
  const matching = entries.find(entry => entry.bytes === 20 && entry.crc32 === metadata.crc32 && entry.name.toLowerCase().endsWith(".key"));
  if (!matching) return { required: true, hex: null, source: null, status: "missing" };
  const key = await extractZIPEntry(file, matching);
  return { required: true, hex: key.toString("hex"), source: "archive", status: "archive" };
}

async function availableCPS2KeyForROM(file, system, driver) {
  const archived = await detectCPS2KeyInArchive(file, system, driver);
  if (!archived.required || archived.hex) {
    // Every path that discovers a key runs through here, so this is where the
    // server table learns one. A failure to record it must not fail the
    // upload: the key is already in hand for this ROM either way.
    if (archived.hex) {
      try { await rememberCPS2Key(system, driver, archived.hex); }
      catch (error) { console.warn(`无法记录 CPS2 key（${driver}）：${error.message}`); }
    }
    return archived;
  }
  const bundled = bundledCPS2KeyHex(system, driver);
  if (!bundled) return archived;
  return { required: true, hex: bundled, source: "manual", status: "builtin" };
}

async function resolvedManifestCPS2Key(manifest, romPath) {
  const driver = manifest.rom?.driver || ((manifest.system === "arcade" || manifest.system === "neoGeo") ? baseName(romPath) : null);
  const metadata = cps2DriverMetadata(manifest.system, driver);
  const declaration = manifest.emulation?.cps2Key;
  if (!metadata) {
    if (declaration) throw new Error("该 ROM 驱动不需要 CPS2 key，请移除 manifest.json 中的 emulation.cps2Key。 ");
    return { required: false, hex: null, source: null, status: "not-required", driver };
  }
  let configuredHex = null;
  if (declaration) {
    if (declaration.format !== "cps2-key-20") throw new Error("CPS2 key format 必须为 cps2-key-20。 ");
    if (declaration.source != null && !["archive", "manual"].includes(declaration.source)) throw new Error("CPS2 key source 只能是 archive 或 manual。 ");
    configuredHex = validateCPS2KeyHex(declaration.hex, manifest.system, driver);
  }
  const archived = await detectCPS2KeyInArchive(romPath, manifest.system, driver);
  if (configuredHex && archived.hex && configuredHex !== archived.hex) {
    throw new Error("ROM 压缩包内的 CPS2 key 与 manifest.json 不一致。 ");
  }
  const bundled = bundledCPS2KeyHex(manifest.system, driver);
  const hex = configuredHex || archived.hex || bundled;
  const configuredStatus = archived.hex ? "verified" : (configuredHex === bundled ? "builtin" : "manifest");
  return {
    required: true,
    hex,
    source: configuredHex ? (declaration.source || "manual") : (archived.source || (bundled ? "manual" : null)),
    status: configuredHex ? configuredStatus : (archived.hex ? archived.status : (bundled ? "builtin" : archived.status)),
    driver
  };
}







async function validateROMFile(file, fileName, system, details) {
  const auxiliary = auxiliaryROMReason(fileName, details);
  if (auxiliary) {
    throw new Error(`${fileName} 是${auxiliary}，不是游戏 ROM；请使用管理页对应的 BIOS / 系统文件入口。`);
  }
  const bytes = Number(details?.bytes) || (await fsp.stat(file)).size;
  if (system === "nes") {
    if (["fds", "qd"].includes(extension(fileName))) {
      await validateFDSImage(file, fileName);
      return;
    }
    const header = await readFileRange(file, 16);
    if (header.toString("ascii", 0, 4) !== "NES\x1a") throw new Error("NES ROM 缺少有效的 iNES/NES 2.0 文件头。 ");
    const minimum = 16 + (header[6] & 4 ? 512 : 0) + header[4] * 16_384 + header[5] * 8_192;
    if (header[4] === 0 || bytes < minimum) throw new Error("NES ROM 的 PRG/CHR 数据不完整，拒绝导入。 ");
    return;
  }
  if (system === "snes") {
    await analyzeSNESROM(file);
    return;
  }
  if (system === "megaDrive") {
    if (bytes < 512 || bytes > 0x400000 + 512 || (bytes & 1) !== 0) {
      throw new Error("Mega Drive ROM 大小超出核心支持范围或不是偶数字节。");
    }
    const probe = await readFileRange(file, Math.min(bytes, 0x4200));
    const ascii = offset => probe.length >= offset + 4 && probe.toString("ascii", offset, offset + 4);
    let linearBytes = 0;
    if (ascii(0x100) === "SEGA" || ascii(0x100) === "ESAG") {
      linearBytes = bytes;
    } else if (bytes > 512 && ascii(0x300) === "SEGA") {
      linearBytes = bytes - 512;
    } else if (bytes > 512 && (bytes - 512) % 0x4000 === 0 && probe.length > 512 + 0x2081 &&
               probe[512 + 0x2080] === 0x53 && probe[512 + 0x80] === 0x45 &&
               probe[512 + 0x2081] === 0x47 && probe[512 + 0x81] === 0x41) {
      linearBytes = bytes - 512;
    } else {
      const half = bytes / 2;
      const upper = await readFileRange(file, 2, half + 0x80);
      const split = upper.length === 2 && upper[0] === 0x53 && probe[0x80] === 0x45 &&
        upper[1] === 0x47 && probe[0x81] === 0x41;
      if (split) linearBytes = bytes;
    }
    if (!linearBytes || linearBytes > 0x400000 || (linearBytes & 1) !== 0) {
      throw new Error("Mega Drive ROM 缺少可识别的 SEGA 卡带头，或者排列格式不受核心支持。");
    }
    return;
  }
  if (system === "sega32x") {
    // A 32X cartridge is a linear Mega Drive ROM (header at 0x100), run through
    // the adapter; the only extra requirement over a Mega Drive ROM is the
    // "SEGA 32X" marker, with a tolerated 512-byte copier header.
    if (bytes < 512 || bytes > 0x400000 + 512 || (bytes & 1) !== 0) {
      throw new Error("32X ROM 大小超出核心支持范围或不是偶数字节。");
    }
    const probe = await readFileRange(file, Math.min(bytes, 0x410));
    const marker = Sega32X.SEGA32X_CARTRIDGE_HEADER;
    const header = offset => probe.length >= offset + marker.length && probe.toString("latin1", offset, offset + marker.length) === marker;
    const linearBytes = header(0x100) ? bytes : (bytes > 512 && header(0x300) ? bytes - 512 : 0);
    if (!linearBytes || linearBytes > 0x400000 || (linearBytes & 1) !== 0) {
      throw new Error("32X ROM 缺少 \"SEGA 32X\" 卡带头，或者排列格式不受核心支持。");
    }
    return;
  }
  if (system === "playStation") {
    // The package rules FCPS1Disc.c enforces, the canonical form, and a data
    // first track.
    await PS1.validatePS1PackageFile(file);
    return;
  }
  if (system === "megaCD") {
    // The same package rules under FCMCDPK1, and a Mega CD system area.
    await MegaCD.validateMegaCDPackageFile(file);
    return;
  }
  if (system === "pcEngineCD") {
    // The same package rules under FCPCDPK1, and the System Card's boot record.
    await PCECD.validatePCECDPackageFile(file);
    return;
  }
  if (system === "pcEngine") {
    // A program at the reset vector, not a System Card (FCPCECoreC's loading rules).
    await PCE.validatePCEROMFile(file);
    return;
  }
  if (system === "gameBoyAdvance") {
    // The fixed $96 at $b2 and a header checksum that holds, as the core's
    // fc_gba_cartridge_inspect; the save chip comes from the SDK ID string.
    await validateGBAROMFile(file);
    return;
  }
  if (GAME_BOY_SYSTEMS.has(system)) {
    // Whole 16 KiB banks, a cartridge controller the core runs, a header
    // whose checksum holds, and the right console for the CGB flag.
    if (bytes < 32 * 1024 || bytes > MAX_GAME_BOY_ROM_BYTES || bytes % 0x4000 !== 0) {
      throw new Error("Game Boy ROM 大小必须是 32 KiB 到 8 MiB 之间的整 16 KiB 倍数。");
    }
    const header = await readFileRange(file, 0x150);
    let checksum = 0;
    for (let offset = 0x134; offset <= 0x14c; offset++) checksum = (checksum - header[offset] - 1) & 0xff;
    if (checksum !== header[0x14d]) throw new Error("Game Boy ROM 卡带头校验和不符，不是完整的卡带镜像。");
    if (!GAME_BOY_CARTRIDGE_TYPES.has(header[0x147])) {
      throw new Error(`Game Boy 卡带类型 0x${header[0x147].toString(16).padStart(2, "0")} 暂不支持。`);
    }
    if (system === "gameBoy" && header[0x143] === 0xc0) throw new Error("这是 Game Boy Color 专用卡带，不能按 Game Boy 导入。");
    if (system === "gameBoyColor" && !(header[0x143] & 0x80)) throw new Error("这张卡带不支持 Game Boy Color，请按 Game Boy 导入。");
    return;
  }
  if (system === "masterSystem" || system === "gameGear") {
    // Whole 16 KiB pages (the last one may be short on small homebrew), an
    // optional 512-byte copier header, and a program rather than a blank
    // chip: Mark III titles ship without the "TMR SEGA" header, so its
    // absence is not refused.
    const label = system === "gameGear" ? "Game Gear" : "Master System";
    if (bytes < 1024 || bytes > MAX_SEGA8_ROM_BYTES) {
      throw new Error(`${label} ROM 大小超出核心支持范围。`);
    }
    const probe = await readFileRange(file, Math.min(bytes, 0x8000));
    const headerOffset = bytes % 0x4000 === 512 ? 512 : 0;
    const distinct = new Set(probe.subarray(headerOffset, headerOffset + Math.min(1024, probe.length - headerOffset)));
    if (distinct.size < 8) {
      throw new Error(`${label} ROM 开头 1 KiB 没有程序代码，拒绝导入。`);
    }
    const headerAt = [0x7ff0, 0x3ff0, 0x1ff0].map(offset => offset + headerOffset)
      .find(offset => probe.length >= offset + 16 && probe.toString("ascii", offset, offset + 8) === "TMR SEGA");
    if (headerAt !== undefined) {
      const regionCode = probe[headerAt + 15] >> 4;
      if (system === "gameGear" ? regionCode < 3 || regionCode > 7 : regionCode !== 3 && regionCode !== 4) {
        throw new Error(`${label} ROM 的 TMR SEGA 头声明了别的主机（地区码 ${regionCode}）。`);
      }
    }
    return;
  }
  if (system === "sg1000") {
    // An SG-1000 cartridge is a raw Z80 program, no "TMR SEGA" header; it runs
    // on the Sega 8-bit core's Mark III model. Just a plausible size and real
    // code at the reset vectors.
    if (bytes < 1024 || bytes > MAX_SEGA8_ROM_BYTES) {
      throw new Error("SG-1000 ROM 大小超出核心支持范围。");
    }
    const probe = await readFileRange(file, Math.min(bytes, 1024));
    if (new Set(probe).size < 8) {
      throw new Error("SG-1000 ROM 开头 1 KiB 没有程序代码，拒绝导入。");
    }
    return;
  }
  if (system === "wonderSwan") {
    // A WonderSwan / WonderSwan Color cartridge is a raw word-swapped ROM with
    // no leading header; its 16-byte internal header is a footer at the ROM
    // end (word[-5] high byte is the color flag the core reads). The core
    // (fc_ws_load_rom) requires a power-of-two image of at least 64 KiB, so
    // check that and that the footer's save-type byte is one the core knows.
    if (bytes < 0x10000 || bytes > MAX_WONDERSWAN_ROM_BYTES || (bytes & (bytes - 1)) !== 0) {
      throw new Error("WonderSwan ROM 大小不是核心支持的 2 的幂（至少 64 KiB）。");
    }
    // A blank or erased chip has no real code: WonderSwan ROMs may begin with
    // fill (Mr. Driller's first KiB is one repeated byte), so the footer, not
    // the head, carries the identity. Require a non-uniform footer and a
    // save-type byte the core decodes (word[-3] high byte = footer byte 11;
    // FCWonderSwanCoreC fc_ws_load_rom's switch).
    const footer = await readFileRange(file, 16, bytes - 16);
    if (new Set(footer).size < 2) {
      throw new Error("WonderSwan ROM 页脚全为同一字节（空白卡），拒绝导入。");
    }
    if (![0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x10, 0x20, 0x50].includes(footer[11])) {
      throw new Error("WonderSwan ROM 页脚的存档类型字节无效，拒绝导入。");
    }
    return;
  }
  if (system === "neoGeoPocket") {
    // A Neo Geo Pocket / Color cartridge is a raw Toshiba-flash image with
    // SNK's 28-byte license string at offset 0 ("COPYRIGHT BY SNK CORPORATION"
    // or " LICENSED BY SNK CORPORATION"). The core (fc_ngp_load_rom) accepts
    // only a fixed set of mask sizes and masks the cart to 4 MiB, so check the
    // size is one it loads and the header carries SNK's mark (which also
    // refuses a blank 0xFF chip). The color flag (byte 0x23) is the core's
    // concern; the server catalogs .ngp and .ngc as one system.
    if (!NeoGeoPocket.NEOGEOPOCKET_ROM_BYTES.has(bytes)) {
      throw new Error("Neo Geo Pocket ROM 大小不是核心支持的掩码尺寸（32 KiB 或 512 KiB / 1 / 2 / 4 MiB）。");
    }
    const header = await readFileRange(file, 28, 0);
    if (!NeoGeoPocket.neoGeoPocketCartridgeHeaderValid(header)) {
      throw new Error("Neo Geo Pocket ROM 开头没有 SNK 版权标识（空白卡或非 NGP ROM），拒绝导入。");
    }
    return;
  }
  const ext = extension(fileName);
  if (ext === CPS3.CPS3_PACKAGE_EXTENSION) {
    // Header and sizes only; the CRC over ~50 MB is checked on install and in a full audit.
    const parsed = await CPS3.readCPS3Package(file);
    if (!parsed.driver) throw new Error("CPS3 游戏包里的 BIOS 不属于已知的 CPS3 驱动。");
    return;
  }
  const prefix = await readFileRange(file, 8);
  // The floor turns away blank or truncated uploads, but the early boards'
  // sets are genuinely small (invaders is 5 KB, pacman 11 KB): an archive
  // whose chips identify a supported driver by size and CRC32 is complete by
  // that test, so only an unidentified (or unreadable) small archive is refused.
  const minimumArchiveBytes = 64 * 1024;
  const identifiedArcade = bytes < minimumArchiveBytes
    ? await identifyArcadeArchive(file, fileName).catch(() => null)
    : null;
  const hasNeoGeoCartridgeLayout = bytes < minimumArchiveBytes && ext === "zip"
    ? await looksLikeNeoGeoArchive(file).catch(() => false)
    : false;
  if (bytes < minimumArchiveBytes && !identifiedArcade?.driver && !hasNeoGeoCartridgeLayout) {
    throw new Error(`压缩 ROM 仅 ${Math.max(1, Math.round(bytes / 1024))} KB，明显小于可用的 Neo Geo/Arcade ROM 集。`);
  }
  if (ext === "zip") {
    if (prefix.readUInt32LE(0) !== 0x04034b50) throw new Error("ROM 压缩包不是有效的 ZIP 文件。 ");
    const tailLength = Math.min(bytes, 66_000);
    const tail = await readFileRange(file, tailLength, bytes - tailLength);
    const eocd = zipEndOfCentralDirectory(tail);
    if (eocd < 0) throw new Error("ZIP ROM 缺少中央目录，文件可能未下载完整。 ");
    const entries = tail.readUInt16LE(eocd + 10);
    if (entries < 2) throw new Error("ZIP ROM 内没有足够的游戏芯片文件，拒绝导入。 ");
    return;
  }
  if (ext === "7z") {
    if (!prefix.subarray(0, 6).equals(Buffer.from([0x37, 0x7a, 0xbc, 0xaf, 0x27, 0x1c]))) throw new Error("ROM 压缩包不是有效的 7z 文件。 ");
    return;
  }
  throw new Error("不支持的 ROM 文件格式。 ");
}

async function copyIfAbsent(source, destination) {
  await fsp.mkdir(path.dirname(destination), { recursive: true });
  try { await fsp.access(destination); }
  catch { await fsp.copyFile(source, destination); }
}

async function moveOrCopy(source, destination) {
  await fsp.mkdir(path.dirname(destination), { recursive: true });
  try { await fsp.rename(source, destination); }
  catch (error) {
    if (error.code !== "EXDEV") throw error;
    await fsp.copyFile(source, destination); await fsp.unlink(source);
  }
}

function atomicJSON(file, object) {
  return writeJSONAtomic(file, object);
}

function defaultCatalog() {
  const createdAt = now();
  return {
    schemaVersion: 1, createdAt, updatedAt: createdAt,
    settings: { title: DEFAULT_LIBRARY_TITLE, sourceDirectory: process.env.FC_LIBRARY_SOURCE_DIRECTORY || "", preferredSearchSites: DEFAULT_PREFERRED_SEARCH_SITES, preferredSearchSitesVersion: PREFERRED_SEARCH_SITES_VERSION, coverDirectory: "", autoMatchThreshold: 0.88 },
    games: [], collections: []
  };
}

function createService(options = {}) {
  const dataRoot = path.resolve(options.dataRoot || process.env.FC_LIBRARY_DATA_DIR || path.join(__dirname, "data"));
  const automaticCoverScanVersion = Math.max(0, Math.trunc(Number(
    Object.hasOwn(options, "automaticCoverScanVersion")
      ? options.automaticCoverScanVersion
      : process.env.FC_LIBRARY_AUTOMATIC_COVER_SCAN_VERSION
  ) || 0));
  // Whether a game that joins the library without going through the upload
  // page (a script calling addROMToCanonicalLibrary, a CPS3 install) is
  // researched too, and whether a start-up sweeps the games that never were.
  // The packages turn it on; tests leave it off so nothing reaches the web.
  const automaticResearchEnabled = Object.hasOwn(options, "automaticResearch")
    ? Boolean(options.automaticResearch)
    : process.env.FC_LIBRARY_AUTOMATIC_RESEARCH === "1";
  // Tests substitute small fixtures for the real split-clone chip records.
  const neoGeoSplitSets = options.neoGeoSplitSets || NEOGEO_SPLIT_SETS;
  // ...and for the arcade dumps that lack a shared device ROM.
  const arcadeDeviceROMSets = options.arcadeDeviceROMSets || ARCADE_DEVICE_ROM_SETS;
  const arcadeDeviceROMArchives = options.arcadeDeviceROMArchives || ARCADE_DEVICE_ROM_ARCHIVES;
  const publicRoot = path.join(__dirname, "public");
  const paths = {
    dataRoot, publicRoot,
    catalog: path.join(dataRoot, "catalog.json"),
    uploads: path.join(dataRoot, "uploads"),
    managedROMs: path.join(dataRoot, "managed", "roms"),
    managedArtwork: path.join(dataRoot, "managed", "artwork"),
    managedBIOS: path.join(dataRoot, "managed", "bios"),
    managedNeoGeoBIOS: path.join(dataRoot, "managed", "bios", "neogeo.zip"),
    managedFDSBIOS: path.join(dataRoot, "managed", "bios", "disksys.rom"),
    managedGBABIOS: path.join(dataRoot, "managed", "bios", GBA_BIOS_NAME),
    managedPGMBIOS: path.join(dataRoot, "managed", "bios", "pgm.zip"),
    managedSNESIPL: path.join(dataRoot, "managed", "bios", "spc700.rom"),
    saves: path.join(dataRoot, "saves"),
    dropbox: path.join(dataRoot, "dropbox"),
    credentials: path.join(dataRoot, "credentials.json"),
    tasks: path.join(dataRoot, "background-tasks.json"),
    researchCache: path.join(dataRoot, "rom-research-cache.json"),
    coverIndexCache: path.join(dataRoot, "cover-index-cache"),
    sourceListCache: path.join(dataRoot, "source-list-cache.json"),
    // One preview directory per data root: initialize() empties it, and two
    // services sharing one (the test files, which node --test runs as
    // parallel processes) deleted each other's previews mid-download.
    webCoverTemp: path.join(os.tmpdir(), "FCEmulatorLibraryServer",
      `web-cover-previews-${crypto.createHash("sha256").update(dataRoot).digest("hex").slice(0, 16)}`),
    exportParent: path.join(dataRoot, "export"),
    exportRoot: path.join(dataRoot, "export", "FCEmulatorLibrary")
  };
  let catalog = defaultCatalog();
  let coverCandidates = [];
  const webCoverSearches = new Map();
  const archiveIndexes = new Map();
  const libretroIndexes = new Map();
  const webSearchRuns = new Map();
  const webSearchDiagnostics = new Map();
  const automaticResearch = new Map();
  const backgroundTasks = new Map();
  const pendingBackgroundTasks = [];
  /* Running tasks per lane. A CPS-3 install holds its lane for up to an
   * hour, so it has a lane of its own rather than stalling uploads' research
   * behind it in the shared one. */
  const activeBackgroundTasks = new Map();
  let sourceRevision = 1;
  let sourceListCache = null;
  let sourceHealthCache = null;
  /* BIOS and firmware are verified when they arrive, not on every page view:
   * see lib/verified-files.js. Library reads (which publish the root BIOS
   * declarations) and the status endpoints both go through these, so a GET
   * hashes a file only if it changed since it was last verified. */
  const verifiedFiles = createVerifiedFiles({ file: path.join(dataRoot, "verified-files.json") });
  const verifiedNeoGeoBIOS = file => verifiedFiles.verified("neogeo-bios", file, () => validateNeoGeoBIOSArchive(file));
  const verifiedPGMBIOS = file => verifiedFiles.verified("pgm-bios", file, () => validatePGMBIOSArchive(file));
  const verifiedGBABIOS = file => verifiedFiles.verified("gba-bios", file, () => validateGBABIOSFile(file));
  const verifiedFDSBIOS = file => verifiedFiles.verified("fds-bios", file, () => validateFDSBIOSFile(file));
  const verifiedPS1BIOS = file => verifiedFiles.verified("ps1-bios", file, () => PS1.validatePS1BIOSFile(file));
  const verifiedMegaCDBIOS = file => verifiedFiles.verified("megacd-bios", file, () => MegaCD.validateMegaCDBIOSFile(file));
  const verifiedSega32XBIOS = file => verifiedFiles.verified("sega32x-bios", file, () => Sega32X.validateSega32XBIOSFile(file));
  const verifiedNeoGeoPocketBIOS = file => verifiedFiles.verified("neogeopocket-bios", file, () => NeoGeoPocket.validateNeoGeoPocketBIOSFile(file));
  const verifiedNeoGeoPocketNVRAM = file => verifiedFiles.verified("neogeopocket-nvram", file, () => NeoGeoPocket.validateNeoGeoPocketNVRAMFile(file));
  const verifiedPCECDSystemCard = file => verifiedFiles.verified("pcecd-syscard", file, () => PCECD.validatePCECDSystemCardFile(file));
  let researchCache = { bySHA256: {}, byCRC32: {} };
  let researchCacheWrite = Promise.resolve();
  // `deepSeekKeyOverride` is a test seam only (like `fetchRemoteHTML`,
  // `fetchRemoteJSON` and `preferredCoverProviders`): a string, "" included, forces the configured
  // key so a test can exercise the no-key fallback on a machine that has a
  // real key in the environment or Keychain. Production never passes it.
  let deepSeekKey = typeof options.deepSeekKeyOverride === "string"
    ? options.deepSeekKeyOverride
    : runtimeSecret("DEEPSEEK_API_KEY", "FCEmulatorLibraryServer.DeepSeek");
  let deepSeekKeySource = process.env.DEEPSEEK_API_KEY ? "环境变量" : (deepSeekKey ? "macOS Keychain" : "未配置");
  let managementToken = String(process.env.FC_LIBRARY_TOKEN || "");
  let writeQueue = Promise.resolve();

  async function initialize() {
    await fsp.rm(paths.webCoverTemp, { recursive: true, force: true });
    await Promise.all([paths.uploads, paths.managedROMs, paths.managedArtwork, paths.managedBIOS, paths.saves, paths.dropbox, paths.exportParent, paths.webCoverTemp, paths.coverIndexCache]
      .map(directory => fsp.mkdir(directory, { recursive: true })));
    try { catalog = JSON.parse(await fsp.readFile(paths.catalog, "utf8")); }
    catch (error) { if (error.code !== "ENOENT") throw error; await save(); }
    catalog.games ||= []; catalog.collections ||= []; catalog.settings ||= defaultCatalog().settings;
    catalog.settings.sourceDirectory ??= process.env.FC_LIBRARY_SOURCE_DIRECTORY || "";
    let upgradedBrandTitle = false;
    if (!String(catalog.settings.title || "").trim() || catalog.settings.title === LEGACY_DEFAULT_LIBRARY_TITLE) {
      catalog.settings.title = DEFAULT_LIBRARY_TITLE;
      upgradedBrandTitle = true;
    }
    catalog.settings.preferredSearchSites = normalisePreferredSearchSites(catalog.settings.preferredSearchSites?.length ? catalog.settings.preferredSearchSites : DEFAULT_PREFERRED_SEARCH_SITES);
    let upgradedPreferredSearchSites = false;
    if ((Number(catalog.settings.preferredSearchSitesVersion) || 1) < PREFERRED_SEARCH_SITES_VERSION) {
      catalog.settings.preferredSearchSites = normalisePreferredSearchSites([
        ...catalog.settings.preferredSearchSites, ...ADDED_PREFERRED_SEARCH_SITES_V2
      ]);
      catalog.settings.preferredSearchSitesVersion = PREFERRED_SEARCH_SITES_VERSION;
      upgradedPreferredSearchSites = true;
    }
    if (String(catalog.settings.sourceDirectory || "").trim()) {
      try {
        const root = path.resolve(catalog.settings.sourceDirectory);
        const indexPath = path.join(root, "library.json");
        if (upgradedBrandTitle) {
          const index = JSON.parse(await fsp.readFile(indexPath, "utf8"));
          if (!String(index.title || "").trim() || index.title === LEGACY_DEFAULT_LIBRARY_TITLE) {
            index.title = DEFAULT_LIBRARY_TITLE;
            await writeCanonicalIndex(indexPath, index);
          }
        }
        const [stored, indexStat] = await Promise.all([fsp.readFile(paths.sourceListCache, "utf8").then(JSON.parse), fsp.stat(indexPath)]);
        const indexSignature = `${indexStat.size}:${indexStat.mtimeMs}`;
        if (stored.directory === root && stored.indexSignature === indexSignature && Array.isArray(stored.value?.roms)) {
          sourceRevision = Math.max(1, Number(stored.revision) || 1);
          stored.value.revision = sourceRevision;
          for (const rom of stored.value.roms) rom.automaticResearch = null;
          sourceListCache = { key: `${root}:${sourceRevision}`, value: stored.value };
        }
      } catch (error) { if (error.code !== "ENOENT") console.warn(`无法读取资料库索引快照：${error.message}`); }
    }
    // Keep editable credentials outside catalog.json.  The file is created
    // with mode 0600 only on hosts without a usable macOS Keychain.
    try {
      const credentials = JSON.parse(await fsp.readFile(paths.credentials, "utf8"));
      if (!deepSeekKey && typeof credentials.deepSeekApiKey === "string" && credentials.deepSeekApiKey.trim()) {
        deepSeekKey = credentials.deepSeekApiKey.trim(); deepSeekKeySource = "服务器私有配置";
      }
      if (!managementToken && typeof credentials.managementToken === "string") managementToken = credentials.managementToken.trim();
    } catch (error) { if (error.code !== "ENOENT") console.warn(`无法读取服务器私有配置：${error.message}`); }
    try {
      const persisted = JSON.parse(await fsp.readFile(paths.tasks, "utf8"));
      for (const saved of Array.isArray(persisted.tasks) ? persisted.tasks : []) {
        const item = { ...saved };
        if (item.state === "queued" || item.state === "running") {
          item.state = "failed"; item.completedAt = now(); item.error = "服务重启，任务已中断；可以重新加入队列。"; item.message = item.error;
        }
        backgroundTasks.set(item.id, item);
      }
    } catch (error) { if (error.code !== "ENOENT") console.warn(`无法读取后台任务记录：${error.message}`); }
    try {
      const storedResearch = JSON.parse(await fsp.readFile(paths.researchCache, "utf8"));
      researchCache = { bySHA256: storedResearch.bySHA256 || {}, byCRC32: storedResearch.byCRC32 || {} };
    } catch (error) { if (error.code !== "ENOENT") console.warn(`无法读取 ROM 指纹资料缓存：${error.message}`); }
    // Covers are supplied by explicit upload or the web-search workflow.  Do
    // not scan a host-local artwork library during normal operation.
    coverCandidates = [];
    if (String(catalog.settings.sourceDirectory || "").trim()) {
      try { await repairInterruptedPackageRenames(); }
      catch (error) { console.warn(`无法修复中断的游戏包改名：${error.message}`); }
      try { await reconcileCanonicalArcadeDrivers(); }
      catch (error) { console.warn(`无法核对街机 driver：${error.message}`); }
      try { await reconcileCanonicalArcadeCollections(); }
      catch (error) { console.warn(`无法核对街机自动合集：${error.message}`); }
      // A library written before manufacturerCounts existed gets it once here,
      // in one write (the reconciles above only write when they change a game).
      try { await ensureCanonicalManufacturerCounts(); }
      catch (error) { console.warn(`无法补写厂家游戏数：${error.message}`); }
      try { await reconcileCanonicalPCEHardware(); }
      catch (error) { console.warn(`无法核对 PC Engine 主机：${error.message}`); }
      try { await reconcileCanonicalSNESHardware(); }
      catch (error) { console.warn(`无法核对 Super NES 硬件声明：${error.message}`); }
      // A restart (a package upgrade, say) ends a running CPS-3 install;
      // anything with its BIOS, CD and key and no package yet goes back on
      // its lane rather than waiting for someone to notice.
      startPendingCPS3Installs().catch(error => console.warn(`无法恢复 CPS3 安装：${error.message}`));
    }
    if (upgradedPreferredSearchSites || upgradedBrandTitle) await save();
    if (automaticCoverScanVersion > (Number(catalog.maintenance?.automaticCoverScanVersion) || 0) &&
        String(catalog.settings.sourceDirectory || "").trim()) {
      try { await startAutomaticMissingCoverScan(automaticCoverScanVersion); }
      catch (error) { console.warn(`无法启动升级后的缺失封面扫描：${error.message}`); }
    }
    if (automaticResearchEnabled && String(catalog.settings.sourceDirectory || "").trim()) {
      try { await startUnresearchedSourceScan(); }
      catch (error) { console.warn(`无法启动未识别游戏的补识别：${error.message}`); }
    }
  }

  async function save() {
    catalog.updatedAt = now();
    await atomicJSON(paths.catalog, catalog);
  }

  async function savePrivateCredentials(credentials) {
    await fsp.mkdir(paths.dataRoot, { recursive: true });
    let existing = {};
    try { existing = JSON.parse(await fsp.readFile(paths.credentials, "utf8")); } catch (error) { if (error.code !== "ENOENT") throw error; }
    await writeFileAtomic(paths.credentials, `${JSON.stringify({ ...existing, ...credentials })}\n`, { mode: 0o600 });
  }

  async function configureDeepSeekKey(value) {
    const key = String(value || "").trim();
    if (!key) throw new Error("DeepSeek API Key 不能为空。 ");
    if (key.length < 12 || /[\r\n]/.test(key)) throw new Error("DeepSeek API Key 格式无效。 ");
    // Keychain is preferred on macOS.  NAS/Linux falls back to a mode-0600
    // private file under FC_LIBRARY_DATA_DIR; it is never returned by an API
    // and never mixed into catalog.json or any exported library file.
    if (storeKeychainSecret("FCEmulatorLibraryServer.DeepSeek", key)) {
      await savePrivateCredentials({ deepSeekApiKey: null }); deepSeekKeySource = "macOS Keychain";
    } else {
      await savePrivateCredentials({ deepSeekApiKey: key }); deepSeekKeySource = "服务器私有配置";
    }
    deepSeekKey = key;
  }

  async function configureManagementToken(value) {
    const token = String(value || "").trim();
    if (token.length < 16 || /[\r\n]/.test(token)) throw new Error("管理 Token 至少需要 16 个字符。 ");
    await savePrivateCredentials({ managementToken: token });
    managementToken = token;
  }

  function publicSettings() {
    return {
      ...catalog.settings,
      deepSeekConfigured: Boolean(deepSeekKey),
      deepSeekKeySource: deepSeekKey ? deepSeekKeySource : "未配置",
      managementTokenConfigured: Boolean(managementToken),
      libraryProtectionEnabled: Boolean(managementToken && process.env.FC_LIBRARY_PROTECT_LIBRARY === "1")
    };
  }

  function serializedCatalog() {
    return {
      ...catalog, settings: publicSettings(),
      exportURL: "/library/library.json",
      exportDirectory: paths.exportRoot,
      coverCandidateCount: coverCandidates.length,
      games: catalog.games.map(game => {
        const driver = game.arcadeDriver || ((game.system === "arcade" || game.system === "neoGeo") ? baseName(game.originalName) : null);
        const required = Boolean(cps2DriverMetadata(game.system, driver));
        const hardware = arcadeHardware(game.system, driver);
        return {
          ...game, arcadeDriver: driver, arcadeHardware: hardware?.label || null,
          arcadeHardwareID: hardware?.id || null, cps2KeyRequired: required,
          cps2KeyStatus: required ? (game.cps2Key ? "manual" : "missing") : "not-required",
          coverURL: game.cover ? `/api/games/${encodeURIComponent(game.id)}/cover` : null,
          coverVersion: game.cover?.sha256 || null
        };
      })
    };
  }

  async function withWrite(task, cacheOptions = {}) {
    const mutation = async () => {
      const result = await task();
      sourceRevision++;
      if (sourceListCache && (cacheOptions.preserveSourceList || cacheOptions.sourceROMPatch)) {
        if (cacheOptions.sourceROMPatch) {
          const patch = typeof cacheOptions.sourceROMPatch === "function"
            ? cacheOptions.sourceROMPatch(result) : cacheOptions.sourceROMPatch;
          if (!patch) sourceListCache = null;
          if (patch && sourceListCache) {
            const row = sourceListCache.value.roms.find(rom => String(rom.id) === String(patch.id));
            if (row) Object.assign(row, patch);
            else sourceListCache = null;
          }
        }
        if (sourceListCache) {
          sourceListCache.value.revision = sourceRevision;
          sourceListCache.key = `${sourceListCache.value.directory}:${sourceRevision}`;
        }
      } else sourceListCache = null;
      sourceHealthCache = null;
      await fsp.rm(paths.sourceListCache, { force: true });
      return result;
    };
    const next = writeQueue.then(mutation, mutation);
    writeQueue = next.catch(() => {});
    return next;
  }

  async function scanDirectory(root) {
    const files = [];
    async function visit(directory) {
      for (const entry of await fsp.readdir(directory, { withFileTypes: true })) {
        const item = path.join(directory, entry.name);
        if (entry.isDirectory()) await visit(item);
        else if (entry.isFile() && detectedSystem(entry.name)) files.push(item);
      }
    }
    await visit(root);
    const imported = [];
    const failures = [];
    for (const file of files) {
      try { imported.push(await ingestFile(file, path.basename(file), { skipSave: true })); }
      catch (error) { failures.push({ file: path.relative(root, file), error: error.message || String(error) }); }
    }
    await save();
    return { imported, failures };
  }

  async function scanDropbox() { return scanDirectory(paths.dropbox); }

  async function resolvedSourceDirectory() {
    const configured = String(catalog.settings.sourceDirectory || "").trim();
    if (!configured) throw new Error("请先保存服务器上的导入目录绝对路径。");
    const root = path.resolve(configured);
    const relativeToData = path.relative(paths.dataRoot, root);
    if (!relativeToData.startsWith("..") && !path.isAbsolute(relativeToData)) throw new Error("导入目录不能是服务自身的 data 目录或其子目录。");
    let info;
    try { info = await fsp.stat(root); } catch { throw new Error("导入目录不存在或服务无权读取。"); }
    if (!info.isDirectory()) throw new Error("导入目录必须是文件夹。");
    return root;
  }

  async function listDirectories(requestedPath) {
    const browseRoot = path.resolve(process.env.FC_LIBRARY_DIRECTORY_BROWSE_ROOT || path.parse(paths.dataRoot).root);
    const requested = path.resolve(String(requestedPath || catalog.settings.sourceDirectory || browseRoot));
    const relative = path.relative(browseRoot, requested);
    if (relative.startsWith("..") || path.isAbsolute(relative)) throw new Error("该目录不在允许浏览的范围内。");
    const volumesOnly = String(process.env.FC_LIBRARY_DIRECTORY_BROWSE_VOLUMES_ONLY || "").toLowerCase() === "yes";
    const firstSegment = relative.split(path.sep).filter(Boolean)[0];
    if (volumesOnly && firstSegment && !/^volume\d+$/.test(firstSegment)) {
      throw new Error("在 DSM 中只能浏览存储空间目录（/volume1、/volume2 等）。");
    }
    let info;
    try { info = await fsp.stat(requested); } catch { throw new Error("目录不存在或服务无权读取。"); }
    if (!info.isDirectory()) throw new Error("只能浏览文件夹。");
    const entries = await fsp.readdir(requested, { withFileTypes: true });
    const directories = entries.filter(entry => entry.isDirectory() && !entry.name.startsWith(".")
      && (!volumesOnly || requested !== browseRoot || /^volume\d+$/.test(entry.name))).map(entry => ({ name: entry.name, path: path.join(requested, entry.name) }))
      .sort((left, right) => left.name.localeCompare(right.name, "zh-Hans-CN")).slice(0, 500);
    return { path: requested, parent: requested === browseRoot ? null : path.dirname(requested), directories };
  }

  async function canonicalLibraryIfConfigured() {
    if (!String(catalog.settings.sourceDirectory || "").trim()) return null;
    return configuredCanonicalLibrary();
  }

  function makeServer() { return http.createServer((req, res) => request(req, res)); }
  // The lib/service modules hold parts of this service. `ctx` is what they
  // share with it: values and functions, plus accessors for the mutable
  // state above; each module adds its own functions to ctx for the others.
  const ctx = {
    options, paths, webCoverSearches, archiveIndexes, libretroIndexes, webSearchRuns,
    webSearchDiagnostics, CATEGORIES, IMAGE_EXTENSIONS, arcadeCatalogTitle, arcadeSetName,
    researchAnswerNamesTheSet, categoryForSystem, titleFromFile, normalized,
    containsWordSequence, scoreMatch, decodeHTMLText, libretroThumbnailEntries,
    libretroBoxArtMatches, launchBoxQueries, libretroPlaylists, imageDimensions, safeRemoteURL,
    atomicJSON, verifiedNeoGeoBIOS, verifiedPGMBIOS, verifiedGBABIOS, verifiedFDSBIOS,
    verifiedPS1BIOS, verifiedMegaCDBIOS, verifiedSega32XBIOS, verifiedNeoGeoPocketBIOS,
    verifiedNeoGeoPocketNVRAM, verifiedPCECDSystemCard, SNES_COPROCESSOR_PUBLISHED_NAMES,
    NEOGEO_MAIN_BIOS_IMAGES, neoGeoSplitSets, arcadeDeviceROMSets, arcadeDeviceROMArchives, resolvedSourceDirectory, UNDATED_GAME_ADDED_AT,
    DEFAULT_LIBRARY_TITLE, arcadeHardware, arcadeManufacturer, automaticArcadeCollection,
    AUTOMATIC_ARCADE_COLLECTION_IDS, snesHardwareDeclaration, analyzeSNESROM,
    identifyMAMECapcomArchive, identifyArcadeArchive, arcadeROMFileName, knownArcadeDriverName, unidentifiedArcadeArchiveMessage, arcadeImportFailureMessage, looksLikeNeoGeoArchive, availableCPS2KeyForROM, slug, uniqueID,
    automaticResearchEnabled, BUILT_IN_SNES_IPL, detectedSystem, auxiliaryROMReason, resolveGameBoySystem,
    resolveMegaDriveSystem, safeName, mapperForNESFile, romInfoForNESFile,
    extractSingleConsoleROMFromZIP, validateROMFile, automaticResearch, withWrite,
    ARTWORK_TYPES, stripPlatformTag, mapWithConcurrency, englishROMFileName,
    englishGamePackageID, cps2DriverMetadata, validateCPS2KeyHex, rememberCPS2Key,
    detectCPS2KeyInArchive, resolvedManifestCPS2Key, isArcadeDriverArchive, backgroundTasks,
    save, verifiedFiles, canonicalLibraryIfConfigured, moveOrCopy, PGM_BIOS_COMPONENTS,
    NEOGEO_BIOS_COMPONENTS, validateNeoGeoBIOSArchive, validatePGMBIOSArchive, SNES_IPL_BYTES,
    BUILT_IN_SNES_IPL_SHA256, BUILT_IN_SNES_CX4, BUILT_IN_SNES_CX4_SHA256,
    SNES_COPROCESSOR_FIRMWARE, SNES_COPROCESSOR_FIRMWARE_NAMES, SNES_OWN_DSP_PROGRAMS,
    snesNECDSPFirmwareUploadName, extractSNESCoprocessorFirmwareFromZIP, copyIfAbsent,
    publicRoot, configureDeepSeekKey, configureManagementToken, publicSettings,
    serializedCatalog, scanDropbox, listDirectories, SEGA32X_BIOS_MAX_BYTES, NGP_BIOS_MAX_BYTES,
    NGP_NVRAM_MAX_BYTES, MIME_TYPES, MAX_NEOGEO_BIOS_BYTES, SNES_COPROCESSOR_MAX_FIRMWARE_BYTES,
    MAX_PGM_BIOS_BYTES, identifyPGMArchive, pendingBackgroundTasks, activeBackgroundTasks,
    get catalog() { return catalog; }, set catalog(value) { catalog = value; },
    get researchCache() { return researchCache; }, set researchCache(value) { researchCache = value; },
    get researchCacheWrite() { return researchCacheWrite; }, set researchCacheWrite(value) { researchCacheWrite = value; },
    get deepSeekKey() { return deepSeekKey; }, set deepSeekKey(value) { deepSeekKey = value; },
    get sourceRevision() { return sourceRevision; }, set sourceRevision(value) { sourceRevision = value; },
    get sourceListCache() { return sourceListCache; }, set sourceListCache(value) { sourceListCache = value; },
    get sourceHealthCache() { return sourceHealthCache; }, set sourceHealthCache(value) { sourceHealthCache = value; },
    get coverCandidates() { return coverCandidates; }, set coverCandidates(value) { coverCandidates = value; },
    get managementToken() { return managementToken; }, set managementToken(value) { managementToken = value; }
  };
  const webResearch = createWebResearch(ctx);
  Object.assign(ctx, webResearch);
  const {
    normalisePreferredSearchSites, directPreferredCoverCandidates, createWebCoverSearch
  } = webResearch;
  const biosDeclarations = createBIOSDeclarations(ctx);
  Object.assign(ctx, biosDeclarations);
  const canonicalLibrary = createCanonicalLibrary(ctx);
  Object.assign(ctx, canonicalLibrary);
  const {
    writeCanonicalIndex, configuredCanonicalLibrary, ensureCanonicalManufacturerCounts,
    reconcileCanonicalArcadeCollections, repairInterruptedPackageRenames,
    reconcileCanonicalPCEHardware, reconcileCanonicalSNESHardware,
    reconcileCanonicalArcadeDrivers
  } = canonicalLibrary;
  const libraryIngest = createLibraryIngest(ctx);
  Object.assign(ctx, libraryIngest);
  const {
    addROMToCanonicalLibraryAndResearch
  } = libraryIngest;
  const sourceLibrary = createSourceLibrary(ctx);
  Object.assign(ctx, sourceLibrary);
  const {
    auditSourceLibrary, listSourceROMs, sourceROMPage, sourceLibraryGame,
    updateSourceLibraryGame, refreshSourceSNESFirmware, migrateSourceCPS2Keys,
    normaliseSourceEnglishName, storeSourceLibraryArtwork
  } = sourceLibrary;
  const sourceAutomation = createSourceAutomation(ctx);
  Object.assign(ctx, sourceAutomation);
  const {
    sourceLogoCandidates, startUnresearchedSourceScan, performAutomaticSourceResearch,
    startAutomaticMissingCoverScan, deleteSourceLibraryGame
  } = sourceAutomation;
  const cps3Service = createCPS3Service(ctx);
  Object.assign(ctx, cps3Service);
  const {
    cps3Status, storeCPS3Upload, setCPS3Key, startPendingCPS3Installs
  } = cps3Service;
  const biosStore = createBIOSStore(ctx);
  Object.assign(ctx, biosStore);
  const {
    neoGeoBIOSStatus, updateNeoGeoBIOSPreference, storeNeoGeoBIOS, pgmBIOSStatus, storePGMBIOS,
    gbaBIOSStatus, storeGBABIOS, ps1BIOSStatus, storePS1BIOS, pceCDBIOSStatus,
    storePCECDSystemCard, megaCDBIOSStatus, storeMegaCDBIOS, sega32xBIOSStatus,
    storeSega32XBIOS, neoGeoPocketBIOSStatus, storeNeoGeoPocketBIOS, neoGeoPocketNVRAMStatus,
    storeNeoGeoPocketNVRAM, fdsBIOSStatus, storeFDSBIOS
  } = biosStore;
  const snesFirmware = createSNESFirmware(ctx);
  Object.assign(ctx, snesFirmware);
  const {
    snesIPLStatus, snesNECDSPFirmwareStatus, snesNECDSPFirmwareStatuses,
    storeSNESNECDSPFirmware, storeSNESCoprocessorFirmwareArchive, storeSNESIPL
  } = snesFirmware;
  const libraryExport = createLibraryExport(ctx);
  Object.assign(ctx, libraryExport);
  const {
    exportLibrary
  } = libraryExport;
  const httpAPI = createHTTPAPI(ctx);
  Object.assign(ctx, httpAPI);
  const {
    request
  } = httpAPI;
  const catalogIngest = createCatalogIngest(ctx);
  Object.assign(ctx, catalogIngest);
  const {
    ingestFile, refreshCoverCandidates, storeArcadeDeviceROMArchive, isArcadeDeviceROMArchiveName
  } = catalogIngest;
  const backgroundTaskQueue = createBackgroundTasks(ctx);
  Object.assign(ctx, backgroundTaskQueue);
  const {
    listBackgroundTasks, flushBackgroundTasks, startBackgroundTask, cancelBackgroundTask
  } = backgroundTaskQueue;
  return { initialize, paths, makeServer, exportLibrary, ingestFile, addROMToCanonicalLibrary: addROMToCanonicalLibraryAndResearch, scanDropbox, get catalog() { return catalog; }, refreshCoverCandidates, serializedCatalog, listSourceROMs, sourceROMPage, sourceLibraryGame, updateSourceLibraryGame, deleteSourceLibraryGame, refreshSourceSNESFirmware, migrateSourceCPS2Keys, reconcileCanonicalArcadeDrivers, reconcileCanonicalArcadeCollections, reconcileCanonicalPCEHardware, reconcileCanonicalSNESHardware, repairInterruptedPackageRenames, storeSourceLibraryArtwork, auditSourceLibrary, createWebCoverSearch, performAutomaticSourceResearch, startAutomaticMissingCoverScan, startUnresearchedSourceScan, directPreferredCoverCandidates, sourceLogoCandidates, startBackgroundTask, cancelBackgroundTask, listBackgroundTasks, flushBackgroundTasks, normaliseSourceEnglishName, neoGeoBIOSStatus, storeNeoGeoBIOS, updateNeoGeoBIOSPreference, fdsBIOSStatus, storeFDSBIOS, gbaBIOSStatus, storeGBABIOS, ps1BIOSStatus, storePS1BIOS, megaCDBIOSStatus, storeMegaCDBIOS, sega32xBIOSStatus, storeSega32XBIOS, neoGeoPocketBIOSStatus, storeNeoGeoPocketBIOS, neoGeoPocketNVRAMStatus, storeNeoGeoPocketNVRAM, pceCDBIOSStatus, storePCECDSystemCard, snesIPLStatus, storeSNESIPL, snesNECDSPFirmwareStatus, snesNECDSPFirmwareStatuses, storeSNESNECDSPFirmware, storeSNESCoprocessorFirmwareArchive, pgmBIOSStatus, storePGMBIOS, storeArcadeDeviceROMArchive, isArcadeDeviceROMArchiveName, cps3Status, storeCPS3Upload, setCPS3Key, startPendingCPS3Installs };
}

function slug(value) {
  const ascii = normalized(value).replace(/\s+/g, "-").replace(/[^\p{L}\p{N}-]/gu, "").slice(0, 48);
  return ascii || "game";
}
function isArcadeDriverArchive(system, fileName) {
  return (system === "neoGeo" || system === "arcade") && (extension(fileName) === "zip" || extension(fileName) === "7z");
}
function uniqueID(candidate, used) { let result = candidate, suffix = 2; const existing = new Set(used); while (existing.has(result)) result = `${candidate}-${suffix++}`; return result; }

async function main() {
  const service = createService(); await service.initialize();
  const port = Number(process.env.FC_LIBRARY_PORT || 8282);
  const host = process.env.FC_LIBRARY_HOST || "0.0.0.0";
  const server = service.makeServer();
  server.listen(port, host, () => {
    console.log(`Retro Console Library Server: http://${host}:${port}`);
    console.log(`资料库导出地址: http://<此服务器IP>:${port}/library/`);
    console.log(`数据目录: ${service.paths.dataRoot}`);
  });
  // A task that finished in the last 100ms is only in memory; the journal
  // write is still a pending timer. Flush it before the process goes away,
  // or a restart forgets the task ever ran.
  for (const signal of ["SIGTERM", "SIGINT"]) {
    process.once(signal, () => {
      server.close();
      service.flushBackgroundTasks().finally(() => process.exit(0));
    });
  }
}

if (require.main === module) main().catch(error => { console.error(error); process.exitCode = 1; });
module.exports = {
  identifyPGMArchive, looksLikeNeoGeoArchive,
  createService, mapperFromHeader, scoreMatch, titleFromFile, stripPlatformTag, launchBoxQueries, noIntroArticleFirst, detectedSystem, auxiliaryROMReason,
  arcadeCatalogTitle, arcadeSetName, researchAnswerNamesTheSet,
  arcadeHardware, arcadeManufacturer, automaticArcadeCollection, categoryForSystem,
  identifyMAMECapcomArchive, identifyArcadeArchive, arcadeROMFileName, knownArcadeDriverName, unidentifiedArcadeArchiveMessage, arcadeImportFailureMessage, portableMAMEArcadeDriver, exactCPS2ArchiveMatch,
  libretroThumbnailEntries, libretroBoxArtMatches, libretroPlaylists,
  isArcadeDriverArchive, imageDimensions, cps1GraphicsNeedOffsets, normalizeCPS2KeyHex,
  validateCPS2KeyHex, detectCPS2KeyInArchive, availableCPS2KeyForROM,
  rememberCPS2Key, cps2KeyCatalogue, validateNeoGeoBIOSArchive,
  validatePGMBIOSArchive,
  validateFDSBIOSFile, validateFDSImage, validatePortableManifestHardware,
  analyzeSNESROM
};
