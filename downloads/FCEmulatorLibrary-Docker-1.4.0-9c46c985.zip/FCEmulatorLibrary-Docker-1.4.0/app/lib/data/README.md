# Legacy CUE encoding indexes

These tables come from the WHATWG Encoding Standard, pinned at commit
`a985b62a9b45c17da3e17a9f0a0b4e30c34c4a8a`:

- [gb18030 index](https://github.com/whatwg/encoding/blob/a985b62a9b45c17da3e17a9f0a0b4e30c34c4a8a/index-gb18030.txt)
- [gb18030 ranges](https://github.com/whatwg/encoding/blob/a985b62a9b45c17da3e17a9f0a0b4e30c34c4a8a/index-gb18030-ranges.txt)
- [JIS0208 index](https://github.com/whatwg/encoding/blob/a985b62a9b45c17da3e17a9f0a0b4e30c34c4a8a/index-jis0208.txt)

`whatwg-encoding-source.json` records each original SHA-256, generated SHA-256,
entry count and conversion. Generation reads the decimal pointer and hexadecimal
Unicode scalar columns of non-comment source lines. Dense tables fill omitted
pointers with -1; range pairs retain their original order. No mapping values
are inferred from a filename or substituted for invalid bytes.

The decoder is this project's independent implementation of the standard's
[gb18030 decoder](https://encoding.spec.whatwg.org/#gb18030-decoder),
[gb18030 range lookup](https://encoding.spec.whatwg.org/#index-gb18030-ranges-code-point),
and [Shift_JIS decoder](https://encoding.spec.whatwg.org/#shift_jis-decoder).
It uses fatal errors for the complete buffer, so error recovery/restored bytes
in the standard never continue after an invalid sequence. It supports GB18030's
Euro byte, four-byte range gap and pointer 7457 exception, and Shift_JIS's
halfwidth katakana and EUDC/PUA window. No ICU, iconv, external process, locale,
network access, or third-party emulator implementation is needed at runtime.

Only these two transport encodings are exposed. UTF-8 and BOM handling remain
with the caller. The input limit is 512 KiB; existing CUE/package limits still
apply separately. Valid control characters are decoded faithfully: the CUE
parser remains responsible for rejecting unsafe text and archive paths.

Copyright © WHATWG (Apple, Google, Mozilla, Microsoft). The pinned upstream
LICENSE states CC-BY-4.0 for the work and BSD-3-Clause for portions incorporated
into source code; these tables are incorporated into the server under that BSD
option. The complete upstream notice and both license texts are included in
`WHATWG-ENCODING-LICENSE.txt`. They are not described as CC0. This project does
not copy third-party decoder or emulator implementation code.
