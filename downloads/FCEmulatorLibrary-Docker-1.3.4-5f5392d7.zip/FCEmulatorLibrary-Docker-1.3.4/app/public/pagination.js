// Page arithmetic for the games list's pagination bar. Pure functions only, so
// the same file runs in the browser (as window.FCPagination) and under
// `node --test` (as a CommonJS module).
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.FCPagination = api;
})(typeof self !== "undefined" ? self : this, () => {
  const PAGE_SIZES = [20, 50, 100, 200];

  // Where an (offset, limit, total) triple sits: 1-based page, page count, and
  // the offset that page starts at. An offset past the end (the list shrank
  // after a delete) lands on the last page.
  function pageInfo(offset, limit, total) {
    const size = Math.max(1, Math.floor(Number(limit)) || 1);
    const count = Math.max(0, Math.floor(Number(total)) || 0);
    const pageCount = Math.ceil(count / size);
    if (!pageCount) return { page: 1, pageCount: 0, offset: 0, limit: size, total: 0 };
    const page = Math.min(pageCount, Math.floor(Math.max(0, Number(offset) || 0) / size) + 1);
    return { page, pageCount, offset: (page - 1) * size, limit: size, total: count };
  }

  // The page buttons to draw: numbers and "gap" markers. The first and last
  // page are always present; `siblings` pages either side of the current one;
  // a gap that would hide a single page shows that page instead. The number of
  // items stays constant once the page count is large, so the bar does not
  // jump around while paging.
  //   pageItems(6, 40) → [1, "gap", 4, 5, 6, 7, 8, "gap", 40]
  function pageItems(current, pageCount, siblings = 2) {
    const last = Math.max(0, Math.floor(pageCount) || 0);
    if (last <= 1) return last ? [1] : [];
    const page = Math.min(last, Math.max(1, Math.floor(current) || 1));
    if (last <= 2 * siblings + 5) return Array.from({ length: last }, (_, index) => index + 1);
    const start = Math.max(2, Math.min(page - siblings, last - 2 * siblings - 2));
    const end = Math.min(last - 1, Math.max(page + siblings, 2 * siblings + 3));
    const items = [1];
    if (start === 3) items.push(2); else if (start > 3) items.push("gap");
    for (let number = start; number <= end; number++) items.push(number);
    if (end === last - 2) items.push(last - 1); else if (end < last - 2) items.push("gap");
    items.push(last);
    return items;
  }

  // A typed "go to page" value, clamped to the real range; null when it is not
  // a number at all.
  function parsePage(value, pageCount) {
    const number = Math.floor(Number(String(value ?? "").trim()));
    if (!String(value ?? "").trim() || !Number.isFinite(number) || pageCount < 1) return null;
    return Math.min(pageCount, Math.max(1, number));
  }

  // A remembered page size, accepted only if it is one the server honours.
  function normalizePageSize(value, fallback = 100) {
    const number = Number(value);
    return PAGE_SIZES.includes(number) ? number : fallback;
  }

  return { PAGE_SIZES, pageInfo, pageItems, parsePage, normalizePageSize };
});
