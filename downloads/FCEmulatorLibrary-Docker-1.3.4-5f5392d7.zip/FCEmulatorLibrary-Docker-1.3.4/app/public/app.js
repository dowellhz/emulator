const t = (source, params = {}) => FCI18n.t(source, params);
function readSessionToken() { try { return sessionStorage.getItem("fc-library-token") || ""; } catch { return ""; } }
function writeSessionToken(token) { try { sessionStorage.setItem("fc-library-token", token); } catch { /* Authentication remains usable in memory when browser storage is blocked. */ } }
const state = { catalog: null, selected: null, token: readSessionToken(), taskRefreshTimer: null, taskSignature: "", sourceRomsSignature: "", sourceRoms: [], selectedSourceIDs: new Set(), sourceOffset: 0, sourceLimit: 100, sourceTotal: 0, sourceRevision: 0 };
const $ = selector => document.querySelector(selector);
FCI18n.setChangeGuard(() => {
  if (state.uploading || state.pendingWrites) { showNotice(t("正在上传或保存，请等待完成后切换语言。"), true); return false; }
  if (document.querySelector("dialog[open]")) { showNotice(t("请先关闭当前窗口，再切换语言。"), true); return false; }
  return true;
});
// The page size is a per-browser convenience; storage may be unavailable.
const PAGE_SIZE_KEY = "fc-library-page-size";
try { state.sourceLimit = FCPagination.normalizePageSize(localStorage.getItem(PAGE_SIZE_KEY), state.sourceLimit); } catch {}
const categoryOptions = ["经典", "动作", "闯关", "射击", "格斗", "体育", "竞速", "益智", "冒险", "角色扮演", "策略", "模拟", "多人", "教育", "街机", "破解", "其他"];

function headers(extra = {}) { return { "Accept-Language": FCI18n.language, ...extra, ...(state.token ? { Authorization: `Bearer ${state.token}` } : {}) }; }
// A read that hangs must not leave the page on "正在读取…": GETs give up
// after this long and say so. Uploads and other writes have no limit.
const READ_TIMEOUT_MS = 20_000;
async function api(url, options = {}) {
  const { timeout = (options.method || "GET") === "GET" ? READ_TIMEOUT_MS : 0, ...fetchOptions } = options;
  const isWrite = !["GET", "HEAD", "OPTIONS"].includes((options.method || "GET").toUpperCase());
  if (isWrite) state.pendingWrites = (state.pendingWrites || 0) + 1;
  const controller = timeout ? new AbortController() : null;
  const timer = controller ? setTimeout(() => controller.abort(), timeout) : null;
  try {
    const response = await fetch(url, { ...fetchOptions, ...(controller ? { signal: controller.signal } : {}), headers: headers(fetchOptions.headers || {}) });
    const value = await response.json().catch(() => ({}));
    if (controller?.signal.aborted) throw new DOMException("timeout", "AbortError");
    if (!response.ok) {
      const error = new Error((value.error ? FCI18n.translateMessage(value.error) : null) || t("请求失败 ({status})", { status: response.status })); error.status = response.status;
      if (value.atariDeclaration) error.atariDeclaration = value.atariDeclaration;
      throw error;
    }
    return value;
  } catch (error) {
    if (controller?.signal.aborted) { const timedOut = new Error(t("服务器 {value1} 秒内没有响应", { value1: Math.round(timeout / 1000) })); timedOut.timeout = true; throw timedOut; }
    throw error;
  } finally { if (timer) clearTimeout(timer); if (isWrite) state.pendingWrites -= 1; }
}
function setStatus(id, message, bad = false) { const node = $(id); node.textContent = FCI18n.translateMessage(message); node.classList.toggle("error", bad); }
function showNotice(message, bad = false) {
  const node = $("#notice"); node.textContent = FCI18n.translateMessage(message); node.hidden = false; node.classList.toggle("error", bad);
  clearTimeout(state.noticeTimer); state.noticeTimer = setTimeout(() => { node.hidden = true; }, bad ? 8_000 : 4_000);
}
function requestAction(message, { heading = t("请确认"), input = false, initial = "", danger = false } = {}) {
  return new Promise(resolve => {
    const dialog = $("#action-dialog"), inputNode = $("#action-input"), confirm = $("#action-confirm"), cancel = $("#action-cancel");
    $("#action-heading").textContent = heading; $("#action-message").textContent = message;
    inputNode.hidden = !input; inputNode.value = initial; confirm.classList.toggle("danger", danger);
    const finish = value => { confirm.onclick = null; cancel.onclick = null; dialog.oncancel = null; dialog.close(); resolve(value); };
    cancel.onclick = () => finish(null); confirm.onclick = () => finish(input ? inputNode.value : true);
    dialog.oncancel = event => { event.preventDefault(); finish(null); };
    dialog.showModal(); if (input) inputNode.focus(); else confirm.focus();
  });
}
function displayName(game) { return FCI18n.language === "en" ? (game.englishTitle || game.title || game.chineseTitle) : (game.chineseTitle || game.title || game.englishTitle); }
function hasImmutableArcadeDriverName(game) { return ["arcade", "neoGeo"].includes(game?.system) && /\.(?:zip|7z)$/i.test(String(game?.originalName || "")); }
function systemLabel(game) {
  if (game?.arcadeHardware) return game.arcadeHardware;
  if (game?.system === "megaDrive") return "Mega Drive";
  if (game?.system === "sega32x") return "32X";
  if (game?.system === "masterSystem") return "Master System";
  if (game?.system === "gameGear") return "Game Gear";
  if (game?.system === "sg1000") return "SG-1000";
  if (game?.system === "gameBoy") return "Game Boy";
  if (game?.system === "gameBoyColor") return "Game Boy Color";
  if (game?.system === "gameBoyAdvance") return "Game Boy Advance";
  if (game?.system === "wonderSwan") return "WonderSwan";
  if (game?.system === "neoGeoPocket") return "Neo Geo Pocket";
  if (game?.system === "pcEngine") return "PC Engine";
  if (game?.system === "pcEngineCD") return "PC Engine CD";
  if (game?.system === "playStation") return "PlayStation";
  if (game?.system === "megaCD") return "Mega CD";
  if (game?.system === "snes") return "Super NES";
  if (game?.system === "neoGeo") return "Neo Geo";
  if (game?.system === "arcade") return "Arcade";
  return game?.system || "ROM";
}
function assetURL(url, version = "") {
  const parameters = [];
  if (state.token) parameters.push(`token=${encodeURIComponent(state.token)}`);
  if (version) parameters.push(`v=${encodeURIComponent(version)}`);
  if (!parameters.length) return url;
  return `${url}${url.includes("?") ? "&" : "?"}${parameters.join("&")}`;
}
function coverVersion(game) { return game?.coverVersion || game?.cover?.sha256 || ""; }
function coverStyle(game) { return game.coverURL ? `background-image:url(${assetURL(game.coverURL, coverVersion(game))})` : ""; }
function formatBytes(bytes) { return bytes > 1024 * 1024 ? `${(bytes / 1024 / 1024).toFixed(1)} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`; }
function selectedAPI(action = "") { const root = state.selected?.sourceID ? `/api/source-roms/${encodeURIComponent(state.selected.sourceID)}` : `/api/games/${encodeURIComponent(state.selected?.id || "")}`; return action ? `${root}/${action}` : root; }
function searchScopeText() { const count = new Set((state.catalog?.settings?.preferredSearchSites || []).map(value => { try { return new URL(value).hostname; } catch { return ""; } }).filter(Boolean)).size; return count ? t("仅搜索已配置的 {count} 个站点", { count: count }) : t("搜索公开网页"); }
function deepSeekReady() { return Boolean(state.catalog?.settings?.deepSeekConfigured); }
function settingsPayload() { return { title: $("#library-title").value, sourceDirectory: $("#source-directory").value, preferredSearchSites: $("#preferred-search-sites").value, deepSeekApiKey: $("#deepseek-api-key").value, managementToken: $("#management-token").value }; }

function normalizedLibraryRootURL(relativeURL) {
  const url = new URL(relativeURL || "/library/", location.origin);
  if (url.pathname.endsWith("/library.json")) url.pathname = url.pathname.slice(0, -"library.json".length);
  if (!url.pathname.endsWith("/")) url.pathname += "/";
  url.search = "";
  url.hash = "";
  return url;
}

function libraryLinkUsesLoopback(url) {
  const host = url.hostname.toLowerCase();
  return host === "localhost" || host === "127.0.0.1" || host === "::1" || host === "[::1]";
}

async function openLibraryLinkDialog(button) {
  button.disabled = true;
  try {
    const result = await api("/api/export", { method: "POST" });
    const rootURL = normalizedLibraryRootURL(result.url);
    $("#library-root-url").value = rootURL.href;
    const status = $("#library-link-status");
    status.classList.toggle("error", libraryLinkUsesLoopback(rootURL));
    status.textContent = libraryLinkUsesLoopback(rootURL)
      ? t("当前管理页使用本机回环地址打开，Apple TV 无法访问。请用 NAS/电脑的局域网 IP 或 .local 主机名打开管理页后重新生成。")
      : t("已生成 {games} 个游戏的资料库根链接。", { games: result.games });
    $("#library-link-auth").textContent = state.catalog?.settings?.libraryProtectionEnabled
      ? t("此服务器已保护资料库：Apple TV 的认证方式请选择 Bearer Token，并单独输入管理 Token。链接本身不会包含或泄露 Token。")
      : t("链接不包含密码或 Token；请只在可信的家庭局域网内使用。");
    $("#library-link-dialog").showModal();
  } catch (error) {
    showNotice(error.message, true);
  } finally {
    button.disabled = false;
  }
}

async function copyLibraryLink() {
  const input = $("#library-root-url");
  try {
    if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(input.value);
    else { input.select(); document.execCommand("copy"); }
    $("#library-link-status").textContent = t("地址已复制，可提交到 Apple TV 的浏览器配置页。");
    $("#library-link-status").classList.remove("error");
  } catch {
    input.select();
    $("#library-link-status").textContent = t("浏览器未允许自动复制；地址已选中，请手动复制。");
  }
}

async function verifyLibraryLink() {
  const button = $("#verify-library-link");
  button.disabled = true;
  try {
    const rootURL = normalizedLibraryRootURL($("#library-root-url").value);
    const index = await api(new URL("library.json", rootURL).href);
    const count = Array.isArray(index.games) ? index.games.length : 0;
    $("#library-link-status").textContent = t("索引验证通过：{count} 个游戏，schemaVersion {schemaVersion}。", { count: count, schemaVersion: index.schemaVersion });
    $("#library-link-status").classList.remove("error");
  } catch (error) {
    $("#library-link-status").textContent = t("索引验证失败：{message}", { message: error.message });
    $("#library-link-status").classList.add("error");
  } finally {
    button.disabled = false;
  }
}

// The games page loads only what it shows: the catalog, the game list, then
// the dashboard (health, tasks, CPS3 installs). The BIOS and firmware cards
// are read when their tab is opened (loadBIOSStatuses), so no status read can
// hold back the game list, and one that fails or hangs marks only its card.
function showLoadFailure(message) {
  const summary = $("#summary");
  summary.textContent = t("读取失败：{message}", { message: message });
  summary.classList.add("error");
  $("#reload").hidden = false;
}
async function load() {
  $("#reload").hidden = true;
  $("#summary").classList.remove("error");
  if (!state.catalog) $("#summary").textContent = t("正在读取…");
  try {
    const catalog = await api("/api/catalog");
    state.catalog = catalog;
    $("#summary").textContent = t("{length} 个游戏", { length: state.catalog.games.length });
    $("#library-title").value = state.catalog.settings.title || "";
    $("#source-directory").value = state.catalog.settings.sourceDirectory || "";
    $("#preferred-search-sites").value = (state.catalog.settings.preferredSearchSites || []).join("\n");
    $("#deepseek-api-key").value = "";
    $("#management-token").value = "";
    $("#management-token-hint").textContent = state.catalog.settings.managementTokenConfigured ? t("管理 Token 已启用；留空保存不会修改。") : t("尚未设置管理 Token；同一局域网内可直接访问管理接口。建议立即设置。");
    $("#deepseek-key-hint").textContent = deepSeekReady()
      ? t("已配置 DeepSeek（{value1}）。留空保存不会覆盖现有 Key；Key 不会显示在浏览器。", { value1: (state.catalog.settings.deepSeekKeySource ? t(state.catalog.settings.deepSeekKeySource) : t("服务器私有配置")) })
      : t("未配置 DeepSeek：上传、校验照常；识别资料会从公开站点抓取规范标题、年份、人数、英文说明和封面，中文译名与说明待配置 Key 后补充。");
    renderGames();
    await loadSourceROMs();
    // Whatever changed (an upload, a setting, a token) may have changed a
    // BIOS card too: read them again now if the tab is showing, else the
    // next time it is opened.
    state.biosStale = true;
    if (state.view === "bios") loadBIOSStatuses();
    await loadDashboard();
  } catch (error) { if (error.status === 401) requestToken(); else showLoadFailure(error.message); }
}

// The BIOS page: each card's state drives its dot. The manager reports
// what the server recorded when each file arrived; it does not re-verify
// every BIOS on a page view, and the games tab carries no BIOS count.
function markBIOS(node, state) {
  const card = node?.closest?.(".bios-card");
  if (card) card.dataset.state = state;
}

// One status read per card, each on its own: a slow or failed one shows
// its error and a retry button on its own card and holds back nothing else.
const BIOS_STATUS_SOURCES = [
  { url: "/api/neogeo-bios", node: "#bios-status", render: status => { state.neoGeoBIOS = status; renderNeoGeoBIOSStatus(status); } },
  { url: "/api/pgm-bios", node: "#pgm-bios-status", render: status => renderPGMBIOSStatus(status) },
  { url: "/api/fds-bios", node: "#fds-bios-status", render: status => renderFDSBIOSStatus(status) },
  { url: "/api/gba-bios", node: "#gba-bios-status", render: status => renderGBABIOSStatus(status) },
  { url: "/api/atari5200-bios", node: "#atari5200-bios-status", render: renderAtari5200BIOSStatus },
  ...["ntsc", "pal", "highScore"].map(role => ({ url: "/api/atari7800-firmware", node: `#atari7800-${role}-status`, render: status => renderAtari7800FirmwareRole(status, role) })),
  { url: "/api/ps1-bios", node: "#ps1-bios-status", render: status => renderPS1BIOSStatus(status) },
  { url: "/api/pcecd-bios", node: "#pcecd-bios-status", render: status => renderPCECDBIOSStatus(status) },
  { url: "/api/megacd-bios", node: "#megacd-bios-status", render: status => renderMegaCDBIOSStatus(status) },
  { url: "/api/sega32x-bios", node: "#sega32x-bios-status", render: status => renderSega32XBIOSStatus(status) },
  { url: "/api/neogeopocket-bios", node: "#neogeopocket-bios-status", render: status => renderNeoGeoPocketBIOSStatus(status) },
  { url: "/api/neogeopocket-nvram", node: "#neogeopocket-nvram-mono-status", render: status => renderNeoGeoPocketNVRAMStatus(status, "mono") },
  { url: "/api/neogeopocket-nvram", node: "#neogeopocket-nvram-color-status", render: status => renderNeoGeoPocketNVRAMStatus(status, "color") },
  { url: "/api/snes-ipl", node: "#snes-ipl-status", render: status => renderSNESIPLStatus(status) },
  { url: "/api/snes-coprocessor-firmware", node: "#snes-dsp-status", render: status => renderSNESDSPStatus(status) }
];
async function loadBIOSStatus(source) {
  const node = $(source.node);
  if (!node) return;
  node.textContent = t("正在读取…"); node.classList.remove("error");
  try { source.render(await api(source.url)); }
  catch (error) {
    if (error.status === 401) { requestToken(); return; }
    node.textContent = t("读取失败：{message}", { message: error.message }); node.classList.add("error");
    const retry = document.createElement("button"); retry.type = "button"; retry.className = "bios-retry"; retry.textContent = t("重试");
    // The status sits inside the card's file-picker label: the retry must
    // not open the picker.
    retry.onclick = event => { event.preventDefault(); event.stopPropagation(); loadBIOSStatus(source); };
    node.append(" ", retry);
    markBIOS(node, "unknown");
  }
}
function loadBIOSStatuses() {
  state.biosStale = false;
  return Promise.all(BIOS_STATUS_SOURCES.map(loadBIOSStatus));
}

function showView(view) {
  const selected = view === "bios" ? "bios" : "games";
  state.view = selected;
  $("#view-games").hidden = selected !== "games";
  $("#view-bios").hidden = selected !== "bios";
  for (const tab of document.querySelectorAll(".view-tab")) {
    const active = tab.dataset.view === selected;
    tab.classList.toggle("active", active);
    if (active) tab.setAttribute("aria-current", "page"); else tab.removeAttribute("aria-current");
  }
  if (selected === "bios" && state.biosStale !== false && state.catalog) loadBIOSStatuses();
}
window.addEventListener("hashchange", () => showView(location.hash.slice(1)));
showView(location.hash.slice(1));

const NEOGEO_BIOS_LABELS = {
  euro: t("欧版 MVS v2 (sp-s2.sp1)"), "euro-s1": t("欧版 MVS v1"), "asia-mv1c": t("亚洲 MV1C"), "asia-mv1b": t("亚洲 MV1B"),
  us: t("美版 MVS v2"), "us-e": t("美版 MVS v1"), "us-v2": t("美版 4 槽 v2"), "us-u4": t("美版 U4"), "us-u3": t("美版 U3"),
  japan: t("日版 MVS v3"), "japan-s2": t("日版 MVS v2"), "japan-s1": t("日版 MVS v1"), "japan-mv1b": t("日版 MV1B"),
  "japan-j3a": t("日版 J3"), "japan-mv1c": t("日版 MV1C"), "japan-hotel": t("日本酒店定制"),
  asia: t("AES 亚洲"), "japan-aes": t("AES 日版"), devel: t("开发用 ROM")
};
function neoGeoBIOSLabel(option) {
  if (NEOGEO_BIOS_LABELS[option]) return `${NEOGEO_BIOS_LABELS[option]} · ${option}`;
  const universe = /^unibios(\d)(\d)(o?)$/.exec(option);
  if (universe) return `Universe BIOS ${universe[1]}.${universe[2]}${universe[3] ? t(" 旧版") : ""} · ${option}`;
  return option;
}
function renderNeoGeoBIOSPreference(status) {
  const block = $("#neogeo-bios-preference");
  if (!status?.valid) { block.hidden = true; return; }
  const optionSelect = $("#neogeo-bios-option");
  optionSelect.replaceChildren(new Option(t("自动（MAME 表序）"), ""),
    ...(status.mainImages || []).map(option => new Option(neoGeoBIOSLabel(option), option)));
  optionSelect.value = status.option && status.mainImages?.includes(status.option) ? status.option : "";
  $("#neogeo-system").value = status.system === "aes" ? "aes" : "mvs";
  $("#neogeo-bios-preference-status").textContent =
    t("实际启动 {value1}，{value2}；客户端同步后生效。", { value1: neoGeoBIOSLabel(status.bootImage), value2: status.system === "aes" ? t("AES 家用机") : t("MVS 街机板") });
  block.hidden = false;
}
async function saveNeoGeoBIOSPreference() {
  const node = $("#neogeo-bios-preference-status");
  try {
    const status = await api("/api/neogeo-bios", {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ option: $("#neogeo-bios-option").value, system: $("#neogeo-system").value })
    });
    renderNeoGeoBIOSStatus(status);
    showNotice(t("Neo Geo 启动设置已写入资料库。"));
  } catch (error) {
    if (error.status === 401) requestToken(); else { node.textContent = error.message; }
  }
}
function renderNeoGeoBIOSStatus(status) {
  const node = $("#bios-status");
  renderNeoGeoBIOSPreference(status);
  if (status?.valid) {
    node.textContent = t("已验证 · {value1} · {value2}… · {length} 个主 BIOS", { value1: formatBytes(status.bytes), value2: status.sha256.slice(0, 10), length: status.mainImages.length });
    node.classList.remove("error");
  } else if (status?.configured) {
    node.textContent = t("文件无效：{value1}", { value1: FCI18n.translateMessage(status.error) || t("请重新上传") });
    node.classList.add("error");
  } else {
    node.textContent = t("选择用户自有的 neogeo.zip");
    node.classList.remove("error");
  }
  markBIOS(node, status?.valid ? "ok" : status?.configured ? "error" : "missing");
}

function renderPGMBIOSStatus(status) {
  const node = $("#pgm-bios-status");
  if (status?.valid) {
    node.textContent = t("已验证 · {value1} · {value2}…", { value1: formatBytes(status.bytes), value2: status.sha256.slice(0, 10) });
    node.classList.remove("error");
  } else if (status?.configured) {
    node.textContent = t("文件无效：{value1}", { value1: FCI18n.translateMessage(status.error) || t("请重新上传") });
    node.classList.add("error");
  } else {
    node.textContent = t("选择用户自有的 pgm.zip");
    node.classList.remove("error");
  }
  markBIOS(node, status?.valid ? "ok" : status?.configured ? "error" : "missing");
}

const CPS3_KEY_LABELS = { table: t("key 已在服务端表中"), missing: t("缺 key"), invalid: t("表中 key 解不开这块 BIOS"), unknown: "" };

function renderCPS3Status(status) {
  state.cps3 = status;
  const summary = $("#cps3-status"), panel = $("#cps3-panel");
  if (state.cps3Timer) { clearTimeout(state.cps3Timer); state.cps3Timer = null; }
  if (!status) return;
  summary.classList.toggle("error", !status.libraryConfigured || !status.installerAvailable);
  if (!status.libraryConfigured) summary.textContent = t("请先在设置里选择资料库目录");
  else if (!status.installerAvailable) summary.textContent = t("服务端缺少 CPS3 安装器（resources/cps3-install.wasm）");
  else summary.textContent = t("支持：{value1}；上传游戏集 ZIP 与光盘 .img", { value1: status.supported.map(item => item.driver).join(t("、")) });
  panel.replaceChildren();
  for (const item of status.drivers) {
    const task = item.task;
    if (item.installedGameID && (!task || task.state === "completed")) continue;
    const row = document.createElement("div"); row.className = "cps3-row";
    const title = document.createElement("b"); title.textContent = t("{title}（{driver}）", { title: item.title, driver: item.driver });
    const facts = [
      item.bios ? "BIOS ✓" : t("缺 BIOS"),
      item.cd ? t("光盘 ✓") : t("缺光盘 {cdVolumeID}", { cdVolumeID: item.cdVolumeID }),
      CPS3_KEY_LABELS[item.keyStatus] || ""
    ];
    if (item.installedGameID) facts.push(t("已加入资料库"));
    else if (task && ["queued", "running"].includes(task.state)) facts.push(FCI18n.translateMessage(task.message) || t("安装中…"));
    else if (task?.state === "failed") facts.push(t("安装失败：{value1}", { value1: FCI18n.translateMessage(task.error) || FCI18n.translateMessage(task.message) || "" }));
    const detail = document.createElement("span"); detail.textContent = facts.filter(Boolean).join(" · ");
    row.append(title, detail);
    if (item.bios && !item.installedGameID && item.keyStatus !== "table") {
      const input = document.createElement("input"); input.type = "password"; input.autocomplete = "new-password";
      input.spellcheck = false; input.placeholder = t("16 个十六进制字符"); input.maxLength = 40;
      const save = document.createElement("button"); save.type = "button"; save.textContent = t("保存 key");
      save.onclick = async () => {
        save.disabled = true;
        try { renderCPS3Status((await api("/api/cps3/key", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ driver: item.driver, key: input.value }) })).cps3); pollTasks(); }
        catch (error) { showNotice(error.message, true); save.disabled = false; }
      };
      row.append(input, save);
    } else if (item.bios && item.cd && item.keyStatus === "table" && !item.installedGameID && !(task && ["queued", "running"].includes(task.state))) {
      const retry = document.createElement("button"); retry.type = "button"; retry.textContent = t("重新安装");
      retry.onclick = async () => {
        retry.disabled = true;
        try { renderCPS3Status((await api("/api/cps3/install", { method: "POST" })).cps3); pollTasks(); }
        catch (error) { showNotice(error.message, true); retry.disabled = false; }
      };
      row.append(retry);
    }
    panel.append(row);
  }
  for (const family of status.cds) {
    if (status.drivers.some(item => item.family === family)) continue;
    const row = document.createElement("div"); row.className = "cps3-row";
    row.textContent = t("已收到 {family} 的光盘，还需要该游戏的 MAME 游戏集 ZIP（含卡带 BIOS）。", { family: family });
    panel.append(row);
  }
  panel.hidden = !panel.childElementCount;
  if (status.drivers.some(item => item.task && ["queued", "running"].includes(item.task.state))) {
    state.cps3Timer = setTimeout(async () => {
      try { renderCPS3Status(await api("/api/cps3")); if (!state.cps3.drivers.some(item => item.task?.state === "running")) await load(); }
      catch { /* keep the last status */ }
    }, 3_000);
  }
}

async function uploadCPS3(files) {
  const node = $("#cps3-status");
  for (const file of [...files]) {
    node.textContent = t("正在上传 {name}…", { name: file.name }); node.classList.remove("error");
    try {
      const result = await api(`/api/upload?name=${encodeURIComponent(file.name)}`, { method: "POST", body: file });
      if (!["cps3CD", "cps3BIOS"].includes(result.kind)) {
        showNotice(t("{name} 不是 CPS3 游戏集或光盘，已按普通 ROM 处理。", { name: file.name }), true);
        continue;
      }
      renderCPS3Status(result.cps3);
      showNotice(result.kind === "cps3CD" ? t("已收到 {volumeID} 光盘。", { volumeID: result.volumeID }) : t("已收到 {title} 的卡带 BIOS。", { title: result.title }));
    } catch (error) { showNotice(t("{name}：{message}", { name: file.name, message: error.message }), true); }
  }
  $("#cps3-upload").value = "";
  pollTasks();
  await load();
}

// Atari firmware status follows the API's verified roles; the HSC is only
// required by cartridges that declare a High Score Cartridge save device.
const ATARI7800_ROLE_LABELS = { ntsc: "NTSC BIOS", pal: "PAL BIOS", highScore: "High Score Cartridge" };
function renderAtariFirmwareStatus(node, status, missing) {
  if (status?.valid) {
    node.textContent = t("已验证 · {value1} · {value2}…", { value1: formatBytes(status.bytes), value2: String(status.sha256).slice(0, 10) });
  } else if (status?.configured) {
    node.textContent = t("文件无效：{value1}", { value1: FCI18n.translateMessage(status.error) || t("请重新上传") });
  } else { node.textContent = missing; }
  node.classList.toggle("error", Boolean(status?.configured && !status?.valid));
  markBIOS(node, status?.valid ? "ok" : status?.configured ? "error" : "missing");
}
function renderAtari5200BIOSStatus(status) {
  renderAtariFirmwareStatus($("#atari5200-bios-status"), status, t("缺少 Atari 5200 BIOS；上传 atari5200-bios.rom 后可启动游戏"));
}
function renderAtari7800FirmwareRole(status, role) {
  renderAtariFirmwareStatus($(`#atari7800-${role}-status`), status?.roles?.[role], role === "highScore"
    ? t("仅声明 High Score Cartridge 的游戏需要；普通卡带无需上传")
    : t("当前客户端启动 {value1} 游戏需要对应 BIOS；按游戏制式上传", { value1: role.toUpperCase() }));
  if (role === "highScore" && !status?.roles?.[role]?.configured) markBIOS($("#atari7800-highScore-status"), "optional");
}
async function uploadAtari5200BIOS(file) {
  if (!file) return;
  const node = $("#atari5200-bios-status"); node.textContent = t("正在校验 Atari 5200 BIOS…");
  try {
    const status = await api(`/api/atari5200-bios?name=${encodeURIComponent(file.name)}`, { method: "POST", body: file });
    renderAtari5200BIOSStatus(status); showNotice(t("Atari 5200 BIOS 已验证并写入资料库。"));
  } catch (error) { renderAtari5200BIOSStatus({ configured: true, valid: false, error: error.message }); }
  finally { $("#atari5200-bios-upload").value = ""; }
}
async function uploadAtari7800Firmware(file, role) {
  if (!file) return;
  const node = $(`#atari7800-${role}-status`); node.textContent = t("正在按身份校验 Atari 7800 固件…");
  try {
    const result = await api("/api/atari7800-firmware", { method: "POST", body: file });
    for (const key of Object.keys(ATARI7800_ROLE_LABELS)) renderAtari7800FirmwareRole(result.status, key);
    showNotice(t("Atari 7800 {value1} 已验证并写入资料库。", { value1: ATARI7800_ROLE_LABELS[result.role] }));
  } catch (error) {
    node.textContent = t("上传失败：{message}", { message: error.message }); node.classList.add("error"); markBIOS(node, "error");
  } finally { $(`#atari7800-${role}-upload`).value = ""; }
}
function retainUploadWarnings(fileName, warnings) {
  const entries = (Array.isArray(warnings) ? warnings : []).filter(warning => typeof warning?.message === "string" && warning.message.trim());
  if (!entries.length) return;
  const list = $("#upload-warnings-list");
  for (const warning of entries) {
    const item = document.createElement("li"); item.textContent = t("{fileName}：{message}", { fileName: fileName, message: FCI18n.translateMessage(warning.message) }); list.append(item);
  }
  $("#upload-warnings").hidden = false;
}

function renderGBABIOSStatus(status) {
  const node = $("#gba-bios-status");
  if (status?.valid) {
    node.textContent = t("已验证 · 16 KiB · {value1}…", { value1: status.sha256.slice(0, 10) });
    node.classList.remove("error");
  } else if (status?.configured) {
    node.textContent = t("文件无效：{value1}", { value1: FCI18n.translateMessage(status.error) || t("请重新上传") });
    node.classList.add("error");
  } else {
    node.textContent = t("可选：不上传时客户端用内置 BIOS");
    node.classList.remove("error");
  }
  markBIOS(node, status?.valid ? "ok" : status?.configured ? "error" : "optional");
}

async function uploadGBABIOS(file) {
  if (!file) return;
  if (file.name.toLowerCase() !== "gba_bios.bin") {
    renderGBABIOSStatus({ configured: true, valid: false, error: t("文件必须命名为 gba_bios.bin") });
    return;
  }
  const node = $("#gba-bios-status"); node.textContent = t("正在按 MAME 身份校验 16 KiB BIOS…"); node.classList.remove("error");
  try {
    const status = await api(`/api/gba-bios?name=${encodeURIComponent(file.name)}`, { method: "POST", body: file });
    renderGBABIOSStatus(status);
    showNotice(t("GBA BIOS 已验证并写入私人资料库。"));
  } catch (error) {
    renderGBABIOSStatus({ configured: true, valid: false, error: error.message });
  } finally {
    $("#gba-bios-upload").value = "";
  }
}

const PS1_REGION_NAMES = { usa: t("美版"), japan: t("日版"), europe: t("欧版") };

function renderPS1BIOSStatus(status) {
  const node = $("#ps1-bios-status");
  const regions = Object.entries(status?.regions || {});
  const valid = regions.filter(([, item]) => item.valid);
  const broken = regions.filter(([, item]) => item.configured && !item.valid);
  if (!status?.libraryConfigured) {
    node.textContent = t("需要先在设置里选择资料库目录");
    node.classList.remove("error");
  } else if (broken.length) {
    node.textContent = broken.map(([region, item]) => t("{value1}无效：{value2}", { value1: PS1_REGION_NAMES[region], value2: FCI18n.translateMessage(item.error) || t("请重新上传") })).join(t("；"));
    node.classList.add("error");
  } else if (valid.length) {
    node.textContent = t("已验证：{value1}", { value1: valid.map(([region, item]) => `${PS1_REGION_NAMES[region]} ${item.version}`).join(" · ") }) +
      (valid.length < regions.length ? t("；缺 {value1}", { value1: regions.filter(([, item]) => !item.valid).map(([region]) => PS1_REGION_NAMES[region]).join(t("、")) }) : "");
    node.classList.remove("error");
  } else {
    node.textContent = t("选择用户自有的 BIOS；按身份自动分美/日/欧区");
    node.classList.remove("error");
  }
  markBIOS(node, broken.length ? "error" : valid.length ? "ok" : "missing");
}

async function uploadPS1BIOS(file) {
  if (!file) return;
  const node = $("#ps1-bios-status"); node.textContent = t("正在按 MAME 身份校验 512 KiB BIOS…"); node.classList.remove("error");
  try {
    const result = await api("/api/ps1-bios", { method: "POST", body: file });
    renderPS1BIOSStatus(result.status);
    showNotice(t("PlayStation {value1} BIOS {version} 已验证并写入私人资料库。", { value1: PS1_REGION_NAMES[result.region], version: result.version }));
  } catch (error) {
    node.textContent = t("文件无效：{message}", { message: error.message });
    node.classList.add("error");
    markBIOS(node, "error");
  } finally {
    $("#ps1-bios-upload").value = "";
  }
}

function renderMegaCDBIOSStatus(status) {
  const node = $("#megacd-bios-status");
  const regions = Object.entries(status?.regions || {});
  const valid = regions.filter(([, item]) => item.valid);
  const broken = regions.filter(([, item]) => item.configured && !item.valid);
  if (!status?.libraryConfigured) {
    node.textContent = t("需要先在设置里选择资料库目录");
    node.classList.remove("error");
  } else if (broken.length) {
    node.textContent = broken.map(([region, item]) => t("{value1}无效：{value2}", { value1: PS1_REGION_NAMES[region], value2: FCI18n.translateMessage(item.error) || t("请重新上传") })).join(t("；"));
    node.classList.add("error");
  } else if (valid.length) {
    node.textContent = t("已验证：{value1}", { value1: valid.map(([region, item]) => `${PS1_REGION_NAMES[region]} ${item.version}`).join(" · ") }) +
      (valid.length < regions.length ? t("；缺 {value1}", { value1: regions.filter(([, item]) => !item.valid).map(([region]) => PS1_REGION_NAMES[region]).join(t("、")) }) : "");
    node.classList.remove("error");
  } else {
    node.textContent = t("选择用户自有的 BIOS；按身份自动分美/日/欧区");
    node.classList.remove("error");
  }
  markBIOS(node, broken.length ? "error" : valid.length ? "ok" : "missing");
}

function renderPCECDBIOSStatus(status) {
  const node = $("#pcecd-bios-status");
  const regions = Object.entries(status?.regions || {});
  const valid = regions.filter(([, item]) => item.valid);
  const broken = regions.filter(([, item]) => item.configured && !item.valid);
  if (!status?.libraryConfigured) {
    node.textContent = t("需要先在设置里选择资料库目录");
    node.classList.remove("error");
  } else if (broken.length) {
    node.textContent = broken.map(([region, item]) => t("{value1}无效：{value2}", { value1: PS1_REGION_NAMES[region], value2: FCI18n.translateMessage(item.error) || t("请重新上传") })).join(t("；"));
    node.classList.add("error");
  } else if (valid.length) {
    node.textContent = t("已验证：{value1}", { value1: valid.map(([region, item]) => `${PS1_REGION_NAMES[region]} ${item.version}`).join(" · ") }) +
      (valid.some(([, item]) => !item.super) ? t("；Super CD-ROM² 游戏需要 3.0") : "");
    node.classList.remove("error");
  } else {
    node.textContent = t("选择用户自有的 System Card（Super CD-ROM² 游戏需要 3.0）；按身份自动分日/美版");
    node.classList.remove("error");
  }
  markBIOS(node, broken.length ? "error" : valid.length ? "ok" : "missing");
}

async function uploadPCECDBIOS(file) {
  if (!file) return;
  const node = $("#pcecd-bios-status"); node.textContent = t("正在按 MAME 身份校验 System Card…"); node.classList.remove("error");
  try {
    const result = await api("/api/pcecd-bios", { method: "POST", body: file });
    renderPCECDBIOSStatus(result.status);
    showNotice(result.kept
      ? t("已有 {kept}，保留它（{version} 不能启动 Super CD-ROM² 游戏）。", { kept: result.kept, version: result.version })
      : t("System Card {version} 已验证并写入私人资料库。", { version: result.version }));
  } catch (error) {
    node.textContent = t("文件无效：{message}", { message: error.message });
    node.classList.add("error");
    markBIOS(node, "error");
  } finally {
    $("#pcecd-bios-upload").value = "";
  }
}

async function uploadMegaCDBIOS(file) {
  if (!file) return;
  const node = $("#megacd-bios-status"); node.textContent = t("正在按 MAME 身份校验 128 KiB BIOS…"); node.classList.remove("error");
  try {
    const result = await api("/api/megacd-bios", { method: "POST", body: file });
    renderMegaCDBIOSStatus(result.status);
    showNotice(t("Mega CD {value1} BIOS {version} 已验证并写入私人资料库。", { value1: PS1_REGION_NAMES[result.region], version: result.version }));
  } catch (error) {
    node.textContent = t("文件无效：{message}", { message: error.message });
    node.classList.add("error");
    markBIOS(node, "error");
  } finally {
    $("#megacd-bios-upload").value = "";
  }
}

const SEGA32X_ROLE_NAMES = { master: t("主 SH-2"), slave: t("副 SH-2"), gside: t("MD 侧 G") };

function renderSega32XBIOSStatus(status) {
  const node = $("#sega32x-bios-status");
  const roles = Object.entries(status?.roles || {});
  const valid = roles.filter(([, item]) => item.valid);
  const broken = roles.filter(([, item]) => item.configured && !item.valid);
  if (!status?.libraryConfigured) {
    node.textContent = t("需要先在设置里选择资料库目录");
    node.classList.remove("error");
  } else if (broken.length) {
    node.textContent = broken.map(([role, item]) => t("{value1}无效：{value2}", { value1: SEGA32X_ROLE_NAMES[role], value2: FCI18n.translateMessage(item.error) || t("请重新上传") })).join(t("；"));
    node.classList.add("error");
  } else if (valid.length) {
    node.textContent = t("已验证：{value1}", { value1: valid.map(([role]) => SEGA32X_ROLE_NAMES[role]).join(" · ") }) +
      (valid.length < roles.length ? t("；缺 {value1}", { value1: roles.filter(([, item]) => !item.valid).map(([role]) => SEGA32X_ROLE_NAMES[role]).join(t("、")) }) : "");
    node.classList.remove("error");
  } else {
    node.textContent = t("依次上传三件适配器 BIOS；按身份自动归主/副/MD 侧");
    node.classList.remove("error");
  }
  markBIOS(node, broken.length ? "error" : valid.length === roles.length && roles.length ? "ok" : "missing");
}

async function uploadSega32XBIOS(file) {
  if (!file) return;
  const node = $("#sega32x-bios-status"); node.textContent = t("正在按 MAME 身份校验 32X 适配器 BIOS…"); node.classList.remove("error");
  try {
    const result = await api("/api/sega32x-bios", { method: "POST", body: file });
    renderSega32XBIOSStatus(result.status);
    showNotice(t("32X {value1} BIOS 已验证并写入私人资料库。", { value1: SEGA32X_ROLE_NAMES[result.role] }));
  } catch (error) {
    node.textContent = t("文件无效：{message}", { message: error.message });
    node.classList.add("error");
    markBIOS(node, "error");
  } finally {
    $("#sega32x-bios-upload").value = "";
  }
}

const NEOGEOPOCKET_ROLE_NAMES = { mono: t("单色"), color: t("彩色") };

function renderNeoGeoPocketBIOSStatus(status) {
  const node = $("#neogeopocket-bios-status");
  const roles = Object.entries(status?.roles || {});
  const valid = roles.filter(([, item]) => item.valid);
  const broken = roles.filter(([, item]) => item.configured && !item.valid);
  if (!status?.libraryConfigured) {
    node.textContent = t("需要先在设置里选择资料库目录");
    node.classList.remove("error");
  } else if (broken.length) {
    node.textContent = broken.map(([role, item]) => t("{value1}无效：{value2}", { value1: NEOGEOPOCKET_ROLE_NAMES[role], value2: FCI18n.translateMessage(item.error) || t("请重新上传") })).join(t("；"));
    node.classList.add("error");
  } else if (valid.length) {
    node.textContent = t("已验证：{value1}", { value1: valid.map(([role]) => NEOGEOPOCKET_ROLE_NAMES[role]).join(" · ") }) +
      (valid.length < roles.length ? t("；缺 {value1}", { value1: roles.filter(([, item]) => !item.valid).map(([role]) => NEOGEOPOCKET_ROLE_NAMES[role]).join(t("、")) }) : "");
    node.classList.remove("error");
  } else {
    node.textContent = t("分别上传单色与彩色主机 BIOS；按身份自动归 mono/color");
    node.classList.remove("error");
  }
  markBIOS(node, broken.length ? "error" : valid.length === roles.length && roles.length ? "ok" : "missing");
}

async function uploadNeoGeoPocketBIOS(file) {
  if (!file) return;
  const node = $("#neogeopocket-bios-status"); node.textContent = t("正在按 MAME 身份校验 Neo Geo Pocket BIOS…"); node.classList.remove("error");
  try {
    const result = await api("/api/neogeopocket-bios", { method: "POST", body: file });
    renderNeoGeoPocketBIOSStatus(result.status);
    showNotice(t("Neo Geo Pocket {value1} BIOS 已验证并写入私人资料库。", { value1: NEOGEOPOCKET_ROLE_NAMES[result.role] }));
  } catch (error) {
    node.textContent = t("文件无效：{message}", { message: error.message });
    node.classList.add("error");
    markBIOS(node, "error");
  } finally {
    $("#neogeopocket-bios-upload").value = "";
  }
}

// NVRAM has no self-identity, so each console's role has its own card; the
// status endpoint reports both roles and each card renders its own.
function renderNeoGeoPocketNVRAMStatus(status, role) {
  const node = $(`#neogeopocket-nvram-${role}-status`);
  const item = status?.roles?.[role];
  if (!status?.libraryConfigured) {
    node.textContent = t("需要先在设置里选择资料库目录");
    node.classList.remove("error");
  } else if (item?.valid) {
    node.textContent = t("已验证 · 12320 字节 · {nonzero} 非零 · {value2}…", { nonzero: item.nonzero, value2: item.sha256.slice(0, 10) });
    node.classList.remove("error");
  } else if (item?.configured) {
    node.textContent = t("文件无效：{value1}", { value1: FCI18n.translateMessage(item.error) || t("请重新上传") });
    node.classList.add("error");
  } else {
    node.textContent = t("上传{value1}主机的首启电池存档（引导必需）", { value1: NEOGEOPOCKET_ROLE_NAMES[role] });
    node.classList.remove("error");
  }
  markBIOS(node, item?.valid ? "ok" : item?.configured ? "error" : "missing");
}

function uploadNeoGeoPocketNVRAM(role) {
  return async file => {
    if (!file) return;
    const node = $(`#neogeopocket-nvram-${role}-status`); node.textContent = t("正在按尺寸与内容校验 NVRAM…"); node.classList.remove("error");
    try {
      const result = await api(`/api/neogeopocket-nvram?role=${role}`, { method: "POST", body: file });
      renderNeoGeoPocketNVRAMStatus(result.status, role);
      showNotice(t("Neo Geo Pocket {value1} NVRAM 已校验并写入私人资料库。", { value1: NEOGEOPOCKET_ROLE_NAMES[role] }));
    } catch (error) {
      node.textContent = t("文件无效：{message}", { message: error.message });
      node.classList.add("error");
      markBIOS(node, "error");
    } finally {
      $(`#neogeopocket-nvram-${role}-upload`).value = "";
    }
  };
}
const uploadNeoGeoPocketNVRAMMono = uploadNeoGeoPocketNVRAM("mono");
const uploadNeoGeoPocketNVRAMColor = uploadNeoGeoPocketNVRAM("color");

function renderFDSBIOSStatus(status) {
  const node = $("#fds-bios-status");
  if (status?.valid) {
    node.textContent = t("已验证 · 8 KiB · {value1}…", { value1: status.sha256.slice(0, 10) });
    node.classList.remove("error");
  } else if (status?.configured) {
    node.textContent = t("文件无效：{value1}", { value1: FCI18n.translateMessage(status.error) || t("请重新上传") });
    node.classList.add("error");
  } else {
    node.textContent = t("选择用户自有的 disksys.rom");
    node.classList.remove("error");
  }
  markBIOS(node, status?.valid ? "ok" : status?.configured ? "error" : "missing");
}

function renderSNESIPLStatus(status) {
  const node = $("#snes-ipl-status");
  if (status?.builtIn) {
    node.textContent = t("使用内置 IPL · 也可上传自有的 spc700.rom 替换");
    node.classList.remove("error");
  } else if (status?.valid) {
    node.textContent = t("已验证 · 64 字节 · {value1}…", { value1: status.sha256.slice(0, 10) });
    node.classList.remove("error");
  } else if (status?.configured) {
    node.textContent = t("文件无效：{value1}", { value1: FCI18n.translateMessage(status.error) || t("请重新上传") });
    node.classList.add("error");
  } else {
    node.textContent = t("未上传时使用内置 IPL");
    node.classList.remove("error");
  }
  markBIOS(node, status?.builtIn || status?.valid ? "ok" : status?.configured ? "error" : "optional");
}

function renderSNESDSPStatus(statuses) {
  const node = $("#snes-dsp-status");
  const entries = Object.entries(statuses || {});
  // A firmware the project supplies itself is not one the user verified.
  // Reporting Cx4 and the IPL as "已验证" made a fresh install look as though
  // somebody had already uploaded them, and kept the prompt below from ever
  // appearing, since something was always "present".
  const supplied = entries.filter(([, status]) => status?.valid && !status.builtIn);
  const builtIn = entries.filter(([, status]) => status?.valid && status.builtIn).map(([name]) => name);
  const broken = entries.filter(([, status]) => status?.configured && !status.valid);
  if (broken.length) {
    node.textContent = t("文件无效：{value1}", { value1: broken.map(([name, status]) => t("{name}（{value2}）", { name: name, value2: FCI18n.translateMessage(status.error) || t("请重新上传") })).join(t("；")) });
    node.classList.add("error");
  } else {
    const parts = [];
    if (supplied.length) parts.push(t("已验证：{value1}", { value1: supplied.map(([name]) => t("{name}（{value2}）", { name: name, value2: formatBytes(statuses[name].bytes) })).join(t("、")) }));
    if (builtIn.length) parts.push(t("内置、无需上传：{value1}", { value1: builtIn.join(t("、")) }));
    if (!supplied.length) parts.push(t("选择用户自有的 DSP-1/2/3/4 或 ST010/011/018 固件；也接受 DSP/ST 的 program/data 两半"));
    node.textContent = parts.join(t("；"));
    node.classList.remove("error");
  }
  markBIOS(node, broken.length ? "error" : supplied.length ? "ok" : "optional");
}

function metric(label, value, level = "") {
  const node = document.createElement("div"); node.className = `metric ${level}`;
  const labelNode = document.createElement("span"); labelNode.textContent = label;
  const number = document.createElement("strong"); number.textContent = String(value);
  node.append(labelNode, number); return node;
}

function renderHealth(report) {
  const dashboard = $("#library-dashboard");
  if (!report) { dashboard.hidden = true; return; }
  state.health = report;
  dashboard.hidden = false;
  $("#health-checked-at").textContent = t("上次快速检查：{value1}", { value1: new Date(report.checkedAt).toLocaleString(FCI18n.language) });
  const summary = report.summary;
  const metrics = $("#health-metrics"); metrics.replaceChildren(
    metric(t("游戏"), summary.games), metric(t("有效"), summary.valid), metric(t("无封面"), summary.missingCover, summary.missingCover ? "warning" : ""),
    metric(t("资料不完整"), summary.incompleteMetadata, summary.incompleteMetadata ? "warning" : ""), metric(t("文件异常"), summary.missingROM + summary.invalidROM + summary.missingManifest, summary.missingROM + summary.invalidROM + summary.missingManifest ? "error" : ""),
    metric(t("重复 ROM"), summary.duplicateROM, summary.duplicateROM ? "warning" : ""), metric(t("孤立游戏包"), summary.orphanPackage, summary.orphanPackage ? "warning" : "")
  );
  const issues = $("#health-issues"); issues.replaceChildren();
  for (const issue of report.issues.slice(0, 50)) {
    const node = document.createElement("button"); node.type = "button"; node.className = "issue issue-link";
    const title = document.createElement("b"); title.textContent = issue.title;
    const message = document.createElement("span"); message.textContent = issue.message;
    node.title = t("打开游戏编辑页"); node.onclick = () => openSourceEditor(issue.id);
    node.append(title, message); issues.append(node);
  }
  if (!report.issues.length) issues.innerHTML = t("<p class=\"muted\">资料库没有待处理项。</p>");
}

function taskSignature(tasks) { return JSON.stringify(tasks.map(task => [task.id, task.state, task.completed, task.total, task.message, task.completedAt, task.canCancel])); }
function sourceRomsSignature(response) { return JSON.stringify([response.directory, response.title, response.revision, response.total, response.offset, response.roms]); }

function renderTasks(tasks) {
  const list = $("#task-list"); list.replaceChildren();
  for (const task of tasks) {
    const node = document.createElement("div"); node.className = `task ${task.state}`;
    const title = document.createElement("b"); title.textContent = task.title;
    const detail = document.createElement("span");
    const progress = task.total ? ` ${task.completed || 0}/${task.total}` : "";
    detail.textContent = `${task.state === "running" ? t("进行中") : task.state === "failed" ? t("失败") : task.state === "cancelled" ? t("已取消") : task.state === "queued" ? t("等待中") : t("已完成")}${progress} · ${FCI18n.translateMessage(task.message) || ""}`;
    node.append(title, detail);
    if (task.canCancel) {
      const cancel = document.createElement("button"); cancel.type = "button"; cancel.className = "task-cancel"; cancel.textContent = t("取消");
      cancel.onclick = async () => { cancel.disabled = true; try { await api(`/api/tasks/${encodeURIComponent(task.id)}/cancel`, { method: "POST" }); await pollTasks(); } catch (error) { showNotice(error.message, true); } };
      node.append(cancel);
    }
    list.append(node);
  }
  if (!tasks.length) list.innerHTML = t("<p class=\"muted\">没有正在执行或最近的后台任务。</p>");
}

function scheduleTaskRefresh(tasks) {
  if (state.taskRefreshTimer) { clearTimeout(state.taskRefreshTimer); state.taskRefreshTimer = null; }
  const active = tasks.some(task => task.state === "queued" || task.state === "running");
  if (active) state.taskRefreshTimer = setTimeout(() => { state.taskRefreshTimer = null; pollTasks(); }, 3_000);
}

async function pollTasks() {
  if (!state.catalog?.settings?.sourceDirectory) return;
  try {
    const response = await api("/api/tasks"); const tasks = response.tasks || [];
    const signature = taskSignature(tasks); const changed = signature !== state.taskSignature;
    if (changed) {
      state.taskSignature = signature; renderTasks(tasks);
      const active = tasks.some(task => task.state === "queued" || task.state === "running");
      const refreshDue = !active || Date.now() - (state.lastSourceRefreshAt || 0) >= 10_000;
      if (Number(response.sourceRevision) !== state.sourceRevision && refreshDue) await Promise.all([loadSourceROMs({ onlyIfChanged: true }), api("/api/source-health").then(renderHealth)]);
    }
    scheduleTaskRefresh(tasks);
  } catch (error) { /* A transient polling failure must not redraw the page. */ }
}

async function loadDashboard() {
  if (!state.catalog?.settings?.sourceDirectory) $("#library-dashboard").hidden = true;
  else try {
    const [health, taskResponse] = await Promise.all([api("/api/source-health"), api("/api/tasks")]);
    const tasks = taskResponse.tasks || [];
    renderHealth(health); renderTasks(tasks); state.taskSignature = taskSignature(tasks); state.sourceRevision = Number(taskResponse.sourceRevision) || state.sourceRevision; scheduleTaskRefresh(tasks);
  } catch (error) { $("#library-dashboard").hidden = true; }
  // The CPS3 installs panel sits under the task list. Its status is the
  // server's record (no BIOS hashing, no manifest scan) and it loads after
  // the list, so it never delays the games.
  try { renderCPS3Status(await api("/api/cps3")); }
  catch (error) { if (error.status !== 401) setStatus("#cps3-status", t("CPS3 状态读取失败：{message}", { message: error.message }), true); }
}

function updateBulkControls() {
  const count = state.selectedSourceIDs.size;
  $("#bulk-research").disabled = !count; $("#bulk-delete").disabled = !count;
  const visible = state.visibleSourceRoms || state.sourceRoms;
  $("#select-all-source").textContent = visible.length && visible.every(rom => state.selectedSourceIDs.has(rom.id)) ? t("取消本页") : t("全选本页");
  setStatus("#bulk-status", count ? t("已选择 {count} 个游戏。", { count: count }) : "");
}

function populateSourceFilter(selector, values, placeholder) {
  const select = $(selector); const previous = select.value;
  select.replaceChildren(new Option(placeholder, ""), ...values.map(value => new Option(value === "snes" ? "Super NES" : selector === "#source-category" && categoryOptions.includes(value) ? t(value) : value, value)));
  select.value = values.includes(previous) ? previous : "";
}

async function loadSourceROMs({ onlyIfChanged = false, force = false, scrollToList = false, focusPage = false } = {}) {
  const section = $("#source-roms");
  const managed = $("#managed-library");
  if (!state.catalog?.settings?.sourceDirectory) { section.hidden = true; managed.hidden = false; $("#summary").textContent = t("{length} 个游戏", { length: state.catalog.games.length }); return; }
  try {
    const params = new URLSearchParams({ offset: String(state.sourceOffset), limit: String(state.sourceLimit), q: $("#source-search").value.trim(), system: $("#source-system").value, category: $("#source-category").value, collection: $("#source-collection").value, status: $("#source-status").value, sort: $("#source-sort").value });
    if (force) params.set("refresh", "1");
    const response = await api(`/api/source-roms?${params}`);
    // The list shrank under the current page (a delete, a narrower filter the
    // server already applied): land on the last page that still exists.
    const responseTotal = Number(response.total) || 0;
    if (responseTotal && !response.roms?.length && state.sourceOffset >= responseTotal) {
      state.sourceOffset = FCPagination.pageInfo(state.sourceOffset, state.sourceLimit, responseTotal).offset;
      return loadSourceROMs({ onlyIfChanged, scrollToList, focusPage });
    }
    const signature = sourceRomsSignature(response);
    if (onlyIfChanged && signature === state.sourceRomsSignature) return false;
    state.sourceRomsSignature = signature;
    section.hidden = false; managed.hidden = true;
    state.sourceRevision = Number(response.revision) || state.sourceRevision;
    state.lastSourceRefreshAt = Date.now();
    state.sourceTotal = Number(response.total) || 0;
    state.sourceOffset = Number(response.offset) || 0;
    $("#summary").textContent = t("{sourceTotal} 个游戏", { sourceTotal: state.sourceTotal });
    $("#library-title").value = response.title || state.catalog.settings.title || "";
    state.sourceRoms = response.roms;
    populateSourceFilter("#source-system", response.facets?.systems || [], t("全部主机"));
    populateSourceFilter("#source-category", response.facets?.categories || [], t("全部分类"));
    populateSourceFilter("#source-collection", response.facets?.collections || [], t("全部收藏集"));
    const roms = response.roms; state.visibleSourceRoms = roms;
    const first = state.sourceTotal ? state.sourceOffset + 1 : 0, last = state.sourceOffset + roms.length;
    $("#source-rom-count").textContent = t("显示 {first}–{last} / {sourceTotal} 个 · 当前资料库：{directory}", { first: first, last: last, sourceTotal: state.sourceTotal, directory: response.directory });
    renderSourcePagination({ focusPage });
    const list = $("#source-rom-list"); list.replaceChildren();
    for (const rom of roms) {
      const item = document.createElement("article"); item.className = "game-card source-game-card";
      const select = document.createElement("input"); select.type = "checkbox"; select.className = "source-select"; select.checked = state.selectedSourceIDs.has(rom.id);
      select.setAttribute("aria-label", t("选择 {value1}", { value1: displayName(rom) || rom.id })); select.onchange = () => { if (select.checked) state.selectedSourceIDs.add(rom.id); else state.selectedSourceIDs.delete(rom.id); updateBulkControls(); };
      const cover = document.createElement("div"); cover.className = "cover";
      if (rom.hasCover) cover.style.backgroundImage = `url(${assetURL(`/api/source-roms/${encodeURIComponent(rom.id)}/cover`, rom.coverVersion)})`;
      else cover.textContent = systemLabel(rom).toUpperCase();
      const content = document.createElement("div"); content.className = "game-card-content";
      const system = document.createElement("span"); system.className = "pill"; system.textContent = systemLabel(rom);
      const title = document.createElement("h3"); title.textContent = displayName(rom) || rom.path;
      const details = document.createElement("p"); details.className = "details";
      details.textContent = [categoryOptions.includes(rom.category) ? t(rom.category) : rom.category, rom.system === "nes" && rom.mapper != null ? `Mapper ${rom.mapper}` : null, rom.versionCount > 1 ? t("{versionCount} 个版本", { versionCount: rom.versionCount }) : null, rom.bytes ? formatBytes(rom.bytes) : null].filter(Boolean).join(" · ");
      // The card names the ROM file only; the package path is internal and
      // lives in the editor. A finished research run says nothing here.
      const path = document.createElement("p"); path.className = "filename muted";
      path.textContent = String(rom.path || "").split("/").pop();
      path.title = rom.path || "";
      if (rom.collections?.length) path.textContent += ` · ${rom.collections.join(t("、"))}`;
      const research = rom.automaticResearch;
      const researchStatus = document.createElement("p"); researchStatus.className = "muted auto-research";
      if (research?.state === "running") researchStatus.textContent = t("正在识别…");
      else if (research?.state === "failed") researchStatus.textContent = t("识别失败：{message}", { message: FCI18n.translateMessage(research.message) });
      if (rom.manifestError) { researchStatus.textContent = t("资料需更新：{manifestError}", { manifestError: FCI18n.translateMessage(rom.manifestError) }); researchStatus.classList.add("error"); }
      const edit = document.createElement("button"); edit.type = "button"; edit.textContent = t("编辑"); edit.onclick = () => openSourceEditor(rom.id);
      content.append(system, title, details, path, researchStatus, edit); item.append(select, cover, content); list.append(item);
    }
    if (!roms.length) list.innerHTML = t("<p class=\"muted\">没有符合当前筛选条件的游戏。</p>");
    updateBulkControls();
    if (scrollToList) section.scrollIntoView({ block: "start" });
    return true;
  } catch (error) {
    if (error.status === 401) { requestToken(); return; }
    section.hidden = false; managed.hidden = true; $("#source-rom-count").textContent = error.message; $("#source-rom-list").replaceChildren(); $("#source-pagination").hidden = true;
    showLoadFailure(error.message);
  }
}
// 首页 / 上一页 / 1 … 4 5 [6] 7 8 … 40 / 下一页 / 末页. Hidden for an empty
// list or a single page. Page arithmetic lives in pagination.js.
function renderSourcePagination({ focusPage = false } = {}) {
  const nav = $("#source-pagination");
  const info = FCPagination.pageInfo(state.sourceOffset, state.sourceLimit, state.sourceTotal);
  $("#source-page-size").value = String(state.sourceLimit);
  if (info.pageCount <= 1) { nav.hidden = true; return; }
  nav.hidden = false;
  $("#source-page-summary").textContent = t("第 {page} / {pageCount} 页，共 {total} 个游戏", { page: info.page, pageCount: info.pageCount, total: info.total });
  const jump = $("#source-page-jump"); jump.max = String(info.pageCount); jump.placeholder = String(info.page);
  const buttons = $("#source-page-buttons"); buttons.replaceChildren();
  const add = (text, page, label, className, disabled = false) => {
    const button = document.createElement("button"); button.type = "button"; button.className = `page-button ${className}`;
    button.textContent = text; button.setAttribute("aria-label", label); button.disabled = disabled;
    if (!disabled) button.onclick = () => goToSourcePage(page);
    buttons.append(button); return button;
  };
  add(t("首页"), 1, t("首页"), "page-edge", info.page <= 1);
  add(t("上一页"), info.page - 1, t("上一页"), "page-step", info.page <= 1);
  let current = null;
  for (const item of FCPagination.pageItems(info.page, info.pageCount)) {
    if (item === "gap") { const gap = document.createElement("span"); gap.className = "page-gap"; gap.textContent = "…"; gap.setAttribute("aria-hidden", "true"); buttons.append(gap); continue; }
    const isCurrent = item === info.page;
    const button = add(String(item), item, t("第 {item} 页", { item: item }), isCurrent ? "page-number current" : "page-number");
    if (isCurrent) { button.setAttribute("aria-current", "page"); button.onclick = null; current = button; }
  }
  add(t("下一页"), info.page + 1, t("下一页"), "page-step", info.page >= info.pageCount);
  add(t("末页"), info.pageCount, t("末页，第 {pageCount} 页", { pageCount: info.pageCount }), "page-edge", info.page >= info.pageCount);
  // Buttons were rebuilt; keep keyboard focus in the bar on the new page.
  if (focusPage && current) current.focus({ preventScroll: true });
}
function goToSourcePage(page) {
  const info = FCPagination.pageInfo((Math.max(1, page) - 1) * state.sourceLimit, state.sourceLimit, state.sourceTotal);
  state.sourceOffset = info.offset;
  loadSourceROMs({ scrollToList: true, focusPage: true });
}
function renderGames() {
  const root = $("#games"); root.replaceChildren();
  const query = $("#search").value.trim().toLocaleLowerCase();
  const games = state.catalog.games.filter(game => !query || [game.title, game.chineseTitle, game.originalName, game.system, game.arcadeHardware, game.category].join(" ").toLocaleLowerCase().includes(query))
    .sort((left, right) => Date.parse(right.createdAt || 0) - Date.parse(left.createdAt || 0));
  $("#game-count").textContent = query ? t("找到 {length} / {length2} 个游戏", { length: games.length, length2: state.catalog.games.length }) : t("共 {length} 个游戏", { length: games.length });
  for (const game of games) {
    const node = $("#game-template").content.cloneNode(true);
    const cover = node.querySelector(".cover"); cover.style = coverStyle(game); cover.textContent = game.coverURL ? "" : systemLabel(game).toUpperCase();
    node.querySelector(".system").textContent = systemLabel(game);
    node.querySelector("h3").textContent = displayName(game);
    node.querySelector(".details").textContent = [categoryOptions.includes(game.category) ? t(game.category) : game.category, game.system === "nes" ? `Mapper ${game.mapper ?? 0}` : null, formatBytes(game.bytes)].filter(Boolean).join(" · ");
    node.querySelector(".filename").textContent = game.originalName;
    node.querySelector(".edit").onclick = () => openEditor(game.id);
    root.append(node);
  }
  if (!games.length) root.innerHTML = `<p class="empty-state muted">${state.catalog.games.length ? t("没有找到匹配的游戏。") : t("上传 ROM 或扫描投放目录即可开始。")}</p>`;
}
async function uploadROMs(files) {
  if (!files.length) return;
  if (state.uploading) { showNotice(t("正在上传，请等待当前批次完成。"), true); return; }
  state.uploading = true;
  const results = [];
  try {
    let index = 0;
    for (const file of files) {
      index += 1;
      setStatus("#upload-status", files.length > 1 ? t("正在上传 {name}…（{index}/{length}）", { name: file.name, index: index, length: files.length }) : t("正在上传 {name}…", { name: file.name }));
      try {
        const result = await uploadROMWithDeclarations(file);
        if (!result) { results.push(t("{name}（未声明，已跳过）", { name: file.name })); continue; }
        retainUploadWarnings(file.name, result.warnings);
        results.push(["neoGeoBIOS", "fdsBIOS", "gbaBIOS", "ps1BIOS", "megaCDBIOS", "sega32xBIOS", "neoGeoPocketBIOS", "pcEngineCDBIOS", "snesIPL", "snesNECDSPFirmware", "snesCoprocessorFirmware", "pgmBIOS", "atari5200BIOS", "atari7800Firmware"].includes(result.kind) ? t("{name}（固件已验证）", { name: file.name })
          : result.kind === "cps3CD" ? t("{name}（CPS3 光盘 {volumeID} 已保存）", { name: file.name, volumeID: result.volumeID })
          : result.kind === "cps3BIOS" ? t("{name}（CPS3 卡带 BIOS 已保存）", { name: file.name }) : result.duplicate ? t("{name}（已存在）", { name: file.name }) : t("{name}（已加入）", { name: file.name }));
      }
      catch (error) { results.push(t("{name}（{message}）", { name: file.name, message: error.message })); }
    }
  } finally { state.uploading = false; }
  setStatus("#upload-status", results.join(t("；"))); await load();
}

// An Atari image that cannot state its TV standard / board / controllers is
// answered with `atariDeclaration`; ask the uploader and retry with the chosen
// query. Null when the uploader skips the file.
async function uploadROMWithDeclarations(file) {
  let query = "";
  for (let attempt = 0; ; attempt += 1) {
    try {
      return await api(`/api/upload?name=${encodeURIComponent(file.name)}${query ? `&${query}` : ""}`, { method: "POST", body: file });
    } catch (error) {
      if (!error.atariDeclaration || attempt >= 3 || !window.FCAtariDeclaration) throw error;
      const chosen = await requestAtariDeclaration(file.name, error.message, error.atariDeclaration);
      if (chosen == null) return null;
      query = chosen;
    }
  }
}
function requestAtariDeclaration(fileName, message, declaration) {
  const A = window.FCAtariDeclaration;
  return new Promise(resolve => {
    const dialog = $("#atari-dialog"), form = $("#atari-form"), root = $("#atari-fields"), missing = $("#atari-missing");
    $("#atari-heading").textContent = t("声明 {value1} 卡带", { value1: A.systemLabel(declaration.system) });
    $("#atari-file").textContent = declaration.knownCart
      ? t("{fileName}\n已知卡带：{description}（MAME {softlist}/{name}）", { fileName: fileName, description: declaration.knownCart.description, softlist: declaration.knownCart.softlist, name: declaration.knownCart.name })
      : fileName;
    $("#atari-message").textContent = FCI18n.translateMessage(message);
    missing.hidden = true; root.replaceChildren();
    const controls = {};
    const select = (options, preselected, label) => {
      const node = document.createElement("select"); node.setAttribute("aria-label", t(label));
      const placeholder = document.createElement("option"); placeholder.value = ""; placeholder.textContent = t("请选择…");
      node.append(placeholder);
      for (const option of options) { const item = document.createElement("option"); item.value = option.value; item.textContent = t(option.label); node.append(item); }
      node.value = preselected || ""; return node;
    };
    for (const field of A.declarationFields(declaration, fileName)) {
      const box = document.createElement("fieldset");
      const legend = document.createElement("legend"); legend.textContent = field.required ? t(field.label) : t("{label}（可改）", { label: t(field.label) }); box.append(legend);
      if (field.kind === "ports") {
        const ports = document.createElement("div"); ports.className = "atari-ports";
        controls[field.parameter] = field.ports.map(port => {
          const label = document.createElement("label"); label.textContent = t(port.label);
          const node = select(port.options, port.preselected, port.label); label.append(node); ports.append(label); return node;
        });
        box.append(ports);
      } else {
        const node = select(field.options, field.preselected, field.label);
        controls[field.parameter] = node; box.append(node);
      }
      if (field.hint) { const hint = document.createElement("p"); hint.className = "atari-hint"; hint.textContent = t(field.hint); box.append(hint); }
      root.append(box);
    }
    const selections = () => Object.fromEntries(Object.entries(controls).map(([key, node]) => [key, Array.isArray(node) ? node.map(item => item.value) : node.value]));
    const finish = value => { form.onsubmit = null; $("#atari-cancel").onclick = null; dialog.oncancel = null; dialog.onclose = null; if (dialog.open) dialog.close(); resolve(value); };
    form.onsubmit = event => {
      event.preventDefault();
      const result = A.declarationQuery(declaration, selections());
      if (result.query == null) { missing.textContent = t("请先选择：{value1}。", { value1: result.missing.join(t("、")) }); missing.hidden = false; return; }
      finish(result.query);
    };
    $("#atari-cancel").onclick = () => finish(null);
    dialog.oncancel = event => { event.preventDefault(); finish(null); };
    dialog.onclose = () => finish(null);
    dialog.showModal();
  });
}

async function uploadNeoGeoBIOS(file) {
  if (!file) return;
  if (file.name.toLowerCase() !== "neogeo.zip") {
    renderNeoGeoBIOSStatus({ configured: true, valid: false, error: t("文件必须命名为 neogeo.zip") });
    return;
  }
  const node = $("#bios-status"); node.textContent = t("正在上传并校验 Neo Geo 系统 BIOS 组件…"); node.classList.remove("error");
  try {
    const status = await api(`/api/neogeo-bios?name=${encodeURIComponent(file.name)}`, { method: "POST", body: file });
    renderNeoGeoBIOSStatus(status);
    showNotice(t("Neo Geo 系统 BIOS 已验证并写入私人资料库。"));
  } catch (error) {
    renderNeoGeoBIOSStatus({ configured: true, valid: false, error: error.message });
  } finally {
    $("#bios-upload").value = "";
  }
}
async function uploadFDSBIOS(file) {
  if (!file) return;
  if (file.name.toLowerCase() !== "disksys.rom") {
    renderFDSBIOSStatus({ configured: true, valid: false, error: t("文件必须命名为 disksys.rom") });
    return;
  }
  const node = $("#fds-bios-status"); node.textContent = t("正在按 MAME 身份校验 8 KiB BIOS…"); node.classList.remove("error");
  try {
    const status = await api(`/api/fds-bios?name=${encodeURIComponent(file.name)}`, { method: "POST", body: file });
    renderFDSBIOSStatus(status);
    showNotice(t("FDS BIOS 已验证并写入私人资料库。"));
  } catch (error) {
    renderFDSBIOSStatus({ configured: true, valid: false, error: error.message });
  } finally {
    $("#fds-bios-upload").value = "";
  }
}
async function uploadPGMBIOS(file) {
  if (!file) return;
  if (file.name.toLowerCase() !== "pgm.zip") {
    renderPGMBIOSStatus({ configured: true, valid: false, error: t("文件必须命名为 pgm.zip") });
    return;
  }
  const node = $("#pgm-bios-status"); node.textContent = t("正在上传并校验三个 PGM 主机组件…"); node.classList.remove("error");
  try {
    const status = await api(`/api/pgm-bios?name=${encodeURIComponent(file.name)}`, { method: "POST", body: file });
    renderPGMBIOSStatus(status);
    showNotice(t("PGM 主机 BIOS 已验证并写入私人资料库。"));
  } catch (error) {
    renderPGMBIOSStatus({ configured: true, valid: false, error: error.message });
  } finally {
    $("#pgm-bios-upload").value = "";
  }
}
async function uploadSNESIPL(file) {
  if (!file) return;
  if (file.name.toLowerCase() !== "spc700.rom") {
    renderSNESIPLStatus({ configured: true, valid: false, error: t("文件必须命名为 spc700.rom") });
    return;
  }
  const node = $("#snes-ipl-status"); node.textContent = t("正在校验 64 字节 SPC700 IPL…"); node.classList.remove("error");
  try {
    const status = await api(`/api/snes-ipl?name=${encodeURIComponent(file.name)}`, { method: "POST", body: file });
    renderSNESIPLStatus(status);
    showNotice(t("Super NES SPC700 IPL 已验证并写入私人资料库。"));
  } catch (error) {
    renderSNESIPLStatus({ configured: true, valid: false, error: error.message });
  } finally {
    $("#snes-ipl-upload").value = "";
  }
}
async function uploadSNESDSPFirmware(file) {
  if (!file) return;
  const directFirmware = /^(?:cx4|(?:dsp[1-4]b?|st01[018])(?:\.(?:program|data))?)\.rom$/.test(file.name.toLowerCase());
  const originalArchive = /^(?:cx4|dsp[1-4]b?|st01[018])(?:\s+\([^()]*\))+\.zip$/i.test(file.name)
    && /\(\s*enhancement chip\s*\)/i.test(file.name);
  if (!directFirmware && !originalArchive) {
    renderSNESDSPStatus({ [file.name]: { configured: true, valid: false, error: t("文件须为原始的 (World) (Enhancement Chip).zip，或命名为 dsp1/1b/2/3/4.rom、cx4.rom、st010/011/018.rom，或 DSP/ST 的 .program.rom / .data.rom 两半") } });
    return;
  }
  const node = $("#snes-dsp-status"); node.textContent = t("正在校验 {name}…", { name: file.name }); node.classList.remove("error");
  try {
    const endpoint = originalArchive ? "/api/upload" : "/api/snes-coprocessor-firmware";
    await api(`${endpoint}?name=${encodeURIComponent(file.name)}`, { method: "POST", body: file });
    renderSNESDSPStatus(await api("/api/snes-coprocessor-firmware"));
    showNotice(t("Super NES {name} 已验证并写入私人资料库。", { name: file.name }));
  } catch (error) {
    renderSNESDSPStatus({ [file.name]: { configured: true, valid: false, error: error.message } });
  } finally {
    $("#snes-dsp-upload").value = "";
  }
}
async function saveSettings() {
  try {
    const payload = settingsPayload();
    await api("/api/settings", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    if (payload.managementToken.trim()) { state.token = payload.managementToken.trim(); writeSessionToken(state.token); }
    setStatus("#settings-status", t("已保存。")); await load(); $("#settings-dialog").close();
  }
  catch (error) { setStatus("#settings-status", error.message, true); }
}
// Several reads can be refused at once; ask for the token once.
async function requestToken() { if ($("#action-dialog").open) return; const token = await requestAction(t("这个服务器启用了访问令牌。请输入管理 Token："), { heading: t("服务器认证"), input: true, initial: state.token }); if (token != null) { state.token = token.trim(); writeSessionToken(state.token); load(); } }

function displaySourceLabel(source) {
  return ["手工编辑", "文件名解析", "本地 ROM 识别"].includes(source) ? t(source) : source;
}

function renderFieldLocks(game) {
  const form = $("#editor-form");
  for (const node of form.querySelectorAll(".field-lock")) node.remove();
  if (!game.sourceID) return;
  for (const name of ["title", "chineseTitle", "mapper", "players", "region", "releaseYear", "sortTitle", "description", "englishDescription"]) {
    const field = form.elements[name]; const label = field?.closest("label"); if (!label) continue;
    const locked = Boolean(game.fieldLocks?.[name]); const source = displaySourceLabel(game.fieldSources?.[name]) || t("未记录来源");
    const button = document.createElement("button"); button.type = "button"; button.className = `field-lock ${locked ? "locked" : ""}`;
    button.textContent = locked ? t("已锁定") : t("允许自动更新"); button.title = t("资料来源：{source}。点击{value2}。", { source: source, value2: locked ? t("解除锁定") : t("锁定") });
    button.onclick = async event => {
      event.preventDefault(); const fieldLocks = { ...(state.selected.fieldLocks || {}), [name]: !locked };
      try {
        const updated = await api(selectedAPI(), { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fieldLocks }) });
        state.selected = { ...state.selected, ...updated, fieldLocks }; renderFieldLocks(state.selected);
      } catch (error) { setStatus("#cover-search-status", error.message, true); }
    };
    label.append(button);
  }
}

function updateCPS3KeyField(game) {
  const form = $("#editor-form");
  const required = Boolean(game?.cps3KeyRequired);
  $("#cps3-key-field").hidden = !required;
  form.elements.cps3Key.disabled = !required;
  form.elements.cps3Key.value = required ? game.cps3Key || "" : "";
  const hints = { "server-table": t("安装时由服务端 key 表写入 manifest.json。"), manual: t("已手工填写，并用游戏包内的 BIOS 校验通过。"), missing: t("缺少 key：填写后用游戏包内的 BIOS 校验。") };
  $("#cps3-key-hint").textContent = hints[game?.cps3KeyStatus] || hints.missing;
}

function updatePS1AnalogField(game) {
  const form = $("#editor-form");
  const editable = Boolean(game?.sourceID && game.system === "playStation" && form.elements.system.value === "playStation");
  $("#ps1-analog-field").hidden = !editable;
  form.elements.ps1AnalogPad.disabled = !editable;
  form.elements.ps1AnalogPad.checked = editable && game.ps1AnalogPad === true;
}

function updateCPS2KeyField(game) {
  const form = $("#editor-form");
  const input = form.elements.cps2Key;
  const required = Boolean(game?.cps2KeyRequired && form.elements.system.value === "arcade");
  input.disabled = !required;
  if (!required) input.value = "";
  else if (document.activeElement !== input) input.value = game.cps2Key || "";
  const hints = {
    archive: t("已从 ROM ZIP 自动检测；保存后会写入私人 manifest.json。"),
    verified: t("ROM ZIP 与 manifest.json 中的 key 完全一致。"),
    builtin: t("已由私人 Web 服务内置表自动匹配，并写入当前资料库的 manifest.json。"),
    manifest: t("已从私人 manifest.json 读取并通过驱动 CRC 校验。"),
    manual: t("已填写并通过驱动 CRC 校验。"),
    missing: t("该 CPS2 驱动需要 key，请填写 40 个十六进制字符。"),
    "manual-required": t("该压缩格式无法自动读取 key，请填写 40 个十六进制字符。")
  };
  $("#cps2-key-hint").textContent = required ? (hints[game.cps2KeyStatus] || hints.missing) : t("当前驱动不需要 key。");
}

function openEditorFor(game) {
  state.selected = game;
  const form = $("#editor-form"); $("#editor-heading").textContent = displayName(game);
  for (const name of ["title", "chineseTitle", "mapper", "players", "region", "releaseYear", "sortTitle", "description", "englishDescription"]) form.elements[name].value = game[name] ?? "";
  form.elements.collections.value = (game.collections || []).join(", ");
  form.elements.system.value = game.system;
  form.elements.cps2Key.value = game.cps2Key || "";
  updateCPS2KeyField(game);
  updateCPS3KeyField(game);
  updatePS1AnalogField(game);
  form.elements.category.replaceChildren(...categoryOptions.map(value => new Option(t(value), value, false, value === game.category)));
  const preview = $("#cover-preview"); preview.style = coverStyle(game); preview.textContent = game.coverURL ? "" : t("无封面");
  $("#artwork-summary").textContent = [game.artwork?.backdrop ? t("背景") : null, game.artwork?.logo ? "Logo" : null].filter(Boolean).join(" · ") || t("尚未添加背景或 Logo");
  const mapperInfo = game.system === "nes" ? t("\nMapper：{value1}", { value1: game.mapper ?? 0 }) : "";
  const fingerprint = game.crc32 ? ` · CRC32 ${game.crc32}` : "";
  const headerInfo = game.romInfo?.internalTitle ? t("\nROM 内部标题：{internalTitle}", { internalTitle: game.romInfo.internalTitle }) : "";
  const confidence = game.research?.confidence ? t("\n联网识别：{value1}% · {value2}", { value1: Math.round(game.research.confidence * 100), value2: displaySourceLabel(game.research.source) || "" }) : "";
  $("#file-info").textContent = `${game.originalName}\n${formatBytes(game.bytes)}${fingerprint} · SHA-256 ${game.sha256}${mapperInfo}${headerInfo}${confidence}`;
  const sourceGame = Boolean(game.sourceID), immutableDriverName = hasImmutableArcadeDriverName(game), renameButton = $("#rename-rom");
  $("#identify-game").hidden = false; $("#search-cover").hidden = false; $("#search-diagnostic").hidden = !sourceGame; $("#search-diagnostic-output").hidden = true;
  renameButton.hidden = !sourceGame; renameButton.disabled = immutableDriverName; renameButton.title = immutableDriverName ? t("街机驱动包依赖原始 ZIP / 7z 文件名，不能重命名。") : "";
  setStatus("#cover-search-status", sourceGame ? t("编辑的是当前资料库的 manifest.json；联网识别或封面搜索会直接更新该游戏包。") : t("封面搜索会自动采用最匹配的海报并直接保存。"));
  $("#candidate-list").replaceChildren();
  renderFieldLocks(game);
  $("#editor").showModal();
}
async function openEditor(id) {
  const game = state.catalog.games.find(item => item.id === id); if (game) openEditorFor(game);
}
async function openSourceEditor(id) {
  try { openEditorFor(await api(`/api/source-roms/${encodeURIComponent(id)}`)); }
  catch (error) { showNotice(error.message, true); }
}
async function saveGame(event) {
  if (event.submitter?.id !== "save-game") return;
  event.preventDefault(); if (!state.selected) return;
  try {
    const input = Object.fromEntries(new FormData(event.currentTarget));
    // A checkbox is in the form data only when ticked; send the PlayStation
    // mark as a boolean, and only for a game that has it.
    const analog = event.currentTarget.elements.ps1AnalogPad;
    if (analog.disabled) delete input.ps1AnalogPad; else input.ps1AnalogPad = analog.checked;
    const endpoint = state.selected.sourceID ? `/api/source-roms/${encodeURIComponent(state.selected.sourceID)}` : `/api/games/${encodeURIComponent(state.selected.id)}`;
    await api(endpoint, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(input) });
    $("#editor").close(); await load();
  } catch (error) { showNotice(error.message, true); }
}
async function deleteGame() {
  if (!state.selected) return;
  const name = displayName(state.selected);
  if (!await requestAction(t("确定删除「{name}」吗？\nROM、封面和该游戏的资料文件都会从当前资料库移除。", { name: name }), { heading: t("删除游戏"), danger: true })) return;
  try {
    await api(selectedAPI(), { method: "DELETE" });
    $("#editor").close(); await load();
  } catch (error) { showNotice(error.message, true); }
}
function refreshEditorArtwork(updated) {
  if (!state.selected || !updated) return;
  const next = { ...state.selected };
  if (Object.hasOwn(updated, "coverURL")) next.coverURL = updated.coverURL;
  if (Object.hasOwn(updated, "coverVersion")) next.coverVersion = updated.coverVersion;
  if (updated.cover && typeof updated.cover === "object") {
    next.cover = updated.cover;
    next.coverVersion = updated.cover.sha256 || next.coverVersion;
  }
  if (updated.artwork && typeof updated.artwork === "object") next.artwork = updated.artwork;
  state.selected = next;
  const preview = $("#cover-preview"); preview.style = coverStyle(next); preview.textContent = next.coverURL ? "" : t("无封面");
  $("#artwork-summary").textContent = [next.artwork?.backdrop ? t("背景") : null, next.artwork?.logo ? "Logo" : null].filter(Boolean).join(" · ") || t("尚未添加背景或 Logo");
  if (next.sourceID && next.coverURL) {
    const listed = state.sourceRoms.find(game => game.id === next.sourceID);
    if (listed) { listed.hasCover = true; listed.coverVersion = next.coverVersion || ""; }
  }
}
async function uploadCover(file) {
  if (!file || !state.selected) return;
  const sourceID = state.selected.sourceID;
  const endpoint = sourceID ? `/api/source-roms/${encodeURIComponent(sourceID)}/cover` : `/api/games/${encodeURIComponent(state.selected.id)}/cover`;
  try {
    const updated = await api(`${endpoint}?name=${encodeURIComponent(file.name)}`, { method: "POST", body: file });
    refreshEditorArtwork(updated);
  }
  catch (error) { showNotice(error.message, true); }
}
async function uploadArtwork(type, file) {
  if (!file || !state.selected?.sourceID) return;
  try {
    const updated = await api(`${selectedAPI(`artwork/${type}`)}?name=${encodeURIComponent(file.name)}`, { method: "POST", body: file });
    refreshEditorArtwork(updated);
  } catch (error) { setStatus("#cover-search-status", error.message, true); }
}
function showCoverCandidates(response) {
  const list = $("#candidate-list"); list.replaceChildren();
  for (const candidate of response.candidates || []) {
    const candidateButton = document.createElement("button"); candidateButton.type = "button"; candidateButton.className = "candidate";
    candidateButton.style.backgroundImage = `url(${assetURL(selectedAPI(`cover-search/${encodeURIComponent(candidate.id)}/preview`))})`;
    candidateButton.title = t("{title}\n来源：{source}", { title: candidate.title, source: candidate.source });
    candidateButton.setAttribute("aria-label", t("使用封面：{title}", { title: candidate.title }));
    candidateButton.onclick = async () => {
      await applyWebCoverCandidate(candidate);
    };
    list.append(candidateButton);
  }
}
async function applyWebCoverCandidate(candidate, automatically = false) {
  if (!state.selected) return;
  const updated = await api(selectedAPI(`cover-search/${encodeURIComponent(candidate.id)}/select`), { method: "POST" });
  refreshEditorArtwork(updated);
  setStatus("#cover-search-status", t("{value1}封面：{title}。", { value1: automatically ? t("已自动采用") : t("已采用"), title: candidate.title }));
}
async function searchCover() {
  if (!state.selected) return;
  const searchButton = $("#search-cover"); searchButton.disabled = true; setStatus("#cover-search-status", deepSeekReady() ? t("正在优先检索已配置的封面站点；未命中时才使用一次 DeepSeek Web Search（{value1}）…", { value1: searchScopeText() }) : t("DeepSeek 未配置；正在直接检索 LaunchBox 和 Internet Archive 等公开优先站点…"));
  try {
    const response = await api(selectedAPI("cover-search"), { method: "POST" });
    const searchPlace = response.fallbackUsed ? t("优先站点未命中后在公开网页") : t("优先站点中");
    if (response.candidates?.length) {
      // The server returns candidates in verified best-first order.  Searching
      // for a cover is an explicit replacement action, so apply the first one
      // immediately instead of asking through a browser confirm dialog.
      await applyWebCoverCandidate(response.candidates[0], true);
    } else {
      setStatus("#cover-search-status", response.localFallback ? response.message : t("优先站点和公开网页均未找到可用海报候选（{searchPlace}）。", { searchPlace: searchPlace }));
    }
  } catch (error) { setStatus("#cover-search-status", error.message, true); }
  finally { searchButton.disabled = false; }
}
async function identifyGame() {
  if (!state.selected) return;
  const identifyButton = $("#identify-game"); identifyButton.disabled = true; setStatus("#cover-search-status", deepSeekReady() ? t("正在通过 DeepSeek Web Search 识别资料；会先查优先站点，必要时在同一次搜索中回退公开网页（{value1}）…", { value1: searchScopeText() }) : t("DeepSeek 未配置；正在从公开站点抓取规范标题、年份、人数、英文说明和封面…"));
  try {
    const response = await api(selectedAPI("metadata-search"), { method: "POST" });
    const metadata = response.metadata || {};
    // Research is a draft: expose it immediately so the user can inspect or
    // correct every field.  The existing form's Save button remains the sole
    // action that writes metadata back to the library.
    const form = $("#editor-form");
    for (const name of ["title", "chineseTitle", "region", "releaseYear", "players", "sortTitle", "description", "englishDescription"]) {
      if (metadata[name] != null && form.elements[name]) form.elements[name].value = metadata[name];
    }
    if (["nes", "megaDrive", "sega32x", "masterSystem", "gameGear", "gameBoy", "gameBoyColor", "gameBoyAdvance", "wonderSwan", "neoGeoPocket", "pcEngine", "pcEngineCD", "playStation", "megaCD", "neoGeo", "arcade"].includes(metadata.system)) form.elements.system.value = metadata.system;
    if (categoryOptions.includes(metadata.category)) form.elements.category.value = metadata.category;
    showCoverCandidates(response);
    const filled = Object.keys(metadata).length;
    setStatus("#cover-search-status", response.localFallback ? response.message : (response.candidates?.length ? t("已将 {filled} 项识别结果填入表单，并找到 {length} 张封面候选{value3}。检查后点击“保存”才会写入资料库。", { filled: filled, length: response.candidates.length, value3: response.fallbackUsed ? t("（已启用公开网页后备搜索）") : "" }) : t("已将 {filled} 项识别结果填入表单；优先站点及公开网页均没有可用海报。检查后点击“保存”才会写入资料库。", { filled: filled }) ));
  } catch (error) { setStatus("#cover-search-status", error.message, true); }
  finally { identifyButton.disabled = false; }
}
async function showSearchDiagnostic() {
  if (!state.selected?.sourceID) return;
  const output = $("#search-diagnostic-output");
  try {
    const response = await api(selectedAPI("search-diagnostic"));
    const diagnostic = response.diagnostic;
    output.hidden = false;
    output.textContent = diagnostic ? [
      t("时间：{value1}", { value1: diagnostic.checkedAt || t("未知") }), t("HTTP：{value1}", { value1: diagnostic.httpStatus ?? t("未知") }), t("状态：{value1}", { value1: diagnostic.responseStatus || t("未知") }),
      diagnostic.error ? t("错误：{error}", { error: diagnostic.error }) : null, diagnostic.outputText ? t("输出：{outputText}", { outputText: diagnostic.outputText }) : null,
      ...(diagnostic.stages || []).map(stage => t("阶段：{name} · {durationMs} ms{value3}", { name: stage.name, durationMs: stage.durationMs, value3: stage.candidates != null ? t(" · {candidates} 个候选", { candidates: stage.candidates }) : "" })),
      ...(diagnostic.output || []).map(item => `${item.type || "output"} / ${item.status || "unknown"}${item.text ? `\n${item.text}` : ""}`)
    ].filter(Boolean).join("\n\n") : t("该游戏还没有 DeepSeek 搜索诊断；公开站点直查不会产生 DeepSeek 诊断。");
  } catch (error) { setStatus("#cover-search-status", error.message, true); }
}
async function renameROM() {
  if (!state.selected?.sourceID) return;
  if (hasImmutableArcadeDriverName(state.selected)) { showNotice(t("街机驱动包必须保留原始文件名，不能重命名。"), true); return; }
  if (!await requestAction(t("将 ROM 重命名为不含空格的英文名称，保留扩展名。\n\n当前：") + state.selected.originalName, { heading: t("重命名 ROM") })) return;
  const button = $("#rename-rom"); button.disabled = true;
  try {
    const game = await api(selectedAPI("rename-rom"), { method: "POST" });
    state.selected = game;
    await loadSourceROMs();
    await openEditor(game.id);
  } catch (error) { setStatus("#cover-search-status", error.message, true); }
  finally { button.disabled = false; }
}
async function showHistory() {
  if (!state.selected?.sourceID) return;
  try {
    const response = await api(selectedAPI("history")); const entries = response.entries || [];
    if (!entries.length) { setStatus("#cover-search-status", t("尚没有可恢复的资料历史。 ")); return; }
    const selected = await requestAction(t("输入要恢复的序号：\n\n{value1}", { value1: entries.map((entry, index) => `${index + 1}. ${new Date(entry.createdAt).toLocaleString(FCI18n.language)} · ${entry.action}`).join("\n") }), { heading: t("资料历史"), input: true });
    const index = Number(selected) - 1;
    if (!Number.isInteger(index) || !entries[index]) return;
    if (!await requestAction(t("恢复到这条历史记录？\n{action}", { action: entries[index].action }), { heading: t("恢复资料") })) return;
    const game = await api(selectedAPI(`history/${encodeURIComponent(entries[index].id)}/restore`), { method: "POST" });
    await load(); await openSourceEditor(game.id);
  } catch (error) { setStatus("#cover-search-status", error.message, true); }
}
async function browseDirectory(path) {
  const query = path ? `?path=${encodeURIComponent(path)}` : "";
  const response = await api(`/api/directories${query}`);
  state.browsedDirectory = response.path;
  $("#directory-path").textContent = response.path;
  $("#directory-up").disabled = !response.parent;
  $("#directory-up").onclick = () => response.parent && browseDirectory(response.parent);
  const list = $("#directory-list"); list.replaceChildren();
  for (const directory of response.directories) {
    const button = document.createElement("button"); button.type = "button"; button.className = "directory-entry"; button.textContent = directory.name;
    button.onclick = () => browseDirectory(directory.path); list.append(button);
  }
  if (!response.directories.length) list.innerHTML = t("<p class=\"muted\">此目录没有可浏览的子目录。</p>");
}
async function openDirectoryBrowser() {
  try { await browseDirectory($("#source-directory").value.trim()); $("#directory-browser").showModal(); }
  catch (error) { setStatus("#settings-status", error.message, true); }
}

async function startAudit(full) {
  const button = full ? $("#full-audit") : $("#quick-audit"); button.disabled = true;
  try {
    const response = await api("/api/source-audit", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ full }) });
    setStatus("#upload-status", t("{title}已加入后台任务。", { title: response.task.title })); await loadDashboard();
  } catch (error) { setStatus("#upload-status", error.message, true); }
  finally { button.disabled = false; }
}

async function repairMissingMetadata() {
  const summary = state.health?.summary;
  const count = (summary?.incompleteMetadata || 0) + (summary?.missingCover || 0);
  if (!count) { setStatus("#upload-status", t("没有需要自动补全的游戏。 ")); return; }
  if (!await requestAction(t("将把缺少资料或封面的游戏加入后台自动补全队列。\n\n当前约有 {count} 项缺失（同一游戏可能同时缺资料和封面）。\n任务会按缺失字段处理；优先站点未命中时才使用 DeepSeek。已有资料和封面不会被覆盖。", { count: count }), { heading: t("自动补全资料") })) return;
  const button = $("#repair-missing"); button.disabled = true;
  try {
    const response = await api("/api/source-repair", { method: "POST" });
    setStatus("#upload-status", t("{title}已加入后台任务，可继续使用网站。", { title: response.task.title })); await load();
  } catch (error) { setStatus("#upload-status", error.message, true); }
  finally { button.disabled = false; }
}

async function runBulk(action) {
  const ids = [...state.selectedSourceIDs]; if (!ids.length) return;
  if (action === "delete" && !await requestAction(t("确定删除选中的 {length} 个游戏吗？\nROM、封面和 manifest 都会从当前资料库移除。", { length: ids.length }), { heading: t("批量删除"), danger: true })) return;
  const button = action === "research" ? $("#bulk-research") : $("#bulk-delete"); button.disabled = true;
  try {
    const response = await api("/api/source-roms/bulk", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action, ids }) });
    state.selectedSourceIDs.clear(); updateBulkControls();
    setStatus("#bulk-status", t("{title}已加入后台任务。", { title: response.task.title })); await load();
  } catch (error) { setStatus("#bulk-status", error.message, true); }
  finally { button.disabled = false; }
}

$("#rom-upload").addEventListener("change", event => uploadROMs([...event.target.files]));
$("#bios-upload").addEventListener("change", event => uploadNeoGeoBIOS(event.target.files[0]));
$("#neogeo-bios-option").addEventListener("change", saveNeoGeoBIOSPreference);
$("#neogeo-system").addEventListener("change", saveNeoGeoBIOSPreference);
$("#fds-bios-upload").addEventListener("change", event => uploadFDSBIOS(event.target.files[0]));
$("#atari5200-bios-upload").addEventListener("change", event => uploadAtari5200BIOS(event.target.files[0]));
for (const role of Object.keys(ATARI7800_ROLE_LABELS)) $(`#atari7800-${role}-upload`).addEventListener("change", event => uploadAtari7800Firmware(event.target.files[0], role));
$("#upload-warnings-bios").onclick = () => { location.hash = "bios"; showView("bios"); };
$("#upload-warnings-dismiss").onclick = () => { $("#upload-warnings-list").replaceChildren(); $("#upload-warnings").hidden = true; };
$("#gba-bios-upload").addEventListener("change", event => uploadGBABIOS(event.target.files[0]));
$("#ps1-bios-upload").addEventListener("change", event => uploadPS1BIOS(event.target.files[0]));
$("#megacd-bios-upload").addEventListener("change", event => uploadMegaCDBIOS(event.target.files[0]));
$("#sega32x-bios-upload").addEventListener("change", event => uploadSega32XBIOS(event.target.files[0]));
$("#neogeopocket-bios-upload").addEventListener("change", event => uploadNeoGeoPocketBIOS(event.target.files[0]));
$("#neogeopocket-nvram-mono-upload").addEventListener("change", event => uploadNeoGeoPocketNVRAMMono(event.target.files[0]));
$("#neogeopocket-nvram-color-upload").addEventListener("change", event => uploadNeoGeoPocketNVRAMColor(event.target.files[0]));
$("#pcecd-bios-upload").addEventListener("change", event => uploadPCECDBIOS(event.target.files[0]));
$("#snes-ipl-upload").addEventListener("change", event => uploadSNESIPL(event.target.files[0]));
$("#snes-dsp-upload").addEventListener("change", event => uploadSNESDSPFirmware(event.target.files[0]));
$("#pgm-bios-upload").addEventListener("change", event => uploadPGMBIOS(event.target.files[0]));
$("#cps3-upload").addEventListener("change", event => uploadCPS3(event.target.files));

const DROP_FILE_LIMIT = 200;
const DROP_DIRECTORY_DEPTH = 8;
const BIOS_DROP_HANDLERS = { "atari5200-bios-upload": uploadAtari5200BIOS,
  ...Object.fromEntries(Object.keys(ATARI7800_ROLE_LABELS).map(role => [`atari7800-${role}-upload`, file => uploadAtari7800Firmware(file, role)])), "bios-upload": uploadNeoGeoBIOS, "fds-bios-upload": uploadFDSBIOS, "gba-bios-upload": uploadGBABIOS, "ps1-bios-upload": uploadPS1BIOS, "megacd-bios-upload": uploadMegaCDBIOS, "sega32x-bios-upload": uploadSega32XBIOS, "neogeopocket-bios-upload": uploadNeoGeoPocketBIOS, "neogeopocket-nvram-mono-upload": uploadNeoGeoPocketNVRAMMono, "neogeopocket-nvram-color-upload": uploadNeoGeoPocketNVRAMColor, "pcecd-bios-upload": uploadPCECDBIOS, "snes-ipl-upload": uploadSNESIPL, "snes-dsp-upload": uploadSNESDSPFirmware, "pgm-bios-upload": uploadPGMBIOS };
const ROM_DROP_EXTENSIONS = ($("#rom-upload").getAttribute("accept") || "").split(",").map(value => value.trim().toLowerCase()).filter(Boolean);
const BIOS_DROP_NAMES = new Set(["atari5200-bios.rom", "atari7800-bios-ntsc.rom", "atari7800-bios-pal.rom", "atari7800-highscore.rom", "neogeo.zip", "disksys.rom", "gba_bios.bin", "spc700.rom", "pgm.zip",
  "cx4.rom",
  ...["dsp1", "dsp1b", "dsp2", "dsp3", "dsp4", "st010", "st011", "st018"]
    .flatMap(base => [`${base}.rom`, `${base}.program.rom`, `${base}.data.rom`])]);

function importableDropName(name) {
  const lower = String(name).toLowerCase();
  return BIOS_DROP_NAMES.has(lower) || ROM_DROP_EXTENSIONS.some(extension => lower.endsWith(extension));
}
function draggingFiles(event) { return [...(event.dataTransfer?.types || [])].includes("Files"); }
function uploadCardOf(event) { return event.target?.closest?.(".upload") || null; }
function highlightUploadCard(card) {
  for (const node of document.querySelectorAll(".upload.dragging")) if (node !== card) node.classList.remove("dragging");
  card?.classList.add("dragging");
}
function showDropOverlay(visible) { $("#drop-overlay").hidden = !visible; if (!visible) highlightUploadCard(null); }

function readDirectoryBatch(reader) { return new Promise((resolve, reject) => reader.readEntries(resolve, reject)); }
async function collectDropEntry(entry, collected, depth = 0) {
  if (!entry || collected.files.length >= DROP_FILE_LIMIT) { if (entry) collected.truncated = true; return; }
  if (entry.isFile) { collected.files.push(await new Promise((resolve, reject) => entry.file(resolve, reject))); return; }
  if (!entry.isDirectory || depth >= DROP_DIRECTORY_DEPTH) return;
  const reader = entry.createReader();
  for (;;) {
    const batch = await readDirectoryBatch(reader);
    if (!batch.length) return;
    for (const child of batch) await collectDropEntry(child, collected, depth + 1);
  }
}
// DataTransfer items are neutered once the drop handler yields, so the entries
// and the plain file list are both captured before the first await.
async function droppedFiles(transfer) {
  const entries = [...(transfer?.items || [])].map(item => item.webkitGetAsEntry?.()).filter(Boolean);
  const plain = [...(transfer?.files || [])];
  if (!entries.length) return { files: plain.slice(0, DROP_FILE_LIMIT), truncated: plain.length > DROP_FILE_LIMIT };
  const collected = { files: [], truncated: false };
  for (const entry of entries) await collectDropEntry(entry, collected);
  return collected;
}

let dropDepth = 0;
window.addEventListener("dragenter", event => { if (!draggingFiles(event)) return; dropDepth += 1; showDropOverlay(true); });
window.addEventListener("dragleave", event => { if (!draggingFiles(event)) return; dropDepth = Math.max(0, dropDepth - 1); if (!dropDepth) showDropOverlay(false); });
window.addEventListener("dragover", event => {
  if (!draggingFiles(event)) return;
  event.preventDefault();
  event.dataTransfer.dropEffect = "copy";
  highlightUploadCard(uploadCardOf(event));
});
window.addEventListener("drop", async event => {
  if (!draggingFiles(event)) return;
  event.preventDefault();
  const card = uploadCardOf(event);
  dropDepth = 0; showDropOverlay(false);
  let files = [], truncated = false;
  try { ({ files, truncated } = await droppedFiles(event.dataTransfer)); }
  catch (error) { setStatus("#upload-status", t("读取拖入的文件失败：{message}", { message: error.message }), true); return; }
  if (card?.getAttribute("for") === "cps3-upload") { await uploadCPS3(files); return; }
  const biosUpload = BIOS_DROP_HANDLERS[card?.getAttribute("for")];
  if (biosUpload) {
    if (files.length !== 1) { showNotice(t("BIOS 卡片一次只接受一个文件。"), true); return; }
    await biosUpload(files[0]);
    return;
  }
  const importable = files.filter(file => importableDropName(file.name));
  if (!importable.length) {
    setStatus("#upload-status", files.length ? t("拖入的 {length} 个文件都不是可导入的 ROM 或 BIOS。", { length: files.length }) : t("没有读取到拖入的文件。"), true);
    return;
  }
  const ignored = files.length - importable.length;
  if (truncated) showNotice(t("一次最多导入 {DROP_FILE_LIMIT} 个文件；剩余部分请再拖一次，或在设置中配置资料库目录后扫描。", { DROP_FILE_LIMIT: DROP_FILE_LIMIT }), true);
  else if (ignored) showNotice(t("已忽略 {ignored} 个非 ROM 文件。", { ignored: ignored }));
  await uploadROMs(importable);
});
$("#open-settings").onclick = () => $("#settings-dialog").showModal();
$("#search").addEventListener("input", renderGames);
$("#save-settings").onclick = saveSettings;
$("#browse-source").onclick = openDirectoryBrowser;
$("#close-browser").onclick = () => $("#directory-browser").close();
$("#use-directory").onclick = () => { if (state.browsedDirectory) $("#source-directory").value = state.browsedDirectory; $("#directory-browser").close(); };
$("#scan-source").onclick = async () => {
  const button = $("#scan-source"); button.disabled = true;
  try {
    const sourceDirectory = $("#source-directory").value.trim();
    if (!sourceDirectory) throw new Error(t("请先输入或浏览选择导入目录。"));
    setStatus("#settings-status", t("正在保存资料库目录并校验清单…"));
    await api("/api/settings", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(settingsPayload()) });
    const response = await api("/api/scan-source", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ full: false }) });
    setStatus("#settings-status", t("扫描完成：{valid} 个有效，{length} 个待处理项。", { valid: response.summary.valid, length: response.issues.length })); await load();
  } catch (error) { setStatus("#settings-status", error.message, true); }
  finally { button.disabled = false; }
};
$("#refresh-source-roms").onclick = () => loadSourceROMs({ force: true });
for (const selector of ["#source-system", "#source-category", "#source-collection", "#source-status", "#source-sort"]) $(selector).addEventListener("change", () => { state.sourceOffset = 0; loadSourceROMs(); });
$("#source-search").addEventListener("input", () => {
  clearTimeout(state.sourceFilterTimer);
  state.sourceFilterTimer = setTimeout(() => { state.sourceOffset = 0; loadSourceROMs(); }, 250);
});
$("#source-page-jump").addEventListener("keydown", event => {
  if (event.key !== "Enter") return;
  event.preventDefault();
  const info = FCPagination.pageInfo(state.sourceOffset, state.sourceLimit, state.sourceTotal);
  const page = FCPagination.parsePage(event.target.value, info.pageCount);
  event.target.value = "";
  if (page != null && page !== info.page) goToSourcePage(page);
});
$("#source-page-size").addEventListener("change", event => {
  // Keep the first game on screen in view: its page under the new size.
  const size = FCPagination.normalizePageSize(event.target.value, state.sourceLimit);
  state.sourceOffset = Math.floor(state.sourceOffset / size) * size; state.sourceLimit = size;
  try { localStorage.setItem(PAGE_SIZE_KEY, String(size)); } catch {}
  loadSourceROMs({ scrollToList: true });
});
$("#quick-audit").onclick = () => startAudit(false);
$("#full-audit").onclick = () => startAudit(true);
$("#repair-missing").onclick = repairMissingMetadata;
$("#select-all-source").onclick = () => {
  const visible = state.visibleSourceRoms || state.sourceRoms;
  if (visible.length && visible.every(rom => state.selectedSourceIDs.has(rom.id))) for (const rom of visible) state.selectedSourceIDs.delete(rom.id);
  else for (const rom of visible) state.selectedSourceIDs.add(rom.id);
  loadSourceROMs();
};
$("#bulk-research").onclick = () => runBulk("research");
$("#bulk-delete").onclick = () => runBulk("delete");
$("#export").onclick = event => openLibraryLinkDialog(event.currentTarget);
$("#copy-library-link").onclick = copyLibraryLink;
$("#verify-library-link").onclick = verifyLibraryLink;
$("#close-library-link").onclick = () => $("#library-link-dialog").close();
$("#done-library-link").onclick = () => $("#library-link-dialog").close();
$("#editor-form").addEventListener("submit", saveGame);
$("#editor-form").elements.system.addEventListener("change", () => { updateCPS2KeyField(state.selected); updatePS1AnalogField(state.selected); });
$("#delete-game").onclick = deleteGame;
$("#cover-upload").addEventListener("change", event => uploadCover(event.target.files[0]));
$("#background-upload").addEventListener("change", event => uploadArtwork("backdrop", event.target.files[0]));
$("#logo-upload").addEventListener("change", event => uploadArtwork("logo", event.target.files[0]));
$("#identify-game").onclick = identifyGame;
$("#search-cover").onclick = searchCover;
$("#search-diagnostic").onclick = showSearchDiagnostic;
$("#rename-rom").onclick = renameROM;
$("#show-history").onclick = showHistory;
$("#reload").onclick = () => load();
load();
