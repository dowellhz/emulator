"use strict";

(function (root) {
  const ERR = { BADF: 8, ISDIR: 31, NOTDIR: 54, FAULT: 21, INVAL: 28, IO: 29, MFILE: 33, NOENT: 44, OVERFLOW: 61, ROFS: 69 };
  const ROOT_FD = 3;
  const FIRST_FD = 4;
  const MAX_FD = 1023;
  const MAX_OFFSET = (1n << 63n) - 1n;
  const FD_READ = 1n << 1n;
  const FD_NONBLOCK = 4;
  const FILE_READ = FD_READ | (1n << 2n) | (1n << 5n) | (1n << 21n);
  const DIR_READ = (1n << 13n) | (1n << 18n) | (1n << 21n);
  const FD_READDIR = 1n << 14n;
  const encoder = new TextEncoder();
  const RANGE_MARKER = "X-FC-Preview-Range";
  const MAX_BLOCK = 1024 * 1024;
  const decoder = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true });

  function fileName(path) {
    if (typeof path !== "string" || path.length > 1024 || /[\\\x00-\x1f\x7f]/.test(path)) return null;
    const name = path.startsWith("/") ? path.slice(1) : path;
    return name.split("/").every(part => part && part !== "." && part !== "..") ? name : null;
  }

  function sameOriginURL(url, origin) {
    const endpoint = new URL(url, origin);
    if (endpoint.origin !== origin || !/^https?:$/.test(endpoint.protocol) ||
        endpoint.username || endpoint.password || endpoint.hash) {
      throw new Error("Invalid media endpoint");
    }
    return endpoint.href;
  }

  function strongETag(value) {
    return typeof value === "string" && /^"[\x21\x23-\x7e\x80-\xff]+"$/.test(value);
  }

  async function describeFile({ path, url, origin = root.location?.origin, headers, signal, identityHeader,
    fetch: fetchImpl = root.fetch } = {}) {
    if (!fileName(path)) throw new Error("Invalid guest media path");
    const endpoint = sameOriginURL(url, origin);
    const requestHeaders = new Headers(headers);
    requestHeaders.set(RANGE_MARKER, "1");
    const response = await fetchImpl(endpoint, {
      method: "HEAD", headers: requestHeaders, redirect: "error", cache: "no-store", signal
    });
    const bytes = response.headers.get("Content-Length");
    const etag = response.headers.get("ETag");
    if (response.status !== 200 || response.headers.get(RANGE_MARKER) !== "1" ||
        !/^[0-9]+$/.test(bytes || "") || !strongETag(etag)) {
      throw new Error("Preview media endpoint did not promise bounded ranges");
    }
    const size = BigInt(bytes);
    if (size > MAX_OFFSET) throw new Error("Media file is too large");
    if (!identityHeader) return { path, url: endpoint, size, etag };
    const sha256 = response.headers.get(identityHeader);
    if (!/^[a-f0-9]{64}$/.test(sha256 || "")) throw new Error("Missing preview media identity");
    return { path, url: endpoint, size, etag, sha256 };
  }

  function rangePlan(file, start, end, origin, baseHeaders) {
    const length = end - start + 1n;
    if (start < 0n || end >= file.size || length <= 0n || length > BigInt(MAX_BLOCK) || !strongETag(file.etag)) {
      throw new Error("Invalid media byte range");
    }
    const headers = new Headers(baseHeaders);
    headers.set("Range", `bytes=${start}-${end}`);
    headers.set("If-Match", file.etag);
    headers.set(RANGE_MARKER, "1");
    return {
      endpoint: sameOriginURL(file.url, origin), headers, length: Number(length),
      range: `bytes ${start}-${end}/${file.size}`
    };
  }

  function verifyRange(file, plan, status, getHeader, responseURL) {
    const encoding = getHeader("Content-Encoding");
    if (status !== 206 || responseURL !== plan.endpoint || getHeader(RANGE_MARKER) !== "1" ||
        getHeader("Content-Range") !== plan.range || getHeader("Content-Length") !== String(plan.length) ||
        getHeader("ETag") !== file.etag || (encoding && encoding !== "identity")) {
      throw new Error("Media range was not honored or the file changed");
    }
  }

  /* The same-origin endpoint must promise that marker requests never fall
   * back to a full 200 body. A synchronous Worker cannot interrupt body
   * delivery at response headers, so check that contract during discovery. */
  function workerReader({ origin = root.location?.origin, headers, timeout = 10000 } = {}) {
    if (!Number.isInteger(timeout) || timeout <= 0) throw new Error("Invalid media timeout");
    if (typeof WorkerGlobalScope !== "function" || !(root instanceof WorkerGlobalScope) ||
        typeof XMLHttpRequest !== "function") {
      throw new Error("Synchronous media reads require a Worker");
    }
    return (file, start, end) => {
      const plan = rangePlan(file, start, end, origin, headers);
      const request = new XMLHttpRequest();
      request.open("GET", plan.endpoint, false);
      request.responseType = "arraybuffer";
      request.timeout = timeout;
      for (const [name, value] of plan.headers) request.setRequestHeader(name, value);
      request.send();
      verifyRange(file, plan, request.status, name => request.getResponseHeader(name), request.responseURL);
      const bytes = new Uint8Array(request.response);
      if (bytes.byteLength !== plan.length) throw new Error("Truncated media block");
      return bytes;
    };
  }

  /* An asynchronous host can reject a 200 at headers without reading any
   * body. Unlike workerReader this function can be used for prefetching. */
  async function fetchRange(file, start, end, { origin = root.location?.origin, headers, signal,
    fetch: fetchImpl = root.fetch } = {}) {
    const plan = rangePlan(file, start, end, origin, headers);
    const response = await fetchImpl(plan.endpoint, {
      headers: plan.headers, redirect: "error", cache: "no-store", signal
    });
    try {
      verifyRange(file, plan, response.status, name => response.headers.get(name), response.url);
    } catch (error) {
      await response.body?.cancel().catch(() => {});
      throw error;
    }
    const reader = response.body.getReader();
    const output = new Uint8Array(plan.length);
    let at = 0;
    try {
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        if (value.byteLength > output.length - at) throw new Error("Media block exceeded its advertised length");
        output.set(value, at);
        at += value.byteLength;
      }
      if (at !== output.length) throw new Error("Truncated media block");
      return output;
    } catch (error) {
      await reader.cancel().catch(() => {});
      throw error;
    } finally {
      reader.releaseLock();
    }
  }

  /* WASI Preview 1's synchronous, read-only file subset. Guest names are
   * exact allowlisted paths in one preopen. fd_dup is a companion import
   * because WASI Preview 1 does not provide POSIX dup/F_DUPFD_CLOEXEC. */
  function create({ files = [], readRange, blockBytes = 128 * 1024, cacheBytes = 8 * 1024 * 1024, directories = false, firstFd = FIRST_FD } = {}) {
    if (!Array.isArray(files) || (files.length && typeof readRange !== "function") ||
        !Number.isInteger(blockBytes) || blockBytes <= 0 || blockBytes > MAX_BLOCK ||
        !Number.isSafeInteger(cacheBytes) || cacheBytes < blockBytes ||
        !Number.isInteger(firstFd) || firstFd < FIRST_FD || firstFd > MAX_FD) throw new Error("Invalid media configuration");
    const paths = new Map();
    for (const file of files) {
      const name = fileName(file.path);
      if (!name || paths.has(name) || typeof file.size !== "bigint" ||
          file.size < 0n || file.size > MAX_OFFSET || !strongETag(file.etag)) {
        throw new Error("Invalid or duplicate media file");
      }
      paths.set(name, { ...file, inode: BigInt(paths.size + 2) });
    }
    const tree = new Map([["", { inode: 1n, children: new Map(), parent: "" }]]);
    const directoryRights = directories ? DIR_READ | FD_READDIR : DIR_READ;
    const handleRights = directories ? FILE_READ | directoryRights : FILE_READ;
    if (directories) {
      let inode = BigInt(paths.size + 2);
      for (const [name, file] of paths) {
        const parts = name.split("/");
        let parent = "";
        for (const part of parts.slice(0, -1)) {
          const path = parent ? parent + "/" + part : part;
          if (paths.has(path)) throw new Error("Media file and directory overlap");
          if (!tree.has(path)) {
            const folder = { inode: inode++, children: new Map(), parent };
            tree.set(path, folder);
            tree.get(parent).children.set(part, { node: folder, type: 3 });
          }
          parent = path;
        }
        tree.get(parent).children.set(parts.at(-1), { node: file, type: 4 });
      }
    }
    const handles = new Map();
    const cache = new Map();
    const blockSize = BigInt(blockBytes);
    const maxBlocks = Math.floor(cacheBytes / blockBytes);
    let memory;

    function view(pointer, length) {
      const start = pointer >>> 0;
      const count = length >>> 0;
      const buffer = memory?.buffer;
      return buffer && start <= buffer.byteLength && count <= buffer.byteLength - start
        ? new DataView(buffer, start, count) : null;
    }

    function data(pointer, length) {
      const bytes = view(pointer, length);
      return bytes && new Uint8Array(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    }

    function guestPath(pointer, length) {
      const bytes = length >>> 0;
      if (!bytes || bytes > 4096) return null;
      const name = data(pointer, bytes);
      try { return name && decoder.decode(name); }
      catch { return null; }
    }

    function directory(fd) {
      return fd === ROOT_FD ? "" : handles.get(fd)?.directory;
    }

    function targetPath(fd, ptr, length, parentStat = false) {
      const base = directory(fd);
      const name = guestPath(ptr, length);
      if (base === undefined || !name) return null;
      if (name === ".") return base;
      if (name === ".." && directories && parentStat) return tree.get(base).parent;
      const relative = !name.startsWith("/") && fileName(name);
      return relative ? (base ? base + "/" + relative : relative) : null;
    }

    function block(file, position) {
      const start = (position / blockSize) * blockSize;
      const key = `${file.inode}:${start}`;
      const stored = cache.get(key);
      if (stored) {
        cache.delete(key);
        cache.set(key, stored);
        return stored;
      }
      const end = start + blockSize < file.size ? start + blockSize - 1n : file.size - 1n;
      const bytes = readRange(file, start, end);
      if (!(bytes instanceof Uint8Array) || bytes.byteLength !== Number(end - start + 1n)) {
        throw new Error("Invalid synchronous media block");
      }
      if (cache.size === maxBlocks) cache.delete(cache.keys().next().value);
      const chunk = bytes.byteLength === bytes.buffer.byteLength ? bytes : bytes.slice();
      cache.set(key, chunk);
      return chunk;
    }

    function installFd(handle, minimum, output) {
      const result = view(output, 4);
      if (!result) return ERR.FAULT;
      if (!Number.isInteger(minimum) || minimum < 0) return ERR.INVAL;
      let fd = Math.max(minimum, firstFd);
      while (fd <= MAX_FD && handles.has(fd)) fd++;
      if (fd > MAX_FD) return ERR.MFILE;
      handles.set(fd, handle);
      result.setUint32(0, fd, true);
      return 0;
    }

    function read(fd, iov, count, position, written, updateOffset) {
      const handle = handles.get(fd);
      if (!handle) return ERR.BADF;
      if (!handle.file) return ERR.ISDIR;
      const start = updateOffset ? handle.offset : BigInt.asUintN(64, position);
      if (start > MAX_OFFSET) return ERR.OVERFLOW;
      const result = view(written, 4);
      const entries = count >>> 0;
      if (entries > 4096) return ERR.INVAL;
      const pointers = view(iov, entries * 8);
      if (!result || !pointers) return ERR.FAULT;
      const buffers = [];
      for (let i = 0; i < entries; i++) {
        const bytes = data(pointers.getUint32(i * 8, true), pointers.getUint32(i * 8 + 4, true));
        if (!bytes) return ERR.FAULT;
        buffers.push(bytes);
      }

      let offset = start;
      let size = 0;
      let errno = 0;
      try {
        for (const output of buffers) {
          let cursor = 0;
          while (cursor < output.length && offset < handle.file.size) {
            const bytes = block(handle.file, offset);
            const within = Number(offset % blockSize);
            const bytesRead = Math.min(bytes.length - within, output.length - cursor, 0xffffffff - size);
            if (!bytesRead) break;
            output.set(bytes.subarray(within, within + bytesRead), cursor);
            cursor += bytesRead;
            offset += BigInt(bytesRead);
            size += bytesRead;
          }
          if (cursor < output.length) break;
        }
      } catch {
        errno = ERR.IO;
      }
      result.setUint32(0, size, true);
      if (updateOffset) handle.offset = offset;
      return size ? 0 : errno;
    }

    function fileStat(output, node, isDirectory) {
      const bytes = data(output, 64);
      if (!bytes) return ERR.FAULT;
      bytes.fill(0);
      const stat = view(output, 64);
      stat.setBigUint64(8, node.inode, true);
      stat.setUint8(16, isDirectory ? 3 : 4);
      stat.setBigUint64(24, 1n, true);
      stat.setBigUint64(32, node.size ?? 0n, true);
      return 0;
    }

    const wasi = {
      clock_time_get(clock, _precision, output) {
        if (clock !== 0 && clock !== 1) return ERR.INVAL;
        const stamp = view(output, 8);
        if (!stamp) return ERR.FAULT;
        const nanoseconds = clock === 0 ? BigInt(Date.now()) * 1_000_000n
          : BigInt(Math.floor(performance.now() * 1_000_000));
        stamp.setBigUint64(0, nanoseconds, true);
        return 0;
      },
      environ_get() { return 0; },
      environ_sizes_get(count, bytes) {
        const countView = view(count, 4), bytesView = view(bytes, 4);
        if (!countView || !bytesView) return ERR.FAULT;
        countView.setUint32(0, 0, true);
        bytesView.setUint32(0, 0, true);
        return 0;
      },
      fd_prestat_get(fd, output) {
        if (fd !== ROOT_FD) return ERR.BADF;
        const data = view(output, 8);
        if (!data) return ERR.FAULT;
        data.setUint32(0, 0, true);
        data.setUint32(4, 1, true);
        return 0;
      },
      fd_prestat_dir_name(fd, output, length) {
        if (fd !== ROOT_FD) return ERR.BADF;
        if (!length) return ERR.INVAL;
        const name = view(output, 1);
        if (!name) return ERR.FAULT;
        name.setUint8(0, 47);
        return 0;
      },
      path_open(fd, flags, pointer, length, oflags, rights, inheriting, fdflags, output) {
        if (directory(fd) === undefined) return ERR.BADF;
        if ((oflags & ~2) || (!directories && (oflags || !(rights & FD_READ))) || (fdflags & ~FD_NONBLOCK) ||
            (rights & ~handleRights) || (inheriting & ~handleRights)) return ERR.ROFS;
        const path = targetPath(fd, pointer, length);
        const folder = path !== null && directories && tree.has(path);
        if (folder) {
          if (!(rights & ((1n << 13n) | FD_READDIR))) return ERR.ROFS;
          return installFd({ directory: path, flags: fdflags }, firstFd, output);
        }
        const file = path !== null && paths.get(path);
        if (!file) return ERR.NOENT;
        if (oflags & 2) return ERR.NOTDIR;
        if (!(rights & FD_READ)) return ERR.ROFS;
        return installFd({ file, offset: 0n, flags: fdflags }, firstFd, output);
      },
      path_filestat_get(fd, flags, pointer, length, output) {
        if (directory(fd) === undefined) return ERR.BADF;
        const path = targetPath(fd, pointer, length, true);
        const folder = tree.get(path);
        if (folder) return fileStat(output, folder, true);
        const file = paths.get(path);
        return file ? fileStat(output, file, false) : ERR.NOENT;
      },
      fd_fdstat_get(fd, output) {
        const handle = handles.get(fd);
        if (fd !== ROOT_FD && !handle) return ERR.BADF;
        const bytes = data(output, 24);
        if (!bytes) return ERR.FAULT;
        bytes.fill(0);
        const stat = view(output, 24);
        const folder = directory(fd) !== undefined;
        stat.setUint8(0, folder ? 3 : 4);
        stat.setUint16(2, handle?.flags ?? 0, true);
        stat.setBigUint64(8, folder ? directoryRights : FILE_READ, true);
        stat.setBigUint64(16, folder ? handleRights : 0n, true);
        return 0;
      },
      fd_fdstat_set_flags(fd, flags) {
        const handle = handles.get(fd);
        if (!handle) return ERR.BADF;
        if (flags & ~FD_NONBLOCK) return ERR.ROFS;
        handle.flags = flags;
        return 0;
      },
      fd_filestat_get(fd, output) {
        const handle = handles.get(fd);
        if (fd !== ROOT_FD && !handle) return ERR.BADF;
        const folder = tree.get(directory(fd));
        return fileStat(output, folder || handle.file, !!folder);
      },
      fd_seek(fd, delta, mode, output) {
        const handle = handles.get(fd);
        if (!handle) return ERR.BADF;
        if (!handle.file) return ERR.ISDIR;
        if (mode !== 0 && mode !== 1 && mode !== 2) return ERR.INVAL;
        const result = view(output, 8);
        if (!result) return ERR.FAULT;
        const offset = delta + (mode === 0 ? 0n : mode === 1 ? handle.offset : handle.file.size);
        if (offset < 0n) return ERR.INVAL;
        if (offset > MAX_OFFSET) return ERR.OVERFLOW;
        handle.offset = offset;
        result.setBigUint64(0, offset, true);
        return 0;
      },
      fd_tell(fd, output) {
        const handle = handles.get(fd);
        if (!handle) return ERR.BADF;
        if (!handle.file) return ERR.ISDIR;
        const result = view(output, 8);
        if (!result) return ERR.FAULT;
        result.setBigUint64(0, handle.offset, true);
        return 0;
      },
      fd_readdir(fd, pointer, length, cookie, output) {
        const folder = directories && tree.get(directory(fd));
        if (!folder) return handles.has(fd) ? ERR.NOTDIR : ERR.BADF;
        const destination = data(pointer, length);
        const result = view(output, 4);
        if (!destination || !result) return ERR.FAULT;
        const entries = [[".", {node: folder, type: 3}], ["..", {node: tree.get(folder.parent), type: 3}],
          ...folder.children];
        let written = 0;
        for (let index = Number(BigInt.asUintN(64, cookie)); index < entries.length && written < destination.length; index++) {
          const [entry, {node, type}] = entries[index];
          const name = encoder.encode(entry);
          const encoded = new Uint8Array(24 + name.length);
          const header = new DataView(encoded.buffer);
          header.setBigUint64(0, BigInt(index + 1), true);
          header.setBigUint64(8, node.inode, true);
          header.setUint32(16, name.length, true);
          header.setUint8(20, type);
          encoded.set(name, 24);
          const chunk = encoded.subarray(0, destination.length - written);
          destination.set(chunk, written);
          written += chunk.length;
        }
        result.setUint32(0, written, true);
        return 0;
      },
      fd_read(fd, iov, count, written) { return read(fd, iov, count, 0n, written, true); },
      fd_pread(fd, iov, count, position, written) { return read(fd, iov, count, position, written, false); },
      fd_write(fd) { return handles.has(fd) ? ERR.ROFS : ERR.BADF; },
      fd_close(fd) { return handles.delete(fd) ? 0 : ERR.BADF; },
      fd_renumber(from, to) {
        const handle = handles.get(from);
        if (!handle || to < firstFd || to > MAX_FD) return ERR.BADF;
        if (from !== to) {
          handles.set(to, handle);
          handles.delete(from);
        }
        return 0;
      },
      proc_exit(code) { throw new Error(`WebAssembly media core exited (${code})`); }
    };
    const fd_dup = (fd, minimum, output) => {
      const handle = handles.get(fd);
      return handle ? installFd(handle, minimum, output) : ERR.BADF;
    };
    return {
      imports: { wasi_snapshot_preview1: wasi, fc_preview_media: { fd_dup } },
      bindMemory(wasmMemory) { memory = wasmMemory; }
    };
  }

  const media = { create, describeFile, workerReader, fetchRange };
  if (typeof module === "object" && module.exports) module.exports = media;
  else root.FCPreviewWasiMedia = media;
})(globalThis);
