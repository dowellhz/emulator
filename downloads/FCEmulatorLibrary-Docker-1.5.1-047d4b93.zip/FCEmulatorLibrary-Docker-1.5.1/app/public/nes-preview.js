"use strict";

const FCNESPreview = (() => {
  let activeSession = false;
  const buttons = new Map([
    ["KeyX", 1], ["KeyZ", 2], ["ShiftRight", 4], ["Enter", 8],
    ["ArrowUp", 16], ["ArrowDown", 32], ["ArrowLeft", 64], ["ArrowRight", 128],
    ["KeyA", 256], ["KeyS", 512], ["KeyD", 1024], ["KeyF", 2048], ["KeyQ", 4096], ["KeyW", 8192]
  ]);
  const arcadeKeys = new Map([
    ["ArrowRight", 1], ["ArrowLeft", 2], ["ArrowDown", 4], ["ArrowUp", 8],
    ["KeyX", 16], ["KeyZ", 32], ["KeyA", 64], ["KeyS", 128], ["Enter", 1024], ["KeyC", 2048]
  ]);
  const arcadeActionKeys = new Map([...arcadeKeys, ["KeyD", 256], ["KeyF", 512]]);
  const twinStickKeys = new Map([...arcadeActionKeys,
    ["KeyL", 0x1000], ["KeyJ", 0x2000], ["KeyK", 0x4000], ["KeyI", 0x8000]]);
  const mahjongKeys = new Map([["Enter", 1024], ["ShiftRight", 2048]]);
  const pspKeys = new Map([
    ["ShiftRight", 1], ["Enter", 8], ["ArrowUp", 16], ["ArrowRight", 32], ["ArrowDown", 64], ["ArrowLeft", 128],
    ["KeyQ", 256], ["KeyE", 512], ["KeyS", 0x1000], ["KeyA", 0x2000], ["KeyX", 0x4000], ["KeyZ", 0x8000],
    ["KeyL", 0x10000], ["KeyJ", 0x20000], ["KeyI", 0x40000], ["KeyK", 0x80000]
  ]);
  const pspPadButtons = [
    [0, 0x4000], [1, 0x2000], [2, 0x8000], [3, 0x1000], [5, 8], [6, 256], [7, 512],
    [8, 1], [9, 8], [12, 16], [13, 64], [14, 128], [15, 32]
  ];

  function readPSPGamepad() {
    let pads;
    try { pads = navigator.getGamepads?.(); } catch { return; }
    for (const pad of pads || []) {
      if (!pad?.connected || pad.mapping !== "standard") continue;
      const pressed = index => pad.buttons[index]?.pressed === true || pad.buttons[index]?.value >= 0.5;
      let buttons = 0;
      for (const [index, mask] of pspPadButtons) if (pressed(index)) buttons |= mask;
      function axis(value) {
        const magnitude = Number.isFinite(value) ? Math.min(1, Math.abs(value)) : 0;
        if (magnitude <= 0.18) return 128;
        const scale = value < 0 ? -128 : 127;
        return Math.round(128 + scale * (magnitude - 0.18) / 0.82);
      }
      return { buttons, analog: [axis(pad.axes[0]), axis(pad.axes[1])], leftShoulder: pressed(4) };
    }
  }

  const nintendo64Keys = new Map([
    ["KeyX", 0x8000], ["KeyZ", 0x4000], ["KeyQ", 0x2000], ["Enter", 0x1000],
    ["KeyW", 0x800], ["KeyS", 0x400], ["KeyA", 0x200], ["KeyD", 0x100],
    ["KeyE", 0x20], ["KeyR", 0x10], ["KeyI", 8], ["KeyK", 4], ["KeyJ", 2], ["KeyL", 1],
    ["ArrowRight", 0x10000], ["ArrowLeft", 0x20000], ["ArrowUp", 0x40000], ["ArrowDown", 0x80000]
  ]);
  for (let i = 0; i < 14; i++) mahjongKeys.set("Key" + String.fromCharCode(65 + i), 1 << (12 + i));
  for (let i = 0; i < 5; i++) mahjongKeys.set("Digit" + (i + 1), 1 << (26 + i));
  const arcadeControls = {
    1: "左右方向键转向 · X 油门 · Z 刹车 · C 投币 · Enter 开始",
    2: "方向键控制轨迹球 · I/J/K/L 控制手柄 · A/S 切换阵型 · X/Z 击球 · C 投币 · Enter 开始",
    3: "左右方向键转动旋钮 · X/Z 为动作键 · C 投币 · Enter 开始",
    7: "鼠标或方向键瞄准 · 点击或 X 射击 · C 投币 · Enter 开始",
    9: "A–N 选牌 · 1 杠 · 2 碰 · 3 吃 · 4 立直 · 5 荣和 · 右 Shift 投币 · Enter 开始",
    10: "方向键控制左摇杆 · I/J/K/L 控制右摇杆 · X/Z 为动作键 · C 投币 · Enter 开始",
    12: "移动鼠标或按方向键控制轨迹球 · X/Z 为动作键 · C 投币 · Enter 开始",
    13: "方向键控制车把 · X 投报 · C 投币 · Enter 开始",
    14: "左右方向键转向 · X 油门 · C 投币 · Enter 开始",
    16: "左右方向键移动 · 上下方向键选拳位 · X 右拳 · Z 左拳 · C 投币 · Enter 开始"
  };
  const pgmKeys = new Map([
    ["Enter", 1], ["ArrowUp", 2], ["ArrowDown", 4], ["ArrowLeft", 8], ["ArrowRight", 16],
    ["KeyX", 32], ["KeyZ", 64], ["KeyA", 128], ["KeyS", 256], ["KeyC", 512]
  ]);
  const atariKeypad = Array.from({ length: 10 }, (_, digit) => [`Digit${digit}`, 1 << (16 + digit)]);
  atariKeypad.push(["BracketLeft", 1 << 26], ["BracketRight", 1 << 27]);
  const controlSchemes = {
    standard: { mask: 255, label: "方向键移动 · Z 为 B · X 为 A · Enter 开始 · 右 Shift 选择" },
    shoulders: { mask: 1023, label: "方向键移动 · X/Z 为 A/B · A/S 为 L/R · Enter 开始 · 右 Shift 选择" },
    snes: { mask: 4095, label: "方向键移动 · X/Z 为 A/B · D/F 为 X/Y · A/S 为 L/R · Enter 开始 · 右 Shift 选择" },
    megaDrive: { mask: 4095, label: "方向键移动 · X/Z/A 为 A/B/C · S/D/F 为 X/Y/Z · Enter 开始 · 右 Shift 为模式键" },
    megaCD: { mask: 507, label: "方向键移动 · X/Z/A 为 A/B/C · Enter 开始" },
    playStation: { mask: 16383, label: "方向键移动 · X/Z/D/F 为 ×/○/□/△ · A/S 为 L1/R1 · Q/W 为 L2/R2 · Enter 开始 · 右 Shift 选择" },
    saturn: { mask: 16379, label: "方向键移动 · X/Z/A 为 A/B/C · S/D/F 为 X/Y/Z · Q/W 为 L/R · Enter 开始" },
    sega8: { mask: 255, label: "方向键移动 · X/Z 为 1/2 · Enter 暂停" },
    gameGear: { mask: 255, label: "方向键移动 · X/Z 为 1/2 · Enter 开始" },
    neoGeo: { mask: 4095, keys: arcadeKeys, label: "方向键移动 · X/Z/A/S 为 A/B/C/D · C 投币 · Enter 开始" },
    cps: { mask: 0x7fff, keys: new Map([...arcadeActionKeys,
      ["KeyQ", 0x1000], ["KeyW", 0x2000], ["KeyV", 0x4000], ["F2", 0x8000]]),
      label: "方向键移动 · X/Z/A/S/D/F 为动作键 · C 投币 · Enter 开始" },
    arcade: { mask: 0xfff, keys: arcadeActionKeys,
      label: "方向键移动 · X/Z/A/S/D/F 为动作键 · C 投币 · Enter 开始" },
    nix: { mask: 0x4c7f, keys: new Map([...arcadeKeys, ["KeyV", 0x4000]]),
      label: "方向键移动 · X/Z/A 为动作键 · C/V 投币 · Enter 开始" },
    rare: { mask: 0xc3f, keys: arcadeKeys,
      label: "方向键移动 · X/Z 为动作键 · C 投币 · Enter 开始" },
    psp: { mask: 0xfffff, keys: pspKeys,
      label: "方向键为十字键 · I/J/K/L 控制摇杆 · X/Z/A/S 为 ×/□/○/△ · Q/E 为 L/R · Enter 开始 · 右 Shift 选择" },
    nintendo64: { mask: 0xfffff, keys: nintendo64Keys,
      label: "方向键控制摇杆 · W/A/S/D 为十字键 · X/Z 为 A/B · Q 为 Z · E/R 为 L/R · I/J/K/L 为 C 键 · Enter 开始" },
    pgm: { mask: 1023, keys: pgmKeys, label: "方向键移动 · X/Z/A/S 为 A/B/C/D · C 投币 · Enter 开始" },
    neoGeoPocket: { mask: 251, label: "方向键移动 · X/Z 为 A/B · Enter 为 Option" },
    atari2600: { mask: 0xcff, label: "方向键控制摇杆或旋钮 · X/Z 为动作键 · Enter 重置 · 右 Shift 选择" },
    atari5200: {
      mask: 0x0fff01ff, keys: new Map([...buttons, ...atariKeypad]),
      label: "方向键控制摇杆 · X/Z 为两个动作键 · 0–9 与 [ ] 为键盘 · Enter 开始 · 右 Shift 暂停 · A 重置"
    },
    atari7800: { mask: 0x5ff, label: "方向键移动 · X/Z 为动作键 · Enter 重置 · 右 Shift 选择 · A 暂停" },
    wonderSwan: {
      mask: 4091,
      directionKeys: new Map([["KeyI", 256], ["KeyJ", 1024], ["KeyK", 512], ["KeyL", 2048]]),
      label: "方向键控制主方向 · I/J/K/L 为另一组方向 · X/Z 为 A/B · Enter 开始"
    }
  };

  const standardFaces = [["right", "A", "KeyX"], ["down", "B", "KeyZ"]];
  const megaFaces = [...standardFaces, ["left", "C", "KeyA"]];
  const segaFaces = [["down", "1", "KeyX"], ["right", "2", "KeyZ"]];
  const arcadeFaces = [
    ...standardFaces, ["up", "X", "KeyA"], ["left", "Y", "KeyS"], ["extra-left", "5", "KeyD"], ["extra-right", "6", "KeyF"]
  ];
  const consoleCentre = [["SELECT", "ShiftRight"], ["START", "Enter"]];
  const arcadeCentre = [["COIN", "KeyC"], ["START", "Enter"]];
  const controllerLayouts = {
    standard: { faces: standardFaces, centre: consoleCentre },
    pcEngine: { faces: [["right", "I", "KeyX"], ["down", "II", "KeyZ"]], centre: [["SELECT", "ShiftRight"], ["RUN", "Enter"]] },
    shoulders: { faces: standardFaces, centre: consoleCentre, shoulders: [["L", "KeyA"], ["R", "KeyS"]] },
    snes: { faces: [...standardFaces, ["up", "X", "KeyD"], ["left", "Y", "KeyF"]],
      centre: consoleCentre, shoulders: [["L", "KeyA"], ["R", "KeyS"]] },
    megaDrive: { faces: [...megaFaces, ["up", "X", "KeyS"], ["extra-left", "Y", "KeyD"], ["extra-right", "Z", "KeyF"]],
      centre: [["MODE", "ShiftRight"], ["START", "Enter"]] },
    megaCD: { faces: megaFaces, centre: [["START", "Enter"]] },
    playStation: { faces: [["up", "△", "KeyF"], ["right", "○", "KeyZ"], ["down", "×", "KeyX"], ["left", "□", "KeyD"]],
      centre: consoleCentre, shoulders: [["L1", "KeyA"], ["R1", "KeyS"], ["L2", "KeyQ"], ["R2", "KeyW"]] },
    saturn: { faces: [...megaFaces, ["up", "X", "KeyS"], ["extra-left", "Y", "KeyD"], ["extra-right", "Z", "KeyF"]],
      centre: [["START", "Enter"]], shoulders: [["L", "KeyQ"], ["R", "KeyW"]] },
    sega8: { faces: segaFaces, centre: [["PAUSE", "Enter"]] },
    gameGear: { faces: segaFaces, centre: [["START", "Enter"]] },
    neoGeo: { faces: [...standardFaces, ["up", "C", "KeyA"], ["left", "D", "KeyS"]], centre: arcadeCentre },
    pgm: { faces: [...standardFaces, ["up", "C", "KeyA"], ["left", "D", "KeyS"]], centre: arcadeCentre },
    cps: { faces: arcadeFaces, centre: arcadeCentre },
    arcade: { faces: arcadeFaces, centre: arcadeCentre },
    nix: { faces: megaFaces, centre: [["COIN 1", "KeyC"], ["COIN 2", "KeyV"], ["START", "Enter"]] },
    rare: { faces: standardFaces, centre: arcadeCentre },
    nintendo64: {
      directions: ["KeyW", "KeyA", "KeyD", "KeyS"],
      stick: true,
      camera: [["up", "C↑", "KeyI"], ["left", "C←", "KeyJ"], ["right", "C→", "KeyL"], ["down", "C↓", "KeyK"]],
      faces: [["left", "B", "KeyZ"], ["down", "A", "KeyX"]],
      centre: [["START", "Enter"]], shoulders: [["L", "KeyE"], ["Z", "KeyQ"], ["R", "KeyR"]]
    },
    neoGeoPocket: { faces: standardFaces, centre: [["OPTION", "Enter"]] }
  };

  async function open({ name, url, mediaPath, driver, format, headers, t }) {
    const dialog = document.querySelector("#nes-preview");
    if (dialog.open || activeSession) return;
    const surface = dialog.querySelector(".nes-preview-surface");
    const closeForm = dialog.querySelector('form[method="dialog"]');
    const closeButton = closeForm.querySelector("button");
    const pauseButton = dialog.querySelector(".psp-preview-pause");
    const utility = dialog.querySelector(".psp-utility");
    const fullscreen = dialog.querySelector(".nes-preview-fullscreen");
    const diskControls = dialog.querySelector(".nes-preview-disk");
    const diskSide = diskControls.querySelector("select");
    const diskToggle = diskControls.querySelector("button");
    const configuredCore = format.systemID != null;
    const disk = format.firmware === "fds";
    const offThread = format.discMedia || format.worker;
    const lightGunPort = format.atari?.lightGunPort;
    diskControls.hidden = true;
    diskSide.disabled = diskToggle.disabled = false;
    const controls = controlSchemes[format.controls || "standard"];
    let controlsMask = controls.mask;
    let activeKeys = controls.keys || (controls.directionKeys
      ? new Map([...buttons].filter(([, bit]) => bit < 256).concat([...controls.directionKeys]))
      : buttons);
    const controlsLabel = dialog.querySelector("#nes-preview-controls");
    const controlsPad = dialog.querySelector(".nes-preview-pad");
    const illustratedKeys = new Map();
    controlsLabel.textContent = t(lightGunPort === undefined ? controls.label
      : "鼠标瞄准 · 点击或 X 射击 · Enter 重置 · 右 Shift 选择 · A 暂停");
    const canvas = dialog.querySelector("canvas");
    const status = dialog.querySelector("[role=status]");
    const context = canvas.getContext("2d", { alpha: false });
    const controller = new AbortController();
    const { signal } = controller;
    const pressed = new Set();
    const pointerKeys = new Map();
    const isHeld = code => pressed.has(code) || Array.from(pointerKeys.values()).some(key => key.code === code);
    const refreshKey = code => illustratedKeys.get(code)?.classList.toggle("is-held", isHeld(code));
    let latchedInput = 0;
    let frameRequest = 0;
    let nextFrame;
    let audio;
    let audioOutput;
    let closeCore, requestPersistentClose;
    let arcadeControl = 0, rotation = 0, displayAspect = format.displayAspect;
    let gunPosition, gunTrigger = false, pendingLightGunShot, gunOnScreen = false, trackX = 0, trackY = 0;
    if (lightGunPort !== undefined) canvas.style.cursor = "crosshair";
    function showControllerLayout(specialControls = false) {
      if (!controlsPad) return;
      const scheme = format.module?.startsWith("pce") ? "pcEngine" : (format.controls || "standard");
      const layout = specialControls || lightGunPort !== undefined ? undefined : controllerLayouts[scheme];
      controlsLabel.classList.toggle("pad-caption", Boolean(layout));
      controlsPad.hidden = !layout;
      controlsPad.classList.toggle("preview-pad-nintendo64", Boolean(layout?.stick));
      pointerKeys.clear();
      controlsPad.replaceChildren();
      illustratedKeys.clear();
      if (!layout) return;
      function group(kind) {
        const element = document.createElement("div");
        element.className = "preview-pad-" + kind;
        controlsPad.append(element);
        return element;
      }
      function key(parent, label, code, position) {
        if (!(activeKeys.get(code) & controlsMask)) return;
        const keycap = document.createElement("button");
        keycap.type = "button";
        keycap.className = "preview-pad-key";
        if (position) keycap.dataset.position = position;
        keycap.dataset.key = code;
        keycap.classList.toggle("is-held", isHeld(code));
        keycap.textContent = label;
        if (!code.startsWith("Arrow")) {
          const caption = document.createElement("kbd");
          caption.textContent = code === "ShiftRight" ? "R Shift" : code.replace(/^Key/, "");
          keycap.append(caption);
        }
        parent.append(keycap);
        illustratedKeys.set(code, keycap);
      }
      if (layout.shoulders) {
        const shoulders = group("shoulders");
        for (const [label, code] of layout.shoulders) key(shoulders, label, code);
      }
      function cross(parent, codes = ["ArrowUp", "ArrowLeft", "ArrowRight", "ArrowDown"]) {
        const directions = [["up", "↑"], ["left", "←"], ["right", "→"], ["down", "↓"]];
        directions.forEach(([position, label], i) => key(parent, label, codes[i], position));
      }
      cross(group("directions"), layout.directions);
      if (layout.stick) {
        const stick = group("stick");
        stick.setAttribute("role", "group");
        stick.setAttribute("aria-label", "Analog stick");
        cross(stick);
        const camera = group("camera");
        for (const [position, label, code] of layout.camera) key(camera, label, code, position);
      }
      const centre = group("centre");
      for (const [label, code] of layout.centre) key(centre, label, code);
      const faces = group("faces");
      faces.classList.toggle("has-extra-buttons", layout.faces.some(([pos]) => pos.startsWith("extra")));
      for (const [position, label, code] of layout.faces) key(faces, label, code, position);
    }
    try {
      if (window.AudioContext) {
        audio = new AudioContext();
        audioOutput = FCPreviewAudio.create(audio);
        audio.addEventListener("statechange", () => {
          if (audio.state !== "running" && audio.state !== "closed") audioOutput.reset();
        }, { signal });
        void audio.resume().catch(() => {});
      }
    } catch { /* The preview can run silently when audio is unavailable. */ }

    function changeKey(event) {
      if (!utility.hidden || event.target !== canvas || !(activeKeys.get(event.code) & controlsMask)) return;
      if (event.type === "keyup") {
        pressed.delete(event.code);
        refreshKey(event.code);
      }
      if (event.ctrlKey || event.altKey || event.metaKey) return;
      event.preventDefault();
      if (event.type === "keydown") {
        if (arcadeControl === 7 && event.code.startsWith("Arrow")) gunPosition = undefined;
        if (lightGunPort !== undefined && event.code === "KeyX" && !event.repeat) queueLightGunShot();
        pressed.add(event.code);
        refreshKey(event.code);
        if (offThread) latchedInput |= activeKeys.get(event.code);
      }
    }

    function readInput() {
      let input = latchedInput;
      for (const key of pressed) input |= activeKeys.get(key);
      for (const key of pointerKeys.values()) {
        input |= activeKeys.get(key.code);
        key.sampled = true;
      }
      if (gunTrigger && arcadeControl === 7) input |= 16;
      latchedInput = 0;
      return input;
    }
    function clearInput() {
      pressed.clear();
      pointerKeys.clear();
      for (const button of illustratedKeys.values()) button.classList.remove("is-held");
      latchedInput = 0;
      gunTrigger = false;
      pendingLightGunShot = null;
      trackX = trackY = 0;
    }

    function queueLightGunShot() {
      // The console game checks the trigger before polling the light sensor.
      // A short desktop click must keep its aim through those emulated frames.
      pendingLightGunShot = { position: gunPosition, onScreen: gunOnScreen, frames: 10 };
    }

    function rotatePointer(x, y, edge) {
      if (rotation === 90) return [y, edge - x];
      if (rotation === 180) return [edge - x, edge - y];
      if (rotation === 270) return [edge - y, x];
      return [x, y];
    }
    function aim(event) {
      if (arcadeControl !== 7 && arcadeControl !== 12 && lightGunPort === undefined) return;
      const rect = canvas.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      if (arcadeControl === 7 || lightGunPort !== undefined) {
        const quantize = n => Math.round(Math.max(0, Math.min(1, n)) * 65535);
        const x = (event.clientX - rect.left) / rect.width, y = (event.clientY - rect.top) / rect.height;
        gunOnScreen = x >= 0 && x <= 1 && y >= 0 && y <= 1;
        gunPosition = rotatePointer(quantize(x), quantize(y), 65535);
      } else if (arcadeControl === 12 && event.type === "pointermove") {
        const [dx, dy] = rotatePointer(Math.round(event.movementX * canvas.width / rect.width),
          Math.round(event.movementY * canvas.height / rect.height), 0);
        trackX = Math.max(-32767, Math.min(32767, trackX + dx));
        trackY = Math.max(-32767, Math.min(32767, trackY + dy));
      }
    }

    const isFullscreen = () => document.fullscreenElement === surface;
    const isExpanded = () => dialog.classList.contains("nes-preview-expanded");
    function syncFullscreen() {
      fullscreen.textContent = t(isFullscreen() || isExpanded() ? "退出全屏" : "全屏");
    }
    fullscreen.addEventListener("click", async () => {
      if (isFullscreen()) await document.exitFullscreen().catch(() => {});
      else if (isExpanded()) dialog.classList.remove("nes-preview-expanded");
      else {
        try {
          if (!surface.requestFullscreen || !document.fullscreenEnabled) throw new Error();
          await surface.requestFullscreen();
        } catch {
          if (!signal.aborted) dialog.classList.add("nes-preview-expanded");
        }
      }
      if (!signal.aborted) {
        syncFullscreen();
        canvas.focus();
      }
    }, { signal });
    document.addEventListener("fullscreenchange", syncFullscreen, { signal });
    dialog.addEventListener("cancel", event => {
      if (isExpanded() || isFullscreen()) {
        event.preventDefault();
        if (isFullscreen()) void document.exitFullscreen().catch(() => {});
        dialog.classList.remove("nes-preview-expanded");
        syncFullscreen();
        canvas.focus();
      } else if (requestPersistentClose) {
        event.preventDefault();
        requestPersistentClose(false);
      }
    }, { signal });
    closeForm.addEventListener("submit", event => {
      if (!requestPersistentClose) return;
      event.preventDefault();
      requestPersistentClose(true);
    }, { signal });
    dialog.addEventListener("close", () => {
      activeSession = false;
      controller.abort();
      cancelAnimationFrame(frameRequest);
      closeCore?.();
      closeButton.disabled = false;
      closeButton.textContent = t("关闭");
      pauseButton.hidden = true;
      utility.hidden = true;
      utility.replaceChildren();
      dialog.classList.remove("nes-preview-expanded");
      canvas.style.removeProperty("cursor");
      if (isFullscreen()) void document.exitFullscreen().catch(() => {});
      audioOutput?.close();
      if (audio) void audio.close().catch(() => {});
    }, { once: true });
    if (controlsPad) {
      function focusGame() {
        canvas.focus({ preventScroll: true });
        if (audio && audio.state === "suspended") void audio.resume().catch(() => {});
      }

      controlsPad.addEventListener("pointerdown", event => {
        const key = event.target.closest(".preview-pad-key");
        if (!key || event.button !== 0 || controlsPad.hidden) return;
        event.preventDefault();
        const code = key.dataset.key;
        focusGame();
        pointerKeys.set(event.pointerId, { code, sampled: false });
        key.setPointerCapture(event.pointerId);
        refreshKey(code);
      }, { signal });

      function releasePadKey(event) {
        const key = pointerKeys.get(event.pointerId);
        if (!key) return;
        pointerKeys.delete(event.pointerId);
        // A completed tap shorter than a frame still needs to reach the emulator.
        if (event.type === "pointerup" && !key.sampled) latchedInput |= activeKeys.get(key.code);
        refreshKey(key.code);
      }
      for (const eventName of ["pointerup", "pointercancel", "lostpointercapture"]) {
        controlsPad.addEventListener(eventName, releasePadKey, { signal });
      }

      controlsPad.addEventListener("click", event => {
        const key = event.target.closest(".preview-pad-key");
        if (!key || event.detail || controlsPad.hidden) return;
        focusGame();
        latchedInput |= activeKeys.get(key.dataset.key);
      }, { signal });
    }
    canvas.addEventListener("keydown", changeKey, { signal });
    canvas.addEventListener("keyup", changeKey, { signal });
    canvas.addEventListener("blur", clearInput, { signal });
    canvas.addEventListener("pointermove", aim, { signal });
    canvas.addEventListener("pointerleave", () => { gunOnScreen = false; }, { signal });
    canvas.addEventListener("pointerdown", event => {
      if (audio && audio.state !== "running" && audio.state !== "closed") void audio.resume().catch(() => {});
      if ((arcadeControl !== 7 && lightGunPort === undefined) || event.button !== 0) return;
      aim(event);
      canvas.setPointerCapture(event.pointerId);
      gunTrigger = true;
      if (arcadeControl === 7) latchedInput |= 16;
      else queueLightGunShot();
    }, { signal });
    for (const eventName of ["pointerup", "pointercancel", "lostpointercapture"]) {
      canvas.addEventListener(eventName, () => { gunTrigger = false; }, { signal });
    }
    window.addEventListener("blur", clearInput, { signal });
    document.addEventListener("visibilitychange", () => {
      clearInput();
      nextFrame = undefined;
    }, { signal });

    dialog.querySelector("h2").textContent = name;
    syncFullscreen();
    status.textContent = t("正在加载试玩…");
    context.clearRect(0, 0, canvas.width, canvas.height);
    dialog.showModal();
    activeSession = true;
    showControllerLayout(offThread);
    canvas.focus();

    let image, pixels, renderedAspect;
    function resizeVideo(width, height) {
      const aspect = displayAspect || width / height;
      if (renderedAspect !== aspect) {
        renderedAspect = aspect;
        surface.style.setProperty("--preview-aspect", aspect);
        canvas.style.aspectRatio = aspect;
      }
      if (image && canvas.width === width && canvas.height === height) return;
      canvas.width = width;
      canvas.height = height;
      image = context.createImageData(width, height);
      pixels = new Uint32Array(image.data.buffer);
    }
    function paintVideo(source, rgbaPixels) {
      if (rgbaPixels) {
        pixels.set(source);
      } else {
        for (let i = 0; i < pixels.length; i++) {
          const bgra = source[i];
          pixels[i] = 0xff000000 | ((bgra & 255) << 16) | (bgra & 0xff00) | ((bgra >>> 16) & 255);
        }
      }
      context.putImageData(image, 0, 0);
    }

    function playInWorker() {
      const worker = new Worker("/assets/preview-worker.js?v=15");
      let timer, closeTimer, pendingVideo;
      let sampleRate, interval, busy = false, failed = false;
      let waitingForDiscReply = false, discTrayOpen = false;
      let savingAndClosing = false, saveCloseFailed = false, saveConflict = false, currentUtility;
      const psp = format.worker === "psp";
      const n64 = format.worker === "nintendo64";
      const persistentSystem = n64 ? "n64" : "psp";
      let pspPaused = false, skipPendingAudio = false;
      let padState, latchedPadButtons = 0, leftShoulderDown = false, padHelpShown = false;

      function clearPadInput() {
        padState = undefined;
        latchedPadButtons = 0;
      }
      if (psp) {
        canvas.addEventListener("blur", clearPadInput, { signal });
        window.addEventListener("blur", clearPadInput, { signal });
        document.addEventListener("visibilitychange", clearPadInput, { signal });
      }

      function setPSPPaused(paused) {
        pspPaused = paused;
        pauseButton.textContent = t(paused ? "继续游戏" : "暂停");
        pauseButton.disabled = Boolean(currentUtility && !paused);
        clearInput();
        clearPadInput();
        if (paused) {
          clearTimeout(timer);
          skipPendingAudio = busy;
          audioOutput?.reset();
          worker.postMessage({ kind: "psp-checkpoint" });
          pauseButton.focus();
        } else {
          if (currentUtility && document.activeElement === pauseButton) {
            utility.querySelector("input:not(:disabled), button:not(:disabled)")?.focus();
          } else if (!currentUtility) {
            canvas.focus();
          }
          nextFrame = undefined;
          advance();
        }
      }

      function pollPSPGamepad() {
        if (document.hidden || !document.hasFocus()) {
          clearPadInput();
          return;
        }
        const pad = readPSPGamepad();
        if (pad && !padHelpShown) {
          controlsLabel.textContent += " · " + t("L1 暂停或继续 · R1 开始 · L2/R2 为 PSP 肩键");
          padHelpShown = true;
        }
        const shoulder = Boolean(pad?.leftShoulder);
        const toggle = shoulder && !leftShoulderDown;
        leftShoulderDown = shoulder;
        if (toggle && !savingAndClosing && !saveCloseFailed &&
            (pspPaused || (!currentUtility && document.activeElement === canvas))) {
          setPSPPaused(!pspPaused);
          return;
        }
        padState = !pspPaused && !currentUtility && document.activeElement === canvas ? pad : undefined;
        if (padState) latchedPadButtons |= padState.buttons;
        else latchedPadButtons = 0;
      }

      function presentUtility(request) {
        currentUtility = request;
        pauseButton.disabled = Boolean((request && !pspPaused) || savingAndClosing || saveCloseFailed);
        utility.replaceChildren();
        utility.hidden = !request;
        if (!request) {
          if (!savingAndClosing && !pspPaused) canvas.focus();
          return;
        }
        clearInput();
        clearPadInput();
        const form = document.createElement("form");
        const caption = document.createElement("p");
        caption.textContent = request.type === 2 ? request.description : request.message;
        form.append(caption);
        const actions = document.createElement("div");
        actions.className = "row";
        const answer = data => {
          if (currentUtility !== request || savingAndClosing) return;
          for (const field of form.elements) field.disabled = true;
          worker.postMessage({ kind: "psp-utility-answer", id: request.id, ...data });
          if (pspPaused) pauseButton.focus();
        };
        const button = (text, action) => {
          const item = document.createElement("button");
          item.type = "button";
          item.textContent = text;
          item.addEventListener("click", action);
          actions.append(item);
          return item;
        };
        let focus;
        if (request.type === 2) {
          const input = document.createElement("input");
          input.type = "text";
          input.value = request.text;
          input.setAttribute("aria-label", caption.textContent || t("输入文字"));
          input.maxLength = request.textLimit > 0 ? Math.min(request.textLimit, 2047) : 2047;
          form.append(input);
          focus = input;
          const submit = () => answer({ text: input.value });
          button(request.okayLabel || t("确定"), submit);
          form.addEventListener("submit", event => { event.preventDefault(); submit(); });
        } else {
          form.addEventListener("submit", event => event.preventDefault());
          for (const [allowed, label, choice] of [
            [request.allowYes, t("是"), 1], [request.allowNo, t("否"), 2],
            [request.allowOK, request.okayLabel || t("确定"), 4]
          ]) {
            if (!allowed) continue;
            const item = button(label, () => answer({choice}));
            if (!focus || request.defaultAnswer === choice) focus = item;
          }
        }
        if (request.allowCancel) {
          const cancel = () => answer({choice:3});
          const item = button(request.cancelLabel || t("取消"), cancel);
          if (!focus) focus = item;
          form.addEventListener("keydown", event => {
            if (event.key === "Escape") { event.preventDefault(); event.stopPropagation(); cancel(); }
          });
        }
        form.append(actions);
        utility.append(form);
        focus?.focus();
      }
      function reportCloseFailure(conflict = false) {
        clearTimeout(closeTimer);
        saveConflict = conflict;
        savingAndClosing = false;
        saveCloseFailed = true;
        closeButton.disabled = false;
        closeButton.textContent = t("放弃未保存进度并关闭");
        const message = conflict ? "其他标签页已保存此游戏。关闭将放弃本次未保存进度。"
          : n64 ? "N64 存档保存失败。按 Esc 可重试。" : "PSP 存档保存失败。按 Esc 可重试。";
        status.textContent = t(message);
      }
      closeCore = () => {
        clearTimeout(timer);
        clearTimeout(closeTimer);
        worker.terminate();
      };
      function fail(code) {
        if (failed || signal.aborted) return;
        failed = true;
        pauseButton.hidden = true;
        cancelAnimationFrame(frameRequest);
        if (!(code === "runtime" && requestPersistentClose)) closeCore();
        status.textContent = code === "firmware" ? (format.discMedia === "pcecd"
          ? t("PC Engine CD 试玩需要有效的 System Card。") : t("固件读取失败。"))
          : code === "runtime" ? t("试玩已停止，模拟器运行出错。") : t("无法启动这款游戏。");
      }
      function advance() {
        if (failed || signal.aborted || savingAndClosing || pspPaused) return;
        const now = performance.now();
        if (!document.hidden && !busy && (audioOutput?.ahead() || 0) < 0.32) {
          if (nextFrame == null || now - nextFrame > interval * 5) nextFrame = now;
          if (now >= nextFrame) {
            const frames = Math.min(3, Math.floor((now - nextFrame) / interval) + 1);
            busy = true;
            nextFrame += frames * interval;
            const panel = arcadeControl === 7 ? gunPosition : trackX || trackY ? [trackX, trackY] : undefined;
            const pad = psp && document.activeElement === canvas && document.hasFocus() ? padState : undefined;
            const buttons = readInput() | (pad ? pad.buttons | latchedPadButtons : 0);
            latchedPadButtons = 0;
            worker.postMessage({ kind: "step", frames, buttons, panel, analog: pad?.analog });
            trackX = trackY = 0;
          }
        }
        // The display clock can be throttled independently of the audio
        // device. Keep making audio while paint requests are coalesced.
        timer = setTimeout(advance, 4);
      }
      function draw() {
        if (failed || signal.aborted) return;
        if (psp && !savingAndClosing && !saveCloseFailed) pollPSPGamepad();
        if (pendingVideo) {
          try {
            displayAspect = pendingVideo.displayAspect || displayAspect;
            resizeVideo(pendingVideo.width, pendingVideo.height);
            paintVideo(pendingVideo.pixels, pendingVideo.rgbaPixels);
            pendingVideo = null;
          } catch {
            fail("runtime");
            return;
          }
        }
        frameRequest = requestAnimationFrame(draw);
      }
      worker.addEventListener("error", () => fail("runtime"), { signal });
      worker.addEventListener("message", ({ data }) => {
        if (signal.aborted) return;
        if (data.kind === `${persistentSystem}-closed`) {
          dialog.close();
          return;
        }
        if (data.kind === `${persistentSystem}-close-error`) {
          reportCloseFailure(Boolean(data.conflict));
          return;
        }
        if (data.kind === "psp-utility") {
          if (!savingAndClosing) presentUtility(data.request);
          return;
        }
        if (data.kind === "psp-utility-error") {
          if (currentUtility?.id === data.id) presentUtility(currentUtility);
          return;
        }
        if (data.kind === `${persistentSystem}-storage-error`) {
          if (!savingAndClosing) status.textContent = t(n64 ? "N64 本地存档未写入。关闭前将重试。" : "PSP 本地存档未写入。关闭前将重试。");
          return;
        }
        if (failed) return;
        if (data.kind === "error") {
          fail(data.code);
        } else if (data.kind === "ready") {
          if (psp) {
            pauseButton.hidden = false;
            pauseButton.disabled = false;
            pauseButton.textContent = t("暂停");
            pauseButton.addEventListener("click", () => setPSPPaused(!pspPaused), { signal });
          }
          if (psp || n64) {
            requestPersistentClose = discardAllowed => {
              if (saveCloseFailed && discardAllowed) { dialog.close(); return; }
              if (savingAndClosing || saveConflict) return;
              savingAndClosing = true;
              saveCloseFailed = false;
              clearTimeout(timer);
              pauseButton.disabled = true;
              closeButton.disabled = true;
              closeButton.textContent = t("关闭");
              status.textContent = t(n64 ? "正在保存 N64 存档…" : "正在保存 PSP 存档…");
              worker.postMessage({ kind: `${persistentSystem}-close` });
              closeTimer = setTimeout(reportCloseFailure, 12000);
            };
            document.addEventListener("visibilitychange", () => {
              if (document.hidden && !savingAndClosing && !failed) worker.postMessage({ kind: `${persistentSystem}-checkpoint` });
            }, { signal });
          }
          interval = 1_000_000 / data.refresh;
          sampleRate = data.sampleRate;
          rotation = data.rotation;
          displayAspect = data.displayAspect || displayAspect;
          arcadeControl = data.arcadeControl || 0;
          if (arcadeControl) {
            clearInput();
            if ([2, 10, 11].includes(arcadeControl)) {
              activeKeys = twinStickKeys;
              controlsMask = 0xffff;
            } else if (arcadeControl === 9) {
              activeKeys = mahjongKeys;
              controlsMask = ((data.mahjongWiredKeys || 0) << 12) | 0xc00;
            }
            if (arcadeControl === 7) canvas.style.cursor = "crosshair";
            const group = ({ 6: 1, 8: 3, 11: 10, 15: 3 })[arcadeControl] || arcadeControl;
            if (arcadeControls[group]) controlsLabel.textContent = t(arcadeControls[group]);
            if (data.lightGunReloads) controlsLabel.textContent += " · " + t("Z 装弹");
          }
          if (data.paddleConfiguration) {
            controlsMask |= 0x8000;
            const label = "方向键移动 · F2 设置机台旋钮 · Q/W 转动旋钮 · X 发射 · C 投币 · Enter 开始";
            controlsLabel.textContent = t(label);
          } else if (data.hasDial) {
            const label = "方向键移动 · Q/W 转动旋钮 · X/Z/A/S/D/F 为动作键 · C 投币 · Enter 开始";
            controlsLabel.textContent = t(label);
          } else if (data.inputLayout === 8) {
            const label = "方向键移动 · X/Z/A 为动作键 · C/V 投币 · Enter 开始";
            controlsLabel.textContent = t(label);
          }
          showControllerLayout(Boolean(arcadeControl || data.paddleConfiguration || data.hasDial || data.inputLayout === 8));
          if (data.count > 1) {
            diskSide.setAttribute("aria-label", t("光盘"));
            diskSide.replaceChildren(...Array.from({ length: data.count }, (_, i) =>
              new Option(t("第 {number} 碟", { number: i + 1 }), i)));
            diskSide.value = data.disc;
            diskToggle.textContent = t("切换光盘");
            diskToggle.addEventListener("click", () => {
              if (diskToggle.disabled) return;
              diskSide.disabled = diskToggle.disabled = true;
              busy = waitingForDiscReply = true;
              worker.postMessage({ kind: "disc", index: Number(diskSide.value) });
              canvas.focus();
            }, { signal });
            diskControls.hidden = false;
          }
          draw();
          advance();
        } else if (data.kind === "disc") {
          busy = waitingForDiscReply = false;
          discTrayOpen = data.changed && data.disc < 0;
          if (!discTrayOpen) {
            diskSide.value = data.disc;
            diskSide.disabled = diskToggle.disabled = false;
          }
          if (discTrayOpen) {
            status.textContent = t("正在切换光盘…");
          } else if (data.changed) {
            status.textContent = "";
            audioOutput?.reset();
            pendingVideo = null;
            nextFrame = undefined;
          } else {
            status.textContent = t("无法切换磁碟。");
          }
        } else if (data.kind === "frame") {
          try {
            if (!pspPaused && !savingAndClosing && !skipPendingAudio) audioOutput?.write(data.audio, 2, sampleRate);
            skipPendingAudio = false;
            pendingVideo = data;
            if (data.duration > 0 && nextFrame != null) nextFrame += data.duration - data.frames * interval;
            if (discTrayOpen && data.disc >= 0) {
              diskSide.value = data.disc;
              diskSide.disabled = diskToggle.disabled = false;
              discTrayOpen = false;
              status.textContent = "";
            }
            if (status.textContent === t("正在加载试玩…")) status.textContent = "";
            busy = waitingForDiscReply;
          } catch {
            fail("runtime");
          }
        }
      }, { signal });
      worker.postMessage({ kind: "init", url, driver, mediaPath, module: format.module,
        simdModule: format.simdModule,
        arcade: format.worker, systemID: format.systemID, discKind: format.discMedia, analogPorts: format.analogPorts,
        discProfile: format.discProfile, discBIOS: format.discBIOS, headers });
    }

    try {
      if (offThread) return playInWorker();
      const media = { headers, signal, cache: "no-store" };
      const entry = url.slice(0, -"/preview-rom".length);
      const [response, { instance }, firmware, coprocessor, adapter] = await Promise.all([
        fetch(url, media),
        WebAssembly.instantiateStreaming(fetch(`/assets/${format.module}`, { signal }), {}),
        format.packageFirmware ? fetch(`${entry}/preview-firmware/system-firmware`, media)
          : format.firmware ? fetch(`/api/preview/firmware/${format.firmware}`, media) : null,
        format.packageFirmware ? fetch(`${entry}/preview-firmware/coprocessor-firmware`, media) : null,
        format.adapterFirmware ? fetch(`${entry}/preview-firmware/adapter-firmware`, media) : null
      ]);
      if (!response.ok) throw new Error(t("ROM 读取失败（{status}）", { status: response.status }));
      if ([firmware, coprocessor, adapter].some(resource => resource && !resource.ok)) {
        throw new Error(disk ? t("FDS 试玩需要有效的 disksys.rom。") : t("固件读取失败。"));
      }
      const read = async resource => resource && resource.status !== 204 ? new Uint8Array(await resource.arrayBuffer()) : null;
      const [data, bios, chip, addon] = await Promise.all([read(response), read(firmware), read(coprocessor), read(adapter)]);
      if (signal.aborted) return;
      const wasm = instance.exports;
      wasm._initialize();
      closeCore = wasm.preview_close;
      function setClock() {
        if (!wasm.preview_set_time) return;
        const now = Math.floor(Date.now() / 1000);
        wasm.preview_set_time(BigInt(now), BigInt(now - new Date().getTimezoneOffset() * 60));
      }
      setClock();
      const buffers = [];
      function allocate(bytes) {
        const pointer = wasm.malloc(bytes.length);
        if (!pointer) throw new Error(t("无法启动这款游戏。"));
        buffers.push(pointer);
        new Uint8Array(wasm.memory.buffer, pointer, bytes.length).set(bytes);
        return pointer;
      }
      let refreshMilliHz;
      try {
        const pointer = allocate(data);
        const biosPointer = bios ? allocate(bios) : 0;
        const chipPointer = chip ? allocate(chip) : 0;
        const addonPointer = addon ? allocate(addon) : 0;
        if (format.atari) {
          const board = new TextEncoder().encode(format.atari.board);
          if (!wasm.preview_configure(allocate(board), board.length,
            format.atari.standard, format.atari.option, format.atari.ports)) {
            throw new Error(t("无法启动这款游戏。"));
          }
        }
        if (configuredCore) refreshMilliHz = wasm.preview_boot(format.systemID, pointer, data.length,
          biosPointer, bios?.length || 0, chipPointer, chip?.length || 0, addonPointer, addon?.length || 0);
        else if (disk) refreshMilliHz = wasm.preview_boot_disk(pointer, data.length, biosPointer, bios?.length || 0);
        else refreshMilliHz = wasm.preview_boot(pointer, data.length);
      } finally {
        for (const pointer of buffers) wasm.free(pointer);
      }
      if (!refreshMilliHz) throw new Error(t("无法启动这款游戏。"));

      resizeVideo(configuredCore ? wasm.preview_width() : 256, configuredCore ? wasm.preview_height() : 240);
      const audioChannels = configuredCore ? 2 : 1;
      const audioRate = configuredCore ? wasm.preview_audio_rate() : 44100;
      setClock();
      if (disk) {
        let inserted = true;
        diskSide.setAttribute("aria-label", t("磁碟面"));
        diskSide.replaceChildren(...Array.from({ length: wasm.preview_disk_sides() }, (_, i) =>
          new Option(t("第 {number} 面", { number: i + 1 }), i)));
        diskToggle.textContent = t("弹出磁碟");
        function changeDisk(next) {
          if (wasm.preview_disk(Number(diskSide.value), Number(next))) {
            inserted = next;
            diskToggle.textContent = t(inserted ? "弹出磁碟" : "插入磁碟");
            status.textContent = "";
          } else {
            status.textContent = t("无法切换磁碟。");
          }
        }
        diskToggle.addEventListener("click", () => { changeDisk(!inserted); canvas.focus(); }, { signal });
        diskSide.addEventListener("change", () => changeDisk(false), { signal });
        diskControls.hidden = false;
      }
      const interval = 1_000_000 / refreshMilliHz;
      const framePointer = wasm.preview_pixels();
      const audioPointer = wasm.preview_audio();

      function renderDueFrame(now) {
        if (nextFrame == null || now - nextFrame > interval * 4) nextFrame = now;
        if (now >= nextFrame && !document.hidden && (audioOutput?.ahead() || 0) < 0.32) {
          let input = readInput();
          if (format.controls === "atari5200") {
            wasm.preview_set_controller(0, -1, -1, input >>> 16);
            input &= 0xffff;
          }
          do {
            if (lightGunPort !== undefined) {
              const heldAim = gunTrigger ? null : pendingLightGunShot;
              const [x, y] = (heldAim ? heldAim.position : gunPosition) || [0, 0];
              const inBounds = heldAim?.onScreen ?? gunOnScreen;
              const flags = Number(inBounds) | (gunTrigger || pendingLightGunShot || (input & 1) ? 2 : 0);
              if (!wasm.preview_set_light_gun(lightGunPort, x, y, flags)) throw new Error("Light gun input rejected");
              if (pendingLightGunShot && --pendingLightGunShot.frames === 0) pendingLightGunShot = null;
            }
            const samples = wasm.preview_step(input);
            if (samples < 0) throw new Error("Emulator frame failed");
            if (samples && audioOutput) audioOutput.write(
              new Float32Array(wasm.memory.buffer, audioPointer, samples * audioChannels), audioChannels, audioRate);
            nextFrame += interval;
          } while (nextFrame <= now);

          if (format.dynamicVideo) resizeVideo(wasm.preview_width(), wasm.preview_height());
          paintVideo(new Uint32Array(wasm.memory.buffer, framePointer, pixels.length));
        }
      }
      function advance(now) {
        try {
          renderDueFrame(now);
          frameRequest = requestAnimationFrame(advance);
        } catch {
          status.textContent = t("试玩已停止，模拟器运行出错。");
        }
      }

      status.textContent = "";
      frameRequest = requestAnimationFrame(advance);
    } catch (error) {
      if (!signal.aborted) status.textContent = error instanceof TypeError || error instanceof WebAssembly.CompileError
        ? t("无法加载网页模拟器。") : error.message;
    }
  }

  return { open };
})();
