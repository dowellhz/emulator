"use strict";

(function (scope) {
  const VERSION = 1, WIRE_BYTES = 8908, MAX_UNITS = 2047;
  const utf8 = new TextDecoder("utf-8", { ignoreBOM: true });
  const utf16 = new TextDecoder("utf-16le", { ignoreBOM: true });

  function readRequest(core) {
    const address = core.preview_utility_request() >>> 0;
    if (!address) return null;
    const data = new DataView(core.memory.buffer, address, WIRE_BYTES);
    const u32 = offset => data.getUint32(offset, true);
    const type = u32(16);
    const flags = u32(24);
    const descriptionUnits = u32(68);
    const textUnits = u32(72);
    const id = data.getBigUint64(8, true);
    if (u32(0) !== VERSION || u32(4) !== WIRE_BYTES || !id ||
        (type !== 1 && type !== 2) || (flags & ~31) || u32(76) ||
        descriptionUnits > MAX_UNITS || textUnits > MAX_UNITS) {
      throw new Error("Invalid PSP utility request");
    }
    function field(decoder, offset, length, terminated = false) {
      const bytes = new Uint8Array(data.buffer, data.byteOffset + offset, length);
      const zero = terminated ? bytes.indexOf(0) : -1;
      return decoder.decode(zero < 0 ? bytes : bytes.subarray(0, zero));
    }
    return {
      id, type, status: u32(20), canAnswer: !!(flags & 1),
      allowYes: !!(flags & 2), allowNo: !!(flags & 4),
      allowCancel: !!(flags & 8), allowOK: !!(flags & 16),
      mode: u32(28), options: u32(32), errorCode: u32(36), language: u32(40),
      buttonSwap: u32(44), defaultAnswer: u32(48), opacity: u32(52),
      textLimit: u32(56), inputLanguage: u32(60), inputType: u32(64),
      message: field(utf8, 80, 512, true),
      okayLabel: field(utf8, 592, 64, true),
      cancelLabel: field(utf8, 656, 64, true),
      description: field(utf16, 720, descriptionUnits * 2),
      text: field(utf16, 4814, textUnits * 2)
    };
  }

  function answerText(core, id, string) {
    if (typeof id !== "bigint" || id <= 0n || id >= (1n << 64n) || typeof string !== "string")
      throw new TypeError("Invalid PSP keyboard answer");
    const address = core.preview_utility_text_input() >>> 0;
    if (!address) throw new Error("Missing PSP keyboard input buffer");
    const staging = new DataView(core.memory.buffer, address, MAX_UNITS * 2);
    let written = 0;
    for (let i = 0; i < string.length && written < MAX_UNITS; ++i) {
      const unit = string.charCodeAt(i);
      if (unit === 0) break;
      // PSP keeps UCS-2 characters. Filter before applying the transport's cap.
      if (unit >= 0xd800 && unit <= 0xdfff) continue;
      staging.setUint16(written++ * 2, unit, true);
    }
    return core.preview_utility_answer_text(id, written);
  }

  const utility = { readRequest, answerText };
  if (typeof module === "object" && module.exports) module.exports = utility;
  else scope.FCPreviewPSPUtility = utility;
})(typeof self === "object" ? self : globalThis);
