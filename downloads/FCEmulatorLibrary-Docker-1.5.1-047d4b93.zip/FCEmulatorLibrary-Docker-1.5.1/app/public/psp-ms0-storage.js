"use strict";

(function (scope) {
  const DB_NAME="fc-preview-psp-ms0-v1", STORE_NAME="volumes";

  function openStore(indexedDB=scope.indexedDB) {
    if(!indexedDB)return Promise.reject(new Error("Browser storage is unavailable"));
    return new Promise((resolve,reject)=>{
      const open=indexedDB.open(DB_NAME,1);
      open.onupgradeneeded=()=>open.result.createObjectStore(STORE_NAME);
      open.onerror=()=>reject(open.error);
      open.onblocked=()=>reject(new Error("Browser memory stick storage is blocked"));
      open.onsuccess=()=>{
        const db=open.result;
        db.onversionchange=()=>db.close();
        resolve({
          load(key) {
            return new Promise((done,failed)=>{
              const tx=db.transaction(STORE_NAME,"readonly");
              const req=tx.objectStore(STORE_NAME).get(key);
              tx.onabort=()=>failed(tx.error);
              tx.oncomplete=()=>done(req.result??{generation:0,image:null});
            });
          },
          compareAndSave(key,generation,image) {
            return new Promise((done,failed)=>{
              const tx=db.transaction(STORE_NAME,"readwrite");
              const store=tx.objectStore(STORE_NAME);
              const read=store.get(key);
              let conflict=false;
              read.onsuccess=()=>{
                const latest=read.result?.generation??0;
                const next=generation+1;
                if(latest!==generation||!Number.isSafeInteger(next)){
                  conflict=true;
                  tx.abort();
                  return;
                }
                try{store.put({generation:next,image},key);}catch(error){tx.abort();failed(error);}
              };
              tx.onabort=()=>failed(conflict?new Error("PSP memory stick changed in another session"):tx.error);
              tx.oncomplete=()=>done(generation+1);
            });
          },
          close(){db.close();}
        });
      };
    });
  }

  async function attach({store,key,makeVolume}) {
    if(typeof key!=="string"||!/^[A-Za-z0-9_-]{1,128}$/.test(key))
      throw new TypeError("Invalid PSP volume key");
    const saved=await store.load(key);
    if(!saved||!Number.isSafeInteger(saved.generation)||saved.generation<0)
      throw new Error("Invalid PSP volume generation");
    let generation=saved.generation,committed=0,tail=Promise.resolve();
    const volume=makeVolume(saved.image);
    return {
      volume,
      checkpoint() {
        const next=tail.catch(()=>{}).then(async()=>{
          const revision=volume.revision;
          if(revision===committed)return;
          generation=await store.compareAndSave(key,generation,volume.exportImage());
          committed=revision;
        });
        tail=next;
        return next;
      },
      get dirty(){return committed!==volume.revision;}
    };
  }

  const storage={openStore,attach};
  if(typeof module==="object"&&module.exports)module.exports=storage;
  else scope.FCPSPMemoryStickStorage=storage;
})(typeof self==="object"?self:globalThis);
