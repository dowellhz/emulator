"use strict";

(function (root) {
  const BLOCK = 1024;
  const FADE = 0.005;
  const LEAD = 0.14;

  function create(context) {
    const gain = context.createGain();
    gain.connect(context.destination);
    const active = new Set();
    const samples = [new Float32Array(BLOCK), new Float32Array(BLOCK)];
    const tail = [0, 0];
    let used = 0, sourceRate = 0, phase = 0, end = 0, fadeAt = 0, closed = false;

    function scheduleBlock() {
      const now = context.currentTime;
      const contiguous = end > now + 0.004;
      const start = contiguous ? end : now + LEAD;
      if (fadeAt > now) gain.gain.cancelScheduledValues(fadeAt);
      if (!contiguous || fadeAt <= now) {
        gain.gain.setValueAtTime(0, start);
        gain.gain.linearRampToValueAtTime(1, start + FADE);
      }

      const buffer = context.createBuffer(2, BLOCK, context.sampleRate);
      buffer.copyToChannel(samples[0], 0);
      buffer.copyToChannel(samples[1], 1);
      const source = context.createBufferSource();
      source.buffer = buffer;
      source.connect(gain);
      active.add(source);
      source.onended = () => { active.delete(source); source.disconnect(); };
      source.start(start);
      end = start + buffer.duration;
      fadeAt = end - FADE;
      // Keep the last scheduled block click-free if the emulator stalls.
      // The next block cancels this fade while it is still in the future.
      gain.gain.setValueAtTime(1, fadeAt);
      gain.gain.linearRampToValueAtTime(0, end);
    }

    function push(left, right) {
      samples[0][used] = left;
      samples[1][used] = right;
      if (++used === BLOCK) {
        scheduleBlock();
        used = 0;
      }
    }

    function reset() {
      for (const source of active) {
        source.stop();
        source.disconnect();
      }
      active.clear();
      gain.gain.cancelScheduledValues(context.currentTime);
      gain.gain.setValueAtTime(1, context.currentTime);
      used = sourceRate = phase = end = fadeAt = 0;
    }

    return {
      write(input, channels, rate) {
        if (!input.length || closed || context.state !== "running") return;
        if (sourceRate && sourceRate !== rate) reset();
        sourceRate = rate;
        const frames = input.length / channels;
        const right = channels - 1;
        if (rate === context.sampleRate) {
          for (let i = 0; i < input.length; i += channels) push(input[i], input[i + right]);
          return;
        }
        const stride = rate / context.sampleRate;
        while (phase < frames - 1) {
          const previous = Math.floor(phase);
          const index = previous * channels;
          const fraction = phase - previous;
          const left = previous < 0 ? tail[0] : input[index];
          const other = previous < 0 ? tail[1] : input[index + right];
          push(left + (input[index + channels] - left) * fraction,
            other + (input[index + channels + right] - other) * fraction);
          phase += stride;
        }
        phase -= frames;
        tail[0] = input[(frames - 1) * channels];
        tail[1] = input[(frames - 1) * channels + right];
      },
      ahead() { return context.state === "running" ? Math.max(0, end - context.currentTime) : 0; },
      reset,
      close() {
        if (closed) return;
        reset();
        closed = true;
        gain.disconnect();
      }
    };
  }

  if (typeof module === "object" && module.exports) module.exports = { create };
  else root.FCPreviewAudio = { create };
})(globalThis);
