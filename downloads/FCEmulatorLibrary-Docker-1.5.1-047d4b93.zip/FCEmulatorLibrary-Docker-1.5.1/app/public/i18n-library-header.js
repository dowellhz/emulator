// Import panel labels. The source keys are the Simplified Chinese UI.
for (const [locale, labels] of Object.entries({
  en: ["Import games", "Drop files here or click to upload", "Supported formats"],
  de: ["Spiele importieren", "Dateien hierher ziehen oder zum Hochladen klicken", "Unterstützte Formate"],
  es: ["Importar juegos", "Arrastra archivos aquí o haz clic para subirlos", "Formatos compatibles"],
  ja: ["ゲームをインポート", "ファイルをドロップするか、クリックしてアップロード", "対応形式"],
  ko: ["게임 가져오기", "파일을 여기에 끌어 놓거나 클릭하여 업로드", "지원 형식"],
  "zh-Hant": ["匯入遊戲", "將檔案拖曳到這裡，或點擊上傳", "支援的格式"]
})) {
  FCI18n.addMessages({
    "导入游戏": labels[0],
    "拖拽文件到这里，或点击上传": labels[1],
    "支持的格式": labels[2]
  }, locale);
}
