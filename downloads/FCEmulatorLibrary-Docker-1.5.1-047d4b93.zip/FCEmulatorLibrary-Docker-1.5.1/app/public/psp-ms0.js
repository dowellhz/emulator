"use strict";

(function(scope){

const ERR={BADF:8,EXIST:20,FAULT:21,FBIG:22,INVAL:28,IO:29,ISDIR:31,
  MFILE:33,NOENT:44,NOSPC:51,NOTDIR:54,NOTEMPTY:55,OVERFLOW:61,ROFS:69,
  XDEV:75,NOTCAPABLE:76};
const DIR=3, REG=4, PREOPEN=4, FIRST=1024, LAST=4095;
const ALL=0x1fffffffn, MAX_OFFSET=(1n<<63n)-1n;
const FILE_READ=2n, FILE_WRITE=64n, APPEND=1;
const text=new TextEncoder(), utf8=new TextDecoder("utf-8",{fatal:true});
const required={
  path_create_directory:9,path_rename_source:16,path_rename_target:17,
  path_filestat_get:18,path_filestat_set_times:20,path_remove_directory:25,
  path_unlink_file:26,fd_filestat_get:21,fd_filestat_set_times:23,
  fd_fdstat_set_flags:3,fd_sync:4,fd_datasync:0,fd_seek:2,fd_tell:5,fd_readdir:14
};

function create(media,{maxBytes=32*1024*1024,maxNodes=8192,image=null}={}) {
  if (!Number.isSafeInteger(maxBytes)||maxBytes<1||maxBytes>512*1024*1024||
      !Number.isSafeInteger(maxNodes)||maxNodes<2||maxNodes>65535)
    throw new TypeError("invalid ms0 quota");
  const underlying=media.imports.wasi_snapshot_preview1;
  let memory, inode=0n, used=0, inodeCount=0, revision=0;
  const handles=new Map();
  function allocate(type) {
    const node={type,id:++inode,children:type===DIR?new Map():null,
      parent:null,bytes:new Uint8Array(),atime:0n,mtime:0n,ctime:0n,links:1,opens:0};
    inodeCount++;
    return node;
  }
  function dispose(node) {
    if(!node.opens&&!node.links){
      used-=node.bytes.length;
      inodeCount--;
    }
  }
  const root=allocate(DIR);
  handles.set(PREOPEN,{node:root,offset:0n,flags:0,rights:ALL,inheriting:ALL});
  function validComponent(name) {
    return typeof name==="string"&&name&&name!=="."&&name!==".."&&
      !/[\\/\0-\x1f\x7f]/.test(name)&&text.encode(name).length<=255;
  }
  function validStamp(value) {
    return typeof value==="bigint"&&value>=0n&&value<=(1n<<64n)-1n;
  }
  if(image!==null) {
    if(image.version!==1||!Array.isArray(image.entries)||!image.entries.length||
        image.entries.length>maxNodes||image.entries[0]?.path?.length!==0)
      throw new Error("Invalid PSP ms0 volume");
    for(const [index,entry] of image.entries.entries()) {
      if(!entry||!Array.isArray(entry.path)||entry.path.length>64||
           entry.path.some(p=>!validComponent(p))||
           ![DIR,REG].includes(entry.type)||typeof entry.atime!=="bigint"||
           ![entry.atime,entry.mtime,entry.ctime].every(validStamp)||
           (entry.type===DIR ? entry.contents!==null : !(entry.contents instanceof Uint8Array)))
        throw new Error("Invalid PSP ms0 entry");
      if(!entry.path.length && (index!==0||entry.type!==DIR))
        throw new Error("Invalid PSP ms0 root");
      let node=root;
      if(entry.path.length) {
        for(const name of entry.path.slice(0,-1))node=node?.children?.get(name);
        const name=entry.path.at(-1);
        if(!node?.children||node.children.has(name))
          throw new Error("Invalid nested PSP ms0 entry");
        const parent=node;
        node=allocate(entry.type);
        node.parent=parent;
        parent.children.set(name,node);
        if(entry.contents) {
          if(entry.contents.length>maxBytes-used)throw new Error("PSP ms0 quota");
          node.bytes=new Uint8Array(entry.contents);
          used+=node.bytes.length;
        }
      }
      node.atime=entry.atime; node.mtime=entry.mtime; node.ctime=entry.ctime;
    }
  }
  function exportImage() {
    const entries=[], stack=[[root,[]]];
    while(stack.length) {
      const [node,path]=stack.pop();
      entries.push({path,type:node.type,atime:node.atime,mtime:node.mtime,
        ctime:node.ctime,contents:node.type===REG?node.bytes.slice():null});
      if(node.children)
        for(const [name,child] of [...node.children].reverse())stack.push([child,[...path,name]]);
    }
    return {version:1,entries};
  }
  function view(ptr,length) {
    if(!memory||!Number.isInteger(length)||length<0)return null;
    const offset=ptr>>>0;
    return offset<=memory.buffer.byteLength && length<=memory.buffer.byteLength-offset
      ? new DataView(memory.buffer,offset,length):null;
  }
  function bytes(ptr,length) {
    const d=view(ptr,length);
    return d?new Uint8Array(d.buffer,d.byteOffset,d.byteLength):null;
  }
  function getPath(ptr,length) {
    const raw=bytes(ptr,length);
    if(!raw)return [ERR.FAULT];
    if(!length||length>4096)return [ERR.INVAL];
    let str;
    try{str=utf8.decode(raw);}catch{return [ERR.INVAL];}
    if(str==="."||str==="./")return [0,[]];
    if(str.startsWith("/") || /[\\\0-\x1f\x7f]/.test(str))return [ERR.NOTCAPABLE];
    const path=str.replace(/\/$/,"").split("/");
    if(path.length>64||path.some(p=>!validComponent(p)))return [ERR.NOTCAPABLE];
    return [0,path];
  }
  function resolve(fd,ptr,len,missing=false) {
    const h=handles.get(fd);
    if(!h||h.node.type!==DIR)return [ERR.NOTDIR];
    const [error,path]=getPath(ptr,len);
    if(error)return [error];
    let node=h.node,parent,leaf;
    for(const [index,name] of path.entries()){
      if(node.type!==DIR)return [ERR.NOTDIR];
      parent=node;
      leaf=name;
      node=node.children.get(name);
      if(!node){
        if(missing&&index===path.length-1)return [0,null,parent,leaf];
        return [ERR.NOENT];
      }
    }
    return [0,node,parent,leaf];
  }
  function install(handle, minimum, out) {
    const result=view(out,4);
    if(!result)return ERR.FAULT;
    for(let fd=Math.max(FIRST,minimum);fd<=LAST;fd++){
      if(handles.has(fd))continue;
      handles.set(fd,handle);
      handle.node.opens++;
      result.setUint32(0,fd,true);
      return 0;
    }
    return ERR.MFILE;
  }
  function detach(fd){
    const h=handles.get(fd);
    handles.delete(fd);
    h.node.opens--;
    dispose(h.node);
  }
  function resize(node,length){
    if(length<0)return ERR.INVAL;
    if(length>maxBytes)return ERR.FBIG;
    const next=used-node.bytes.length+length;
    if(next>maxBytes)return ERR.NOSPC;
    if(length===node.bytes.length)return 0;
    try{
      const replacement=new Uint8Array(length);
      replacement.set(node.bytes.subarray(0,length));
      node.bytes=replacement;
    }catch{return ERR.NOSPC;}
    used=next;
    revision++;
    return 0;
  }
  function stat(node,out) {
    const v=view(out,64);
    if(!v)return ERR.FAULT;
    bytes(out,64).fill(0);
    v.setBigUint64(0,0xfc00n,true);
    v.setBigUint64(8,node.id,true);
    v.setUint8(16,node.type);
    v.setBigUint64(24,BigInt(node.links),true);
    v.setBigUint64(32,BigInt(node.bytes.length),true);
    for(const [offset,key] of [[40,"atime"],[48,"mtime"],[56,"ctime"]])
      v.setBigUint64(offset,node[key],true);
    return 0;
  }
  function transfer(fd,iov,count,offset,out,reading,advance) {
    const h=handles.get(fd), result=view(out,4);
    if(h.node.type!==REG)return ERR.ISDIR;
    if(!(h.rights&(reading?FILE_READ:FILE_WRITE)))return ERR.NOTCAPABLE;
    if(!result||count<0||count>1024)return ERR.FAULT;
    const vec=view(iov,count*8);
    if(!vec)return ERR.FAULT;
    const buffers=[];
    let requested=0;
    for(let i=0;i<count;i++){
      const buffer=bytes(vec.getUint32(i*8,true),vec.getUint32(i*8+4,true));
      if(!buffer)return ERR.FAULT;
      requested+=buffer.length;
      if(requested>0xffffffff)return ERR.OVERFLOW;
      buffers.push(buffer);
    }
    if(offset<0n || offset>MAX_OFFSET)return ERR.INVAL;
    let position=offset, total=0;
    if(!reading&&requested){
      if(h.flags&APPEND)position=BigInt(h.node.bytes.length);
      const end=position+BigInt(requested);
      if(end>BigInt(maxBytes))return ERR.FBIG;
      const err=resize(h.node,Math.max(Number(end),h.node.bytes.length));
      if(err)return err;
    }
    for(const buf of buffers){
      if(reading){
        if(position>=BigInt(h.node.bytes.length))break;
        const begin=Number(position);
        const chunk=h.node.bytes.subarray(begin,begin+buf.length);
        buf.set(chunk);
        total+=chunk.length;
        position+=BigInt(chunk.length);
      }else{
        if(buf.length)h.node.bytes.set(buf,Number(position));
        total+=buf.length;
        position+=BigInt(buf.length);
      }
    }
    if(advance)h.offset=position;
    if(!reading&&total)revision++;
    result.setUint32(0,total,true);
    return 0;
  }
  function stamp(node,atime,mtime,flags) {
    if(flags&~15||(flags&3)===3||(flags&12)===12)return ERR.INVAL;
    const now=BigInt(Date.now())*1000000n;
    if(flags&3)node.atime=flags&2?now:atime;
    if(flags&12)node.mtime=flags&8?now:mtime;
    revision++;
    return 0;
  }
  function depthOf(node) {
    let depth=0;
    for(let item=node;item.parent;item=item.parent)depth++;
    return depth;
  }
  function remove(fd,ptr,len,directory) {
    const [err,node,parent,leaf]=resolve(fd,ptr,len);
    if(err)return err;
    if(!parent)return ERR.NOTCAPABLE;
    if(directory&&node.type!==DIR)return ERR.NOTDIR;
    if(!directory&&node.type===DIR)return ERR.ISDIR;
    if(directory&&node.children.size)return ERR.NOTEMPTY;
    parent.children.delete(leaf);
    node.links=0;
    dispose(node);
    revision++;
    return 0;
  }
  const ms0={
    fd_prestat_get(fd,out){
      if(fd!==PREOPEN)return ERR.BADF;
      const v=view(out,8);
      if(!v)return ERR.FAULT;
      v.setUint32(0,0,true);
      v.setUint32(4,4,true);
      return 0;
    },
    fd_prestat_dir_name(fd,out,length){
      if(fd!==PREOPEN)return ERR.BADF;
      if(length<4)return ERR.INVAL;
      const s=bytes(out,4);
      if(!s)return ERR.FAULT;
      s.set(text.encode("/ms0"));
      return 0;
    },
    path_open(fd,lookup,ptr,len,oflags,rights,inheriting,fdflags,out){
      if(oflags&~15||fdflags&~31)return ERR.INVAL;
      const h=handles.get(fd);
      if(!(h.rights&(1n<<13n))||(rights&~h.inheriting)||(inheriting&~h.inheriting)||
           ((oflags&1)&&!(h.rights&(1n<<10n))))return ERR.NOTCAPABLE;
      const [err,existing,parent,leaf]=resolve(fd,ptr,len,!!(oflags&1));
      if(err)return err;
      if(existing&&(oflags&5)===5)return ERR.EXIST;
      if((oflags&2)&&existing?.type!==DIR)return ERR.NOTDIR;
      if((oflags&8)&&existing?.type===DIR)return ERR.ISDIR;
      if((oflags&8)&&!(rights&FILE_WRITE))return ERR.NOTCAPABLE;
      if(!existing&&(!parent.links||depthOf(parent)>=64))return ERR.NOTCAPABLE;
      if(!existing&&inodeCount>=maxNodes)return ERR.NOSPC;
      const node=existing||allocate(REG);
      const code=install({node,flags:fdflags,rights,inheriting:node.type===DIR?inheriting:0n,offset:0n},FIRST,out);
      if(code){
        if(!existing){node.links=0;dispose(node);}
        return code;
      }
      if(!existing){parent.children.set(leaf,node);node.parent=parent;revision++;}
      if(oflags&8)resize(node,0);
      return 0;
    },
    path_filestat_get(fd,flags,ptr,len,out){
      const raw=bytes(ptr,len);
      if(raw?.length===2&&raw[0]===46&&raw[1]===46){
        const current=handles.get(fd).node;
        return current.type===DIR?stat(current.parent||current,out):ERR.NOTDIR;
      }
      const [err,node]=resolve(fd,ptr,len);
      return err||stat(node,out);
    },
    path_filestat_set_times(fd,lookup,ptr,len,atime,mtime,flags){
      const [err,node]=resolve(fd,ptr,len);
      return err||stamp(node,atime,mtime,flags);
    },
    path_create_directory(fd,ptr,len){
      const [err,node,parent,leaf]=resolve(fd,ptr,len,true);
      if(err)return err;
      if(node)return ERR.EXIST;
      if(!parent.links||depthOf(parent)>=64)return ERR.NOTCAPABLE;
      if(inodeCount>=maxNodes)return ERR.NOSPC;
      const child=allocate(DIR);
      child.parent=parent;
      parent.children.set(leaf,child);
      revision++;
      return 0;
    },
    path_remove_directory(fd,ptr,len){return remove(fd,ptr,len,true);},
    path_unlink_file(fd,ptr,len){return remove(fd,ptr,len,false);},
    path_rename(fd,ptr,len,nextFd,nextPtr,nextLen){
      if(!handles.has(nextFd))return ERR.XDEV;
      if(!(handles.get(nextFd).rights&(1n<<17n)))return ERR.NOTCAPABLE;
      const [err,node,parent,leaf]=resolve(fd,ptr,len);
      if(err)return err;
      const [nextErr,next,nextParent,nextLeaf]=resolve(nextFd,nextPtr,nextLen,true);
      if(nextErr)return nextErr;
      if(!parent||!nextParent)return ERR.NOTCAPABLE;
      if(node===next)return 0;
      const depth=depthOf(nextParent)+1;
      if(!nextParent.links||depth>64)return ERR.NOTCAPABLE;
      if(node.type===DIR){
        if(next?.type===REG)return ERR.NOTDIR;
        if(next?.children.size)return ERR.NOTEMPTY;
        const visit=[[node,depth]];
        while(visit.length){
          const [item,level]=visit.pop();
          if(item===nextParent)return ERR.INVAL;
          if(level>64)return ERR.NOTCAPABLE;
          if(item.children)
            for(const child of item.children.values())visit.push([child,level+1]);
        }
      }else if(next?.type===DIR)return ERR.ISDIR;
      nextParent.children.set(nextLeaf,node);
      node.parent=nextParent;
      parent.children.delete(leaf);
      if(next){next.links=0;dispose(next);}
      revision++;
      return 0;
    },
    fd_fdstat_get(fd,out){
      const h=handles.get(fd),v=view(out,24);
      if(!v)return ERR.FAULT;
      bytes(out,24).fill(0);
      v.setUint8(0,h.node.type);
      v.setUint16(2,h.flags,true);
      v.setBigUint64(8,h.rights,true);
      v.setBigUint64(16,h.inheriting,true);
      return 0;
    },
    fd_fdstat_set_flags(fd,flags){
      if(flags&~31)return ERR.INVAL;
      handles.get(fd).flags=flags;
      return 0;
    },
    fd_fdstat_set_rights(fd,rights,inheriting){
      const h=handles.get(fd);
      if((rights&~h.rights)||(inheriting&~h.inheriting))return ERR.NOTCAPABLE;
      h.rights=rights;
      h.inheriting=inheriting;
      return 0;
    },
    fd_filestat_get(fd,out){return stat(handles.get(fd).node,out);},
    fd_filestat_set_size(fd,size){
      const {node,rights}=handles.get(fd);
      if(node.type!==REG)return ERR.ISDIR;
      if(!(rights&(1n<<22n)))return ERR.NOTCAPABLE;
      return size>BigInt(maxBytes)?ERR.FBIG:resize(node,Number(size));
    },
    fd_filestat_set_times(fd,atime,mtime,flags){
      return stamp(handles.get(fd).node,atime,mtime,flags);
    },
    fd_seek(fd,delta,whence,out){
      const h=handles.get(fd),v=view(out,8);
      if(h.node.type!==REG)return ERR.ISDIR;
      if(!v)return ERR.FAULT;
      if(whence<0||whence>2)return ERR.INVAL;
      const p=delta+(whence===0?0n:whence===1?h.offset:BigInt(h.node.bytes.length));
      if(p<0n)return ERR.INVAL;
      if(p>MAX_OFFSET)return ERR.OVERFLOW;
      h.offset=p;
      v.setBigUint64(0,p,true);
      return 0;
    },
    fd_tell(fd,out){
      const v=view(out,8);
      if(!v)return ERR.FAULT;
      v.setBigUint64(0,handles.get(fd).offset,true);
      return 0;
    },
    fd_read(fd,iov,count,out){return transfer(fd,iov,count,handles.get(fd).offset,out,true,true);},
    fd_write(fd,iov,count,out){return transfer(fd,iov,count,handles.get(fd).offset,out,false,true);},
    fd_pread(fd,iov,count,position,out){return transfer(fd,iov,count,position,out,true,false);},
    fd_pwrite(fd,iov,count,position,out){return transfer(fd,iov,count,position,out,false,false);},
    fd_readdir(fd,out,length,cookie,usedOut){
      const h=handles.get(fd),dest=bytes(out,length),result=view(usedOut,4);
      if(h.node.type!==DIR)return ERR.NOTDIR;
      if(!dest||!result)return ERR.FAULT;
      if(cookie<0n)return ERR.INVAL;
      const entries=[[".",h.node],["..",h.node.parent||h.node],...h.node.children];
      let copied=0;
      for(let n=Number(cookie);n<entries.length&&copied<length;n++){
        const [name,node]=entries[n], encoded=text.encode(name);
        const entry=new Uint8Array(24+encoded.length),v=new DataView(entry.buffer);
        v.setBigUint64(0,BigInt(n+1),true);
        v.setBigUint64(8,node.id,true);
        v.setUint32(16,encoded.length,true);
        v.setUint8(20,node.type);
        entry.set(encoded,24);
        const chunk=entry.subarray(0,length-copied);
        dest.set(chunk,copied);
        copied+=chunk.length;
      }
      result.setUint32(0,copied,true);
      return 0;
    },
    fd_close(fd){if(fd===PREOPEN)return ERR.NOTCAPABLE;detach(fd);return 0;},
    fd_renumber(from,to){
      if(from===PREOPEN||to<FIRST||to>LAST)return ERR.XDEV;
      if(from!==to){
        if(handles.has(to))detach(to);
        handles.set(to,handles.get(from));
        handles.delete(from);
      }
      return 0;
    },
    fd_sync(){return 0;},fd_datasync(){return 0;}
  };
  const wasi={...underlying};
  for(const [name,local] of Object.entries(ms0)){
    wasi[name]=(fd,...args)=>{
      if(handles.has(fd)){
        const bit=required[name];
        if(bit!==undefined&&!(handles.get(fd).rights&(1n<<BigInt(bit))))return ERR.NOTCAPABLE;
        return local(fd,...args);
      }
      if(name==="path_rename"&&handles.has(args[2]))return ERR.XDEV;
      return underlying[name]?.(fd,...args)??(fd===3&&name.startsWith("path_")?ERR.ROFS:ERR.BADF);
    };
  }
  return {
    imports:{wasi_snapshot_preview1:wasi,fc_preview_media:{
      fd_dup(fd,min,out){
        if(handles.has(fd))return install(handles.get(fd),min,out);
        return media.imports.fc_preview_media.fd_dup(fd,min,out);
      },
      path_rename_noreplace(fd, ptr, len, target, targetPtr, targetLen){
        if(!handles.has(fd)||!handles.has(target))return ERR.XDEV;
        const [error,existing]=resolve(target,targetPtr,targetLen,true);
        if(error)return error;
        if(existing)return ERR.EXIST;
        return wasi.path_rename(fd,ptr,len,target,targetPtr,targetLen);
      }
    }},
    bindMemory(m){memory=m;media.bindMemory(m);}, exportImage,
    get revision(){return revision;},
    get usage(){return {bytes:used,nodes:inodeCount};}
  };
}
if(typeof module==="object"&&module.exports)module.exports={create};
else scope.FCPSPMemoryStick={create};
})(typeof self==="object"?self:globalThis);
