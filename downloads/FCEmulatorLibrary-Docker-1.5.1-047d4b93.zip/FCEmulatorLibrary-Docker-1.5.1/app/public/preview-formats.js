// Shared by the authorized media route and the browser's game cards.
(function (root) {
  "use strict";

  const cartridge = { module: "nes-preview.wasm?v=2", maximumBytes: 32 * 1024 * 1024 };
  const disk = { ...cartridge, firmware: "fds" };
  const handheld = { module: "game-boy-preview.wasm?v=1", maximumBytes: 32 * 1024 * 1024 };
  const gameBoy = { ...handheld, systemID: 1 };
  const gameBoyColor = { ...handheld, systemID: 2 };
  const gameBoyAdvance = { ...handheld, systemID: 3, firmware: "gba", controls: "shoulders" };
  const pcEngine = { module: "pce-preview.wasm?v=1", maximumBytes: 16 * 1024 * 1024, systemID: 1,
    dynamicVideo: true, displayAspect: 4 / 3 };
  const turboGrafx = { ...pcEngine, systemID: 3 };
  const pcEngineCD = { ...pcEngine, module: "pcecd-preview.wasm?v=1", discMedia: "pcecd" };
  const playStation = { module: "ps1-preview.wasm?v=1", discMedia: "ps1",
    displayAspect: 4 / 3, controls: "playStation" };
  const saturn = { module: "saturn-preview.wasm?v=1", discMedia: "saturn",
    displayAspect: 4 / 3, controls: "saturn" };
  const saturnCart = new Map([["none", 0], ["backup", 1], ["extram-1m", 3], ["extram-4m", 4]]);
  const sega = { module: "sega-preview.wasm?v=1", maximumBytes: 16 * 1024 * 1024,
    dynamicVideo: true, displayAspect: 4 / 3, controls: "sega8" };
  const megaDrive = { ...sega, systemID: 1, controls: "megaDrive" };
  const megaCD = { ...sega, module: "megacd-preview.wasm?v=1", discMedia: "megacd", controls: "megaCD" };
  const sega32x = { ...sega, module: "sega32x-preview.wasm?v=1", systemID: 6,
    packageFirmware: true, adapterFirmware: true, controls: "megaDrive" };
  const masterSystem = { ...sega, systemID: 2 };
  const gameGear = { ...sega, systemID: 3, displayAspect: 10 / 9, controls: "gameGear" };
  const sg1000 = { ...sega, systemID: 4 };
  const snes = { module: "snes-preview.wasm?v=1", maximumBytes: 9 * 1024 * 1024,
    systemID: 1, packageFirmware: true, dynamicVideo: true, displayAspect: 4 / 3, controls: "snes" };
  const wonderSwan = { module: "wonderswan-preview.wasm?v=3", maximumBytes: 16 * 1024 * 1024,
    systemID: 1, controls: "wonderSwan" };
  const neoGeoPocket = { module: "neogeopocket-preview.wasm?v=1", maximumBytes: 8 * 1024 * 1024,
    systemID: 1, packageFirmware: true, controls: "neoGeoPocket" };
  const neoGeo = { module: "neogeo-preview.wasm?v=5", maximumBytes: 256 * 1024 * 1024,
    worker: "neogeo", controls: "neoGeo", displayAspect: 4 / 3 };
  const pgm = { module: "pgm-preview.wasm?v=1", maximumBytes: 256 * 1024 * 1024,
    worker: "pgm", controls: "pgm" };
  const cps = { module: "cps-preview.wasm?v=1", maximumBytes: 256 * 1024 * 1024, worker: "cps" };
  const cps1 = { ...cps, systemID: 1, controls: "cps" };
  const cps2 = { ...cps, systemID: 2, controls: "cps" };
  const cps3 = { module: "cps3-preview.wasm?v=1", maximumBytes: 128 * 1024 * 1024,
    worker: "cps3", controls: "cps", sourceOnly: true };
  const arcade = { module: "arcade-preview.wasm?v=2", maximumBytes: 256 * 1024 * 1024,
    worker: "arcade", controls: "arcade" };
  const nix = { module: "nix-preview.wasm?v=2", maximumBytes: 8 * 1024 * 1024,
    worker: "arcade", controls: "nix", driver: "pirates" };
  const rare = { module: "btoads-preview.wasm?v=1", maximumBytes: 16 * 1024 * 1024,
    worker: "arcade", controls: "rare", driver: "btoads", displayAspect: 4 / 3 };
  const psp = { module: "psp-preview.wasm?v=2", discMedia: "psp",
    worker: "psp", controls: "psp", displayAspect: 480 / 272 };
  const nintendo64 = { module: "nintendo64-preview.wasm?v=15", maximumBytes: 64 * 1024 * 1024,
    simdModule: "nintendo64-preview-simd.wasm?v=3", worker: "nintendo64", controls: "nintendo64" };
  const atari = { module: "atari-preview.wasm?v=2", maximumBytes: 512 * 1024,
    dynamicVideo: true, displayAspect: 4 / 3 };
  const atari2600 = { ...atari, systemID: 1, controls: "atari2600" };
  const atari5200 = { ...atari, systemID: 2, packageFirmware: true, controls: "atari5200" };
  const atari7800 = { ...atari, systemID: 3, packageFirmware: true, controls: "atari7800" };
  const formats = new Map([
    ["nes:nes", cartridge],
    ["nes:fds", disk], ["nes:qd", disk],
    ["fds:fds", disk], ["fds:qd", disk],
    ["gameBoy:gb", gameBoy], ["gameBoy:gbc", gameBoy],
    ["gameBoyColor:gb", gameBoyColor], ["gameBoyColor:gbc", gameBoyColor],
    ["gameBoyAdvance:gba", gameBoyAdvance],
    ["pcEngine:pce", pcEngine],
    ["pcEngineCD:fcpcecd", pcEngineCD],
    ["playStation:fcps1", playStation],
    ["megaCD:fcmcd", megaCD],
    ["saturn:fcsat", saturn],
    ["megaDrive:md", megaDrive], ["megaDrive:bin", megaDrive], ["megaDrive:gen", megaDrive],
    ["sega32x:32x", sega32x], ["sega32x:bin", sega32x], ["sega32x:md", sega32x], ["sega32x:gen", sega32x],
    ["masterSystem:sms", masterSystem], ["gameGear:gg", gameGear], ["sg1000:sg", sg1000],
    ["snes:sfc", snes], ["snes:smc", snes],
    ["wonderSwan:ws", wonderSwan], ["wonderSwan:wsc", wonderSwan],
    ["neoGeoPocket:ngp", neoGeoPocket], ["neoGeoPocket:ngc", neoGeoPocket],
    ["neoGeo:zip", neoGeo], ["neoGeo:7z", neoGeo],
    ["pgm:zip", pgm], ["pgm:7z", pgm],
    ["nintendo64:z64", nintendo64],
    ["psp:iso", psp], ["psp:cso", psp],
    ["atari2600:a26", atari2600], ["atari5200:a52", atari5200], ["atari7800:a78", atari7800]
  ]);

  function atariConfiguration(format, hardware) {
    const detail = hardware?.atari;
    if (!detail?.board || !Array.isArray(hardware.inputs)) return undefined;
    const standard = hardware.model?.endsWith("-pal") ? 2 : hardware.model?.endsWith("-secam") ? 3 : 1;
    let ports = hardware.inputs.reduce((mask, input) => mask | (1 << input.port), 0);
    let option = 0;
    let lightGunPort;
    if (format === atari2600) {
      for (const input of hardware.inputs) {
        if (input.kind === "atari2600-paddles") option |= 3 << (2 * input.port);
      }
    } else if (format === atari5200) {
      ports = hardware.model === "atari-5200-4-port" ? 4 : 2;
    } else {
      if (detail.interrupts || detail.expansion || (detail.saveDevice & 2)
          || hardware.inputs.some(input => !["atari7800-proline", "atari7800-light-gun"].includes(input.kind))) return undefined;
      for (const { port, kind } of hardware.inputs) {
        if (kind !== "atari7800-light-gun") continue;
        ports = (ports & ~(1 << port)) | (1 << (port + 2));
        lightGunPort ??= port;
      }
      option = (detail.audio || 0) | ((detail.saveDevice & 1) ? 0x100 : 0);
    }
    return { ...format, atari: { board: detail.board, standard, option, ports, lightGunPort } };
  }

  function get(system, filename, hardware, arcadePreviewFamily) {
    const extension = /\.([a-z0-9]+)$/i.exec(filename || "")?.[1].toLowerCase();
    if ((system === "arcade" || system === "neoGeo") && (extension === "zip" || extension === "7z")) {
      if (arcadePreviewFamily === "nix") return nix;
      if (arcadePreviewFamily === "rare") return rare;
    }
    if (system === "arcade" && arcadePreviewFamily === "cps3" && extension === "fcc3") return cps3;
    if (system === "arcade" && (extension === "zip" || extension === "7z")) {
      if (arcadePreviewFamily === "cps1") return cps1;
      if (arcadePreviewFamily === "cps2") return cps2;
      if (arcadePreviewFamily === "pgm") return pgm;
      if (arcadePreviewFamily === "neoGeo") return neoGeo;
      if (arcadePreviewFamily === "arcade") return arcade;
    }
    const format = formats.get(`${system}:${extension}`);
    if (format === playStation) {
      const inputs = Array.isArray(hardware?.inputs) ? hardware.inputs : [];
      const analogPorts = inputs.reduce((mask, { port, kind }) =>
        (port === 0 || port === 1) && kind === "ps1-dualshock-analog" ? mask | (1 << port) : mask, 0);
      return { ...format, analogPorts };
    }
    if (format === saturn) {
      const board = hardware?.saturn;
      if (!board || !Number.isInteger(board.areaCode) || board.areaCode < 1 || board.areaCode > 15 ||
          !saturnCart.has(board.cart) || !["japan", "overseas"].includes(board.bios)) return undefined;
      const discProfile = board.areaCode | (saturnCart.get(board.cart) << 4) | (board.cpuCache === "full" ? 0x80 : 0);
      return { ...format, discProfile, discBIOS: board.bios };
    }
    if (format === nintendo64 && !hardware?.nintendo64) return undefined;
    if (format?.module === atari.module) return atariConfiguration(format, hardware);
    if (format === pcEngine) {
      if (hardware?.model === "supergrafx") return undefined;
      if (hardware?.region === "usa" || hardware?.model === "turbografx-16") return turboGrafx;
    }
    return format;
  }

  if (typeof module === "object" && module.exports) module.exports = { get };
  else root.FCPreviewFormats = { get };
})(globalThis);
