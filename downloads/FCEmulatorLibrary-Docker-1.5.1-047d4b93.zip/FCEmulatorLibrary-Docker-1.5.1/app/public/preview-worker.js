"use strict";

importScripts("/assets/preview-wasi-media.js?v=5");

const filesystem = self.FCPreviewWasiMedia;
const discExtensions = { pcecd: "fcpcecd", ps1: "fcps1", megacd: "fcmcd", saturn: "fcsat" };
let wasm;
let arcadeControl;
let pspSession;
let n64Session;
let n64RgbaPixels = false;
let pspUtilityID;

function ready(refresh, count = 0, disc = 0) {
  if (!refresh) throw new Error("Emulator boot failed");
  const inputLayout = wasm.preview_input_layout?.();
  const rotation = displayRotation();
  const width = wasm.preview_display_aspect_num?.(), height = wasm.preview_display_aspect_den?.();
  const displayAspect = (width && height) ? (rotation % 180 ? height / width : width / height) : undefined;
  arcadeControl = wasm.preview_control_profile?.();
  self.postMessage({ kind: "ready", refresh, sampleRate: wasm.preview_audio_rate(), count, disc,
    hasDial: Boolean(wasm.preview_has_dial?.()), inputLayout, paddleConfiguration: inputLayout === 7,
    arcadeControl, rotation, displayAspect, mahjongWiredKeys: wasm.preview_mahjong_wired_keys?.(),
    lightGunReloads: Boolean(wasm.preview_light_gun_reloads?.()) });
}

function displayRotation() {
  return wasm.preview_display_rotation?.() ?? wasm.preview_rotation?.() ?? 0;
}

async function readPreviewROM(response) {
  const announced = Number(response.headers.get("Content-Length"));
  const stream = Number.isSafeInteger(announced) && announced > 0 && response.body &&
    !response.headers.has("Content-Encoding");
  const bytes = stream ? null : new Uint8Array(await response.arrayBuffer());
  const length = bytes?.byteLength ?? announced;
  const pointer = wasm.malloc(length);
  if (!pointer) throw new Error("Emulator memory allocation failed");
  let reader;
  try {
    const destination = new Uint8Array(wasm.memory.buffer, pointer, length);
    if (bytes) {
      destination.set(bytes);
    } else {
      reader = response.body.getReader();
      let received = 0;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        if (value.length > length - received) throw new Error("ROM exceeds Content-Length");
        destination.set(value, received);
        received += value.length;
      }
      if (received !== length) throw new Error("Incomplete ROM");
    }
    return [pointer, length];
  } catch (error) {
    wasm.free(pointer);
    await reader?.cancel().catch(() => {});
    throw error;
  } finally {
    reader?.releaseLock();
  }
}

async function describePSPFonts(headers) {
  const response = await fetch("/api/preview/psp-fonts", { headers, redirect: "error", cache: "no-store" });
  if (!response.ok) throw new Error("Could not read PSP font selection");
  const selected = await response.json();
  if (!selected || typeof selected !== "object" || Array.isArray(selected)) throw new Error("Invalid PSP font selection");
  return Promise.all(Object.entries(selected).map(async ([name, entry]) => {
    if (!/^(jpn0|ltn([0-9]|1[0-5])|kr0)\.pgf$/.test(name) || !entry ||
        !Number.isInteger(entry.bytes) || entry.bytes < 392 || entry.bytes > 8 * 1024 * 1024 ||
        !/^[a-f0-9]{64}$/.test(entry.sha256 || "")) throw new Error("Invalid PSP font declaration");
    const file = await filesystem.describeFile({ path: "/flash0/font/" + name,
      url: "/api/preview/psp-fonts/" + name, headers, identityHeader: "X-FC-PSP-FONT-SHA256" });
    if (file.size !== BigInt(entry.bytes) || file.sha256 !== entry.sha256) throw new Error("PSP font changed");
    return file;
  }));
}

async function initializePSP({ mediaPath, module, headers }) {
  importScripts("/assets/psp-ms0.js?v=2", "/assets/psp-ms0-storage.js", "/assets/preview-psp-utility.js");
  const extension = /\.([^.]+)$/.exec(mediaPath)?.[1].toLowerCase();
  if (!["iso", "cso"].includes(extension)) throw new Error("Unsupported PSP image");
  const guestPath = "/disc." + extension;
  const relative = mediaPath.split("/").map(encodeURIComponent).join("/");
  const [file, compiled, fonts, fallback] = await Promise.all([
    filesystem.describeFile({ path: guestPath, url: "/api/preview/disc-media/" + relative, headers,
      identityHeader: "X-FC-PSP-ROM-SHA256" }),
    WebAssembly.compileStreaming(fetch("/assets/" + module)),
    describePSPFonts(headers),
    filesystem.describeFile({ path: "/psp-app/fallback.pgf", url: "/api/preview/psp-fonts/fallback.pgf", headers })
  ]);
  const store = await FCPSPMemoryStickStorage.openStore();
  let stick, disc;
  try {
    const storage = await FCPSPMemoryStickStorage.attach({
      store, key: "psp_" + file.sha256,
      makeVolume: image => FCPSPMemoryStick.create(filesystem.create({
        files: [file, ...fonts, fallback], readRange: filesystem.workerReader({ headers }),
        directories: true, firstFd: 5
      }), { image })
    });
    const host = storage.volume;
    wasm = (await WebAssembly.instantiate(compiled, host.imports)).exports;
    host.bindMemory(wasm.memory);
    wasm._initialize();
    function string(text) {
      const bytes = new TextEncoder().encode(text + "\0");
      const pointer = wasm.malloc(bytes.length);
      if (!pointer) throw new Error("PSP boot allocation failed");
      new Uint8Array(wasm.memory.buffer, pointer, bytes.length).set(bytes);
      return pointer;
    }
    disc = string(guestPath);
    stick = string("/ms0");
    const refresh = wasm.preview_boot(disc, stick, fonts.length !== 0);
    if (!refresh) throw new Error("PSP boot failed");
    pspSession = { store, storage, pending: null, nextCheckpoint: performance.now() + 1500 };
    ready(refresh);
  } catch (error) {
    store.close();
    throw error;
  } finally {
    wasm?.free(disc || 0);
    wasm?.free(stick || 0);
  }
}

function checkpointPSP() {
  if (!pspSession) return Promise.resolve();
  const session = pspSession;
  if (session.pending) return session.pending;
  if (!session.storage.dirty) return Promise.resolve();
  session.nextCheckpoint = performance.now() + 1500;
  session.pending = session.storage.checkpoint().finally(() => { session.pending = null; });
  return session.pending;
}

async function closePSP() {
  const session = pspSession;
  if (!session || session.closing) return;
  session.closing = true;
  try {
    // A periodic checkpoint may have started before the last game frame.
    // Let it settle, then commit any revision it left dirty.
    await session.pending?.catch(() => {});
    await checkpointPSP();
    session.store.close();
    pspSession = null;
    wasm.preview_close();
    self.postMessage({ kind: "psp-closed" });
  } finally {
    session.closing = false;
  }
}

// A minimal module that splats an i32 into an i8x16 vector and discards it.
const n64SimdProbe = Uint8Array.of(
  0, 97, 115, 109, 1, 0, 0, 0, 1, 4, 1, 96, 0, 0, 3, 2, 1, 0,
  10, 9, 1, 7, 0, 65, 0, 253, 15, 26, 11
);

async function loadNintendo64Module(module, simdModule, imports) {
  if (simdModule && WebAssembly.validate(n64SimdProbe)) {
    const response = await fetch("/assets/" + simdModule);
    if (response.ok) return WebAssembly.instantiateStreaming(response, imports);
    if (response.status !== 404) throw new Error("Nintendo 64 SIMD module unavailable");
  }
  return WebAssembly.instantiateStreaming(fetch("/assets/" + module), imports);
}

async function initializeNintendo64({ url, module, simdModule, headers }) {
  const host = filesystem.create();
  const [rom, result] = await Promise.all([
    fetch(url, { headers, cache: "no-store", redirect: "error" }),
    loadNintendo64Module(module, simdModule, host.imports)
  ]);
  if (!rom.ok) throw new Error("Nintendo 64 ROM unavailable");
  const profile = JSON.parse(rom.headers.get("X-FC-N64-Configuration"));
  if (!Array.isArray(profile) || profile.length !== 5 || !profile.every(Number.isSafeInteger)) {
    throw new Error("Nintendo 64 cartridge configuration unavailable");
  }
  wasm = result.instance.exports;
  host.bindMemory(wasm.memory);
  wasm._initialize();
  n64RgbaPixels = Boolean(wasm.preview_use_rgba_pixels?.());
  const [pointer, length] = await readPreviewROM(rom);
  let refresh;
  try {
    refresh = wasm.preview_boot(pointer, length, ...profile);
  } finally {
    wasm.free(pointer);
  }
  if (!refresh) throw new Error("Nintendo 64 boot failed");
  if (Array.from({ length: 6 }, (_, slot) => wasm.preview_save_size(slot)).some(Boolean)) {
    importScripts("/assets/preview-n64-saves.js?v=1");
    const store = await self.FCPreviewN64Saves.openStore();
    try {
      // The core hashes the normalized cartridge it actually booted.
      const digest = new Uint8Array(wasm.memory.buffer, wasm.preview_rom_sha256(), 32);
      const key = Array.from(digest, byte => byte.toString(16).padStart(2, "0")).join("");
      const saves = await self.FCPreviewN64Saves.attach(wasm, key, store);
      n64Session = { saves, checkpointAt: performance.now() + 2000, pending: null, closing: false };
    } catch (error) {
      store.close();
      throw error;
    }
  }
  ready(refresh);
}

function checkpointNintendo64(session) {
  if (session.pending) return session.pending;
  session.checkpointAt = performance.now() + 2000;
  session.pending = session.saves.checkpoint().finally(() => { session.pending = null; });
  return session.pending;
}

async function closeNintendo64() {
  const session = n64Session;
  if (session?.closing) return;
  if (session) {
    session.closing = true;
    try {
      await session.pending?.catch(() => {});
      await checkpointNintendo64(session);
      session.saves.close();
    } finally {
      session.closing = false;
    }
    n64Session = null;
  }
  wasm.preview_close();
  self.postMessage({ kind: "n64-closed" });
}

async function initializeDisc({ mediaPath, module, headers, url, discKind, analogPorts, discProfile, discBIOS }) {
  const discPath = "/disc." + discExtensions[discKind];
  const relative = mediaPath.split("/").map(encodeURIComponent).join("/");
  const firmwareURL = discKind === "pcecd" ? "/api/preview/firmware/pcecd"
    : url.replace(/\/preview-rom$/, "/preview-firmware/system-firmware");
  const [disc, compiled, firmware] = await Promise.all([
    filesystem.describeFile({ path: discPath, url: "/api/preview/disc-media/" + relative, headers }),
    WebAssembly.compileStreaming(fetch("/assets/" + module)),
    fetch(firmwareURL, { headers, cache: "no-store", redirect: "error" })
  ]);
  if (!firmware.ok) {
    self.postMessage({ kind: "error", code: "firmware" });
    return;
  }
  const bytes = new Uint8Array(await firmware.arrayBuffer());
  const path = new TextEncoder().encode(discPath);
  const host = filesystem.create({ files: [disc], readRange: filesystem.workerReader({ headers }) });
  const instance = await WebAssembly.instantiate(compiled, host.imports);
  wasm = instance.exports;
  host.bindMemory(wasm.memory);
  wasm._initialize();
  const pathPointer = wasm.malloc(path.length);
  const biosPointer = wasm.malloc(bytes.length);
  let refresh;
  try {
    if (!pathPointer || !biosPointer) throw new Error("Emulator memory allocation failed");
    new Uint8Array(wasm.memory.buffer, pathPointer, path.length).set(path);
    new Uint8Array(wasm.memory.buffer, biosPointer, bytes.length).set(bytes);
    const region = firmware.headers.get(discKind === "pcecd" ? "X-FC-PCECD-Region" : "X-FC-Disc-Region");
    const area = { japan: 1, usa: 2, europe: 3 }[region];
    let profile;
    if (discKind === "saturn") {
      if (!discProfile || region !== discBIOS) throw new Error("Saturn BIOS slot mismatch");
      profile = discProfile;
    } else {
      if (!area || (discKind === "pcecd" && area === 3)) throw new Error("Disc BIOS region missing");
      profile = discKind === "pcecd" ? (area === 2 ? 3 : 1)
        : discKind === "megacd" ? 7 | (area << 4) : area;
    }
    refresh = wasm.preview_boot(profile, pathPointer, path.length, biosPointer, bytes.length, 0, analogPorts || 0);
  } finally {
    wasm.free(pathPointer);
    wasm.free(biosPointer);
  }
  if (refresh && discKind === "saturn") {
    const now = new Date();
    wasm.preview_set_rtc(now.getFullYear(), now.getMonth() + 1, now.getDate(),
      now.getHours(), now.getMinutes(), now.getSeconds());
  }
  ready(refresh, wasm.preview_disc_count(), wasm.preview_disc_index());
}

async function initializeCPS3({ url, module, headers }) {
  const options = { headers, cache: "no-store", redirect: "error" };
  const [rom, result, firmware] = await Promise.all([
    fetch(url, options),
    WebAssembly.instantiateStreaming(fetch("/assets/" + module), {}),
    fetch(url.replace(/\/preview-rom$/, "/preview-key"), options)
  ]);
  if (!rom.ok || !rom.body || !firmware.ok) throw new Error("CPS3 preview files unavailable");
  wasm = result.instance.exports;
  wasm._initialize();
  const key = new Uint8Array(await firmware.arrayBuffer());
  if (key.length !== 8) throw new Error("Invalid CPS3 key size");
  const header = new Uint8Array(44);
  let headerLength = 0;
  let pointer, capacity;
  const reader = rom.body.getReader();
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      let offset = 0;
      if (headerLength < header.length) {
        offset = Math.min(header.length - headerLength, value.length);
        header.set(value.subarray(0, offset), headerLength);
        headerLength += offset;
        if (headerLength < header.length) continue;
        const temporary = wasm.malloc(header.length + key.length);
        if (!temporary) throw new Error("Emulator memory allocation failed");
        try {
          const data = new Uint8Array(wasm.memory.buffer, temporary, header.length + key.length);
          data.set(header);
          data.set(key, header.length);
          if (!wasm.preview_boot_begin(temporary, header.length, temporary + header.length, key.length)) {
            throw new Error("Invalid CPS3 package header");
          }
        } finally {
          new Uint8Array(wasm.memory.buffer, temporary + header.length, key.length).fill(0);
          key.fill(0);
          wasm.free(temporary);
        }
        pointer = wasm.preview_boot_buffer();
        capacity = wasm.preview_boot_buffer_size();
        if (!pointer || capacity < 1) throw new Error("Emulator memory allocation failed");
      }
      while (offset < value.length) {
        const length = Math.min(value.length - offset, capacity);
        new Uint8Array(wasm.memory.buffer, pointer, length).set(value.subarray(offset, offset + length));
        if (!wasm.preview_boot_write(pointer, length)) throw new Error("Invalid CPS3 package data");
        offset += length;
      }
    }
    if (headerLength !== header.length) throw new Error("Incomplete CPS3 package");
    startArcade(wasm.preview_boot_finish());
  } catch (error) {
    await reader.cancel().catch(() => {});
    throw error;
  } finally {
    key.fill(0);
    reader.releaseLock();
  }
}

async function initializeArcade({ url, driver, module, headers, arcade, systemID }) {
  const options = { headers, cache: "no-store", redirect: "error" };
  const generic = arcade === "arcade";
  const host = generic ? filesystem.create() : null;
  const firmwareURL = arcade === "cps"
    ? (systemID === 2 ? url.replace(/\/preview-rom$/, "/preview-key") : null)
    : generic ? null : "/api/preview/firmware/" + arcade;
  const [rom, result, firmware] = await Promise.all([
    fetch(url, options),
    WebAssembly.instantiateStreaming(fetch("/assets/" + module), host?.imports || {}),
    firmwareURL && fetch(firmwareURL, options)
  ]);
  if (!rom.ok || (firmware && !firmware.ok)) throw new Error("Arcade preview files unavailable");
  const bios = await firmware?.arrayBuffer();
  wasm = result.instance.exports;
  host?.bindMemory(wasm.memory);
  wasm._initialize();
  const pointers = [];
  function reserve(length) {
    const pointer = wasm.malloc(length);
    if (!pointer) throw new Error("Emulator memory allocation failed");
    pointers.push(pointer);
    return pointer;
  }
  function allocate(bytes) {
    const pointer = reserve(bytes.byteLength);
    new Uint8Array(wasm.memory.buffer, pointer, bytes.byteLength).set(new Uint8Array(bytes));
    return pointer;
  }
  const encoder = new TextEncoder();
  const encode = value => value ? allocate(encoder.encode(value + "\0")) : 0;
  const now = new Date();
  let refresh;
  try {
    const [gamePtr, gameLength] = await readPreviewROM(rom);
    pointers.push(gamePtr);
    const biosLength = bios?.byteLength || 0;
    const biosPtr = biosLength ? allocate(bios) : 0;
    const driverPtr = encode(driver);
    if (arcade === "cps") {
      refresh = wasm.preview_boot(systemID, gamePtr, gameLength, driverPtr, biosPtr, biosLength);
    } else if (arcade === "pgm") {
      const bcd = value => (Math.floor(value / 10) << 4) | (value % 10);
      const calendar = Uint8Array.from([now.getSeconds(), now.getMinutes(), now.getHours(), now.getDate(),
        now.getMonth() + 1, now.getFullYear() % 100, now.getDay() + 1, (now.getDate() % 7) + 1], bcd);
      refresh = wasm.preview_boot(0, gamePtr, gameLength, biosPtr, biosLength, driverPtr, allocate(calendar));
    } else if (generic) {
      refresh = wasm.preview_boot(0, gamePtr, gameLength, 0, 0, driverPtr, 0);
    } else {
      refresh = wasm.preview_boot(Number(firmware.headers.get("X-FC-NeoGeo-Mode") === "aes"),
        gamePtr, gameLength, biosPtr, biosLength, driverPtr,
        encode(firmware.headers.get("X-FC-NeoGeo-BIOS-Option")));
    }
  } finally {
    for (const pointer of pointers) wasm.free(pointer);
  }
  if (refresh && (generic || arcade === "neogeo" || (arcade === "cps" && systemID === 1))) {
    wasm.preview_set_rtc?.(now.getFullYear() % 100, now.getMonth() + 1, now.getDate(),
      now.getDay() + 1, now.getHours(), now.getMinutes(), now.getSeconds());
  }
  startArcade(refresh);
}

function startArcade(refresh) {
  if (!refresh) throw new Error("Emulator boot failed");
  // Let cold CPU and audio paths initialize before starting the playback clock.
  for (let i = 0; i < 16; i++) {
    if (wasm.preview_step(0) < 0) throw new Error("Emulator frame failed");
  }
  ready(refresh);
}

function runFrames({ frames, buttons, panel, analog }) {
  if (!Number.isInteger(frames) || frames < 1 || frames > 3) throw new Error("Invalid emulator frame budget");
  const chunks = [];
  let length = 0;
  let duration = 0;
  const n64Tick = wasm.preview_master_tick?.();
  if (n64Tick !== undefined) {
    const axis = (positive, negative) => 80 * (Number(Boolean(buttons & positive)) - Number(Boolean(buttons & negative)));
    const x = axis(0x10000, 0x20000), y = axis(0x40000, 0x80000);
    buttons &= 0xffff;
    if (!wasm.preview_set_controller(0, buttons, x, y)) throw new Error("Nintendo 64 controller input rejected");
  }
  function pspAxis(index, positive, negative) {
    const stick = analog?.[index];
    if (Number.isInteger(stick) && stick >= 0 && stick <= 255 && stick !== 128) return stick;
    return 128 + 100 * (Number(Boolean(buttons & positive)) - Number(Boolean(buttons & negative)));
  }
  const dialDirection = Number(Boolean(buttons & 0x1000)) - Number(Boolean(buttons & 0x2000));
  const dialDelta = dialDirection ? dialDirection * (wasm.preview_dial_key_delta?.() || 0) : 0;
  wasm.preview_set_system_buttons?.(buttons & 0x8000 ? 2 : 0);
  const mahjong = arcadeControl === 9 ? buttons >>> 12 : 0;
  if (arcadeControl === 9) buttons &= 0xfff;
  for (let i = 0; i < frames; i++) {
    if (arcadeControl === 9) wasm.preview_set_panel(arcadeControl, mahjong, 0, 0, 0, 0);
    if (panel && (i === 0 || arcadeControl === 7)) {
      wasm.preview_set_panel?.(arcadeControl, panel[0], panel[1], 0, 0, 0);
    }
    const samples = pspSession ? wasm.preview_step(buttons & 0xffff, pspAxis(0, 0x10000, 0x20000), pspAxis(1, 0x80000, 0x40000))
      : wasm.preview_step_controls
      ? wasm.preview_step_controls(buttons & 0xfff, buttons & 0x4000 ? 0x800 : 0, 0, 0, dialDelta, 0)
      : wasm.preview_step(buttons);
    if (samples < 0) throw new Error("Emulator frame failed");
    const chunk = new Float32Array(wasm.memory.buffer, wasm.preview_audio(), samples * 2).slice();
    chunks.push(chunk);
    length += chunk.length;
    if (wasm.preview_frame_duration_us) duration += wasm.preview_frame_duration_us() / 1000;
  }
  const audio = new Float32Array(length);
  let offset = 0;
  for (const chunk of chunks) {
    audio.set(chunk, offset);
    offset += chunk.length;
  }
  const width = wasm.preview_width(), height = wasm.preview_height();
  let displayAspect;
  if (n64Tick !== undefined) {
    // The N64 core uses 187.5 MHz master ticks, including incomplete fields.
    duration = Number(wasm.preview_master_tick() - n64Tick) / 187_500;
    displayAspect = wasm.preview_aspect_numerator() / wasm.preview_aspect_denominator();
  }
  const source = new Uint32Array(wasm.memory.buffer, wasm.preview_pixels(), width * height);
  const rotation = displayRotation();
  const turned = rotation === 90 || rotation === 270;
  const pixels = turned ? new Uint32Array(source.length) : source.slice();
  if (turned) {
    for (let row = 0; row < width; row++) {
      for (let col = 0; col < height; col++) {
        pixels[row * height + col] = rotation === 90
          ? source[(height - 1 - col) * width + row] : source[col * width + width - 1 - row];
      }
    }
  } else if (rotation === 180) {
    pixels.reverse();
  }
  self.postMessage({ kind: "frame", width: turned ? height : width, height: turned ? width : height,
    pixels, audio, duration, frames, displayAspect, rgbaPixels: n64Tick !== undefined && n64RgbaPixels,
    disc: wasm.preview_disc_index?.() }, [pixels.buffer, audio.buffer]);
}

self.onmessage = async ({ data }) => {
  try {
    if (data.kind === "init") {
      if (data.arcade === "psp") await initializePSP(data);
      else if (data.mediaPath) await initializeDisc(data);
      else if (data.arcade === "cps3") await initializeCPS3(data);
      else if (data.arcade === "nintendo64") await initializeNintendo64(data);
      else await initializeArcade(data);
    }
    else if (data.kind === "step") {
      if (pspSession?.closing || n64Session?.closing) return;
      runFrames(data);
      if (pspSession) {
        const request = FCPreviewPSPUtility.readRequest(wasm);
        const id = request?.canAnswer ? request.id : undefined;
        if (id !== pspUtilityID) {
          pspUtilityID = id;
          self.postMessage({ kind: "psp-utility", request: id ? request : null });
        }
      }
      if (pspSession && performance.now() >= pspSession.nextCheckpoint && !pspSession.pending && pspSession.storage.dirty) {
        checkpointPSP().catch(() => self.postMessage({ kind: "psp-storage-error" }));
      }
      if (n64Session && !n64Session.pending && performance.now() >= n64Session.checkpointAt) {
        checkpointNintendo64(n64Session).catch(() => self.postMessage({ kind: "n64-storage-error" }));
      }
    }
    else if (data.kind === "psp-utility-answer" && pspSession) {
      if (!pspUtilityID || data.id !== pspUtilityID) return;
      const result = typeof data.text === "string"
        ? FCPreviewPSPUtility.answerText(wasm, data.id, data.text)
        : wasm.preview_utility_answer(data.id, data.choice);
      if (result) self.postMessage({kind:"psp-utility-error", id:data.id});
    }
    else if (data.kind === "psp-checkpoint") {
      await checkpointPSP().catch(() => self.postMessage({ kind: "psp-storage-error" }));
    }
    else if (data.kind === "psp-close") {
      await closePSP().catch(() => self.postMessage({ kind: "psp-close-error" }));
    }
    else if (data.kind === "n64-checkpoint" && n64Session && !n64Session.closing) {
      const session = n64Session;
      await session.pending?.catch(() => {});
      if (n64Session === session && !session.closing) {
        await checkpointNintendo64(session).catch(() => self.postMessage({ kind: "n64-storage-error" }));
      }
    }
    else if (data.kind === "n64-close") {
      await closeNintendo64().catch(error => self.postMessage({ kind: "n64-close-error", conflict: error.name === "SaveConflictError" }));
    }
    else if (data.kind === "disc") {
      const changed = Boolean(wasm.preview_change_disc(data.index));
      self.postMessage({ kind: "disc", disc: wasm.preview_disc_index(), changed });
    }
  } catch {
    self.postMessage({ kind: "error", code: data.kind === "init" ? "boot" : "runtime" });
  }
};
