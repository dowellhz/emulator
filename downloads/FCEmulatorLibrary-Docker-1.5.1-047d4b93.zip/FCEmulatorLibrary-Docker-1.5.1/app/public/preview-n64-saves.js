"use strict";

(function (scope) {
  const database = "fc-n64-preview-saves";
  const collection = "cartridges";

  function openStore(indexedDB = scope.indexedDB) {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(database, 1);
      let blocked = false;
      request.onupgradeneeded = () => request.result.createObjectStore(collection);
      request.onerror = () => reject(request.error);
      request.onblocked = () => {
        blocked = true;
        reject(new Error("Nintendo 64 save storage is blocked"));
      };
      request.onsuccess = () => {
        const db = request.result;
        if (blocked) { db.close(); return; }
        db.onversionchange = () => db.close();
        resolve({
          load(key) {
            return new Promise((done, failed) => {
              const tx = db.transaction(collection, "readonly");
              const read = tx.objectStore(collection).get(key);
              tx.onabort = () => failed(tx.error);
              tx.oncomplete = () => done(read.result ?? { revision: 0, slots: {} });
            });
          },
          save(key, revision, slots) {
            return new Promise((done, failed) => {
              const tx = db.transaction(collection, "readwrite");
              const records = tx.objectStore(collection);
              const read = records.get(key);
              let error;
              read.onsuccess = () => {
                if ((read.result?.revision ?? 0) !== revision || !Number.isSafeInteger(revision + 1)) {
                  error = new Error("Nintendo 64 save changed in another session");
                  error.name = "SaveConflictError";
                  tx.abort();
                  return;
                }
                try {
                  records.put({ revision: revision + 1, slots }, key);
                } catch (cause) {
                  error = cause;
                  tx.abort();
                }
              };
              tx.onabort = () => failed(error || tx.error);
              tx.oncomplete = () => done(revision + 1);
            });
          },
          close() { db.close(); }
        });
      };
    });
  }

  async function attach(wasm, key, store) {
    if (!/^[a-f0-9]{64}$/.test(key)) throw new TypeError("Invalid Nintendo 64 ROM identity");
    const devices = Array.from({ length: 6 }, (_, slot) => ({ slot, size: wasm.preview_save_size(slot) }))
      .filter(({ size }) => size);
    if (!devices.length) return { checkpoint() {}, close() { store.close(); } };
    const record = await store.load(key);
    if (!Number.isSafeInteger(record.revision) || record.revision < 0 ||
        !record.slots || typeof record.slots !== "object" || Array.isArray(record.slots)) {
      throw new Error("Invalid Nintendo 64 save record");
    }
    let revision = record.revision, slots = record.slots;
    const capacity = Math.max(...devices.map(({ size }) => size));
    const pointer = wasm.malloc(capacity);
    if (!pointer) throw new Error("Nintendo 64 save buffer allocation failed");
    let tail = Promise.resolve();
    // RTC time can move without a guest RTC write (or a generation change).
    const currentGeneration = slot => slot === 5
      ? `${wasm.preview_save_generation(slot)}:${wasm.preview_master_tick()}`
      : wasm.preview_save_generation(slot);

    try {
      for (const device of devices) {
        const bytes = slots[device.slot];
        if (bytes === undefined) continue;
        if (!(bytes instanceof Uint8Array) || bytes.length !== device.size) throw new Error("Nintendo 64 save image size mismatch");
        new Uint8Array(wasm.memory.buffer, pointer, bytes.length).set(bytes);
        if (!wasm.preview_load_save(device.slot, pointer, bytes.length)) throw new Error("Nintendo 64 save image rejected");
      }
      for (const device of devices) device.generation = currentGeneration(device.slot);
    } catch (error) {
      wasm.free(pointer);
      throw error;
    }

    return {
      checkpoint() {
        const next = tail.catch(() => {}).then(async () => {
          const changed = devices.map(device => ({
            device, generation: currentGeneration(device.slot)
          })).filter(({ device, generation }) => device.generation !== generation);
          if (!changed.length) return;

          // Save every dirty device in the same transaction. Keep data for
          // disconnected accessories so reconnecting them can restore it.
          const images = { ...slots };
          let needsWrite = false;
          for (const { device: { slot, size } } of changed) {
            if (wasm.preview_export_save(slot, pointer, size) !== size) throw new Error("Nintendo 64 save export failed");
            const bytes = new Uint8Array(wasm.memory.buffer, pointer, size);
            const previous = slots[slot];
            if (previous && bytes.every((byte, index) => byte === previous[index])) continue;
            images[slot] = bytes.slice();
            needsWrite = true;
          }
          if (needsWrite) {
            revision = await store.save(key, revision, images);
            slots = images;
          }
          for (const { device, generation } of changed) device.generation = generation;
        });
        tail = next;
        return next;
      },
      close() {
        wasm.free(pointer);
        store.close();
      }
    };
  }

  const saves = { openStore, attach };
  if (typeof module !== "undefined" && module.exports) module.exports = saves;
  else scope.FCPreviewN64Saves = saves;
})(globalThis);
