// Atari upload declarations: when POST /api/upload answers with
// `atariDeclaration` (the image cannot say its TV standard, board or 2600
// controllers), the page asks the uploader and retries with the chosen
// atariModel / atariBoard / atariInputs query. Pure functions only, so the
// same file runs in the browser (as window.FCAtariDeclaration) and under
// `node --test` (as a CommonJS module).
//
// Nothing here picks a value for the uploader. A region tag in the file name
// ("(USA)", "(Europe)") only preselects a standard as a hint; the page still
// needs the uploader to confirm. atariInputs starts at the server's own
// default (two joysticks, user decision 2026-10-16), shown as such.
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.FCAtariDeclaration = api;
})(typeof self !== "undefined" ? self : this, () => {
  const SYSTEM_LABELS = { atari2600: "Atari 2600", atari5200: "Atari 5200", atari7800: "Atari 7800" };
  const MODEL_LABELS = {
    "atari-2600-ntsc": "NTSC（北美、日本）", "atari-2600-pal": "PAL（欧洲、澳洲）", "atari-2600-secam": "SECAM（法国、东欧）",
    "atari-5200-4-port": "四手柄口机型", "atari-5200-2-port": "双手柄口机型",
    "atari-7800-ntsc": "NTSC（北美）", "atari-7800-pal": "PAL（欧洲）"
  };
  const INPUT_LABELS = { "atari2600-joystick": "摇杆", "atari2600-paddles": "Paddle 旋钮" };
  const PARAMETER_LABELS = { atariModel: "电视制式", atariBoard: "卡带 board", atariInputs: "输入设备" };

  // Whether an upload's name could be an Atari cartridge the server may ask about.
  function isAtariCandidateName(name) { return /\.(?:a26|a52|a78|bin|zip)$/i.test(String(name || "")); }

  // A standard suggested by a No-Intro style region tag, or null. Only tags
  // that name one standard unambiguously count; "(France)" (PAL or SECAM),
  // "(World)" and anything else give no hint.
  function regionHint(fileName, choices) {
    const tags = [...String(fileName || "").matchAll(/\(([^()]*)\)/g)]
      .flatMap(match => match[1].split(",").map(tag => tag.trim()));
    const find = list => tags.find(tag => list.includes(tag.toLowerCase())) || null;
    let standard = null, tag = null;
    const ntsc = ["usa", "us", "ntsc", "japan", "canada"], pal = ["europe", "pal", "uk", "germany", "australia", "spain", "italy"];
    if (find(["secam"])) { standard = "secam"; tag = find(["secam"]); }
    else if (find(ntsc) && !find(pal)) { standard = "ntsc"; tag = find(ntsc); }
    else if (find(pal) && !find(ntsc)) { standard = "pal"; tag = find(pal); }
    if (!standard) return null;
    const value = (choices || []).find(choice => choice.endsWith(`-${standard}`));
    return value ? { value, tag } : null;
  }

  // The controls the dialog draws, one per needed query parameter.
  function declarationFields(declaration, fileName) {
    const needs = Array.isArray(declaration?.needs) ? declaration.needs : [];
    return needs.map(need => {
      if (need.parameter === "atariInputs") {
        const defaults = String(need.default || "").split(",");
        const ports = Math.max(1, Number(need.ports) || 2);
        return { parameter: need.parameter, label: PARAMETER_LABELS.atariInputs, kind: "ports", required: !need.optional,
          ports: Array.from({ length: ports }, (_, port) => ({
            label: `手柄口 ${port + 1}`,
            options: (need.kinds || []).map(value => ({ value, label: INPUT_LABELS[value] || value })),
            preselected: (need.kinds || []).includes(defaults[port]) ? defaults[port] : ""
          })),
          hint: need.default ? "已按服务端默认（双摇杆）填好；Paddle 游戏请改为 Paddle 旋钮。" : null };
      }
      const choices = Array.isArray(need.choices) ? need.choices : [];
      const hint = need.parameter === "atariModel" ? regionHint(fileName, choices) : null;
      return { parameter: need.parameter, label: PARAMETER_LABELS[need.parameter] || need.parameter, kind: "select",
        required: !need.optional,
        options: choices.map(value => ({ value, label: need.parameter === "atariModel" ? `${MODEL_LABELS[value] || value} · ${value}` : value })),
        preselected: hint ? hint.value : "",
        hint: hint ? `按文件名中的 (${hint.tag}) 预选，仅供参考，请确认与卡带实物一致。`
          : need.parameter === "atariBoard" ? "候选由服务器按文件大小列出，需按卡带实际 board 选择。" : null };
    });
  }

  // The query string for the retry, or an error naming what is still missing.
  // `selections` maps a parameter to a value (or, for atariInputs, an array of per-port kinds).
  function declarationQuery(declaration, selections) {
    const params = new URLSearchParams();
    const missing = [];
    for (const need of declaration?.needs || []) {
      const chosen = selections?.[need.parameter];
      if (need.parameter === "atariInputs") {
        const ports = Array.isArray(chosen) ? chosen : [];
        const count = Math.max(1, Number(need.ports) || 2);
        const valid = ports.length === count && ports.every(kind => (need.kinds || []).includes(kind));
        if (valid) params.set(need.parameter, ports.join(","));
        else if (!need.optional) missing.push(PARAMETER_LABELS.atariInputs);
        continue;
      }
      if ((need.choices || []).includes(chosen)) params.set(need.parameter, chosen);
      else if (!need.optional) missing.push(PARAMETER_LABELS[need.parameter] || need.parameter);
    }
    return missing.length ? { missing, query: null } : { missing: [], query: params.toString() };
  }

  function systemLabel(system) { return SYSTEM_LABELS[system] || system || "Atari"; }

  return { MODEL_LABELS, INPUT_LABELS, isAtariCandidateName, regionHint, declarationFields, declarationQuery, systemLabel };
});
